/**
 * Created with AppCode.
 * User: WanThirty
 * Date: 15/7/6
 * Time: 下午3:17
 * To change this template use File | Settings | File Templates.
 */

var UIHPBar = vee.Class.extend({

	nodeHPContainer : null,

	_hpBarWidth : 44,
	_hp : -1,

	onCreate : function () {

	},

	setHP : function (hpNum) {
		var heartFileName = res.ga_icon_heart_png;
		if (game.Data.checkIs61()) {
			heartFileName = res.ga_ui_Childheart_png;
		}
		this.nodeHPContainer.removeAllChildren();
		for (var i = 0; i < hpNum; ++i) {
			var spHP = new cc.Sprite(heartFileName);
			spHP.setPositionX(i*56);
			this.nodeHPContainer.addChild(spHP);
		}
		if (this._hp > hpNum) {
			var efxNode = EfxCostLife.create(cc.p(cc.p(56*(this._hp-1), 0)));
			this.rootNode.addChild(efxNode, 2);
		}
		this._hp = hpNum;
	}
});

UIHPBar.create = function (hp) {
	var node = cc.BuilderReader.load(res.UIHPBar_ccbi);
	node.controller.setHP(hp);
	return node;
};