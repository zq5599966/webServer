/**
 * Created by john on 2016/11/25.
 */
var app = app = app || {};

app.configManager = {

    AppName : "SuperCat",
    AppAlias : "supercat",
    AppURL : null,
    RateURL : null,

    PromoURL : "http://www.veewo.com",
    PromoChannel : "promo",
    PromoBannerEnable : true,
    PromoFullScreenEnable : true,

    //plugin class name
    GameCenterPluginName : "SocialGameCenter",
    AnalyticsPluginName : "AnalyticsUmengGame",
    AnalyticsPluginADTrackName : "AnalyticsMAT",
    IAPPluginName : "IAPManager",

    //AD Plugin class name 需要重新整理
    AdBannerPluginName : "AdsAdapter",
    AdInterstialPluginName : "AdsAdapter",

    AdVideoPluginName : "AdsVungle",    //Deprecated

    IsBannerEnabled : true,
    IsInterestialEnabled : true,

    AdPosConfig : [],                   //Deprecated
    AdPosEntityConfig : [],             //Deprecated? what's the fuck!

    init : function () {
        switch (game.Data.version.curVersion){
            case VERSION.IOS_GENUINE:
                this.initConfigByTable(appConfig_IOS);
                break;
            case VERSION.IOS_FREE:
                this.initConfigByTable(appConfig_IOS_Free);
                break;
            case VERSION.IOS_FREE_CN:
                this.initConfigByTable(appConfig_IOS_Free_CN);
                break;
            case VERSION.ANDROID_GOOGLE_FREE:
                this.initConfigByTable(appConfig_Android_free);
                break;
        }
    },

    initConfigByTable : function (config) {
        // for(var i in config){
        //     app.configManager[i] = config[i];
        // }
        app.Config = config;
    }
}