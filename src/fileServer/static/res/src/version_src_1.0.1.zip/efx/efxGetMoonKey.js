/**
 * Created with AppCode.
 * User: WanThirty
 * Date: 16/3/31
 * Time: 下午2:30
 * To change this template use File | Settings | File Templates.
 */

var EfxGetMoonKey = vee.Class.extend({
	ccbInit : function () {
		this.playAnimate("open", function () {
			this.playAnimate("hide", function () {
				this.rootNode.removeFromParent();
			}.bind(this));
		}.bind(this));
	}
});

EfxGetMoonKey.show = function () {
	var node = cc.BuilderReader.load(res.efx_PowerMoonBar_ccbi);
	game.Data.oLyGame.rootNode.addChild(node, 8);
	var nodeT = game.Data.oLyGame.nodeT;
	node.setPosition( vee.Utils.pSub(nodeT.getPosition(), cc.p(0, 130)) );
	node.controller.ccbInit();
};