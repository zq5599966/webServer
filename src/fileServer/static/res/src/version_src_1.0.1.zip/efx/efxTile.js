/**
 * Created with AppCode.
 * User: Yop Chan
 * Date: 14-12-1
 * Time: 下午3:48
 * To change this template use File | Settings | File Templates.
 */

/**
 * @require "map.js"
 * @require "flow.js"
 */

var EfxTile = vee.Class.extend({
	/** @type {cc.Point} */
	_grid : null,

	/** @type {vee.Map} */
	_map : null,

	_color : null,

	initGrid : function(grid, animate) {
		this._grid = grid;
		this.rootNode.setColor(this.getColor());
		this.setGrid(grid, animate);
	},

	getGrid : function(){ return this._grid; },

	getMap : function(){ return this._map; },

	setGrid : function(grid, animate) {
		/** @type {vee.Map} */
		var map = this._map;
		if (this._grid) map.removeObject(this._grid);
		map.setObject(this, grid);
		this._grid = grid;
		var pos = map.grid2PositionInMap(grid);
		if (animate != undefined) {
			var delay = cc.delayTime(animate);
			var move = cc.moveTo(0.2, pos);
			this.rootNode.stopAllActions();
			this.rootNode.runAction(cc.sequence(delay, move));
		}
		else this.rootNode.setPosition(pos);
	},

	isOdd : function() {
		return (this._grid.x + this._grid.y)%2 !=0;
	},

	setColor : function(c) {
		this._color = c;
		this.rootNode.setColor(c);
	},

	getColor : function() {
		return this._color;
	},

	cachedAction : null,
	runTransition : function(delay, action) {
		if (this.cachedAction) this.cachedAction.release();
		this.cachedAction = action;
		action.retain();
		vee.Utils.scheduleOnceForTarget(this.rootNode, function(data){
			if (this.cachedAction) {
				this.rootNode.stopAllActions();
				this.rootNode.runAction(this.cachedAction);
				this.cachedAction.release();
				this.cachedAction = null;
			}
		}.bind(this), delay, action);
	},

	onExit : function() {
		vee.Utils.unscheduleAllCallbacksForTarget(this.rootNode);
		if (this.cachedAction) this.cachedAction.release();
		this.cachedAction = null;
	}
});

EfxTile.create = function(map, fileNameOrTexture, rect) {
	if (!rect) {
		var sp = cc.Sprite.createWithSpriteFrameName(fileNameOrTexture);
	} else {
		var sp = cc.Sprite.createWithTexture(fileNameOrTexture, rect);
	}
	var ctl = new EfxTile();
	ctl._map = map;
	sp.controller = ctl;
	ctl.rootNode = sp;
	return ctl;
}



var EfxTileMap = vee.Class.extend({
	/** @type {cc.SpriteBatchNode} */
	lyContent : null,

	_map : null,

	onCreate : function() {
		cc.log('creating efxTileMap');
		var contentSize = this.lyContent.getContentSize();
		var sampleTile = this.lyContent.getChildren()[0];
		sampleTile.setVisible(false);
		var tileSize = sampleTile.getContentSize();
		tileSize.width--;
		tileSize.height--;
		var mapSize = cc.size(Math.ceil(contentSize.width/tileSize.width), Math.ceil(contentSize.height/tileSize.height));
		this.init(tileSize, mapSize, sampleTile.getTexture(), sampleTile.getTextureRect());
	},

	init : function( tileSize, mapSize, fileNameOrTexture, rect) {
		this._map = vee.Map.create(mapSize, tileSize);
		this._map.forEachGrid(function (grid) {
			var tile = EfxTile.create(this._map, fileNameOrTexture, rect);
			this.lyContent.addChild(tile.rootNode);
			tile.setGrid(grid);
		}.bind(this));
	},

	playEffect : function(grid, color, delayFunc, transFunc, callback) {
		var arrFlow = [];
		this._map.forEachObjects(function(obj){
			var data = EfxTileMap.TileEffect.Data.create(
				obj,
				color,
				delayFunc,
				transFunc
			);
			arrFlow.push(Flow.do(EfxTileMap.TileEffect, data));
		});

		Flow.doAll(arrFlow).onResult(callback).go(grid);
	},

	forEachTile : function(callback) {
		this._map.forEachObjects(callback);
	}
});

EfxTileMap.create = function (batchNodeImageName, tileImageName, tileSize, mapSize) {
	var tileEffect = new LyEfxTileMap();
	var contentSize = cc.size(tileSize.width * mapSize.width, tileSize.height * mapSize.height);
	tileEffect.rootNode = cc.Node.creat();
	tileEffect.rootNode.setContentSize(contentSize);
	tileEffect.lyContent = cc.SpriteBatchNode.create(batchNodeImageName);
	tileEffect.lyContent.setContentSize(contentSize);
	tileEffect.rootNode.addChild(tileEffect.lyContent);

	tileEffect.init(tileSize, mapSize, tileImageName);
};


EfxTileMap.TileEffect = Flow.extend({
	name : "EfxTileEffect",
	/** @type {Flow.TileEffect.Data} */
	data : null,

	onAction : function(input) {
		var ele = this.data.tile;
		var sp = ele.rootNode;
		var delay = this.data.delayFunc(ele, input);
		if (delay < 0) {
			this.done(input);
			return;
		}

		var seq;
		var trans = this.data.transFunc;
		if (_.isArray(trans)) {
			var arr = [];
			for (var i in trans) {
				arr.push(trans[i](this.data, input));
			}
			seq = cc.spawn(arr);
		} else seq = trans(this.data, input);
		var callback = cc.callFunc(this.done.bind(this));
		ele.runTransition(delay, cc.sequence(seq, callback));
	}
});

EfxTileMap.TileEffect.Data = {
	/** @type {EfxTile} */
	tile : null,
	/** @type {cc.Color} */
	color : null,
	delayFunc : null,
	transFunc : null,

	create : function(ele, color, delayFunc, transFunc) {
		return {
			tile:ele,
			color:color,
			delayFunc:delayFunc,
			transFunc:transFunc
		}
	}
};



EfxTile.delayZero = function(){ return 0; }

EfxTile.delayLB = function(tile, input){
	return 0.15 + EfxTile.delayTwirl(tile.getGrid(), cc.p(0, game.mapSize.height));
}

EfxTile.delayPoint = function(tile, input){
	var offset = vee.Utils.pSub(tile.getGrid(), input);
	var distance = offset.x*offset.x + offset.y*offset.y;
	return distance*0.02;
}

EfxTile.delayPointReverse = function(tile, input) {
	return 2.2-EfxTile.delayPoint(tile.getGrid(), input);
}

EfxTile.delayRise = function(tile, input) {
	var distance = tile.getMap.mapSize.height - grid.y;
	return distance*0.07;
}

EfxTile.delayRiseOdd = function(tile, input) {
	var grid = tile.getGrid();
	return EfxTile.delayRise(grid, input) + (grid.y%2 == 0 ? 0 : 0.1) + (grid.x%2 == 0 ? 0.1 : 0);
}

EfxTile.delayFall = function(tile, input) {
	return tile.getGrid().y * 0.06;
}

EfxTile.delayRandom = function(tile, input) {
	var map = tile.getMap();
	return vee.Utils.randomInt(0, 5*(map.mapSize.height + map.mapSize.width))/100;
}

EfxTile.delayRandomOrigin = function(tile, input) {
	var map = tile.getMap();
	return vee.Utils.randomInt(-200, 5*(map.mapSize.height + map.mapSize.width))/10;
}

EfxTile.delayFan = function(tile, input) {
	var grid = tile.getGrid();
	var distance = vee.Utils.angleOfLine(grid, input);
	var distance2 = Math.abs(grid.x - input.x) + Math.abs(grid.y - input.y);
	distance += distance2*4;
	distance = distance%120;
	return distance/280 + distance2*0.08;
}

EfxTile.delayTwirl = function(tile, input) {
	var grid = tile.getGrid();
	var distance = vee.Utils.angleOfLine(grid, input);
	var distance2 = Math.abs(grid.x - input.x) + Math.abs(grid.y - input.y);
	distance += 120 - distance2*4;
	distance = distance%120;
	var delay = 1 - (distance/280 + distance2*0.08);
	return (delay > 0 ? delay : 0);
}






EfxTile.transScale = function(data, input) {
	var zoomIn = cc.scaleTo(0.2, 0.75);
	var zoomOut = cc.scaleTo(0.4, 1.05);
	var zoomBack = cc.scaleTo(0.2, 1.0);
	return cc.sequence(zoomIn, zoomOut, zoomBack);
}


EfxTile.transScaleOdd = function(data, input) {
	var isOdd = data.tile.isOdd();
	if (isOdd) return EfxTile.transScale(data, input);
	else {
		var zoomIn = cc.scaleTo(0.4, 0.9);
		var zoomOut = cc.scaleTo(0.2, 1.1);
		var zoomBack = cc.scaleTo(0.2, 1.0);
		return cc.sequence(zoomOut, zoomIn, zoomBack);
	}
}

EfxTile.transTint = function(data, input) {
	var color = data.color;
	var tintTo = cc.tintTo(0.3, color.r, color.g, color.b);
	var c = data.tile.getColor();
	var tintBack = cc.tintTo(0.5, c.r, c.g, c.b);
	return cc.sequence(tintTo, tintBack);
}

EfxTile.transTintBack = function(data, input) {
	var c = data.tile.getColor();
	var tintBack = cc.tintTo(0.5, c.r, c.g, c.b);
	return tintBack;
}

EfxTile.transFadeOrigin = function(data, input) {
	var color = data.tile.getColor();
	var fadeTo = cc.fadeTo(0.3, color.a);
	var fadeBack = cc.fadeTo(0.5, 0);
	return cc.sequence(fadeTo, fadeBack);
}

EfxTile.transPower = function(data, input) {
	var zoomOut = cc.scaleTo(0.2, 0.3);
	var delay = cc.delayTime(0.1);
	var zoomIn = cc.scaleTo(0.1, 1.1);
	var zoomBack = cc.scaleTo(0.1, 1.0);
	return cc.sequence(zoomOut, delay, zoomIn, zoomBack);
}

EfxTile.transPowerTint = function(data, input) {
	var color = data.color;
	var delay = cc.delayTime(0.3);
	var tintTo = cc.tintTo(0.2, color.r, color.g, color.b);
	return cc.sequence(delay,tintTo);
}
