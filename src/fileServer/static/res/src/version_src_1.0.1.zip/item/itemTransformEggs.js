/**
 * Created with AppCode.
 * User: WanThirty
 * Date: 15/7/16
 * Time: 上午11:02
 * To change this template use File | Settings | File Templates.
 */

var ItemTransformBox = Item.extend({
	_transformTo : game.PlayerType.Bullet,
	ps1 : null,

	_aniName : null,
	bornWithPos : function (pos) {
		this.ps1.setPositionType(1);
		switch (this._objType) {
			case game.ObjectType.BoxSmash:
				this._transformTo = game.PlayerType.Smash;
				this._aniName = "smash";
				break;
			case game.ObjectType.BoxBullet:
				this._transformTo = game.PlayerType.Bullet;
				this._aniName = "bullet";
				break;
			case game.ObjectType.BoxTeleport:
				this._transformTo = game.PlayerType.Teleport;
				this._aniName = "teleport";
				break;
			case game.ObjectType.BoxBomb:
				this._transformTo = game.PlayerType.Bomb;
				this._aniName = "bomb";
				break;
			case game.ObjectType.BoxHawk:
				this._transformTo = game.PlayerType.Hawk;
				this._aniName = "star";
				break;
			default :
				break;
		}
		this.playAnimate(this._aniName);
	},

	AILogicPerFrame : function() {
		if (!this._grid) return;
		if (this._grid.x > game.Data.oPlayerCtl._grid.x + this._checkForDieW ||
			this._grid.x < game.Data.oPlayerCtl._grid.x - this._checkForDieW ||
			this._grid.y > game.Data.oPlayerCtl._grid.y + this._checkForDieW ||
			this._grid.y < game.Data.oPlayerCtl._grid.y - this._checkForDieW)
		{
			this.disappear();
		}
	},

	collide : function(dir) {
		if (this._isOver) return;
		this._isOver = true;
		vee.Audio.playEffect(res.inGame_pick_pixie_mp3);

		if (this._transformTo == game.PlayerType.Hawk) {
			// hide player
			ItemTransformBox.transformToHawk(true, true);
		} else {
			game.Data.setPlayerType(this._transformTo);
			game.Data.oLyGame.showPowerDesc(this._transformTo);
		}

		this.playAnimate(this._aniName+"_out", function () {
			this.die();
		}.bind(this));
	},

	slow1 : function() {
		vee.PopMgr.rootNode.getScheduler().setTimeScale(0.7);
	},

	slow2  : function() {
		vee.PopMgr.rootNode.getScheduler().setTimeScale(0.12);
	},

	resume2 : function() {
		vee.PopMgr.rootNode.getScheduler().setTimeScale(0.6);
	},

	resume1 : function() {
		vee.PopMgr.rootNode.getScheduler().setTimeScale(1);
//		game.Data.cameraScaleLimitMIN = 1;
//		game.Data.cameraScaleSpeed = 0.001;
	}
});

ItemTransformBox.transformToHawk = function (autoTransformBack, slow) {
	vee.Audio.playEffect(res.inGame_efx_invisibleStart_mp3);
	game.Data.oPlayerCtl._container.runAction(cc.scaleTo(0.1, 0));
	game.Data.tempPlayerCtl = game.Data.oPlayerCtl;

	// show hawk
	var hawkContent = ElePlayer.create(res.hero_blackcat_ccbi);
	game.Data.oLyGame.lyMap.addChild(hawkContent.container, 2);
	game.Data.oPlayerCtl = hawkContent.controller;
	game.Data.oPlayerCtl.copyPlayerState(game.Data.tempPlayerCtl);
	var node = EfxBlackCatLight.show();
	hawkContent.container.addChild(node, -1);
	hawkContent.container.setScale(0);
	hawkContent.container.runAction(cc.scaleTo(0.1, 1));

	if(game.Data.isInParkour()){
		hawkContent.controller.addMotionStreak(true);
	}

	// start hawk!
	game.Data.playerHawk = true;
	if (slow) {
		game.Data.oLyGame.slowDur = 0.2;
		game.Data.oLyGame.startSlowRate = 0.3;
		game.Data.oLyGame.slowReviveRate = 0.06;
		game.Data.oLyGame.gameSlow();
	}

	// other effects
	game.Data.oLyGame.showPowerDesc(game.PlayerType.Hawk);

	var grid = game.Data.oPlayerCtl._grid;
	var efxPos = game.Logic.getTilePosCenterByGrid(grid);

	var layer = cc.LayerColor.create(cc.BLACK, 10000, 10000);
	game.Data.oLyGame.lyMapBack.addChild(layer, 1);
	layer.setPosition(cc.p(efxPos.x - 5000, efxPos.y - 5000));
	layer.setOpacity(0);
	layer.runAction(cc.sequence(
		cc.fadeTo(0.1, 150),
		cc.delayTime(0.5),
		cc.fadeTo(0.3, 50),
//		cc.fadeTo(0.3, 150),
		cc.fadeTo(0.56, 0),
		cc.callFunc(function () {
			layer.removeFromParent();
		})
	));

	EfxHawkLight.show(cc.p(efxPos.x, efxPos.y - TILE_WIDTH_HALF));
	vee.Audio.playMusic(res.bgm_invisible_mp3);

	if (autoTransformBack) {
		vee.Utils.scheduleOnceForTarget(game.Data, ItemTransformBox.transformBackFromHawk, 60);
	}
};

ItemTransformBox.transformBackFromHawk = function () {
	if (game.Data.playerHawk) {
		// stop hawk
		game.Data.playerHawk = false;
		cc.log("player is back!!!!!!!");

		// bring player back
		game.Data.tempPlayerCtl._container.setScale(1);
		game.Data.tempPlayerCtl.copyPlayerState(game.Data.oPlayerCtl);

		// hawk leave
		EfxBlackCatLight.player = game.Data.oPlayerCtl;
		game.Data.oPlayerCtl.rootNode.setVisible(false);
		game.Data.oPlayerCtl = game.Data.tempPlayerCtl;
		EfxBlackCatLight.remove(function () {
			cc.log("removed");
			EfxBlackCatLight.player._container.removeFromParent();
		});
		game.Data.oPlayerCtl._jumpCount = 1;

		vee.Audio.playMusic(game.Logic._bgmName);
	}
};