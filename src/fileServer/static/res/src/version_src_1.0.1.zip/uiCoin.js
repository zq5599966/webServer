/**
 * Created with AppCode.
 * User: WanThirty
 * Date: 15/9/12
 * Time: 下午6:31
 * To change this template use File | Settings | File Templates.
 */

var UICoin = vee.Class.extend({
	lbCoinNum : null,

	onCreate : function () {
		this.lbCoinNum.setString(game.LevelData.getCoin());
	},

	refresh : function () {
		this.lbCoinNum.setString(game.LevelData.getCoin());
	},

	showAnimate : function () {
		this.playAnimate("show");
	},

	hideAnimate : function () {
		this.playAnimate("end");
	}
});