/**
 * Created with AppCode.
 * User: WanThirty
 * Date: 15/9/15
 * Time: 下午6:30
 * To change this template use File | Settings | File Templates.
 */

var EfxLogo = vee.Class.extend({
	loop : function () {
		this.playAnimate("loop");
	}
});