/**
 * Created with AppCode.
 * User: WanThirty
 * Date: 15/9/9
 * Time: 下午4:53
 * To change this template use File | Settings | File Templates.
 */

var EfxGamePoint = vee.Class.extend({
	onCreate : function () {

	},
	inAnimate : function () {
		this.playAnimate("show", function () {
			this.rootNode.removeFromParent();
		}.bind(this));
	},
	outAnimate : function () {

	},
	loopAnimate : function () {

	}
});

EfxGamePoint.show = function (pos) {
	var node = cc.BuilderReader.load(res.efx_GamePiont_ccbi);
	node.setPosition(pos);
	game.Data.oLyGame.lyMap.addChild(node, 8);
};

var EfxPlayerOut = vee.Class.extend({
	onCreate : function () {
		this.playAnimate("show", function () {
			this.rootNode.removeFromParent();
		}.bind(this));
	}
});

EfxPlayerOut.show = function (pos) {
	var node = cc.BuilderReader.load(res.efx_PlayerOut_ccbi);
	node.setPosition(pos);
	game.Data.oLyGame.lyMap.addChild(node, 8);
};

var EfxCannonPs = vee.Class.extend({
	ps1 : null,
	ps2 : null,
	onCreate : function () {
		this.playAnimate("show", function () {
			game.Data.changePosFunc = null;
			this.rootNode.removeFromParent();
		}.bind(this));
//		game.Data.changePosFunc = function (pos) {
//			this.rootNode.setPosition(pos);
//		}.bind(this);
	},

	init : function () {
		this.ps1.setPositionType(cc.ParticleSystem.TYPE_RELATIVE);
		this.ps1.setPositionType(cc.ParticleSystem.TYPE_RELATIVE);
	}
});

EfxCannonPs.show = function (pos) {
	var node = cc.BuilderReader.load(res.efx_Player_DaPao_LiZi_ccbi);
//	node.setPosition(pos);
	node.controller.init();
//	game.Data.oLyGame.lyMap.addChild(node, 8);
	game.Data.oPlayerCtl._container.addChild(node, 8);
	return node.controller;
};

var EfxPlayerDie = vee.Class.extend({
	removeFunc : null,
	onCreate : function () {
		this.playAnimate("Show", function () {
			this.rootNode.removeFromParent();
			if (this.removeFunc) this.removeFunc();
		}.bind(this));
	}
});

EfxPlayerDie.show = function (pos, removeFunc) {
	var node = cc.BuilderReader.load(res.efx_elePlayerZhai_die_ccbi);
	node.setPosition(pos);
	node.controller.removeFunc = removeFunc;
	game.Data.oLyGame.lyMap.addChild(node, 8);
};