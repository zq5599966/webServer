/**
 * Created with AppCode.
 * User: WanThirty
 * Date: 16/1/19
 * Time: 上午11:01
 * To change this template use File | Settings | File Templates.
 */

var EfxCostEnergy = vee.Class.extend({
	ccbInit : function () {
		this.playAnimate("show");
	}
});

EfxCostEnergy.show = function (pos, parent) {
	if (game.Data.isFreeGame) {
		var node = cc.BuilderReader.load(res.efx_battery_ccbi);
		node.controller.ccbInit();
		node.setPosition(pos);
		parent.addChild(node,2);
	}
};