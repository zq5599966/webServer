/**
 * Created with AppCode.
 * User: WanThirty
 * Date: 15/11/10
 * Time: 下午1:32
 * To change this template use File | Settings | File Templates.
 */

var LyRate = vee.Class.extend({
	// btnConfirm : null,

	_isOver : false,
	_tempSelectorState : null,

	btnStar1 : null,
	btnStar2 : null,
	btnStar3 : null,
	btnStar4 : null,
	btnStar5 : null,

	ccbInit : function () {
		vee.Audio.playEffect(res.inGame_menu_showMessage_mp3);
		// this.playAnimate("show", this.initController.bind(this));
		this.playAnimate("show");
		this.handleKey(true);
		this._tempSelectorState = vee.Controller.cacheControllerState();

		this.initController();
	},

	initController : function () {

		vee.Controller.clearAllButtonAction();
		vee.Controller.activeButton();

		vee.Controller.initSelector(1,1,this.onClose.bind(this),cc.p(0,0));
		// vee.Controller.registerItemByButton(this.btnStar5, cc.p(0,0), this.onConfirm5.bind(this), "res/mfi_btn_on_170.png");
		vee.Controller.registerButtonAction([vee.KeyCode.BUTTON_A, vee.KeyCode.BUTTON_DPAD_CENTER], this.onConfirm5.bind(this));
		vee.Controller.activeSelector();

	},

	onKeyBack : function(){
		this.onClose();
		return true;
	},
	
	onConfirm1 : function () {
		this.onClose();
		vee.Analytics.UGameEvent.rateClickEvent(1);
	},

	onConfirm2 : function () {
		this.onClose();
		vee.Analytics.UGameEvent.rateClickEvent(2);
	},

	onConfirm3 : function () {
		this.onClose();
		vee.Analytics.UGameEvent.rateClickEvent(3);
	},

	onConfirm4 : function () {
		cc.log("zq debug rate layer click 4");
		this.onConfirm();
		vee.Analytics.UGameEvent.rateClickEvent(4);
	},

	onConfirm5 : function () {
		cc.log("zq debug rate layer click 5");
		this.onConfirm();
		vee.Analytics.UGameEvent.rateClickEvent(5);
	},
	

	onConfirm : function () {
		if (this._isOver) return;
		this._isOver = true;

		vee.Utils.rateUs();
		game.Data.rated();

		this.closeFunc();
	},

	onClose : function () {
		if (this._isOver) return;
		this._isOver = true;
		this.closeFunc();
	},

	closeFunc : function () {
		vee.Controller.deactiveSelector();
		this.playAnimate("hide", function () {
			vee.Controller.reviveControllerState(this._tempSelectorState);
			vee.PopMgr.closeLayerByCtl(this);
		}.bind(this));
	}
});

LyRate.show = function () {
	var node = vee.PopMgr.popCCB(res.warnPayment_ccbi, {alpha:0});
	node.controller.ccbInit();
	vee.Audio.playEffect(res.inGame_menu_showMessage_mp3);
};