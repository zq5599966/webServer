/**
 * Created with AppCode.
 * User: yop
 * Date: 15/10/27
 * Time: 下午3:33
 * To change this template use File | Settings | File Templates.
 */

LevelController.LevelMini103 = LevelController.extend({
	eventStory1 : function(grid, dir) {
		this.showStory(1, grid, ""+
		"RemoveEnemy;"+
		"SelectNpc;"+
		"FaceTo,left;"+
		"MoveCamera,32,14,2;"+
		"ShowDialog,"+ vee.Utils.getLocalizedStringForKey("Great! You're almost there!", "不错，你快到了！") +";"+
		"ShowDialog,"+ vee.Utils.getLocalizedStringForKey("Keep moving, buddy!", "别停下脚步，坚持住伙计！") +";"+
		"HideDialog;"+
		"TimeLine,huxi_2;"+
		"Delay,1;"+
		"AddCoin," + vee.Utils.getObjByPlatform('250','500','250') + ";"+
		"Delay,2;"+
		"GameOver"+
		"");
	}
});
