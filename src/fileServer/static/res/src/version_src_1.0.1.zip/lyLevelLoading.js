/**
 * Created with AppCode.
 * User: WanThirty
 * Date: 15/9/11
 * Time: 下午7:07
 * To change this template use File | Settings | File Templates.
 */

var LyLevelLoading = vee.Class.extend({
	lbPercent : null,
	lbHD : null,

	onCreate : function () {
		game.Data.oLvLoadingCtl = this;
		this.playAnimate("in", function () {
			game.Logic.flushFunctionPool();
		});
	},

	onExit : function () {
		game.Data.oLvLoadingCtl = null;
	},

	ccbInit : function () {
		this.lbHD.setVisible(game.Data.isAndroid);
		vee.Audio.playEffect(res.outGame_efx_senceChange_mp3);
	},

	setPercent : function (percent) {
		this.lbPercent.setString(percent+"%");
	},

	loaded : function () {
		// show 100 percent
		this.lbPercent.setString("100%");
		this.playAnimate("out", function () {
			vee.PopMgr.closeLayerByCtl(this);
			vee.Transition.in(res.MapTransition_ccbi, null, cc.p(568, 384));
		}.bind(this));
	}
});

LyLevelLoading.show = function () {
	var node = vee.PopMgr.popCCB(res.lyLevelLoading_ccbi, true);
	node.controller.ccbInit();
};