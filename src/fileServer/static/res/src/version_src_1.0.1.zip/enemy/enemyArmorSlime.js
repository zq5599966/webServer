/**
 * Created with AppCode.
 * User: WanThirty
 * Date: 15/7/14
 * Time: 下午4:50
 * To change this template use File | Settings | File Templates.
 */

var EnemyArmorSlime = EnemyMushroom.extend({
	objType : game.ObjectType.ArmorSlime,

	_popPlayerHeightMax : 1500,
	_popPlayerHeight    : 1500,

	rectSize : null,
	bornWithPos : function (pos) {
		this.rectSize = cc.size(this.boxSize.width, this.boxSize.height);
	},

	getEleRect : function() {
		var pos = this.getElePosition();
		var rect = cc.rect(
			pos.x + this.boxOffset.x - this.boxSize.width/2,
			pos.y + this.boxOffset.y - this.boxSize.height/2,
			this.rectSize.width,
			this.rectSize.height
		);
		return rect;
	},

	_shrink : false,
	collide : function(dir) {
		var oPlayer = game.Data.oPlayerCtl;
		if (oPlayer._isBounce || !this._hasCollide) return;
		if (dir == vee.Direction.Top) {
			this.popPlayerUp();
			var pos = this.getElePosition();
			EfxEnemyDie.show(pos, true);
			if (this._shrink) {
				this.playAnimate("defensehold", function () {
					this.reviveSlime();
				}.bind(this));
			} else {
				this._speedX = 0;
				this._accX = 0;
				this.setShrink(true);
				this.playAnimate("defense", function () {
					this.reviveSlime();
				}.bind(this));
			}
		}
	},

	setShrink : function (isShrink) {
		this._shrink = isShrink;
		if (this._shrink) {
			this.rectSize.height = 30;
			this._stopX = true;
		} else {
			this.rectSize.height = 70;
			this._stopX = false;
		}
	},

	checkCollide : function () {
		var rectEnemy = this.getEleRect();
		var rectForCheck = game.Data.oPlayerCtl.getEleRect();
		rectForCheck.x -= this._checkWidthOff;
		rectForCheck.width += this._checkWidthOff*2;
		if (cc.rectIntersectsRect(rectEnemy, rectForCheck)) {
			var playerY = game.Data.oPlayerCtl.getElePosition().y;
			var rectPlayer = game.Data.oPlayerCtl.getEleRect();
			var enemyY = rectEnemy.y + rectEnemy.height/2;
			var offsetY = playerY - enemyY;
			if (offsetY > this.rectSize.height/2 + this.boxOffset.y) {
				if (game.Data.oPlayerCtl._speedY < 0) {
					this.collide(vee.Direction.Top);
				}
			}
		}
	},

	hitByStar : function () {

	},

	moveLeft : function() {
		if (this._shrink) return;
		this.setFaceTo(vee.Direction.Left, true);
		this._accX = -this._accXForSet;
	},

	moveRight: function() {
		if (this._shrink) return;
		this.setFaceTo(vee.Direction.Right, true);
		this._accX = this._accXForSet;
	},

	reviveSlime : function () {
		this.playAnimate("revive", function () {
			this.playAnimate("run");
			this.setShrink(false);
			if (this._faceTo == vee.Direction.Left) this.moveLeft();
			else this.moveRight();
		}.bind(this));
	},

	dieEffect : function () {
		var pos = this.getElePosition();
		EfxEnemyDie.show(pos);
		this._accX = 0;
		this._speedX = 0;
		this._isOver = true;
		this.playAnimate("die", function () {
			this.die();
		}.bind(this));
	},

	dieAnimate : function (dir) {
		var pos = this.getElePosition();
		EfxEnemyDie.show(pos);
		this._hasCollide = false;
		this._isOver = true;
		this.die();
	}
});

var EnemyArmorSlimeHawk = EnemyMushroom.extend({
	objType : game.ObjectType.ArmorSlimeHawk,
	collideInhale : function () {
		var oPlayer = game.Data.oPlayerCtl;
		if (game.Data.playerInvisible || oPlayer._isBounce) return;
		oPlayer.getShock(vee.Direction.revert(oPlayer._faceTo), true);
		this.onGridChanged();
	},
	collide : function(dir) {
		if (game.Data.playerHawk) {
			game.Data.oLyGame.shake();
			this.die();
			return;
		}
		var oPlayer = game.Data.oPlayerCtl;
		if ((game.Data.playerInvisible || game.Data.oPlayerCtl._isBounce) && !(dir == vee.Direction.Top && game.Data.oPlayerCtl.isSmashing())) return;
		dir = this.getElePosition().x > oPlayer.getElePosition().x ? vee.Direction.Left : vee.Direction.Right;
		oPlayer.getShock(dir, true);
		this.setFaceTo(vee.Direction.revert(dir));
		this.onGridChanged();
		if (this._faceTo == vee.Direction.Left) {
			this.moveLeft();
		} else {
			this.moveRight();
		}
	},
	getInhaleController : function () {
		if (this.inhaleController) {
			return null;
		}
		this.inhaleController = new InhaleDamageObj();
		this.inhaleController.obj = this;
		return this.inhaleController;
	},
	hitByStar : function () {

	},
	checkCollide : function () {
		var rectEnemy = this.getEleRect();
		var rectForCheck = game.Data.oPlayerCtl.getEleRect();
		if (cc.rectIntersectsRect(rectEnemy, rectForCheck)) {
			var playerY = game.Data.oPlayerCtl.getElePosition().y;
			var enemyY = this.getElePosition().y;
			if (enemyY <= playerY) {
				var offsetY = playerY - enemyY;
				if (offsetY > this.boxSize.height/2 + this.boxOffset.y) {
					if (game.Data.oPlayerCtl._speedY < 0) {
						this.collide(vee.Direction.Top);
						return;
					}
				}
			}
			this.collide();
		}
	}
});