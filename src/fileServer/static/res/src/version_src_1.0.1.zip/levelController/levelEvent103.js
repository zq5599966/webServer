/**
 * Created with AppCode.
 * User: yop
 * Date: 15/10/30
 * Time: 下午7:02
 * To change this template use File | Settings | File Templates.
 */


LevelController.LevelEvent103 = LevelController.extend({
	eventStory1 : function(grid, dir) {
		this.showStory(1, grid, ""+
			"SelectNpc,Flash;"+
			"FaceTo,right;"+
			"MoveCamera,19,13,2;"+
			"FaceTo,left;"+
			"Jump,21,13;"+
			"MoveRole,18,13;"+
			"ShowDialog,"+ vee.Utils.getLocalizedStringForKey("Hi buddy!", "嘿，伙计！") +";"+
			"ShowDialog,"+ vee.Utils.getLocalizedStringForKey("A new friend is waiting for you!", "新的小伙伴正等着你呢！") +";"+
			"ShowDialog,"+ vee.Utils.getLocalizedStringForKey("Do you mind have a meeting?", "见个面呗？") +";"+
			"HideDialog;"+
			"SelectNpc;"+
			"MoveRole,23,11;"+
			"Jump,21,13;"+
			"MoveRole,19,13;"+
			"ShowDialog,"+ vee.Utils.getLocalizedStringForKey("WRYYYY!", "呜哇哇哇！") +";"+
			"ShowDialog,"+ vee.Utils.getLocalizedStringForKey("Do you still remember how many bread you've eaten?", "你能记得你吃过多少块面包吗?") +";"+
			"ShowDialog,"+ vee.Utils.getLocalizedStringForKey("Keep collecting this data so that you can call me!", "集齐这些数据，就可以召唤我！") +";"+
			"ShowDialog,"+ vee.Utils.getLocalizedStringForKey("WRYYYY!", "呜哇哇哇！") +";"+
			"HideDialog;"+
			"UnlockRole;"+
			"TimeLine,huxi_2;"+
			"Delay,1;"+
			"MoveCamera,20,9,2;"+
			"Trigger,22,14"+
			"MoveCamera,19,13,1;"+
			"ShowDialog,"+ vee.Utils.getLocalizedStringForKey("And please give a hand to others if you can!", "也请记得帮助其他人！") +";"+
			"HideDialog"+
		"");
	}
});