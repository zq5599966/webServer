/**
 * Created with AppCode.
 * User: yop
 * Date: 15/10/30
 * Time: 下午7:02
 * To change this template use File | Settings | File Templates.
 */


LevelController.LevelEvent101 = LevelController.extend({
	eventStory1 : function(grid, dir) {
		this.showStory(1, grid, ""+
			"MoveCamera,11,11,2;"+
			"SelectNpc,Flash;"+
			"MoveRole,10,12;"+
			"ShowDialog,"+ vee.Utils.getLocalizedStringForKey("I'm glad we met again!", "又见面了！") +";"+
			"ShowDialog,"+ vee.Utils.getLocalizedStringForKey("We were just talking about you!", "我正和小伙伴聊起你呢。") +";"+
			"ShowDialog,"+ vee.Utils.getLocalizedStringForKey("Greetings!", "见个面吧！") +";"+
			"HideDialog;"+
			"SelectNpc;"+
			"MoveRole,9,12;"+
			"ShowDialog,"+ vee.Utils.getLocalizedStringForKey("Oh, so you're the one he just mentioned!", "你就是刚刚提到的那个名人吗！") +";"+
			"ShowDialog,"+ vee.Utils.getLocalizedStringForKey("Perhaps you can share some new data with me?", "也许你能给我一些新的数据？") +";"+
			"ShowDialog,"+ vee.Utils.getLocalizedStringForKey("As a reward, please take my data!", "作为交换，请收下这些！") +";"+
			"HideDialog;"+
			"UnlockRole;"+
			"TimeLine,huxi_2;"+
			"Delay,1;"+
			"Trigger,8,13"+
		"");
	}
});