/**
 * Created with AppCode.
 * User: yop
 * Date: 15/10/27
 * Time: 下午3:33
 * To change this template use File | Settings | File Templates.
 */

LevelController.LevelMini201 = LevelController.extend({
	eventStory1 : function(grid, dir) {
		this.showStory(1, grid, ""+
		"RemoveEnemy;"+
		"MoveCamera,8,9,2;"+
		"SelectNpc;"+
		"ShowDialog,"+ vee.Utils.getLocalizedStringForKey("Well done! Keep going on.", "干的不错，继续吧。") +";"+
		"ShowDialog,"+ vee.Utils.getLocalizedStringForKey("(Snap)", "(响指)") +";"+
		"HideDialog;"+
		"TimeLine,huxi_2;"+
		"Delay,1;"+
		"AddCoin," + vee.Utils.getObjByPlatform('200','300','200') + ";"+
		"Delay,2;"+
		"GameOver"+
		"");
	}
});
