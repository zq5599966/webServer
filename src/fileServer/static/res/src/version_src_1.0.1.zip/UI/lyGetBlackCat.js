/**
 * Created with AppCode.
 * User: WanThirty
 * Date: 16/1/15
 * Time: 下午4:03
 * To change this template use File | Settings | File Templates.
 */

var LyGetBlackCat = vee.Class.extend({
	btnVideo : null,
	btnOK : null,

	_isOver : false,
	_tempControllerState : null,

	ccbInit : function () {

		this.handleKey(true);

		this._tempControllerState = vee.Controller.cacheControllerState();

		game.Data.oLyGame.leftBtnUp();
		game.Data.oLyGame.rightBtnUp();
		vee.Audio.playEffect(res.inGame_function_unlockAvator_mp3);
		if (game.Data.isFreeGame || game.Data.isWeiXin) {
			this.playAnimate("open");
		} else {
			this.playAnimate("open_pro");
		}
		if (game.Data.isWeiXin) {
			this.btnVideo.setBackgroundSpriteForState(new cc.Scale9Sprite(res.btn_hero_power_watch_weixin_png), cc.CONTROL_STATE_NORMAL);
		}

		this.initController();
	},

	onKeyBack : function(){
		this.onClose();
		return true;
	},

	initController : function () {
		vee.Controller.clearAllButtonAction();
		vee.Controller.initSelector(1,1,this.onClose.bind(this),cc.p(0,0));
		var btnCallback = null;
		var btn = null;
		if (game.Data.isFreeGame) {
			btnCallback = this.onVideo.bind(this);
			btn = this.btnVideo;
		} else {
			btnCallback = this.onOK.bind(this);
			btn = this.btnOK;
		}
		vee.Controller.registerItemByButton(btn, cc.p(0,0), btnCallback, "res/mfi_btn_on_210.png");
		vee.Controller.activeSelector();
	},

	onVideo : function() {
		if (this._isOver) return;

		vee.Audio.stopAllEffcts();

		if (game.LevelData.selectedCategory && game.LevelData.selectedLevel) {
			var category = game.LevelData.selectedCategory.idx + 1;
			var level = game.LevelData.selectedLevel.idx + 1;
			// key analy
			vee.Analytics.logEvent("GetBlackCatAt"  + category + "0" + level);
		}
		var successCall = function (pPlugin, num, itemID) {
			game.Data.oLyGame.resumeGame();
			vee.PopMgr.closeLayer();
			vee.Controller.reviveControllerState(this._tempControllerState);
			vee.Analytics.UGameEvent.showAdEvent("alert", "video", "blackCat");
			vee.Utils.scheduleOnce(function() {
				ItemTransformBox.transformToHawk();
			}, 2.0);
		}.bind(this);

		if (game.Data.isWeiXin) {
			vee.IAPMgr.buyProduct(4, successCall);
		} else {
			if(game.Data.zqdebug){
				successCall();
			}
			else{
				vee.Ad.showVideoAd(successCall, "blackCat");
			}


		}
	},

	onOK : function () {
		if (this._isOver) return;
		if (game.LevelData.selectedCategory && game.LevelData.selectedLevel) {
			var category = game.LevelData.selectedCategory.idx + 1;
			var level = game.LevelData.selectedLevel.idx + 1;
			// key analy
			vee.Analytics.logEvent("GetBlackCatAt"  + category + "0" + level);

			game.Data.oLyGame._isBlackCatModel = true;
		}
		game.Data.oLyGame.resumeGame();
		ItemTransformBox.transformToHawk();
		this.onClose();
	},

	onClose : function () {
		if (this._isOver) return;
		this._isOver = true;

		vee.Controller.deactiveSelector();
		vee.Controller.reviveControllerState(this._tempControllerState);

		if (game.Data.isFreeGame) {
			this.playAnimate("hide", this.closeFunc.bind(this));
		} else {
			this.playAnimate("hide_pro", this.closeFunc.bind(this));
		}
	},

	closeFunc : function () {
		vee.PopMgr.closeLayerByCtl(this);
		game.Data.oLyGame.resumeGame();
	}
});

LyGetBlackCat.show = function () {
	cc.log("zq debug ly get black cat pop========");
	if (game.Data.isFreeGame && !game.Data.isWeiXin) {
		if (game.Data.zqdebug || vee.Ad.checkCacheVideoAd()) {
			var node = vee.PopMgr.popCCB(res.lyBlackCatPower_ccbi, { alpha : 0 });
			node.controller.ccbInit();
			game.Data.oLyGame.pauseGame();
		}
	} else {
		var node = vee.PopMgr.popCCB(res.lyBlackCatPower_ccbi, { alpha : 0 });
		node.controller.ccbInit();
		game.Data.oLyGame.pauseGame();
	}
};