/**
 * Created with AppCode.
 * User: WanThirty
 * Date: 15/9/5
 * Time: 下午7:37
 * To change this template use File | Settings | File Templates.
 */

var EfxCostLife = vee.Class.extend({
	ps1 : null,

	onCreate : function () {
		this.playAnimate("Show", function () {
			this.rootNode.removeFromParent();
		}.bind(this));
	},

	init : function () {
		this.ps1.setPositionType(1);
	}
});

EfxCostLife.create = function (pos) {
	var node = cc.BuilderReader.load(res.efx_Life_loss_ccbi);
	node.setPosition(pos);
	node.controller.init();
	return node;
};