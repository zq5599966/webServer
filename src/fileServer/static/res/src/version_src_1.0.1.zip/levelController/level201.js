/**
 * Created with AppCode.
 * User: WanThirty
 * Date: 15/11/18
 * Time: 下午6:23
 * To change this template use File | Settings | File Templates.
 */

LevelController.Level201 = LevelController.extend({
	complete : function () {
		if (game.Data.getTempCoin() >= game.Data.stageMaxCoin) {
			vee.GameCenter.unlockAchievement(8);
		}
	}
});