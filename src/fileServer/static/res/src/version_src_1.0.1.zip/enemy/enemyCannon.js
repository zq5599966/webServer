/**
 * Created with AppCode.
 * User: WanThirty
 * Date: 15/6/19
 * Time: 下午8:43
 * To change this template use File | Settings | File Templates.
 */

var EnemyCannon = EnemyMushroom.extend({
	objType : game.ObjectType.Cannon,
	spHead : null,
	nodeCannon : null,
	_cannonReady : false,
	_ready : false,
	_loopEfx : null,
	onCreate : function() {
		this.boxOffset = this.nodeBox.getPosition();
		this.boxSize = this.nodeBox.getContentSize();
	},

	resetStatus : function () {
		this._cannonReady = false;
		this._ready = false;
		this._stopX = false;
		this._hasCollide = true;
		this._isOver = false;
		this.playAnimate("run");
		this.nodeCannon.setRotation(0);
	},

	transform : function () {
		this._ready = false;
		this.playAnimate("ready", function () {

		}.bind(this));
		this._ready = true;
		this.spHead.setVisible(false);
		this._cannonReady = true;
	},

	checkSpicalRole : function () {
		if(game.Data.checkIsMidAutumn()){
			this.spHead.setTexture(game.AvatarData.getAvatarData(12).cannonHeadName);
			return true;
		}
		else if(game.Data.checkIsHolloween()){
			this.spHead.setTexture(game.AvatarData.getAvatarData(13).cannonHeadName);
			return true;
		}
		else if(game.Data.checkIsThanksgiving()){
			this.spHead.setTexture(game.AvatarData.getAvatarData(14).cannonHeadName);
			return true;
		}
		return false;
	},

	_reloaded : false,
	reload : function () {
		if (!this._ready) return;
		this._reloaded = true;
		game.Data.playerInvisible = true;
		var oPlayer = game.Data.oPlayerCtl;
		oPlayer._container.stopAllActions();
		oPlayer.elf.hide();
		this.playAnimate("ready_in");
		this.spHead.setVisible(true);
		this.spHead.setScaleX(oPlayer._faceTo == vee.Direction.Left ? 1 : -1);
		if (game.Data.playerHawk) {
			var animation = new cc.Animation();
			for (var i = 1; i < 5; ++i) {
				var frame = cc.spriteFrameCache.getSpriteFrame("hero_head_0_cat_"+i+".png");
				animation.addSpriteFrame(frame);
			}
			animation.setDelayPerUnit(2/60);
			animation.setRestoreOriginalFrame(false);
			animation.setLoops(9999);
			this.animate = cc.animate(animation);
			this.spHead.runAction(this.animate);

		}
		else if(!this.checkSpicalRole()){
			this.spHead.setTexture(game.AvatarData.getCurrentAvatar().cannonHeadName);
		}

//		this._container.setScaleX(-1);
		this.setFaceTo(vee.Direction.Right, true);

		oPlayer.extendController = this;
		oPlayer._container.setVisible(false);
		oPlayer.setElePosition(this.getElePosition());
		game.Data.cameraXPos -= oPlayer._offsetX;
		game.Data.cameraYPos -= oPlayer._offsetY;
		game.Data.cameraXrevived = false;
		oPlayer._speedX = 0;
		oPlayer._speedY = 0;
	},

	// shoot...
	onAButton : function () {
		var data = game.Data;
		var player = data.oPlayerCtl;
		player.elf.show();
		this._hasCollide = false;
		this._alreadyRotate = false;
		vee.Utils.unscheduleAllCallbacksForTarget(this._container);
		this.spHead.setVisible(false);
		data.playerInvisible = false;
		player._isFlying = true;
		player.extendController = null;
		player._container.setVisible(true);
		player.setElePosition(this.getElePosition());
		var agl = this.nodeCannon.getRotation();
		var efx = EfxCannonShoot.show(agl);
		this.rootNode.addChild(efx);

		var v = vee.Utils.getPointWithAngle(cc.p(0,0), 2000, agl);
		player._accX = 0;
		player._speedX = -v.x;
		player._speedY = v.y < 1750 ? 1750 : v.y;
		player._isJumpLimitY = false;
		player.setFaceTo(this._agl > 0 ? vee.Direction.Left : vee.Direction.Right);
		if (data.oLyGame._holdLeft) {
			player.moveLeft();
		} else if (data.oLyGame._holdRight) {
			player.moveRight();
		}

		this.playAnimate("attack", false);
//		EfxCannonPs.show(this.getElePosition());
		vee.Audio.stopEffect(this._loopEfx);
		if (game.Data.playerType != game.PlayerType.Normal) {
			game.Data.oLyGame.showControlButton(LyGame.ControlButtonType.ActionButton);
		}
	},

	runCannon : function () {
		this._reloaded = false;
		this.resetStatus();
//		this._grid = this._gridInMap;
		if (this._faceTo == vee.Direction.Right) {
			this.moveRight();
		} else {
			this.moveLeft();
		}
		this.onGridChanged();
	},

	resetGun : function() {
		this.nodeCannon.runAction(cc.rotateTo(1, 0));
	},

	showDust : function () {
		EfxDust.show(this.getElePosition(), DustType.ForceJumpDust);
	},
	touchGround : function () {

	},

	_alreadyRotate : false,
	_rotateDir : vee.Direction.Origin,
	onMoveBtnDown : function (dir) {
		if (this._rotateDir != dir) {
			this._rotateDir = dir;
			this._rotateSpeed = dir == vee.Direction.Left ? -30 : 30;
			this.spHead.setScaleX(this._rotateSpeed < 0 ? -1 : 1);
		}
		if (this._alreadyRotate) return;
		cc.log("start rotate");
		this._alreadyRotate = true;
		vee.Utils.unscheduleAllCallbacksForTarget(this._container);
		vee.Utils.scheduleCallbackForTarget(this._container, this.updateRotate.bind(this));
	},

	onMoveBtnUp : function (dir) {
		this._alreadyRotate = false;
		vee.Utils.unscheduleAllCallbacksForTarget(this._container);
	},

	hitByStar : null,

	_rotateSpeed : 30,
	_agl : 0,
	_aglLimit : 30,
	updateRotate : function (dt) {
		this._agl = this._rotateSpeed*dt+this.nodeCannon.getRotation();
		this._agl = (this._agl > this._aglLimit ? this._aglLimit : this._agl);
		this._agl = (this._agl < -this._aglLimit ? -this._aglLimit : this._agl);
		this.nodeCannon.setRotation(this._agl);
	},

	checkCollide : function () {
		if (!this._hasCollide) return;
		var rectEnemy = this.getEleRect();
		var rectForCheck = game.Data.oPlayerCtl.getEleRect();
		if (cc.rectIntersectsRect(rectEnemy, rectForCheck)) {
			var playerY = game.Data.oPlayerCtl.getElePosition().y;
			var rectPlayer = game.Data.oPlayerCtl.getEleRect();
			var enemyPos = this.getElePosition();
			var enemyY = enemyPos.y;
			if (enemyY <= playerY) {
				var offsetY = playerY - enemyY;
				if (offsetY > this.boxSize.height/2 + this.boxOffset.y) {
					if (game.Data.oPlayerCtl._speedY < 0) {
						this.collide(vee.Direction.Top);
					}
				} else if (enemyPos.x > rectPlayer.x && enemyPos.x < rectPlayer.x + rectPlayer.width) {
					if (rectPlayer.x + rectPlayer.width/2 > enemyPos.x) {
						this.collide(vee.Direction.Right);
					} else {
						this.collide(vee.Direction.Left);
					}
				}
			} else if (enemyPos.x > rectPlayer.x && enemyPos.x < rectPlayer.x + rectPlayer.width) {
				this.collide(vee.Direction.Bottom);
			}
		}
	},

	collide : function(dir) {
		if (!this._hasCollide) return;
		if (dir == vee.Direction.Top && game.Data.oPlayerCtl._speedY < 0 && !game.Data.oPlayerCtl.extendController) {
			this._speedX = 0;
			this._accX = 0;
			this._stopX = true;
			this.transform();
			this.reload();
			game.Data.oLyGame.hideControlButton(LyGame.ControlButtonType.ActionButton);
			return;
			// deprecated...
//			if (this._cannonReady) {
//				this.reload();
//			} else {
//				var pos = this.getElePosition();
//				EfxEnemyDie.show(pos);
//				this.popPlayerUp();
//			}
		}
//		else {
//			if (game.Data.playerInvisible || game.Data.oPlayerCtl._isBounce || this._cannonReady) return;
//			var dir = this.getElePosition().x > game.Data.oPlayerCtl.getElePosition().x ? vee.Direction.Left : vee.Direction.Right;
//			game.Data.oPlayerCtl.getShock(dir, true);
//			this.setFaceTo(vee.Direction.revert(dir));
//			if (this._faceTo == vee.Direction.Left) {
//				this.moveLeft();
//			} else {
//				this.moveRight();
//			}
//			this.onGridChanged();
//		}
	},

	dieEffect : function () {

	},

	getInhaleController : function () {
		return null;
	},

	moveLeft : function() {
		if (this._reloaded) return;
		this._container.setScaleX(1);
		this.setFaceTo(vee.Direction.Left, true);
		this._accX = -this._accXForSet;
	},

	moveRight: function() {
		if (this._reloaded) return;
		this._container.setScaleX(1);
		this.setFaceTo(vee.Direction.Right, true);
		this._accX = this._accXForSet;
	}
});

var EfxCannonShoot = vee.Class.extend({

	nodeCannon : null,
	ps1 : null,
	ps2 : null,
	ps3 : null,

	onCreate : function () {
		this.playAnimate("attack", function () {
			this.rootNode.removeFromParent();
		}.bind(this));
	},

	ccbInit : function () {
		this.ps1.setPositionType(1);
		this.ps2.setPositionType(1);
		this.ps3.setPositionType(1);
	},

	setAngle : function (angle) {
		this.nodeCannon.setRotation(angle);
	}
});

EfxCannonShoot.show = function (angle) {
	var node = cc.BuilderReader.load(res.eleLuoBo_Yan_ccbi);
	node.controller.setAngle(angle);
	node.controller.ccbInit();
	return node;
};









