/**
 * Created with AppCode.
 * User: Yop Chan
 * Date: 15/12/21
 * Time: 下午2:10
 * To change this template use File | Settings | File Templates.
 */

var LyGestureDrawNode = vee.GestureControllerDelegate.extend({
	/** @type {cc.DrawNode} */
	rootNode : null,

	_origin : null,
	_end : null,
	_bufferOffsetX : 25,
	_maxOffsetX : 50,
	_bufferOffsetY : 140,
	_bufferOffsetSmash : 120,

	_distance : 0,

	/** @type {cc.Sprite} */
	spOrigin : null,
	/** @type {cc.Sprite} */
	spEnd : null,

	setScale : function (scale) {
		this._bufferOffsetX = 25 * scale;
		this._maxOffsetX = 50 * scale;
		this._bufferOffsetY = 140 * scale;
		this._bufferOffsetSmash = 120 * scale;
		this.spOrigin.setScale(1 * scale);
		this.spEnd.setScale(2.5 * scale);
	},

	init : function () {
		var node = new cc.Node();
		this.rootNode = node;
		var sp = cc.Sprite.create(res.btn_circle_png);
		sp.setScale(1);
		sp.setOpacity(0);
		node.addChild(sp);
		this.spOrigin = sp;
		sp = cc.Sprite.create(res.efx_one_png);
		sp.setScale(2.5);
		sp.setOpacity(0);
		node.addChild(sp);
		this.spEnd = sp;
		vee.GestureController.registerController(node, this ,false);
	},

	unregister : function () {

	},

	onGestureBegin : function(gestureController) {
		this._origin = gestureController.getBeginPoint();
		this._end = this._origin;
		this.spOrigin.stopAllActions();
		this.spOrigin.setOpacity(128);
		this.spEnd.stopAllActions();
		this.spEnd.setOpacity(196);
		this.draw();
		return true;
	},

	onGestureMove : function(ctl, offset) {
		var pos = ctl.getLastPoint();
		this._end = pos;
		if ( Math.abs(offset.x) < 50 || this._isOnLeft || this._isOnRight ) {  //屏蔽划动操作
			if (pos.x - this._origin.x > this._maxOffsetX) {
				this._origin.x = pos.x - this._maxOffsetX;
			} else if (pos.x - this._origin.x < -this._maxOffsetX) {
				this._origin.x = pos.x + this._maxOffsetX;
			}
		}

		if (offset.y < 0) {
			if (this._origin.y > pos.y)	this._origin.y = pos.y;
		} else {
			if (pos.y - this._origin.y > this._bufferOffsetY) {
				this._origin.y = pos.y - this._bufferOffsetY;
			}
		}

		var dis = this._end.x - this._origin.x;
		this._distance = Math.abs(dis);
		this._end.x += (this._distance > 100 ? (dis > 0 ? 50 : -50) : (dis)/2);
		this.draw();
	},

	onGestureSwipe : function (gestureController, angle, distance) {
		if (distance < this._bufferOffsetSmash) return;
		this.spEnd.setOpacity(0);
		this.spOrigin.setOpacity(0);
	},

	onGestureLeave : function(ctl, offset) {
		this.clear();
		this._origin = null;
	},

	draw : function () {
		this.spOrigin.setOpacity(this._distance > 100 ? 0 : 128);
		this.spOrigin.setPosition(this._origin.x, this._origin.y + 15);
		if (this._distance > this._bufferOffsetX) {
			this.spEnd.setPosition(this._end.x, this._end.y + 15);
		} else {
			this.spEnd.setPosition(this._origin.x, this._end.y + 15);
		}
	},

	clear : function () {
		this.spEnd.runAction(cc.spawn(cc.moveTo(0.2, this._origin.x, this._origin.y + 15), cc.fadeTo(0.2, 0)));
		this.spOrigin.runAction(cc.fadeTo(0.2, 0));
	}

});

LyGestureDrawNode.create = function () {
	cc.spriteFrameCache.addSpriteFrames(res.efx_box_plist);
	var ctl = new LyGestureDrawNode();
	ctl.init();
	return ctl;
}