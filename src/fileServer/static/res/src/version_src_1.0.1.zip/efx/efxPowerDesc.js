/**
 * Created with AppCode.
 * User: WanThirty
 * Date: 15/11/3
 * Time: 上午10:58
 * To change this template use File | Settings | File Templates.
 */

var EfxPowerDesc = vee.Class.extend({
	spIcon : null,
	lbDesc : null,

	ccbInit : function () {

	},

	setType : function (type) {
		switch (type) {
			case game.PlayerType.Smash:
				this.lbDesc.setString("Smash Sprite");
				break;
			case game.PlayerType.Bullet:
				this.lbDesc.setString("Bullet Sprite");
				break;
			case game.PlayerType.Teleport:
				this.lbDesc.setString("Blink Sprite");
				break;
			case game.PlayerType.Bomb:
				this.lbDesc.setString("Bomb Sprite");
				break;
			case game.PlayerType.Hawk:
				this.lbDesc.setString("~Phantom~");
				break;
			default :
				break;
		}
		var idx = parseInt(type)-1;
		this.playAnimate("show "+idx, function () {
			this.playAnimate("hide "+idx, function () {
				this.rootNode.removeFromParent();
			}.bind(this));
		}.bind(this));
	}
});

EfxPowerDesc.show = function (type, pos) {
	var node = cc.BuilderReader.load(res.efx_PowerBar_ccbi);
	node.setPosition(pos);
	game.Data.oLyGame.rootNode.addChild(node, 8);
	node.controller.ccbInit();
	node.controller.setType(type);
};