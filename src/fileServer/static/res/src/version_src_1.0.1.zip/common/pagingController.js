var vee = vee = vee || {};

vee.PagingController = cc.Class.extend({
	_currGrid : null,
	/**
	 * @type {vee.Map}
	 */
	_map : null,
	/**
	 * @type {vee.PagingController.Direction}
	 */
	_horizontalEnabled : false,
	_verticalEnabled : false,
	_canSwipe : true,
	_container : false,
	_offset : null,
	_sensitivity : 1,
	_tileDistance : 0,
	_bounceEnabled : false,

	_pageWidthDiv2 : 0,

	_gestureController : null,

	_currentPos : null,

	/**
	 *
	 * @param {Number} value 设置移动的灵敏度
	 */
	setSensitivity : function(value) {
		this._sensitivity = value;
	},

	/**
	 *
	 * @param {cc.Node} container
	 * @param {vee.Map} map
	 */
	init : function(container, width, height, pageSize){
		this._sensitivity = 1;
		this._bounceEnabled = false;
		this._container = container;
		this._horizontalEnabled = (width && width > 0);
		this._verticalEnabled = (height && height > 0);

		if (!height) height = 1;
		if (!pageSize) pageSize = container.getContentSize();

		if (this._horizontalEnabled && this._verticalEnabled) {
			this._tileDistance = vee.Utils.distanceBetweenPoints(cc.p(0,0), cc.p(pageSize.width, pageSize.height));
		} else if (this._horizontalEnabled) {
			this._tileDistance = pageSize.width;
		} else {
			this._tileDistance = pageSize.height;
		}

		this._pageWidthDiv2 = pageSize.width/2-2;

		var map = new vee.Map();
		map.setMapSize(cc.size(width, height));
		map.setTileSize(pageSize);

		var p = container.getPosition();
		var anp = container.getAnchorPoint();
		this._offset = cc.p(pageSize.width/2, pageSize.height/2);
		p.x -= pageSize.width*(width-1) + this._offset.x;
		p.y += pageSize.height*(height-1) - this._offset.y;
		map.setPosition(p);

		this._map = map;
		this._currGrid = map.position2Grid(container.getPosition());
		this._currentPos = map.grid2Position(this._currGrid);
		this._gestureController = vee.GestureController.registerController(container, this);

		this._dragingBuffer = cc.p(0,0);

		this._dragingEnabled = true;
	},

	setEnabled : function(v) {
		this._gestureController.setEnabled(v);
	},

	setSwallowTouches : function(v) {
		this._gestureController.setSwallowTouches(v);
	},

	setBounceEnabled : function(enable) {
		this._bounceEnabled = enable;
	},

	getPageWidth : function(){
		return this._map.tileSize.width;
	},

	_dragingEnabled : false,

	/**
	 *
	 * @param {BOOL} v
	 */
	setDragingEnabled : function(v) {
		this._dragingEnabled = v;
	},

	_dragingBuffer : null,

	//在 Buffer 范围内拖动页面不会发生位移，只有拖动距离超过了 buffer 值才开始移动
	setDragingBuffer : function(x, y) {
		y = y || x;
		this._dragingBuffer = cc.p(x,y);
	},

	setPosition : function(p) {
		this._container.setPosition(p);
	},

	animatePosition : function(duration, position, isSwipe) {
		var action = cc.MoveTo.create(duration, position);
		this._container.runAction(action);
	},

	onGestureDrag : function(context, offset) {
		if (!this._dragingEnabled) return;

		var p = cc.p(this._currentPos.x, this._currentPos.y);
		var pos = this._map.getPosition();
		var posEnd = this._map.getContentSize();
		posEnd.width += pos.x + this._offset.x + (this._bounceEnabled ? this._pageWidthDiv2 : 0);
		posEnd.height -= pos.y + this._offset.y;
		pos.x += this._offset.x - (this._bounceEnabled ? this._pageWidthDiv2 : 0);
		pos.y -= this._offset.y ;

		var lo = context.getLastOffset();
		if (this._horizontalEnabled && Math.abs(offset.x) > this._dragingBuffer.x) {
			if (lo.x > 50) offset.x -= lo.x - 50;
			else if (lo.x < -50) offset.x -= lo.x + 50;
			var test = p.x + this._sensitivity*(offset.x + (offset.x > 0 ? -this._dragingBuffer.x : this._dragingBuffer.x));
			if (test <= pos.x) test = pos.x;
			else if(test >= posEnd.width) test = posEnd.width;
			p.x = test;
		}
		if (this._verticalEnabled && Math.abs(offset.x) > this._dragingBuffer.y) {
			if (lo.y > 50) offset.x -= lo.y - 50;
			else if (lo.y < -50) offset.y -= lo.y + 50;
			var test = p.y + this._sensitivity*(offset.y + (offset.y > 0 ? -this._dragingBuffer.y : this._dragingBuffer.y));
			if (test <= pos.y) test = pos.y;
			else if (test >= posEnd.height) test = posEnd.height;
			p.y = test;
		}

		this.setPosition(p);
		this._needReset = true;
	},

	/**
	 * @param {Boolean}
	 */
 	setCanSwipe : function(canSwipe) {
	    this._canSwipe = canSwipe;
    },

	/**
	 * @param {vee.GestureController} context
	 */
	onGestureSwipe : function(context, angle, distance) {
		if (!this._canSwipe) return;
		var dir = vee.Direction.getDirectionByAngle(angle, true);
		if (!(this._horizontalEnabled && this._verticalEnabled)) {
			if (this._horizontalEnabled) {
				if (!vee.Direction.isHorizontal(dir)) dir = vee.Direction.origin;
			}
			else {
				if (!vee.Direction.isVertical(dir)) dir = vee.Direction.origin;
			}
		}
//		cc.log("on gesture swipe");
		var grid = this._map.gridByDirection(this._currGrid, dir);
		if (grid) this._setGrid(grid, true, true);
		else this._setGrid(this._currGrid, true);
	},

	_needReset : false,
	onGestureLeave : function() {
		if (!this._dragingEnabled) return;
		if (this._needReset) {
			this._currGrid = this._map.position2Grid(this._container.getPosition());
//			vee.Utils.logObj(this._currGrid, "on gesture leave");
//			vee.Utils.logObj(this._container.getPosition(), "on gesture leave  position====");
			if(this._currGrid)
				this._setGrid(this._currGrid, true);
			else
				this._setGrid(cc.p(6, 0), true);
		}
	},

	/**
	 *
	 * @param {Number} pageNum
	 * @param {Bool} animate
	 */
	setPage : function(pageNum, animate) {
		var page = this._map.length - pageNum;
		cc.log("maplength====%d   set page =====", this._map.length, page);
		this._setGrid(this._map.index2Grid(page), animate);
	},

	_setGrid : function(grid, animate, isSwipe) {
		this._needReset = false;
		this._container.stopAllActions();
		var p = this._map.grid2Position(grid);
		this._currGrid = grid;
		this._currentPos = p;
		if (animate) {
			var distance = vee.Utils.distanceBetweenPoints(p, this._container.getPosition());
			var duration = 0.2*distance/this._tileDistance;
			this.animatePosition(duration, p, isSwipe);
		} else {
			this.setPosition(p);
		}
		if (_.isFunction(this._onPageChanged)){
			this._onPageChanged(this, this.getCurrentPageNum());
		}
	},

	getCurrentPageNum : function() {
		return this._map.length - this._map.grid2Index(this._currGrid);
	},

	getTotalPageCount : function() {
		return this._map.length;
	},

	getCurrentPagePos : function() {
		return this._currentPos;
	},

	_onPageChanged : null,
	/**
	 * @param callback {Function}
	 */
	setPageChanged : function(callback) {
		this._onPageChanged = callback;
	}

});

/**
 *
 * @param {cc.Layer} container
 * @param {Number} width
 * @param {Number} height
 * @param {cc.Size} pageSize
 */
vee.PagingController.registerController = function(container, width, height, pageSize){
	var ctl = new vee.PagingController();
	ctl.init(container, width, height, pageSize);
	container.pagingController = ctl;
	return ctl;
};


/**
 * PowerPagingController 的功能
 * 页面的移动动画更细腻
 * 提供更高级的操作
 * 通过实现 setResetAnimation 和 setPositionChanged 接口，提供移动过程中更精确的移动动画
 */

vee.PowerPagingController = vee.PagingController.extend({
	_animationCallback : null,
	setResetAnimation : function(callback) {
		this._animationCallback = callback;
	},

	_positionChanged : function (position) {},
	setPositionChanged : function(callback) {
		this._positionChanged = callback;
	},

	animatePosition : function(duration, position, isSwipe) {
		var action;
		if (isSwipe) {
			action = cc.moveTo(0.5, position).easing(cc.easeExponentialOut());
		} else {
			action = cc.moveTo(duration, position).easing(cc.easeExponentialOut(3));
		}
		this._container.runAction(action);
		if (this._animationCallback) this._animationCallback(this, duration, position);
	},

	setPosition : function(position) {
		this._container.setPosition(position);
		this._positionChanged(this, position);
	}
});

/**
 *
 * @param {Number} width : Max grid.x
 * @param {Number} height : Max grid.y
 * @param {cc.Size} pageSize : Cell size of every single cell
 */
vee.PowerPagingController.registerController = function(container, width, height, pageSize){
	var ctl = new vee.PowerPagingController();
	ctl.init(container, width, height, pageSize);
	container.pagingController = ctl;
	return ctl;
};