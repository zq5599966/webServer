/**
 *
 * Created with AppCode.
 * User: WanThirty
 * Date: 16/3/11
 * Time: 下午4:36
 * To change this template use File | Settings | File Templates.
 */

var VeeMfiConnect = vee.Class.extend({

	ccbInit : function () {

	},

	showConnect : function () {
		this.playAnimate("on", this.removeFunc.bind(this));
	},

	showDisconect : function () {
		this.playAnimate("off", this.removeFunc.bind(this));
	},

	removeFunc : function () {
		this.rootNode.removeFromParent(true);
	}

});

VeeMfiConnect.create = function () {
	var node = cc.BuilderReader.load("res/mfiConnect.ccbi");
	node.controller.ccbInit();
	return node.controller;
};
