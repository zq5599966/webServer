/**
 * Created with AppCode.
 * User: WanThirty
 * Date: 15/11/23
 * Time: 下午12:08
 * To change this template use File | Settings | File Templates.
 */

var EnemyFlight = EnemyMushroom.extend({
	objType : game.ObjectType.Flight,
	_reloaded : false,
	_accXForSet : 300,
	spHead : null,

	resetStatus : function () {
		this._reloaded = false;
		this._hasCollide = true;
		this._isOver = false;
//		this.needRefreshPos = false;
	},

	checkCollide : function () {
		if (!this._hasCollide) return;
		var rectEnemy = this.getEleRect();
		var rectForCheck = game.Data.oPlayerCtl.getEleRect();
		if (cc.rectIntersectsRect(rectEnemy, rectForCheck)) {
			var playerY = game.Data.oPlayerCtl.getElePosition().y;
			var rectPlayer = game.Data.oPlayerCtl.getEleRect();
			var enemyPos = this.getElePosition();
			var enemyY = enemyPos.y;
			if (enemyY <= playerY) {
				var offsetY = playerY - enemyY;
				if (offsetY > this.boxSize.height/2 + this.boxOffset.y) {
					if (game.Data.oPlayerCtl._speedY < 0) {
						this.collide(vee.Direction.Top);
					}
				} else if (enemyPos.x > rectPlayer.x && enemyPos.x < rectPlayer.x + rectPlayer.width) {
					if (rectPlayer.x + rectPlayer.width/2 > enemyPos.x) {
						this.collide(vee.Direction.Right);
					} else {
						this.collide(vee.Direction.Left);
					}
				}
			} else if (enemyPos.x > rectPlayer.x && enemyPos.x < rectPlayer.x + rectPlayer.width) {
				this.collide(vee.Direction.Bottom);
			}
		}
	},

	collide : function(dir) {
		if (!this._hasCollide) return;
		if (dir == vee.Direction.Top && game.Data.oPlayerCtl._speedY < 0 && !game.Data.oPlayerCtl._isOver) {
			this._hasCollide = false;
			this._speedX = 0;
			this._accX = 0;
			this.reload();
			game.Data.oLyGame.hideControlButton(LyGame.ControlButtonType.ActionButton);
		}
	},

	reload : function () {
		this._reloaded = true;
		this.playAnimate("playerin");

		var oPlayer = game.Data.oPlayerCtl;
		game.Data.playerInvisible = false;
		oPlayer._container.stopAllActions();
		this._container.runAction(cc.EaseExponentialOut.create(cc.rotateTo(0.1, 0)));
		oPlayer.elf.hide();

		// set player head...
		this.spHead.setVisible(true);
		this.spHead.setTexture(game.AvatarData.getCurrentAvatar().headName);
		// set player state...
		oPlayer._speedX = 0;
		oPlayer._speedY = 0;
		oPlayer._accX = 0;
		oPlayer._accY = 0;
		/* need reset */
		oPlayer.extendController = this;
		oPlayer.setElePosition(this._pos);
		oPlayer._container.setVisible(false);
		oPlayer._G = -1000;
		oPlayer._isJumpLimitY = false;
		game.Data.playerXdecay = 800;
		game.Data.playerXSpeedLimit = 300;
		game.Data.isEnableCameraYOff = false;
		/* reset end */

		oPlayer.setJumping(false);
		game.Data.cameraXPos -= oPlayer._offsetX;
		game.Data.cameraYPos -= oPlayer._offsetY;
		game.Data.cameraXrevived = false;
	},

	_touchCount : 0,
	touchGround : function (force) {
		if (this._touchCount >= 1 || force) {
			this._touchCount = 0;
			var oPlayer = game.Data.oPlayerCtl;
			if (oPlayer._accX != 0) {
				oPlayer.setFaceTo(oPlayer._accX > 0 ? vee.Direction.Right : vee.Direction.Left);
			}

			this.playAnimate("playerout");
			this._speedY = 0;

			// detach player
			oPlayer.extendController = null;
			oPlayer._container.setVisible(true);
			oPlayer._G = game.Data.G;
			game.Data.playerXdecay = 2560;
			game.Data.playerXSpeedLimit = 440;
			game.Data.isEnableCameraYOff = true;
			oPlayer._speedY = 1000;
			oPlayer.setJumping(true);

			// reset flight
			this._reloaded = false;
			this._container.stopAllActions();
			this._container.runAction(cc.sequence(
				cc.EaseExponentialOut.create(cc.rotateTo(0.1, 0)),
				cc.delayTime(1),
				cc.callFunc(this.touchGroundComplete.bind(this))
			));
		} else {
			++this._touchCount;
		}
	},

	touchGroundComplete : function () {
		this._hasCollide = true;
	},

	afterUpdatePos : function () {
		if (this._reloaded) {
			this.setElePosition(game.Data.oPlayerCtl._pos);
		}
	},

	onMoveBtnDown : function (dir) {
		var dirS = dir == vee.Direction.Left ? 1 : -1;
		game.Data.oPlayerCtl._accX = this._accXForSet*dirS;
		this._container.stopAllActions();
		this._container.runAction(cc.rotateTo(0.2, 15*dirS));
	},
	onMoveBtnUp : function (dir) {
		game.Data.oPlayerCtl._accX = 0;
		this._container.stopAllActions();
		this._container.runAction(cc.EaseExponentialOut.create(cc.rotateTo(0.2, 0)));
	},

	onAButton : function () {
		this._touchCount = 1;
		this.playAnimate("shoot");
		game.Data.oPlayerCtl._speedY = 400;
		game.Data.cameraRestoreY = true;
		EfxUFO.show(this._pos, -this._container.getRotation());
	},

	dieEffect : function () {

	},

	AILogic : function () {},
	AILogicPerFrame : function () {},
	leftToBarrier : function() {},
	rightToBarrier : function() {},
	hitByStar : function () {}
});

var EfxUFO = vee.Class.extend({
	show : function () {
		this.playAnimate("shoot", function () {
			EfxUFO.pool.push(this.rootNode);
		}.bind(this));
	}
});

EfxUFO.show = function (pos, rotation) {
	var node = null;
	if (EfxUFO.pool.length > 0) {
		node = EfxUFO.pool.shift();
	} else {
		node = cc.BuilderReader.load(res.efxUFO_ccbi);
		game.Data.oLyGame.lyMap.addChild(node, 8);
	}

	node.controller.show();
	node.setPosition(pos);
	node.setRotation(rotation);
};

EfxUFO.pool = [];




