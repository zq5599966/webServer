/**
 * Created with AppCode.
 * User: WanThirty
 * Date: 16/1/5
 * Time: 下午5:22
 * To change this template use File | Settings | File Templates.
 */

var EfxBlackCatLight = vee.Class.extend({
	ccbInit : function () {
		EfxBlackCatLight.ctl = this;
	}
});

EfxBlackCatLight.ctl = null;
EfxBlackCatLight.player = null;

EfxBlackCatLight.show = function () {
	var node = cc.BuilderReader.load(res.efx_HeroBlackCat_ccbi);
	node.controller.ccbInit();
	return node;
};

EfxBlackCatLight.remove = function (callback) {
	if (EfxBlackCatLight.ctl) {
		EfxBlackCatLight.ctl.playAnimate("3", callback);
	}
};