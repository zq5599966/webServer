/**
 * Created with AppCode.
 * User: WanThirty
 * Date: 15/9/9
 * Time: 下午5:14
 * To change this template use File | Settings | File Templates.
 */

var EfxEnemyDie = vee.Class.extend({
	ps1 : null,

	show : function () {
		this.playAnimate("show", function () {
			this.rootNode.setVisible(false);
			EfxEnemyDie.pool.push(this);
		}.bind(this));
		vee.Audio.playEffect(res.inGame_event_deathMonster_mp3);
	},

	ccbInit : function () {
		this.ps1.setPositionType(1);
	}
});

EfxEnemyDie.show = function (pos, isSafe) {
	if (!isSafe) {
		EfxApplause.Analysis.onKillEnemy();
	}
	var efxCtl = EfxEnemyDie.pool.pop();
	if (!efxCtl) {
		var node = cc.BuilderReader.load(res.efx_Guai_die_ccbi);
		node.controller.ccbInit();
		game.Data.oLyGame.lyMap.addChild(node, 8);
		efxCtl = node.controller;
	}
	efxCtl.rootNode.setVisible(true);
	efxCtl.rootNode.setPosition(pos);
	efxCtl.show();
};

EfxEnemyDie.pool = null;