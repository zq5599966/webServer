/**
 * Created with AppCode.
 * User: WanThirty
 * Date: 15/11/13
 * Time: 上午10:47
 * To change this template use File | Settings | File Templates.
 */

var LySplash = vee.Class.extend({

	nodeT : null,

	ccbInit : function () {
		vee.PopMgr.setNodePos(this.nodeT, vee.PopMgr.PositionType.Top);
	}

});

LySplash.show = function () {
	var node = vee.PopMgr.popCCB(res.lyStartPage_ccbi, {alpha:0});
	node.controller.ccbInit();
};