/**
 * Created with AppCode.
 * User: yop
 * Date: 15/9/2
 * Time: 上午10:59
 * To change this template use File | Settings | File Templates.
 */

var LyLevelSelect = vee.Class.extend({
	ccbCategory1 : null,
	ccbCategory2 : null,
	ccbCategory3 : null,
	ccbCategory4 : null,
	ccbCategory5 : null,
	ccbCategory6 : null,
	ccbCategory7 : null,
	//cellSoon : null,
	btnSetting : null,
	btnGoogle : null,
	btnHelp : null,
	btnInfo : null,
	nodeBR : null,

	ccbEnergy : null,
	ccbLevelCells : null,
	ccbBtnShop : null,
	ccbBtnWorld : null,
	ccbFlag : null,
	ccbSocial : null,
	nodeT : null,

	ccbBtnBalloon : null,
	ccbBtnMoon    : null,

	nodeTR : null,
	spKeySelWorld : null,
	nodeReverseParticle : null,
	nodeNormalParticle : null,

	_isOver : false,

	/** @type {cc.LayerGradient} */
	lyBgColor : null,
	/** @type {cc.LayerGradient} */
	lyBgColor2 : null,

	/** @type {CategoryCell} */
	categoryCtls : [],

	width : 0,

	/** @type {CategoryCell} */
	selectedCategory : null,
	isSelectingLevel : false,
	isAnimating : false,

	/** @type {vee.PowerPagingController} */
	pagingCtl : null,

	/** @type {cc.Label} */
	lbCoinNum : null,
	/** @type {cc.Label} */
	lbStarNum : null,

	_selectedPage : 0,
	arrReadyUnlockIdx : null,
	_maxPageNum : 0,
	_mapType : 1,


	ccparticle : null,  //感恩节关卡特别粒子
	nodeNormalParticle : null, //圣诞雪花粒子


	initContent : function(){

		game.Data.curSceen = "LyLevelSelect";
		//x==510
		var num = game.LevelData.categoryCount - 1;
//		cc.log("zq debug num====%d", num);

		var model = this['ccbCategory1'];
		var beginPos = model.getPosition();

		for(var i = 1; i < num; i++){
			var posX = beginPos.x + i * 510;
			var posY = beginPos.y;
			var item = cc.BuilderReader.load(res.CategoryCell_ccbi);

			item.setPosition(cc.p(posX, posY));

			item.controller._origin = cc.p(posX, posY);

			this['ccbCategory' + (i+1)] = item;
			this.lyContent.addChild(item);
		}
	},

	showAudioPreloading : function () {

	},

	/**
	 * add by zq，版本更新判断是否已经玩过跑酷关卡
	 */
	setOldPlayerForParkourLevel : function () {
		if(vee.dataManager.isOldPlayerInParkour() != "false" || game.Data.zqdebug){
			if(vee.dataManager.getIsFirstClickCategory9() == "false"){
				vee.dataManager.setOldplayerInParkour("true");
			}
			else{
				vee.dataManager.setOldplayerInParkour("false");
			}
		}
	},

	ccbInit : function(){

		// vee.Audio.preloadAllSound();

		this.setOldPlayerForParkourLevel();

		vee.IAPMgr.getServicePriceList();

		vee.Controller.clearAll();

		this.initContent();

//		vee.Audio.playMusic(res.bgm_menu_mp3);
		game.Data.retryCount = 0;
		var node = LyAvatarStore.load();
		this.rootNode.addChild(node);
		node.controller.onLoaded();

		VeeRecordButton.stopRecord();
		game.Data.oLvSelectCtl = this;

		game.Data.checkShowBtnWorld();

		this._maxPageNum = game.LevelData.categoryCount;
		//if (game.Data.is61) {
		//	var ctl = vee.PowerPagingController.registerController(this.lyContent, this._maxPageNum - 1);
		//} else {
		//	var ctl = vee.PowerPagingController.registerController(this.lyContent, this._maxPageNum);
		//}
		var ctl = vee.PowerPagingController.registerController(this.lyContent, this._maxPageNum - 1);
		ctl.setSensitivity(0.75);
		ctl.setResetAnimation(this.animatePagePos.bind(this));
		ctl.setPositionChanged(this.updatePagePos.bind(this));
		ctl.setBounceEnabled(true);
		ctl.setDragingBuffer(30);
		ctl.onGestureTap = this.onGestureTap.bind(this);
		ctl.setSwallowTouches(false);
		ctl.setPageChanged(function () {
			vee.Audio.playEffect(res.outGame_menu_viewSection_mp3);
		}.bind(this));

		// if (game.Data.isFreeGame) {
		// 	vee.Utils.scheduleOnce(function() {
		// 		this.showCategoryLevels();
		// 	}.bind(this), 1.1);
		// }

		if(this.ccparticle){
			this.ccparticle.setVisible(false);
		}

		if(this.nodeNormalParticle){
			this.nodeNormalParticle.setVisible(false);
		}

		if(this.ccbparticleSnow){
			this.ccbparticleSnow.setVisible(true);
			vee.Audio.playMusic(res.outGame_menu_levelSelect_mp3);
		}

		this.pagingCtl = ctl;

		this.width = ctl.getPageWidth();

		this.unlockLevel61();

		this.refreshCategory();

		if(game.Data.version.isSetShowSpecialEvent){
			this.setSpecialLevelEvent();
		}
		else{
			this.updateLevel61();
		}

//		this.showFirstCategory();

		this.lyContent.setLocalZOrder(1);

		this.ccbBtnShop.setLocalZOrder(999);
		this.ccbEnergy.setLocalZOrder(999);

		vee.PopMgr.setNodePos(this.ccbBtnWorld, vee.PopMgr.PositionType.TopLeft);
		vee.PopMgr.setNodePos(this.ccbBtnShop, vee.PopMgr.PositionType.TopRight);
		vee.PopMgr.setNodePos(this.nodeTR, vee.PopMgr.PositionType.TopRight);
		if (this.nodeT) {
			vee.PopMgr.setNodePos(this.nodeT, vee.PopMgr.PositionType.Top);
			if (this.ccbFlag) this.ccbFlag.controller.loopAnimate();
		}

		this.refreshCoin();
		cc.log("star = "+game.LevelData.getStar());
		this.lbStarNum.setString(game.LevelData.getStar());
		vee.Analytics.logPlayerLevel(""+game.LevelData.getStar());

		vee.Transition.in(res.MapTransition_ccbi);

		this.ccbLevelCells.controller.updateCells();
		this.handleKey(true);

//		this.initPagePos(ctl, ctl._container.getPosition());

		this.btnGoogle.setVisible(game.Data.isAndroid && game.Data.isFreeGame);
		this.btnSetting.setVisible(game.Data.isAndroid && game.Data.isFreeGame);
		this.ccbEnergy.setVisible(game.Data.isFreeGame);
		this.registerController();

		if (game.Data.isWeiXin) {
			this.btnGoogle.setBackgroundSpriteForState(new cc.Scale9Sprite(res.btn_home_index_quit_png), cc.CONTROL_STATE_NORMAL);
		}

		if (game.Data.isShowBtnWorld()) {
			this.ccbBtnWorld.setVisible(true);
			if (game.Data.isNewReverseWorld)
			{
				game.Data.isNewReverseWorld = false;
				this._mapType = LyLevelSelect.MapType.MAP_NORMAL;
				this._showNormal();
				this.ccbBtnWorld.controller.showMoon();
				this.ccbBtnWorld.controller.setNew(true);
			}
			else
			{
				if (game.Data.isSelectingReverseWorld)
				{
					this._mapType = LyLevelSelect.MapType.MAP_REVERSE;
					this._showReverse();
				}
				else
				{
					this._mapType = LyLevelSelect.MapType.MAP_NORMAL;
					this._showNormal();
				}
			}
		} else {
			this.ccbBtnWorld.setVisible(false);
			game.Data.isSelectingReverseWorld = false;
			this.nodeReverseParticle.setVisible(false);
			// this.nodeNormalParticle.setVisible(true);
			this.nodeNormalParticle.setVisible(true);
		}

		//if (game.Data.is61 && this.ccbBtnBalloon) {
		//	this.ccbBtnBalloon.controller.ccbInit();
		//}

		if(game.Data.version.isMidAutumn && this.ccbBtnMoon){
			cc.log("btn moon visible=====" + !game.Data.isSelectingReverseWorld);
			this.ccbBtnMoon.controller.ccbInit();
			this.ccbBtnMoon.setVisible(!game.Data.isSelectingReverseWorld && game.Data.version.isShowSpecialLevel());
		}

		if (this.nodeBR) {
			vee.PopMgr.setNodePos(this.nodeBR, vee.PopMgr.PositionType.BottomRight);
			this.nodeBR.setLocalZOrder(1000);
//			if (game.Data.isIOSCN || game.Data.isAndroid)
//				this.nodeBR.setVisible(true);
//			else
//				this.nodeBR.setVisible(false);
			this.nodeBR.setVisible(game.Data.version.isKTPlay);
			this.ccbSocial.controller.ccbInit();
		}

		var foxData = game.AvatarData.getAvatarData(11);
		if (!foxData.owned) {
			var state_61 = game.LevelData.getCategory(6).getLevelDataController(0).getLevelState();
			if (state_61 == 2) {
				game.AvatarData.avatarPurchased(11);
				vee.Analytics.UGameEvent.unlockRoleEvent("61", 11);
			}
		}

		this.showLoginPop();

		// this.pagingCtl.setPage(game.LevelData.categoryCount, true);
	},

	showLoginPop : function () {
		if(game.Data.willShowLoginPop && game.Data.isFreeGame){

			game.Data.willShowLoginPop = false;
			var contiunsDays = vee.dataManager.getContinuousLoginDays();
			cc.log("zq debug ===========show login pop   days===" + contiunsDays);
			if(contiunsDays < 5){
				ccbContinuousLoginAlert.show(contiunsDays);
			}

		}
		vee.dataManager.setLoginTime();
	},

	onExit : function () {
		LyLevelSelect.isUnlocking = false;
		game.Data.oLvSelectCtl = null;
		vee.Controller.deactiveSelector();
		vee.Controller.removeControllerSprite(this.spKeySelWorld);
	},

	refreshCategory : function () {
		if (game.Data.isFreeGame) {
			var maxUnlockCategory = 0;
			for(var i = 1; i <= this._maxPageNum - 1; i++) {
				if (this['ccbCategory'+i]) {
					this.categoryCtls[i] = this['ccbCategory' + i].controller;
					var idx = i - 1;
					if (game.Data.isSelectingReverseWorld) idx += 100;
					if (!this.categoryCtls[i].setIndex(idx)) {
						maxUnlockCategory = i;
					}
					this.categoryCtls[i].disSelect(0);
				}
			}
			// if(maxUnlockCategory == 7 || maxUnlockCategory == 8) return;    //add by zq, sp
			// this.pagingCtl.setPage(maxUnlockCategory, true);
			var idx = game.Data.getSelectedLvIdx();
			if (idx > 20) idx -= 100;
			this.pagingCtl.setPage(idx, true);

		} else {
			this.arrReadyUnlockIdx = [];
			for(var i = 1; i <= this._maxPageNum - 1; i++) {
				this.categoryCtls[i] = this['ccbCategory'+i].controller;
				var idx = i-1;
				if (game.Data.isSelectingReverseWorld) idx += 100;
				var readyUnlock = this.categoryCtls[i].setIndex(idx);
				if (readyUnlock) {
					this.arrReadyUnlockIdx.push(i);
				}
				this.categoryCtls[i].disSelect(0);
			}
			this.unlockCategory();
		}
	},

	showFirstCategory : function () {
		this._selectedPage = 1;
		this.selectedCategory = this.categoryCtls[1].select(0.01);

		var colorSet = game.LevelData.getBgColors(this._selectedPage-1);
		this.lyBgColor.setOpacity(255);
		this.lyBgColor.setStartColor(colorSet[1]);
		this.lyBgColor.setEndColor(colorSet[0]);
	},


	// controller func...
	_maxPageCount : -1,
	_isFocusMenu : false,
	_isFocusTop : false,

	registerController : function () {
		this._maxPageCount = this.pagingCtl.getTotalPageCount();
		vee.Controller.clearAllButtonAction();
		// register button action
		vee.Controller.activeButton();
		vee.Controller.registerButtonAction(
			vee.KeyCode.BUTTON_DPAD_LEFT,
			this.pageToLeft.bind(this)
		);
		vee.Controller.registerButtonAction(
			vee.KeyCode.BUTTON_DPAD_RIGHT,
			this.pageToRight.bind(this)
		);
		vee.Controller.registerButtonAction(
			vee.KeyCode.BUTTON_DPAD_DOWN,
			this.pageToBottom.bind(this)
		);
		vee.Controller.registerButtonAction(
			vee.KeyCode.BUTTON_DPAD_UP,
			this.pageToTop.bind(this)
		);
		vee.Controller.registerButtonAction(
			[vee.KeyCode.BUTTON_A, vee.KeyCode.BUTTON_DPAD_CENTER],
			function () {
				if (!this._isFocusMenu && !this.isSelectingLevel) {
					this.showCategoryLevels();
				}
			}.bind(this)
		);
		vee.Controller.registerButtonAction(
			vee.KeyCode.BUTTON_B,
			function () {
				if (this.isSelectingLevel) {
					this.leaveSelectLevel();
				}
				else{
					VeeQuitBox.show();
				}
			}.bind(this)
		);
		vee.Controller.registerButtonAction(
			[vee.KeyCode.BUTTON_RIGHT_SHOULDER,vee.KeyCode.AXIS_RIGHT_TRIGGER],
			this.ccbBtnShop.controller.onOpenStore.bind(this.ccbBtnShop.controller)
		);
		vee.Controller.registerButtonAction(
			[vee.KeyCode.BUTTON_LEFT_SHOULDER,vee.KeyCode.AXIS_LEFT_TRIGGER],
			this.ccbBtnWorld.controller.onReverseWorld.bind(this.ccbBtnWorld.controller)
		);

		vee.Controller.registerControllerSprite(this.spKeySelWorld);
	},
	createTopItemMap : function() {
		// register menu selector
		// 1. init selector first
		vee.Controller.clearAllItem();
		if (game.Data.isReverseWorldOpen && game.Data.isShowBtnWorld()) {
			vee.Controller.initSelector(2, 1, null, cc.p(1,0));
			vee.Controller.registerItemByButton(BtnWorld.instance.btnReverseWorld, cc.p(0,0),
				this.ccbBtnWorld.controller.onReverseWorld.bind(this.ccbBtnWorld.controller), res.mfi_home_world_on_png);
		} else {
			vee.Controller.initSelector(2, 1, null, cc.p(0,0));
			// 2. register selection item
			vee.Controller.registerItemByButton(BtnShop.instance.btnOpenStore, cc.p(0,0),
				this.ccbBtnShop.controller.onOpenStore.bind(this.ccbBtnShop.controller), res.mfi_home_avatar_on_png);
		}

		vee.Controller.deactiveSelector();
	},
	createLeftItemMap : function () {
		// register menu selector
		// 1. init selector first
		vee.Controller.clearAllItem();
		// 2. register selection item
		/*
		if (game.Data.isAndroid && game.Data.isFreeGame) {
			vee.Controller.initSelector(1, 3, null, cc.p(0,0));
			// vee.Controller.registerItemByButton(this.btnSetting, cc.p(0,0), this.onSetting.bind(this), res.mfi_home_help_png);
			// vee.Controller.registerItemByButton(this.btnGoogle, cc.p(0,1), this.onGoogle.bind(this), res.mfi_home_help_png);
			// vee.Controller.registerItemByButton(this.btnHelp, cc.p(0,2), this.onHelp.bind(this), res.mfi_home_help_png);
			// vee.Controller.registerItemByButton(this.btnInfo, cc.p(0,3), this.onInfo.bind(this), res.mfi_home_help_png);
			vee.Controller.registerItemByButton(this.btnGoogle, cc.p(0,0), this.onGoogle.bind(this), res.mfi_home_help_png);
			vee.Controller.registerItemByButton(this.btnHelp, cc.p(0,1), this.onHelp.bind(this), res.mfi_home_help_png);
			vee.Controller.registerItemByButton(this.btnInfo, cc.p(0,2), this.onInfo.bind(this), res.mfi_home_help_png);
		} else {
			vee.Controller.initSelector(1, 2, null, cc.p(0,1));
			vee.Controller.registerItemByButton(this.btnHelp, cc.p(0,1), this.onHelp.bind(this), res.mfi_home_help_png);
			vee.Controller.registerItemByButton(this.btnInfo, cc.p(0,2), this.onInfo.bind(this), res.mfi_home_help_png);
		}
		*/

		vee.Controller.deactiveSelector();
	},

	createLevelsItemMap : function (category) {
		vee.Controller.clearAllItem();
		var beginIdx = Math.ceil((7 - category.levelCount)/2) + 1;
		vee.Controller.initSelector(7, 2, null, cc.p(beginIdx - 1, 1 - beginIdx%2));
		for (var i = 0; i < category.levelCount; ++i) {
			var newIdx = beginIdx + i;
			var x = newIdx - 1;
			var y = 1 - newIdx%2;
			var btnCtl = this.ccbLevelCells.getChildByTag(newIdx).controller;
			vee.Controller.registerItemByButton(
				btnCtl.spBG,
				cc.p(x,y),
				btnCtl.onSelect.bind(btnCtl),
				res.mfi_home_level_on_png
			);
		}
	},

	pageToLeft : function () {
		if (this.isSelectingLevel || this._isFocusTop) return;
		var curPos = this.pagingCtl.getCurrentPageNum();
		if (curPos > 1) {
			this.pagingCtl.setPage(curPos - 1, true);
		} else if (!this._isFocusMenu) {
			this._isFocusMenu = true;
			// controller
			this.createLeftItemMap();
			vee.Controller.activeSelector();
		}
	},
	pageToRight : function () {
		if (this.isSelectingLevel || this._isFocusTop) return;
		var curPos = this.pagingCtl.getCurrentPageNum();
		if (this._isFocusMenu) {
			this._isFocusMenu = false;
			vee.Controller.deactiveSelector(true);
		} else if (curPos < this._maxPageCount) {
			this.pagingCtl.setPage(curPos + 1, true);
		}
	},

	topTag : false,

	pageToTop : function() {
		if (this.isSelectingLevel) return;
		if (!this._isFocusMenu || this.topTag) {
			// controller
			this.createTopItemMap();
			this._isFocusTop = true;
			this._isFocusMenu = false;
			this.topTag = false;
			vee.Controller.activeSelector();
			return;
		}
		if (this._isFocusMenu && (vee.Controller.getSelectorGrid().x == 0 && vee.Controller.getSelectorGrid().y == 0)) {
			this.topTag = true;
		}
	},

	pageToBottom : function() {
		if (!this._isFocusTop) return;
		this._isFocusTop = false;
		vee.Controller.deactiveSelector(true);
	},

	// ccb button callbacks...
	onHelp : function () {
		if (this._isOver) return;
		this._isOver = true;
		vee.Transition.out(res.MapTransition_ccbi, function () {
			vee.PopMgr.closeAll();
			cc.director.purgeCachedData();
			vee.PopMgr.popCCB("res/veeGameLayer.ccbi");
			game.Data.oLyGame.onLoaded();
//			        game.Data.oLyGame.initStage('Tutorial');
			game.Data.oLyGame.initStage('Story1');
		});
	},

	onInfo : function () {
		LyStaff.show();
	},

	onSetting : function(){
		if (this._isOver) return;
		LyPosSetting.show();
	},

	onGoogle : function () {
		if (game.Data.isWeiXin) {
			vee.PopMgr.closeAll();
			LyIndexWeiXin.show();
			vee.IAPMgr.logout();
		} else {
			LyGoogle.show();
		}
	},

	onKeyBack : function () {
		if (this._isOver) return;
		//this._isOver = true;
		if (this.isSelectingLevel) {
			this.leaveSelectLevel();
			return;
		}
		VeeQuitBox.show();
	},

//	initPagePos : function (context, position) {
//		var offsetX = position.x - context.getCurrentPagePos().x;
//
//		var percent = Math.min(1,Math.abs(offsetX)/this.width);
//		if (percent > 0.3) this.selectedCategory = null;
//
//		var pageNum = context.getCurrentPageNum();
//		this.categoryCtls[pageNum].setOffset(1 - percent);
//		if (pageNum > 1) this.categoryCtls[pageNum - 1].setOffset(percent);
//		if (pageNum < 5) this.categoryCtls[pageNum + 1].setOffset(percent);
//	},

	refreshCoin : function () {
		if(this.lbCoinNum){
			this.lbCoinNum.setString(game.LevelData.getCoin());
		}
	},

	unlockCategory : function () {
		cc.log("unlock category length ====%d", this.arrReadyUnlockIdx.length);
		if (this.arrReadyUnlockIdx.length > 0) {
			LyLevelSelect.isUnlocking = true;
			this.pagingCtl.setEnabled(false);
			var idx = this.arrReadyUnlockIdx.shift();
			if (idx > 20) idx -= 100;
			this.pagingCtl.setPage(idx, true);
			this.categoryCtls[idx].unlockAnimate(this.unlockCategory.bind(this));
		} else {
			LyLevelSelect.isUnlocking = false;
			this.pagingCtl.setEnabled(true);
			var idx = game.Data.getSelectedLvIdx();
			cc.log("check 61 idx = "+idx);
			//if (!game.Data.is61 && idx == 7) {
			//	idx = 1;
			//}
			if (idx > 20) idx -= 100;
			this.pagingCtl.setPage(idx, true);
		}
	},

	unlockCategoryByIdx : function(idx, isShow) {
		this.categoryCtls[idx].unlockAnimate(function() {
			this.categoryCtls[idx].changeToPercentage();
			if (isShow) {
				this.showCategoryLevels();
			}
		}.bind(this));
	},

	setSpecialLevelEvent : function () {
		if(game.Data.version.isShowSpecialLevel()){


			for(var i = 6; i < game.LevelData.categoryCount - 1; i++)
			if (game.LevelData.getCategory(i).lockStatus == game.LevelData.LockStatus.LOCKED && game.LevelData.getCategory(i).categoryReady) {
				cc.log("set special level event=====%d", i);
				game.LevelData.setLockStatus(i, game.LevelData.LockStatus.UNLOCKED);
			}
		}
	},

	updateLevel61 : function() {
		if (vee.data["level61_ts"]) {
			if (game.Data.getLevel61LeftTime() > 0) {
				this.ccbCategory7.controller.setLeftTime(game.Data.getLevel61LeftTime());
			}
		}
	},

	unlockLevel61 : function() {
		// if (game.Data.getLevel61LeftTime() <= 0) {
		if (game.Data.getLevel61LeftTime() <= 0) {
			if (game.LevelData.getCategory(6).lockStatus == game.LevelData.LockStatus.LOCKED) {
				game.LevelData.setLockStatus(6, game.LevelData.LockStatus.UNLOCKED);
			}
		}
	},

	onGestureTap : function (context, distance) {
		cc.log("on select click");
		if (!this.selectedCategory || this.isAnimating) return;
		if (!this.isSelectingLevel) {
			var pos = context.getLastPointInWorld();

			if(distance < 30){
				if(vee.Utils.distancePower2BetweenPoints(pos, cc.p(568 - 510, 340)) < 45000){
					this.pageToLeft();
				}
				else if(vee.Utils.distancePower2BetweenPoints(pos, cc.p(568,340)) < 45000){
					this.showCategoryLevels();
				}
				else if(vee.Utils.distancePower2BetweenPoints(pos, cc.p(568 + 510,340)) < 45000){
					this.pageToRight();
				}

			}

//			if (distance < 30 && vee.Utils.distancePower2BetweenPoints(pos, cc.p(568,340)) < 45000) {
//				this.showCategoryLevels();
//			}
		} else {
			this.leaveSelectLevel();
		}
	},

	showCategoryLevels : function () {
		if (!this.selectedCategory.isLock || game.Data.isAllLevelOpen) {
			this.enterSelectLevel();
			var category = game.LevelData.selectedCategory;
			if (category) {
				this.createLevelsItemMap(category);
				vee.Controller.activeSelector();
			}
		} else {
			// timing locked
			var categoryData = this.selectedCategory._categoryData;
			if ( !this.selectedCategory.isComingSoon && (categoryData && categoryData.categoryReady) ) {
				var idx = this.pagingCtl.getCurrentPageNum() - 1;
				AlertUnlockCategory.show(this.selectedCategory.getUnlockStarDesc(game.Data.isSelectingReverseWorld), idx);
			}
			else{
				vee.Analytics.UGameEvent.clickButtonEvent("moreGame");

				var defaultUrl = game.Data.isAndroid ? "https://play.google.com/store/apps/details?id=com.veewo.get10s" : "https://itunes.apple.com/cn/app/just-get-10-seasons/id1056541107?mt=8";
				// var defaultUrl = "http://www.baidu.com";
				var moreGameUrl = vee.OnlineConfig.getConfigParam("moreGameUrl", defaultUrl);
				// var moreGameUrl = vee.OnlineConfig.getConfigParam("level_btn_show_ad_before_count", defaultUrl);

				cc.log("more game url=====%s", moreGameUrl);
				vee.Utils.openURL(moreGameUrl);

			}
		}
	},

	enterSelectLevel : function() {
		//vee.PopMgr.closeAll();
		//var node = vee.PopMgr.popCCB("res/veeGameLayer.ccbi");
		//game.Data.oLyGame.initStage(224);
		//return;

		//enter level Select procedure

		// cc.log("zq debug ====== enter select level");
		// vee.Utils.logObj(this.selectedCategory, "select category===");

		/*
		if(this.selectedCategory && !vee.dataManager.getIsFirstClickCategory9() && this.selectedCategory._idx == 9){
		// if(this.selectedCategory && this.selectedCategory._idx == 9){
			if(vee.Ad.checkCacheVideoAd()){
				VeeAlertSupport.show();
				return;
			}
		}
		*/

		this.isSelectingLevel = true;

		this.pagingCtl.setDragingEnabled(false);
		this.pagingCtl.setCanSwipe(false);

		this.selectedCategory.enter();
		this.ccbLevelCells.setVisible(true);

		this.isAnimating = true;
		game.LevelData.selectedCategory = this.selectedCategory.getCategoryData();

		this.ccbLevelCells.controller.updateCells();

		this.ccbBtnWorld.isCanClick = false;

		this.ccbLevelCells.controller.show(function () {
			this.isAnimating = false;
			this.ccbLevelCells.setLocalZOrder(999);
			this.ccbBtnWorld.isCanClick = true;
		}.bind(this));
	},

	leaveSelectLevel : function(){
		if (this._isOver) return;
		//enter level Select procedure
		this.isSelectingLevel = false;

		this.selectedCategory.out();
		this.ccbLevelCells.setLocalZOrder(0);

		this.isAnimating = true;

		game.LevelData.selectedCategory = null;

		vee.Controller.deactiveSelector();

		this.ccbLevelCells.controller.hide(function () {
			this.isAnimating = false;

			this.pagingCtl.setDragingEnabled(true);
			this.pagingCtl.setCanSwipe(true);

			this.ccbLevelCells.setVisible(false);
		}.bind(this));
	},

	startLevel : function (callback) {
		if (game.Data.costEnergy()) {
			this._isOver = true;
			LyLevelSelect.isUnlocking = true;
			this.pagingCtl.setEnabled(false);
			var delay = game.Data.isEnergyUnlimited() ? 0 : 0.4;
			vee.Utils.scheduleOnceForTarget(this, function () {
				vee.Transition.out(res.MapTransition_ccbi, callback);
			}, delay);
		} else {
			game.Data.onEnergyEmpty(game.LifeEmptyType.Select);
		}
	},

	_tempControllerState : null,
	moonWhiteSceenDebug : false,    //add by zq
	showLevelMap : function (mapType) {
		if (mapType == this._mapType) return;
		this._isFocusMenu = false;
		this._mapType = mapType;
		vee.Controller.deactiveButton();
		vee.Controller.deactiveSelector(true);
		if (mapType == LyLevelSelect.MapType.MAP_NORMAL)
		{
			vee.Transition.perform(res.MapTransition_ccbi, this._showNormal.bind(this), 0, this.showLevelMapFinish.bind(this));
		}
		else if (mapType == LyLevelSelect.MapType.MAP_REVERSE)
		{
			if(!this.moonWhiteSceenDebug){
				this.moonWhiteSceenDebug = true;
				vee.Analytics.logEvent("moonWorld_whiteSceenTag_start");
			}
			vee.Transition.perform(res.MapTransition_ccbi, this._showReverse.bind(this), 0, this.showLevelMapFinish.bind(this));
		}
		if (this.isSelectingLevel) {
			this.leaveSelectLevel();
		}

		this._curMapType = mapType;

		if(game.Data.version.isMidAutumn && this.ccbBtnMoon){
			this.ccbBtnMoon.setVisible(mapType == LyLevelSelect.MapType.MAP_NORMAL && game.Data.version.isShowSpecialLevel());
		}

	},

	showLevelMapFinish : function () {
		vee.Controller.activeButton();
		if(this.moonWhiteSceenDebug){
			this.moonWhiteSceenDebug = false;
			vee.Analytics.logEvent("moonWorld_whiteSceenTag_end");
		}

		// cc.log("showLevelMapFinish------------------------------");
		// if(game.Data.version.isMidAutumn && this.ccbBtnMoon){
		// 	this.ccbBtnMoon.setVisible(this._curMapType == LyLevelSelect.MapType.MAP_NORMAL && game.Data.version.isShowSpecialLevel());
		// }
	},

	_showNormal : function () {
		game.Data.isSelectingReverseWorld = false;
		var colorSet = game.LevelData.getBgColors(this._selectedPage - 1);
		this.resetColor(colorSet);
		this.nodeReverseParticle.setVisible(false);
		// this.nodeNormalParticle.setVisible(true);
		this.nodeNormalParticle.setVisible(true);

		this.ccbBtnWorld.controller.showMoon();
		this.ccbBtnWorld.controller.setNew(false);
		this.refreshCategory();
	},

	_showReverse : function () {
		game.Data.isSelectingReverseWorld = true;
		// set bg color to night
		var colorSet = [
			cc.color(14,6,14,255),
			cc.color(47,34,100,255)
		];
		this.resetColor(colorSet);
		// show particle
		if (this.nodeReverseParticle) this.nodeReverseParticle.setVisible(true);
		// if (this.nodeNormalParticle) this.nodeNormalParticle.setVisible(false);
		if(this.nodeNormalParticle) this.nodeNormalParticle.setVisible(false);
		if (this.ccbBtnWorld) this.ccbBtnWorld.controller.showSun();
		if (this.ccbBtnWorld) this.ccbBtnWorld.controller.setNew(false);
		this.refreshCategory();
	},

	/** paging controller 选定版块，播放动画
	 * @param {vee.PagingController} context
	 * @param duration
	 * @param position
	 */
	animatePagePos : function(context, duration, position) {
		var pageNum = context.getCurrentPageNum();

		if(!this.categoryCtls[pageNum]){
			pageNum = 1;
			this.pagingCtl.setPage(pageNum, false);
		}

		this.selectedCategory = this.categoryCtls[pageNum].select(duration);
		if (pageNum != 1 && this.categoryCtls[pageNum-1]) this.categoryCtls[pageNum-1].disSelect(duration);
		if (pageNum != this._maxPageNum && this.categoryCtls[pageNum+1]) this.categoryCtls[pageNum+1].disSelect(duration);

		if (this._mapType == LyLevelSelect.MapType.MAP_NORMAL) {
			this.updateColor(pageNum);
		}
	},

	updateColor : function (pageNum) {
		if (this._mapType == LyLevelSelect.MapType.MAP_NORMAL) {
			if (pageNum == this._selectedPage) return;
			this._selectedPage = pageNum;
			var colorSet = game.LevelData.getBgColors(pageNum-1);
			this.resetColor(colorSet);
		}

	},

	resetColor : function (colorSet) {
		this.lyBgColor.setOpacity(255);
		this.lyBgColor2.setStartColor(colorSet[1]);
		this.lyBgColor2.setEndColor(colorSet[0]);
		this.lyBgColor.runAction(cc.sequence(
			cc.fadeOut(0.3),
			cc.callFunc(function () {
				this.lyBgColor.setStartColor(this.lyBgColor2.startColor);
				this.lyBgColor.setEndColor(this.lyBgColor2.endColor);
				this.lyBgColor.setOpacity(255);
			}.bind(this))
		));

		/*
		if(this.ccparticle){
			this.ccparticle.setVisible(this._selectedPage == 10);
		}

		if(this.ccbparticleSnow && this._selectedPage == 1){
			this.ccbparticleSnow.setVisible(true);
			vee.Audio.playMusic(res.outGame_menu_levelSelect_mp3);
		}
		else{
			vee.Audio.stopMusic();
		}
		*/
	},

	/** paging controller 实时修改位置
	 * @param {vee.PagingController} context
	 * @param duration
	 * @param position
	 */
	updatePagePos : function(context, position) {
		var offsetX = position.x - context.getCurrentPagePos().x;
		if (offsetX == 0) return;

		var percent = Math.min(1,Math.abs(offsetX)/this.width);
		if (percent > 0.3) this.selectedCategory = null;

		var pageNum = context.getCurrentPageNum();
		this.categoryCtls[pageNum].setOffset(1 - percent);
		if (offsetX > 0 && pageNum > 1) this.categoryCtls[pageNum - 1].setOffset(percent);
		if (offsetX < 0 && pageNum < 5) this.categoryCtls[pageNum + 1].setOffset(percent);
		if (this._isFocusMenu) {
			this._isFocusMenu = false;
			vee.Controller.deactiveSelector(true);
		}
	}

});

LyLevelSelect.isUnlocking = false;
LyLevelSelect.MapType = {
	MAP_NORMAL : 1,
	MAP_REVERSE : 2
};
LyLevelSelect.show = function () {
	vee.soundButton();
	vee.PopMgr.closeAll();

	// if (game.Data.version.isMidAutumn) {
	// 	var ccbName = res.lyLevelSelectNew_ccbi;
	// } else {
		var ccbName = res.lyLevelSelect_ccbi;
	// }
	var node = vee.PopMgr.popCCB(ccbName);
	node.controller.ccbInit();
};

//儿童节跳转按钮
var BtnBalloon = vee.Class.extend({
	spBalloon : null,

	ccbInit : function () {
		this.playAnimate("loop");
		var lang = vee.Utils.getLocalizedStringForKey("lang");
		if (lang == "cn_s" || lang == "cn_t") {
			this.spBalloon.setTexture(res.levelBalloonCN_png);
		}
	},

	onTouch : function () {
		var lvCtl = game.Data.oLvSelectCtl;
		if (lvCtl) {
			if (lvCtl.isSelectingLevel) {
				lvCtl.leaveSelectLevel();
			}
			lvCtl.leaveSelectLevel();
			lvCtl.pagingCtl.setPage(7, true);
		}
	}
});

//中秋关卡跳转按钮
var BtnMoon = vee.Class.extend({

	ccbInit : function(){
		this.playAnimate("loop");
	},

	onTouch : function(){
		var lvCtl = game.Data.oLvSelectCtl;
		if(lvCtl){
			if(lvCtl.isSelectingLevel){
				lvCtl.leaveSelectLevel();
			}
			lvCtl.leaveSelectLevel();
			lvCtl.pagingCtl.setPage(9, true);
		}
	}
});


var EfxFlags = vee.Class.extend({

	loopAnimate : function () {
		this.playAnimate("loop");
	}
});

var BtnSocial = vee.Class.extend({
	nodeAni	: null,
	spDot : null,
	ccbInit : function () {
		var isNew = vee.KTPlay.isNewNotice();
		if (isNew) {
			this.spDot = new cc.Sprite(res.image_redot_png);
			this.nodeAni.addChild(this.spDot);
			this.spDot.setPosition(cc.p(30, 40));
		}
	},

	onKTPlay : function () {
//		if(game.Data.isAndroid){
//			vee.Analytics.loadFeedbackAngent();
//			return;
//		}


// 		if(true){
// 			vee.Ad.showVideoAd();
// // //			vee.GameCenter.autoSaveGame(jsb.fileUtils.getWritablePath(), "autoSave");
// // // 			vee.IAPMgr.getPrice();
// 			return;
// 		}

		vee.KTPlay.show();
		if (this.spDot) this.spDot.setVisible(false);
	}

});