/**
 * Created with AppCode.
 * User: yop
 * Date: 15/9/2
 * Time: 上午10:59
 * To change this template use File | Settings | File Templates.
 */

var CategoryCell = vee.Class.extend({
	_idx : 0,
	/** @type {cc.Node} */
	lyContent : null,
	/** @type {cc.Label} */
	lbTitle : null,
	/** @type {cc.Label} */
	lbPercent : null,
	lbTime : null,
	/** @type {cc.Sprite} */
	spBG : null,
	/** @type {cc.Sprite} */
	spLock : null,
	spLockBg : null,
	spLockStar : null,
	lbStarNum : null,
	nodeLockDesc : null,
	spLockLbStar : null,

	//spLight : null,

	isLock : true,
	categoryReady : false,

	width : 0,

	_categoryData : null,
	_origin : 0,

	onCreate : function () {
		this._origin = this.rootNode.getPosition();
		this._origin.y += 0;
	},

	zqdebugLog : function(str){
		if(this._idx == 8){
			cc.log(str);
		}
	},

	setIndex : function(idx) {
		this._idx = idx;
		/** @type {CategoryData} */
		var data = game.LevelData.getCategory(idx);
		game.LevelData.checkLevelLockState(idx);
		this.lbTitle.setString(vee.Utils.getLocalizedStringForKey(data.title));
		this.lbPercent.setString(data.percent + '%');

		var bgName = data.bg;
		var shouldUnlock = false;
		this.categoryReady = data.categoryReady;

		if (game.Data.isClearVersion || game.Data.isFreeGame) {

			this.lbStarNum.setVisible(false);
			this.nodeLockDesc.setVisible(false);
			this.isLock = (data.lockStatus == game.LevelData.LockStatus.LOCKED);
			this.spLock.setVisible(this.isLock);
			this.spLockBg.setVisible(this.isLock);
			this.spLockStar.setVisible(this.isLock);
			this.lbPercent.setVisible(!this.isLock);
			if (this.isLock) {
				if (game.Data.isSelectingReverseWorld) {
					this.playAnimate("Default Timeline");
				}
				if (!this.categoryReady) {

					if(game.Data.isSelectingReverseWorld){
						this.lbTitle.setString(vee.Utils.getLocalizedStringForKey("COMING SOON"));
						bgName = res.level_image_mid_negative_6_png;
					}
					else{
						this.lbTitle.setString(vee.Utils.getLocalizedStringForKey("MORE GAME"));
						bgName = res.level_image_moregames_png;

						this.spLock.setVisible(false);
						this.spLockBg.setVisible(false);
						this.spLockStar.setVisible(false);
						this.lbStarNum.setVisible(false);
						this.spLockLbStar.setVisible(false);
					}


				}
			} else {
				this.changeToPercentage();
				if (game.Data.isSelectingReverseWorld) {
					bgName = data.bgUnlock;
				}
			}
			if (game.Data.isSelectingReverseWorld) {
				this.spLockStar.setVisible(false);
				this.lbStarNum.setVisible(false);
				this.lbPercent.setVisible(false);
				this.nodeLockDesc.setVisible(false);
			}
			this.spBG.initWithFile(bgName);
			this.lyContent.setCascadeOpacityEnabled(true);
			this.nodeLockDesc.setCascadeOpacityEnabled(true);
			this.width = this.lyContent.getContentSize().width;
			this._categoryData = data;
			return this.isLock;
		} else if (data.lockStatus == game.LevelData.LockStatus.LOCKED || !this.categoryReady) {
			this.spLock.setVisible(true);
			this.spLockBg.setVisible(true);
			this.spLockStar.setVisible(true);
			if (!this.lbTime.isVisible()) {
				this.lbStarNum.setString(game.LevelData.getStar()+" / "+data.unlockStar);
				this.lbStarNum.setOpacity(255);
				this.lbStarNum.setVisible(true);
				this.nodeLockDesc.setVisible(true);
			}
			this.lbPercent.setVisible(false);
			this.isLock = true;
			if (game.Data.isSelectingReverseWorld) {
				this.playAnimate("Default Timeline");
			}
			if (!this.categoryReady) {
				// this.lbTitle.setString(vee.Utils.getLocalizedStringForKey("COMING SOON"));
				// bgName = res.level_image_mid_negative_6_png;
				if(game.Data.isSelectingReverseWorld){
					this.lbTitle.setString(vee.Utils.getLocalizedStringForKey("COMING SOON"));
					bgName = res.level_image_mid_negative_6_png;
				}
				else{
					this.lbTitle.setString(vee.Utils.getLocalizedStringForKey("MORE GAME"));
					bgName = res.level_image_moregames_png;

					this.spLock.setVisible(false);
					this.spLockBg.setVisible(false);
					this.spLockStar.setVisible(false);
					this.lbStarNum.setVisible(false);
					this.spLockLbStar.setVisible(false);
				}
			}
		} else if (data.lockStatus == game.LevelData.LockStatus.READY_TO_UNLOCK) {
			this.spLock.setVisible(true);
			this.spLockBg.setVisible(true);
			this.nodeLockDesc.setVisible(true);
			this.spLockLbStar.setVisible(false);
			shouldUnlock = true;
			this.lbStarNum.setVisible(false);
		} else {
			this.changeToPercentage();
			if (game.Data.isSelectingReverseWorld) {
				bgName = data.bgUnlock;
			}
		}
		if (game.Data.isSelectingReverseWorld) {
			this.spLockStar.setVisible(false);
			this.lbStarNum.setVisible(false);
			this.lbPercent.setVisible(false);
			this.nodeLockDesc.setVisible(false);
		}
		this.spBG.initWithFile(bgName);
		this.lyContent.setCascadeOpacityEnabled(true);
		this.nodeLockDesc.setCascadeOpacityEnabled(true);
		this.width = this.lyContent.getContentSize().width;
		this._categoryData = data;
		return shouldUnlock;
	},

	_getSunWorldBg : function (categoryIdx) {
		var category = game.LevelData.getCategory(categoryIdx-100);
		if (category) {
			return category.bg;
		} else {
			return null;
		}
	},

	setLeftTime : function(timeLeft) {
		this.levelTimeLeft = parseInt(timeLeft);
		this.lbPercent.setVisible(false);
		this.lbStarNum.setVisible(false);
		this.lbTime.setVisible(true);
		this.spLockLbStar.setVisible(false);
		vee.Utils.scheduleCallbackForTarget(this.rootNode, this.updateLevelTimeCounter.bind(this), 1);
	},

	setTimeStr : function() {
		this.lbTime.setString(this.getLevelTimeStr(this.levelTimeLeft));
	},

	getLevelTimeStr : function(leftTime) {
		var h = Math.floor((leftTime) / (60 * 60));
		var m = Math.floor((leftTime / 60 - h * 60));
		var strM = m < 10 ? "0"+m : m;
		var strH = h < 10 ? "0"+h : h;
		return (strH + ":" + strM);
	},

	updateLevelTimeCounter : function() {
		this.levelTimeLeft -= 1;
		if (this.levelTimeLeft > 0) {
			// refresh counter
			this.setTimeStr();
		} else {
			// time up
			vee.Utils.unscheduleAllCallbacksForTarget(this.rootNode);
			vee.data["level61_ts"] = 0;
			game.Data.oLvSelectCtl.unlockCategoryByIdx(7, false);
			vee.saveData();
		}
	},

	getUnlockStarDesc : function (isMoonWorld) {
		var data = game.LevelData.getCategory(this._idx);
		if (isMoonWorld) {
			var reverseData = game.LevelData.getCategory(this._idx - 100);
			return data.levelCount*3 - reverseData.getCategoryStarCount();
		} else {
			return data.unlockStar - game.LevelData.getStar();
		}
	},

	unlockAnimate : function (callback) {
		this.playAnimate("Unlock", function () {
			game.LevelData.setLockStatus(this._idx, game.LevelData.LockStatus.UNLOCKED);
			this.isLock = false;
			if (callback) callback();
		}.bind(this));
	},

	//把星级改为百分比显示
	changeToPercentage : function() {
		this.spLock.setVisible(false);
		this.spLockBg.setVisible(false);
		this.spLockStar.setVisible(false);
		this.nodeLockDesc.setVisible(false);
		this.lbPercent.setVisible(true);
		this.lbTime.setVisible(false);
		this.isLock = false;
	},

	setOffset : function(offsetPercent) {
		this.rootNode.setPositionY(this._origin.y -30 + 30*offsetPercent);
		this.spBG.setOpacity(127 + 128 * offsetPercent);
		var o = Math.max(0, 512*(offsetPercent-0.5)-1);
		this.lbTitle.setOpacity(o);
		this.lbPercent.setOpacity(o);
		if (this._idx == 6) {
			this.lbTime.setOpacity(o);
		}
		this.nodeLockDesc.setOpacity(o);
		//this.spLight.setOpacity(o);
	},

	select : function(duration) {
		this.rootNode.runAction(cc.moveTo(duration, this._origin));
		this.spBG.runAction(cc.fadeTo(duration, 255));
		this.lbTitle.runAction(cc.fadeTo(duration, 255));
		this.lbPercent.runAction(cc.fadeTo(duration, 255));
		if (this._idx == 6) {
			this.lbTime.runAction(cc.fadeTo(duration, 255));
		}
		this.nodeLockDesc.runAction(cc.fadeTo(duration, 255));
		//this.spLight.runAction(cc.fadeTo(duration, 255));
		return this;
	},

	getCategoryData : function(){
		return this._categoryData;
	},

	disSelect : function(duration) {
		if (duration > 0.02) {
			this.rootNode.runAction(cc.moveTo(duration, vee.Utils.pAdd(cc.p(0, -30), this._origin)));
			this.spBG.runAction(cc.fadeTo(duration, 128));
			this.lbTitle.runAction(cc.fadeTo(duration, 0));
			this.lbPercent.runAction(cc.fadeTo(duration, 0));
			if (this._idx == 6) {
				this.lbTime.runAction(cc.fadeTo(duration, 0));
			}
			this.nodeLockDesc.runAction(cc.fadeTo(duration, 0));
		} else {
			this.rootNode.setPosition(vee.Utils.pAdd(cc.p(0, -30), this._origin));
			this.spBG.setOpacity(128);
			this.lbTitle.setOpacity(0);
			this.lbPercent.setOpacity(0);
			if (this._idx == 6) {
				this.lbTime.setOpacity(0);
			}
			this.nodeLockDesc.setOpacity(0);
		}
	},

	enter : function() {
		this.lbTime.setVisible(false);
		this.playAnimate('Enter');
	},

	out : function() {
		this.lbTime.setVisible(false);
		this.playAnimate('Out');
	}
});

var ComingSoonCell = CategoryCell.extend({
	spBG : null,
	isComingSoon : true,

	setIndex : function(idx) {
		this._idx = idx;
	},

	refresh : function () {
		cc.log("zq debug coming soon cell ==============")
		if (game.Data.isSelectingReverseWorld) {
			// this.spBG.setTexture(res.level_image_mid_negative_6_png);
			this.spBG.setTexture(res.level_image_moregames_png);
		}
		// else if(this._idx == 12){
		// 	this.spBG.setTexture(res.level_image_moregames_png);
		// }
		else
		{
			// this.spBG.setTexture(res.level_image_mid_soon_png);
			this.spBG.setTexture(res.level_image_moregames_png);
		}
	},

	select : function(duration) {
		this.rootNode.runAction(cc.moveTo(duration, this._origin));
		this.spBG.runAction(cc.fadeTo(duration, 255));
		return this;
	},

	disSelect : function(duration) {
		this.rootNode.runAction(cc.moveTo(duration, vee.Utils.pAdd(cc.p(0,-30), this._origin)));
		this.spBG.runAction(cc.fadeTo(duration, 128));
	},

	setOffset : function(offsetPercent) {
		this.rootNode.setPositionY(this._origin.y -30 + 30*offsetPercent);
		this.spBG.setOpacity(127 + 128 * offsetPercent);
	}
});