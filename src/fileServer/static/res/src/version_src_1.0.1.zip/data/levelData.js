/**
 * Created with AppCode.
 * User: yop
 * Date: 15/9/2
 * Time: 上午11:15
 * To change this template use File | Settings | File Templates.
 */
var game = game = game || {};

game.LevelData = {

	LockStatus : {
		LOCKED          : 1,
		READY_TO_UNLOCK : 2,
		UNLOCKED        : 3
	},

	categoryCount : 13,// will reset in function: game.LevelData.load()  //历史原因 最大关卡数要+1

	defaultData : [
		{bg : res.level_image_mid_0_png, title : 'OVERTURE', idx : 0, beginLevel : 1,
			levelCount : 3, percent : 0, unlockStar : 0,
			bgUnlock : res.level_image_mid_0_png, categoryReady : true,
			bgColor1 : [0, 222, 186], bgColor2 : [61, 70, 255], lockStatus : 3},
		{bg : res.level_image_mid_1_png, title : 'SOFTLIGHT', idx : 1, beginLevel : 4,
			levelCount : 7, percent : 0, unlockStar : 5,
			bgUnlock : res.level_image_mid_1_png, categoryReady : true,
			bgColor1 : [153,194,255], bgColor2 : [127,13,255], lockStatus : 1},
		{bg : res.level_image_mid_2_png, title : 'RAINFALL', idx : 2, beginLevel : 11,
			levelCount : 7, percent : 0, unlockStar: vee.Utils.getObjByPlatform(20, 20),
			bgUnlock : res.level_image_mid_2_png, categoryReady : true,
			bgColor1 : [255,191,178], bgColor2 : [255,53,181], lockStatus : 1},
		{bg : res.level_image_mid_3_png, title : 'SUNWIND', idx : 3, beginLevel : 18,
			levelCount : 7, percent : 0, unlockStar: vee.Utils.getObjByPlatform(40, 40),
			bgUnlock : res.level_image_mid_3_png, categoryReady : true,
			bgColor1 : [255,220,127], bgColor2 : [255,80,45], lockStatus : 1},
		{bg : res.level_image_mid_4_png, title : 'DREAMLAND', idx : 4, beginLevel : 25,
			levelCount : 7, percent : 0, unlockStar: vee.Utils.getObjByPlatform(60, 60),
			bgUnlock : res.level_image_mid_4_png, categoryReady : true,
			bgColor1 : [255,148,137], bgColor2 : [75, 0, 199], lockStatus : 1},
		{bg : res.level_image_mid_5_png, title : 'SNOWFLAKE', idx : 5, beginLevel : 32,
			levelCount : 7, percent : 0, unlockStar: vee.Utils.getObjByPlatform(70, 70),
			bgUnlock : res.level_image_mid_5_png, categoryReady : true,
			bgColor1 : [224, 136, 255], bgColor2 : [0,18,190], lockStatus : 1},

		{bg : res.level_image_mid_Child_png, title : 'OLDTIME', idx : 6, beginLevel : 39,
			levelCount : 3, percent : 0, unlockStar: 999,
			bgUnlock : res.level_image_mid_Child_png, categoryReady : true,
			bgColor1 : [255,116,214], bgColor2 : [255,129,53], lockStatus : 1},

		{bg : res.level_image_mid_autumn_png, title : 'AUTUMNIGHT', idx : 7, beginLevel : 42,
			levelCount : 3, percent : 0, unlockStar: 999,
			bgUnlock : res.level_image_mid_autumn_png, categoryReady : true,
			bgColor1 : [65, 47, 143], bgColor2 : [114, 55, 141], lockStatus : 1},

		{bg : res.level_image_mid_halloween_png, title : 'HALLOWEEN', idx : 8, beginLevel : 45,
			levelCount : 3, percent : 0, unlockStar: 999,
			bgUnlock : res.level_image_mid_autumn_png, categoryReady : true,
			bgColor1 : [159, 66, 16], bgColor2 : [57, 28, 101], lockStatus : 1},

		{bg : res.level_image_mid_thanks_png, title : 'DISCORUN', idx : 9, beginLevel : 48,
			levelCount : 7, percent : 0, unlockStar: 999,
			bgUnlock : res.level_image_mid_autumn_png, categoryReady : true,
			bgColor1 : [255, 0, 210], bgColor2 : [81, 0, 191], lockStatus : 1},

		{bg : res.level_image_springtime_png, title : 'SPRINGTIME', idx : 10, beginLevel : 55,
			levelCount : 3, percent : 0, unlockStar: 999,
			bgUnlock : res.level_image_springtime_png, categoryReady : true,
			bgColor1 : [255, 178, 95], bgColor2 : [255, 51, 17], lockStatus : 1},

		{bg : res.level_image_moregames_png, bgColor1 : [97,194,255], bgColor2 : [62, 23, 188], lockStatus : 1, categoryReady : false}

//		{bg : res.level_image_mid_Child_png, title : 'OLDTIME', idx : 6, beginLevel : 39,
//			levelCount : 3, percent : 0, unlockStar: 999,
//			bgUnlock : res.level_image_mid_Child_png, categoryReady : true,
//			bgColor1 : [255,116,214], bgColor2 : [255,129,53], lockStatus : 3}
		//change end

		// bgColor for coming soon
//		{bgColor1 : [97,194,255], bgColor2 : [62, 23, 188], lockStatus : 1}
	],

	// for all unlock
//	defaultData : [
//		{bg : res.level_image_mid_0_png, title : 'OVERTURE', idx : 0, beginLevel : 1,
//			levelCount : 3, percent : 0, unlockStar : 0,
//			bgUnlock : res.level_image_mid_0_png, categoryReady : true,
//			bgColor1 : [0,222,186], bgColor2 : [61,70,255], lockStatus : 3},
//		{bg : res.level_image_mid_1_png, title : 'SOFTLIGHT', idx : 1, beginLevel : 4,
//			levelCount : 7, percent : 0, unlockStar : 5,
//			bgUnlock : res.level_image_mid_1_png, categoryReady : true,
//			bgColor1 : [153,194,255], bgColor2 : [127,13,255], lockStatus : 3},
//		{bg : res.level_image_mid_2_png, title : 'RAINFALL', idx : 2, beginLevel : 11,
//			levelCount : 7, percent : 0, unlockStar: vee.Utils.getObjByPlatform(20, 20),
//			bgUnlock : res.level_image_mid_2_png, categoryReady : true,
//			bgColor1 : [255,191,178], bgColor2 : [255,53,181], lockStatus : 3},
//		{bg : res.level_image_mid_3_png, title : 'SUNWIND', idx : 3, beginLevel : 18,
//			levelCount : 7, percent : 0, unlockStar: vee.Utils.getObjByPlatform(40, 40),
//			bgUnlock : res.level_image_mid_3_png, categoryReady : true,
//			bgColor1 : [255,220,127], bgColor2 : [255,80,45], lockStatus : 3},
//		{bg : res.level_image_mid_4_png, title : 'DREAMLAND', idx : 4, beginLevel : 25,
//			levelCount : 7, percent : 0, unlockStar: vee.Utils.getObjByPlatform(60, 60),
//			bgUnlock : res.level_image_mid_4_png, categoryReady : true,
//			bgColor1 : [255,148,137], bgColor2 : [75, 0, 199], lockStatus : 3},
//		{bg : res.level_image_mid_5_png, title : 'SNOWFLAKE', idx : 5, beginLevel : 32,
//			levelCount : 7, percent : 0, unlockStar: vee.Utils.getObjByPlatform(70, 70),
//			bgUnlock : res.level_image_mid_5_png, categoryReady : true,
//			bgColor1 : [224, 136, 255], bgColor2 : [0,18,190], lockStatus : 3},
//		{bg : res.level_image_mid_Child_png, title : 'OLDTIME', idx : 6, beginLevel : 39,
//			levelCount : 3, percent : 0, unlockStar: 0,
//			bgUnlock : res.level_image_mid_Child_png, categoryReady : true,
//			bgColor1 : [255,116,214], bgColor2 : [255,129,53], lockStatus : 3}
//		// bgColor for coming soon
//		// there`s no coming soon cell
////		{bgColor1 : [97,194,255], bgColor2 : [62, 23, 188], lockStatus : 1}
//	],

	initReverseWorldData : function () {
		// init reverse category data
		this.defaultData[100] = {bg : res.level_image_mid_negative_0_png, title : 'CRESCENT', idx : 100, beginLevel : 101,
			levelCount : 3, percent : 0, unlockStar : 999,
			bgUnlock : res.level_image_mid_moon_0_png, categoryReady : true,
			bgColor1 : [0,222,186], bgColor2 : [61,70,255], lockStatus : 1};
		this.defaultData[101] = {bg : res.level_image_mid_negative_1_png, title : 'MOONLIGHT', idx : 101, beginLevel : 104,
			levelCount : 7, percent : 0, unlockStar : 999,
			bgUnlock : res.level_image_mid_moon_1_png, categoryReady : true,
			bgColor1 : [153,194,255], bgColor2 : [127,13,255], lockStatus : 1};
		this.defaultData[102] = {bg : res.level_image_mid_negative_2_png, title : 'MOONFALL', idx : 102, beginLevel : 111,
			levelCount : 7, percent : 0, unlockStar: 999,
			bgUnlock : res.level_image_mid_moon_2_png, categoryReady : true,
			bgColor1 : [255,191,178], bgColor2 : [255,53,181], lockStatus : 1};
		this.defaultData[103] = {bg : res.level_image_mid_negative_3_png, title : 'MOONWIND', idx : 103, beginLevel : 118,
			levelCount : 7, percent : 0, unlockStar: 999,
			bgUnlock : res.level_image_mid_moon_3_png, categoryReady : true,
			bgColor1 : [255,220,127], bgColor2 : [255,80,45], lockStatus : 1};
		this.defaultData[104] = {bg : res.level_image_mid_negative_4_png, title : 'MOONLAND', idx : 104, beginLevel : 125,
			levelCount : 7, percent : 0, unlockStar: 999,
			bgUnlock : res.level_image_mid_moon_4_png, categoryReady : true,
			bgColor1 : [255,148,137], bgColor2 : [75, 0, 199], lockStatus : 1};
		this.defaultData[105] = {bg : res.level_image_mid_negative_5_png, title : 'MOONFLAKE', idx : 105, beginLevel : 132,
			bgUnlock : res.level_image_mid_moon_5_png,
			levelCount : 7, percent : 0, unlockStar: 999, categoryReady : false,
			bgColor1 : [224, 136, 255], bgColor2 : [0,57,174], lockStatus : 1};
		this.defaultData[106] = {bgColor1 : [97,194,255], bgColor2 : [62, 23, 188], lockStatus : 1};
		this.defaultData[107] = {bgColor1 : [97,194,255], bgColor2 : [62, 23, 188], lockStatus : 1};
		this.defaultData[108] = {bgColor1 : [97,194,255], bgColor2 : [62, 23, 188], lockStatus : 1};
		this.defaultData[109] = {bgColor1 : [97,194,255], bgColor2 : [62, 23, 188], lockStatus : 1};
		this.defaultData[110] = {bgColor1 : [97,194,255], bgColor2 : [62, 23, 188], lockStatus : 1};
		this.defaultData[111] = {bgColor1 : [97,194,255], bgColor2 : [62, 23, 188], lockStatus : 1};

		// init reverse level data
		this.levelMap[100] = "229R";
		this.levelMap[101] = "230R";
		this.levelMap[102] = "233R";
		this.levelMap[103] = "100R";
		this.levelMap[104] = "222R";
		this.levelMap[105] = "200R";
		this.levelMap[106] = "231R";
		this.levelMap[107] = "204R";
		this.levelMap[108] = "247R";
		this.levelMap[109] = "201R";
		this.levelMap[110] = "111R";
		this.levelMap[111] = "236R";
		this.levelMap[112] = "106R";
		this.levelMap[113] = "243R";
		this.levelMap[114] = "103R";
		this.levelMap[115] = "115R";
		this.levelMap[116] = "235R";
		this.levelMap[117] = "117R";
		this.levelMap[118] = "246R";
		this.levelMap[119] = "112R";
		this.levelMap[120] = "242R";
		this.levelMap[121] = "114R";
		this.levelMap[122] = "244R";
		this.levelMap[123] = "116R";
		this.levelMap[124] = "108R";
		this.levelMap[125] = "105R";
		this.levelMap[126] = "223R";
		this.levelMap[127] = "113R";
		this.levelMap[128] = "253R";
		this.levelMap[129] = "109R";
		this.levelMap[130] = "252R";
		this.levelMap[131] = "254R";
		this.levelMap[132] = "256R";
		this.levelMap[133] = "245R";
		this.levelMap[134] = "257R";
		this.levelMap[135] = "258R";
		this.levelMap[136] = "248R";
		this.levelMap[137] = "261R";
	},

	levelMap : {
		0: 229,
		1: 230,
		2: 233,
		3: 100,
		4: 222,
		5: 200,
		6: 231,
		7: 204,
		8: 247,
		9: 201,
		10: 111,
		11: 236,
		12: 106,
		13: 243,
		14: 103,
		15: 115,
		16: 235,
		17: 117,
		18: 246,
		19: 112,
		20: 242,
		21: 114,
		22: 244,
		23: 116,
		24: 108,
		25: 105,
		26: 223,
		27: 113,
		28: 253,
		29: 109,
		30: 252,
		31: 254,
		32: 256,
		33: 245,
		34: 257,
		35: 258,
		36: 248,
		37: 261,
		38: "Children1",
		39: "Children2",
		40: "Children3",
		41: "Moon1",
		42: "Moon2",
		43: "Moon3",
		44: "Hollow1",
		45: "Hollow2",
		46: "Hollow3",
		47: "Parkour1",
		48: "Parkour2",
		49: "Parkour3",
		50: "Parkour4",
		51: "Parkour5",
		52: "Parkour6",
		53: "Parkour7",
		54: "Spring1",
		55: "Spring2",
		56: "Spring3",
	},

	/** @type {CategoryData} */
	selectedCategory : null,
	/** @type {CategoryData.LevelDataController} */
	selectedLevel : null,
	/** @type {CategoryData} */
	categories : [],

	coreData : null,

	getDefaultData : function (idx) {
		return this.defaultData[idx];
	},

	/** @return {CategoryData} */
	getCategory : function(idx) {
		// cc.log("get category idx====" + idx);
		if (!this.coreData) this.load();

		var df = this.defaultData[idx];
		if (!df) return null;

		if (!this.categories[idx]) {
			var percent = this.coreData.percents[idx];
			var lockStatus = this.coreData.lockStatus[idx];
			this.categories[idx] = new CategoryData(
				df.bg,
				df.title,
				df.idx,
				df.beginLevel,
				df.levelCount,
				(percent ? percent : 0),
				df.unlockStar,
				(lockStatus ? lockStatus : df.lockStatus),
				df.bgUnlock,
				df.categoryReady
			);
			this.categories[idx].updatePercent();
		}

		this.categories[idx].categoryReady = df.categoryReady;

		return this.categories[idx];
	},

	getCurrentLevelMapIndex : function() {
		return this.levelMap[this.selectedLevel.getLevelNo()-1];
	},

	getBgColors : function(idx) {
//		if (idx == 7) {
//			idx = 6;
//		}
// 		cc.log("get bg color idx====" + idx);
		if(idx > game.LevelData.categoryCount - 2){
			idx = game.LevelData.categoryCount - 2;
		}
		var c1 = this.defaultData[idx].bgColor1;
		var c2 = this.defaultData[idx].bgColor2;
		return [
			cc.color(c1[0], c1[1], c1[2], 255),
			cc.color(c2[0], c2[1], c2[2], 255)
		];
	},

	getNextCategory : function() {
		return this.getCategory(this.selectedCategory.idx + 1);
	},

	setPercent : function (categoryIdx, percent) {
		this.coreData.percents[categoryIdx] = percent;
		this.save();
	},

	setLockStatus : function (categoryIdx, status) {
		if (this.categories[categoryIdx])
		{
			this.coreData.lockStatus[categoryIdx] = status;
			this.categories[categoryIdx].lockStatus = status;
			this.save();
		}
	},

	load : function() {
		//if (game.Data.is61) {
		//	this.categoryCount = 8;
		//} else {
		//	this.categoryCount = 7;
		//}
		this.categoryCount = 13;         //历史原因 最大关卡数要+1
		vee.VIPValues.load({
			coin : 0,
			star : 0
		});
		this.coreData = vee.Utils.loadObj('AtadLevel');
		if (!this.coreData) {
			this.coreData = {
				percents   : {},
				lockStatus : {"0" : 3, "1" : 1, "2" : 1, "3" : 1, "4" : 1, "5" : 1, "6" : 1, "7" : 1, "8" : 1, "9" : 1, "10" : 1, "11" : 1, "12" : 1,
							  "100" : 1, "101" : 1, "102" : 1, "103" : 1, "104" : 1, "105" : 1, "106" : 1, "107" : 1, "108" : 1, "109" : 1, "110" : 1, "111" : 1, "112" : 1}

				// for all unlock
//				lockStatus : {"0" : 3, "1" : 3, "2" : 3, "3" : 3, "4" : 3, "5" : 3, "6" : 3, "7" : 3, "8" : 3, "9" : 3, "10" : 3, "11" : 3, "12" : 3,
//							  "100" : 3, "101" : 3, "102" : 3, "103" : 3, "104" : 3, "105" : 3, "106" : 3, "107" : 3, "108" : 3, "109" : 3, "110" : 3, "111" : 3, "112" : 3}

				// for beta
//				lockStatus : {"0" : 3, "1" : 3, "2" : 3, "3" : 3, "4" : 3, "5" : 3, "6" : 1, "7" : 1, "8" : 1, "9" : 1, "10" : 1, "11" : 1, "12" : 1}
				// for demo
//				lockStatus : {"0" : 3, "1" : 3, "2" : 3, "3" : 3, "4" : 3, "5" : 3, "6" : 1, "7" : 1, "8" : 1, "9" : 1, "10" : 1, "11" : 1, "12" : 1}
			};
			this.save();
		}
	},

	save : function() {
		vee.Utils.saveObj(this.coreData, 'AtadLevel');
		vee.VIPValues.save();
	},

	getStar : function() {
		return vee.VIPValues.getValue('star') || "0";
	},

	addStar : function(num) {
		var star = this.getStar();
		vee.VIPValues.add2Value('star',num);
		star = this.getStar();
		vee.Analytics.UGameEvent.registerSuperProperty("super_starCount", star);
		for(var i in this.defaultData) {
			var df = this.defaultData[i];
			if (star >= df.unlockStar) {
				cc.log("this.coreData.lockStatus["+i+"] = "+this.coreData.lockStatus[i]);
				if (this.coreData.lockStatus[i] == game.LevelData.LockStatus.LOCKED) {
//					if (game.Data.isAndroid && game.Data.isFreeGame) return;
					if (game.Data.isFreeGame) return;
					this.setLockStatus(i, game.LevelData.LockStatus.READY_TO_UNLOCK);
				}
			}
		}
	},

	checkLevelLockState : function(categoryIdx) {
		var star = this.getStar();
		var df = this.defaultData[categoryIdx];
		if (df) {
			if (categoryIdx < 100) {
				// normal world unlock logic
				this._checkNormalCategoryUnlock(categoryIdx, df.unlockStar);
				this._checkMoonCategoryUnlock(categoryIdx+100);
			} else {
				// moon world unlock logic
				this._checkMoonCategoryUnlock(categoryIdx);
			}
		}
	},

	_checkNormalCategoryUnlock : function (normalCategoryIdx, starToUnlock) {
//		if (game.Data.isAndroid && game.Data.isFreeGame) return;
		if (game.Data.isFreeGame) return;
		var star = this.getStar();
		if (star >= starToUnlock) {
			cc.log("this.coreData.lockStatus[" + normalCategoryIdx + "] = " + this.coreData.lockStatus[normalCategoryIdx]);
			if (this.coreData.lockStatus[normalCategoryIdx] == game.LevelData.LockStatus.LOCKED) {
				this.setLockStatus(normalCategoryIdx, game.LevelData.LockStatus.READY_TO_UNLOCK);
			}
		}
	},

	_checkMoonCategoryUnlock : function (moonCategoryIdx) {
		if (!game.Data.isReverseWorldOpen) return;
		var category = game.LevelData.getCategory(moonCategoryIdx-100);
		var moonCategory = game.LevelData.getCategory(moonCategoryIdx); // make sure moon category exist
		if (!moonCategory.categoryReady) return;
		category.updatePercent();

		var unlockfunc = function(){
			if (moonCategory.lockStatus != game.LevelData.LockStatus.UNLOCKED) {
				game.Data.newReverseWorldIdx = moonCategoryIdx;
			}
			this.setLockStatus(moonCategoryIdx, game.LevelData.LockStatus.UNLOCKED);
		}.bind(this);

//		if (category.levels[category.levels.length - 1].isLevelPassed) {
		var firstCate = game.LevelData.getCategory(0);

		if (game.Data.version.newVersion) {
			if(firstCate.levels[firstCate.levels.length - 1].isLevelPassed && category.levels[0].isLevelPassed){
				unlockfunc();
			}
		}
		else if(category.levels[category.levels.length - 1].isLevelPassed){
			unlockfunc();
		}
		else {
			this.setLockStatus(moonCategoryIdx, game.LevelData.LockStatus.LOCKED);
		}
	},

	getCoin : function() {
		return vee.VIPValues.getValue('coin');
	},

	addCoin : function(num) {
		vee.VIPValues.add2Value('coin', num);
		vee.VIPValues.save();
	},

	costCoin : function(num) {
		this.addCoin(-num);
		vee.VIPValues.save();
	},

	resetCoin : function () {
		vee.VIPValues.setValue('coin', 0);
		vee.VIPValues.save();
	},

	checkParkourlevelUnlock : function (levelId) {
		if(!game.Data.isFreeGame || vee.dataManager.isUnlockParkourLevel(levelId) == "true" || vee.dataManager.isAllParkourLevelUnlock() == "true"){
			return true;
		}
		return false;
	}
};

game.MiniLevelData = {
	levels : [
		[101],
		[101,100,107,201,205],
		[201,205,206,103,204,108],
		[204,108,200,105,202],
		[202,104,203,106]
	],

	getMiniGameIdx : function (categoryIdx) {
		if (categoryIdx > 0 && categoryIdx < this.levels.length) {
			var arrLevels = this.levels[categoryIdx];
			var len = arrLevels.length;
			var selectedIdx = -1;
			var mapSign = null;
			var arrUnfinishedMap = [];
			for (var i = 0; i < len; ++i) {
				var levelIdx = arrLevels[i];
				var miniLevelSign = parseInt(vee.data["miniid"+levelIdx]);
				cc.log("checking levelIdx = "+levelIdx);
				cc.log("checking map sign = "+miniLevelSign);
//				if (miniLevelSign == 1) arrUnfinishedMap.push(levelIdx);
				if (!miniLevelSign) {
					selectedIdx = levelIdx;
					mapSign = null;
					cc.log("selected : "+selectedIdx);
					break;
				} else {
					if (selectedIdx == -1) {
						selectedIdx = levelIdx;
						mapSign = miniLevelSign;
						cc.log("selected : "+selectedIdx);
					} else {
						if (mapSign > miniLevelSign) {
							selectedIdx = levelIdx;
							mapSign = miniLevelSign;
							cc.log("selected : "+selectedIdx);
						}
					}
				}
			}

			if (mapSign != null) {
				// random
				selectedIdx = vee.Utils.randomChoice(arrLevels);
			}
			cc.log("selectedIdx = "+selectedIdx);
			cc.log("map sign = "+mapSign);
			return selectedIdx;
		} else {
			return null;
		}
	},

	setMiniGameProgress : function (progress, categoryIdx, levelIdx) {
		var miniLevelSign = parseInt(vee.data["miniid"+levelIdx]);
		if (progress > miniLevelSign || !miniLevelSign) {
			cc.log("refresh mini sign : ctg "+categoryIdx+" level "+levelIdx);
			vee.data["miniid"+levelIdx] = progress;
			vee.saveData();
		}
	}


};






