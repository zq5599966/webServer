/**
 * Created with AppCode.
 * User: yop
 * Date: 15/10/30
 * Time: 下午7:02
 * To change this template use File | Settings | File Templates.
 */


LevelController.LevelEvent205 = LevelController.extend({
	eventStory1 : function(grid, dir) {
		this.showStory(1, grid, ""+
			"SelectNpc,Flash;"+
			"FaceTo,left;"+
			"MoveCamera,17,18,2;"+
			"FaceTo,right;"+
			"MoveRole,10,16;"+
			"Jump,13,17;"+
			"MoveRole,16,17;"+
			"ShowDialog,"+ vee.Utils.getLocalizedStringForKey("Good timing, my friend!", "来的正好，我的朋友！") +";"+
			"ShowDialog,"+ vee.Utils.getLocalizedStringForKey("Time to make some noise!", "是时候吓你一跳了！") +";"+
			"ShowDialog,"+ vee.Utils.getLocalizedStringForKey("Are you ready?", "准备好了吗？") +";"+
			"HideDialog;"+
			"UnlockRole;"+
			"TimeLine,huxi_2;"+
			"Delay,1;"+
			"Trigger,16,19;"+
			"MoveCamera,20,15,1;"+
			"Delay,1;"+
			"MoveCamera,7,15,1;"+
			"Delay,1;"+
			"MoveCamera,17,18,2;"+
			"ShowDialog,"+ vee.Utils.getLocalizedStringForKey("You won't ever be another me, but you can copy my data!", "虽然你不会变的像我这么厉害，要不要交换一下数据？") +";"+
			"ShowDialog,"+ vee.Utils.getLocalizedStringForKey("Maybe you can catch up with me someday!", "也许在以后你能够强过我呢！") +";"+
			"ShowDialog,"+ vee.Utils.getLocalizedStringForKey("Good luck!", "祝你好运~") +";"+
			"HideDialog;"+
			"Delay,1"+
		"");
	}
});