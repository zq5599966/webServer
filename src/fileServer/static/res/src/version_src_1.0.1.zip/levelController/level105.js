/**
 * Created with AppCode.
 * User: WanThirty
 * Date: 15/11/18
 * Time: 下午6:19
 * To change this template use File | Settings | File Templates.
 */

LevelController.Level105 = LevelController.extend({

	complete : function () {
		if (game.Data.jumpCount == 0) {
			vee.GameCenter.unlockAchievement(6);
		}
	}
});