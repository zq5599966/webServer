/**
 * Created with AppCode.
 * User: yop
 * Date: 15/10/27
 * Time: 下午3:33
 * To change this template use File | Settings | File Templates.
 */

LevelController.LevelMini106 = LevelController.extend({
	eventStory1 : function(grid, dir) {
		this.showStory(1, grid, ""+
		"RemoveEnemy;"+
		"MoveCamera,21,7,1;"+
		"SelectNpc;"+
		"ShowDialog,"+ vee.Utils.getLocalizedStringForKey("Good Job -- but this isn't enough.", "还不错，但是还不够。") +";"+
		"ShowDialog,"+ vee.Utils.getLocalizedStringForKey("Try to catch me next time!", "下次再来尝试抓住我吧！") +";"+
		"HideDialog;"+
		"TimeLine,huxi_2;"+
		"Delay,1;"+
		"AddCoin," + vee.Utils.getObjByPlatform('700','900','700') + ";"+
		"Delay,2;"+
		"GameOver"+
		"");
	}
});
