/**
 * Created with AppCode.
 * User: WanThirty
 * Dat  e: 15/6/26
 * Time: 下午2:48
 * To change this template use File | Settings | File Templates.
 */

var EnemySusliks = Enemy.extend({
	objType : game.ObjectType.Susliks,
	needRefreshPos : false,
	resetStatus : function () {
		this.needRefreshPos = false;
	},
	show : function () {
		this.playAnimate("in");
		this.initPosition(this._container.getPosition());
	},

	disappear : function () {
		this._hasCollide = false;
		vee.Utils.unscheduleAllCallbacksForTarget(this.rootNode);
		++EnemySusliks.disappearCount;
		if (EnemySusliks.disappearCount == EnemySusliks.arrSusliks.length) {
			// TODO: Failed
			EnemySusliks.removeAllSusliks();
			this.playAnimate("out", function(){
				this._container.setVisible(false);
			}.bind(this));
		} else {
			this.playAnimate("out", function(){
				this._container.setVisible(false);
			}.bind(this));
		}
	},

	setElePosition : function(pos) {
		this._container.setPosition(pos);
	},

	setDir : function (dir) {
		// TODO: rotate
		switch (dir) {
			case vee.Direction.Left:
				this._container.setRotation(-90);
				break;
			case vee.Direction.Right:
				this._container.setRotation(90);
				break;
			case vee.Direction.Bottom:
				this._container.setRotation(180);
				break;
			default :
				break;
		}
	},

	_hasCollide : true,
	collide : function(dir) {
		if (game.Data.playerInvisible || !this._hasCollide) return;
		if (dir == vee.Direction.Top && game.Data.oPlayerCtl._speedY < 0 && !game.Data.oPlayerCtl.extendController) {
			var pos = this.getElePosition();
			EfxEnemyDie.show(pos);
			this.popPlayerUp();
			this.costHP(dir);
		} else if (game.Data.playerHawk) {
			game.Data.oLyGame.shake();
			this.dieAnimate(dir);
		} else if (dir == vee.Direction.Bottom && game.Data.oPlayerCtl._speedY > 0) {
			var pos = this.getElePosition();
			EfxEnemyDie.show(pos);
			game.Data.oPlayerCtl.upToBarrier();
			this.costHP(dir);
		} else {
			if (game.Data.playerInvisible) return;
			game.Data.oPlayerCtl.getShock(dir, true);
		}
	},

	costHP : function (dir) {
		this._hasCollide = false;
		vee.Utils.unscheduleAllCallbacksForTarget(this.rootNode);
		this._container.stopAllActions();
		++EnemySusliks.killCount;
		++EnemySusliks.disappearCount;
		this.playAnimate("in2", function () {
			if (EnemySusliks.arrSusliks.length == EnemySusliks.killCount) {
				// TODO: Success bonus
				EnemySusliks.removeAllSusliks();
			} else if (EnemySusliks.disappearCount == EnemySusliks.arrSusliks.length) {
				// TODO: Failed
				EnemySusliks.removeAllSusliks();
			} else {
				this.playAnimate("loop2");
			}
		}.bind(this));
	},

	hitByStar : function () {
		if (this._isOver) return;
		this.costHP();
	},

	getInhaleController : function () {
		return null;
	},

	die : function () {
		this.onDead();
		vee.Audio.playEffect("res/inGame_event_deathMonster_"+vee.Utils.randomInt(1,6)+".mp3");
		game.Data.removeUsingEnemy(this);
		this._container.stopAllActions();
		this._isOver = true;
		this._hasCollide = false;
		vee.Utils.unscheduleAllCallbacksForTarget(this.rootNode);
		if (this._container.isVisible()) {
			this.playAnimate("out", function(){
				this._container.removeFromParent();
			}.bind(this), false);
		} else {
			this._container.removeFromParent();
		}
	}
});

EnemySusliks.create = function (pos, dir) {
	var node = cc.BuilderReader.load(res.eleDiShu_ccbi);
	var container = new cc.Node();
	container.addChild(node);
	node.controller._container = container;
	node.controller.setDir(dir);
	container.setPosition(pos);
	return node.controller;
};

EnemySusliks.killCount = 0;
EnemySusliks.disappearCount = 0;
EnemySusliks.arrSusliks = null;

EnemySusliks.removeAllSusliks = function () {
	var len = this.arrSusliks.length;
	for (var i = 0; i < len; ++i) {
		var susCtl = this.arrSusliks[i];
		susCtl.die();
	}
	EnemySusliks.arrSusliks = null;
	EnemySusliks.killCount = 0;
	EnemySusliks.disappearCount = 0;
};