/**
 * Created with AppCode.
 * User: WanThirty
 * Date: 15/7/20
 * Time: 下午4:15
 * To change this template use File | Settings | File Templates.
 */

var EnemyJumpSlime = Enemy.extend({
	objType : game.ObjectType.JumpSlime,
	linkedSlime : null,
	hasLinkedSlime : false,
	jumpCount : 0,
	slimeSign : "slime parent ",
	_lastJumpPos : null,
	initGrid : null,
	limitLeft : null,
	limitRight : null,

	bornWithPos : function (pos) {
		var castPos = cc.p(pos.x, pos.y - (TILE_WIDTH_HALF - this.boxSize.height/2));
		this.setElePosition(castPos);
		this._container.stopAllActions();
		this.playAnimate("huxi");
		this._hasCollide = true;
		this._hasG = false;
		this._needSafePos = false;
		this.needRefreshPos = false;
		var mapConfig = game.Logic.configMap.getObject(this._grid);
		var createLinkedSlime = true;

		// reset
//		this._lastJumpPos = null;
//		this.limitLeft = null;
//		this.limitRight = null;

		// check create link by map config
		if (mapConfig) {
			if (mapConfig.slimeCount == "1") createLinkedSlime = false;
			var arrArgs = mapConfig.name.split(",");
			var len = arrArgs.length;
			if (len > 0) this.limitLeft = this._grid.x + parseInt(arrArgs[0]);
			if (len > 1) this.limitRight = this._grid.x + parseInt(arrArgs[1]);
			if (len > 2) {
				if (arrArgs[2] == "right") {
					this._faceTo = vee.Direction.Right;
					this._container.setScaleX(1);
				}
			}
		}

		if (this.objType == game.ObjectType.JumpFrog) {
			cc.log("asdfasdfasdfasdfasdfasdf");
			createLinkedSlime = false;
		}

		// create linked slime
		if (!this.linkedSlime && createLinkedSlime) {
			this.initGrid = cc.p(this._grid.x, this._grid.y);
			var enemy = Enemy.createWithInfo({type : game.ObjectType.JumpSlimeLink, dir : vee.Direction.Left});
			// link each other
			enemy.controller.objType = game.ObjectType.JumpSlimeLink;
			enemy.controller.linkedSlime = this;
			enemy.controller.hasLinkedSlime = true;
			enemy.controller.limitLeft = this.limitLeft;
			enemy.controller.limitRight = this.limitRight;
			this.linkedSlime = enemy.controller;
			this.hasLinkedSlime = true;
			// show enemy
			var grid = game.Logic.getTileGridByPos(pos);
			grid.y -= 1;
			var pos = game.Logic.getTilePosByGrid(grid);
			enemy.controller._grid = grid;
			enemy.controller.initGrid = cc.p(grid.x, grid.y);
//			enemy.controller.setGridInMap(grid);
			enemy.controller.initPosition(cc.p(pos.x, castPos.y+this.boxSize.height/2 + TILE_WIDTH));
			enemy.controller.slimeSign = "slime child ";
			game.Logic.dynamicObjMap.setObject(enemy.controller, grid);
			game.Data.usingEnemyPool.push(enemy.controller);
			enemy.controller.afterCreate();
			enemy.controller.jumpCount = 1;
			enemy.controller.slimeJump();
		} else if (createLinkedSlime == false) {
			this.slimeJump();
		}
	},

	isSlimeJumping : false,
	slimeJump : function () {
		// search target grid...
		if (!this.linkedSlime) {
			// jump directly
			var targetGrid = this.getTargetPoint();
			this.jumpTo(targetGrid);
			this.isSlimeJumping = true;
		} else if (this.jumpCount > 0) {
			// jump
			var targetGrid = this.getTargetPoint();
			this.jumpTo(targetGrid);
			--this.jumpCount;
			cc.log(this.slimeSign+vee.Direction.direction2String(this._faceTo));
			this.isSlimeJumping = true;
		} else {
			// let linked slime jump
			this.linkedSlime.jumpCount = 2;
			this.linkedSlime.slimeJump();
			this.isSlimeJumping = false;
		}
	},

	jumpTo : function (targetPos) {
		if (!targetPos) return;
		if (!this.linkedSlime && this.hasLinkedSlime) this.hasLinkedSlime = false;
		var grid = game.Logic.getTileGridByPos(targetPos);
		var len = grid.x - this._grid.x;
		if (len > 0) {
			this._container.setScaleX(1);
		} else {
			this._container.setScaleX(-1);
		}
		this._faceTo = len > 0 ? vee.Direction.Right : vee.Direction.Left;
		this.playAnimate("jump_up");
		if (!this._isOver) vee.Audio.playEffect(res.inGame_action_jump_mp3);
		this._container.runAction(cc.sequence(
			cc.spawn(
				cc.EaseInOut.create(cc.jumpTo(0.7, targetPos.x, targetPos.y, Math.abs(len)*game.Data.tileSizeWidth, 1), EnemyJumpSlime.jumpEase),
				cc.sequence(
					cc.delayTime(0.2),
					cc.callFunc(function () {
						if (this.linkedSlime) this.linkedSlime._container.setScaleX(this._container.getScaleX());
					}.bind(this))
				)
			),
			cc.callFunc(function () {
				this.playAnimate("jump_down");
				if (!this.linkedSlime && this.hasLinkedSlime) {
					this.hasLinkedSlime = false;
					this._container.runAction(cc.moveBy(0.3, cc.p(0, -this.boxSize.height)));
				}
			}.bind(this)),
			cc.delayTime(0.6),
			cc.callFunc(function () {
				this.setElePosition(this._container.getPosition());
				this.onGridChanged();
				this.slimeJump();
			}.bind(this))
		));
		this._lastJumpPos = this.getElePosition();
	},

	getTargetPoint : function () {
		var ret;

		if (this.limitLeft && this._faceTo == vee.Direction.Left) {
			if (this._grid.x - (this._jumpWidth - 1) >= this.limitLeft) {
				ret = this.searchTargetPoint(this._faceTo);
			}
		} else if (this.limitRight) {
			if (this._grid.x + (this._jumpWidth - 1) <= this.limitRight) {
				ret = this.searchTargetPoint(this._faceTo);
			}
		} else {
			ret = this.searchTargetPoint(this._faceTo);
		}

		if (!ret) {
			this._faceTo = vee.Direction.revert(this._faceTo);
			ret = this.searchTargetPoint(this._faceTo);
			if (!ret) {
				ret = this._lastJumpPos;
			}
		}

		return ret;
	},

	_jumpWidth : 3,
	_deep : 4,
	searchTargetPoint : function (dir) {
		if (this.jumpCount > 1 && this.linkedSlime) {
			var linkedPos = this.linkedSlime.getElePosition();
			return cc.p(linkedPos.x, linkedPos.y+this.boxSize.height+2);
		} else {
			var ret = null;
			var grid = cc.p(this._grid.x, this._grid.y);
			var off = this._faceTo == vee.Direction.Left ? -1 : 1;
			for (var i = off; Math.abs(i) < this._jumpWidth; i += off) {
				var checkGrid = cc.p(grid.x+i, grid.y);
				var td = game.Logic.map.getObject(checkGrid);
				if (game.Logic.isBlock(td)) {
					break;
				}
				ret = cc.p((grid.x+i), grid.y);
			}
			if (!ret) return null;
			grid = cc.p(ret.x, ret.y);
			for (var i = 1; i < EnemyJumpSlime.deep; ++i) {
				var td = game.Logic.map.getObject(cc.p(grid.x, grid.y+i));
				if (td && td.tileInfo && td.tileInfo.type == game.ObjectType.BlockHurt) {
					return null;
				} else if (game.Logic.isBlock(td)) {
					ret = cc.p(grid.x, grid.y+i-1);
					ret = game.Logic.getTilePosCenterByGrid(ret);
					ret.y = ret.y - (TILE_WIDTH_HALF - this.boxSize.height/2);
					return ret;
				}
			}
			// is too deep...
			return null;
		}
	},

	collide : function (dir) {
		if (game.Data.oPlayerCtl._isBounce || !this._hasCollide) return;
		if (dir == vee.Direction.Top && !game.Data.oPlayerCtl.extendController) {
			if (!game.Data.playerHawk) {
				this.popPlayerUp();
				this.dieAnimate(dir);
			}
		} else if (game.Data.playerHawk) {
			game.Data.oLyGame.shake();
			this.dieAnimate(dir);
		} else {
			if (game.Data.playerInvisible || game.Data.oPlayerCtl._isBounce) return;
			var dir = this.getElePosition().x > game.Data.oPlayerCtl.getElePosition().x ? vee.Direction.Left : vee.Direction.Right;
			game.Data.oPlayerCtl.getShock(dir, true);
		}
	},
	die : function() {
		this.onDead();
		this._container.stopAllActions();
		this._isOver = true;
		game.Data.removeUsingEnemy(this);
		this.inhaleController = null;
		if (this.linkedSlime) {
			if (this._gridInMap) {
				game.Logic.dynamicObjMap.setObject(null, this.linkedSlime.initGrid);
				game.Logic.dynamicObjMap.setObject(this.linkedSlime, this.initGrid);
				this.linkedSlime._gridInMap = cc.p(this._gridInMap.x, this._gridInMap.y);
			} else {
				game.Logic.dynamicObjMap.setObject(null, this.initGrid);
			}
			this.linkedSlime.linkedSlime = null;
			// jump
			if (!this.linkedSlime.isSlimeJumping) {
				this.linkedSlime.slimeJump();
			}
			if (this.linkedSlime.jumpCount == 0) {
				this.linkedSlime.hasLinkedSlime = false;
			}
			this.linkedSlime = null;
		} else {
			if (this._gridInMap) {
				game.Logic.dynamicObjMap.removeObject(this._gridInMap);
			}
		}
		this.rootNode.setVisible(false);
		this._speedX = 0;
		this._speedY = 0;
		this._accX = 0;
		this._accY = 0;
		this._checkPosFirst = null;
		this._checkPosLast = null;
//		game.Data.enemyPool.push(this);
		this._container.removeFromParent();
	},
	dieAnimate : function (dir) {
		this.onKill();
		this._container.stopAllActions();
		var pos = this.getElePosition();
		EfxEnemyDie.show(pos);
		this._hasCollide = false;
		this._isOver = true;
		this.die();
	}
});

EnemyJumpSlime.jumpEase = 0.8;
EnemyJumpSlime.deep = 4;

var EnemyJumpFrog = EnemyJumpSlime.extend({
	objType : game.ObjectType.JumpFrog
});



















