/**
 * Created with AppCode.
 * User: WanThirty
 * Date: 15/9/10
 * Time: 下午2:51
 * To change this template use File | Settings | File Templates.
 */

var ItemSavePoint = Item.extend({
	ps1 : null,

	bornWithPos : function (pos) {
		ItemSavePoint.btnBuyPos = cc.p(pos.x, pos.y + 150);
		ItemSavePoint.btnBuyGrid = cc.p(this._grid.x, this._grid.y);
		if (game.Data.savePointSaved) {
			this.playAnimate("light");
		} else {
			this.playAnimate("close");
		}
		this.setElePosition(cc.p(pos.x, pos.y - TILE_WIDTH_HALF));
		this.ps1.setPositionType(1);
	},

	collide : function(dir) {
		if (!game.Data.savePointSaved) {
			game.Data.retryCount = 0;
			game.Data.savePointSaved = true;
			vee.Audio.playEffect(res.inGame_event_relayReach_mp3);
			this.playAnimate("open");
			game.Data.setSavePointIdx(game.Data.performingTMXIdx);
			if (game.Data.roleType == game.Roles.Girl) {
				game.Data.addLife();
			}
			ItemTransformBox.transformBackFromHawk();
		}
//		BtnSaveHeart.show();
	}
});

ItemSavePoint.btnBuyPos = null;
ItemSavePoint.btnBuyGrid = null;