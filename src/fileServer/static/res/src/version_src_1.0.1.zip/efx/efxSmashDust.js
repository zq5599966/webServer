/**
 * Created with AppCode.
 * User: WanThirty
 * Date: 15/8/3
 * Time: 下午5:40
 * To change this template use File | Settings | File Templates.
 */

var EfxSmashDust = vee.Class.extend({
	psDust : null,
	onCreate : function () {
		this.psDust.setPositionType(1);
		this.playAnimate("smash", function () {
			this.rootNode.removeFromParent();
		}.bind(this));
	}
});

EfxSmashDust.show = function (pos) {
	var node = cc.BuilderReader.load(res.efx_Dust_smash_ccbi);
	node.setPosition(pos);
	game.Data.oLyGame.lyMap.addChild(node, 11);
};

var EfxSmashFlash = vee.Class.extend({
    ps1 : null,
	ps2 : null,
	onCreate : function () {
		this.ps1.setPositionType(1);
		this.ps2.setPositionType(1);
		this.playAnimate("Show", function () {
			this.rootNode.removeFromParent();
		}.bind(this));
	}
});

EfxSmashFlash.show = function (pos) {
	var node = cc.BuilderReader.load(res.efx_elePlayerZhai_Lizi_ccbi);
	node.setPosition(pos);
	game.Data.oLyGame.lyMap.addChild(node, 11);
};