/**
 * Created with AppCode.
 * User: WanThirty
 * Date: 15/11/12
 * Time: 下午1:27
 * To change this template use File | Settings | File Templates.
 */

var LyReward = vee.Class.extend({
	lbTitle : null,
	lbContent : null,
	lbDetailCoin : null,
	lbDetailVideo : null,
	btnVideo : null,
	btnConfirm : null,
	btnRewardCoin : null,
	btnClose : null,

	type : null,
	isOver : false,
	randomCoin : 0,
	_tempControllerState : null,

	//jin change
	setType : function (type) {
		vee.Audio.playEffect(res.inGame_function_bonusEntrance_mp3);
		this.type = type;
		this.randomCoin = vee.Utils.randomInt(50, 100);
		//jin
		this.lbDetailCoin.setString(vee.Utils.getLocalizedStringForKey("Collect")
		+ " " + this.randomCoin + " "
		+ vee.Utils.getLocalizedStringForKey("data"));
		this.lbDetailVideo.setString(vee.Utils.getLocalizedStringForKey("Collect")
		+ " " + game.Data.videoReward + " "
		+ vee.Utils.getLocalizedStringForKey("data"));
		if (type == LyReward.Type.Video) {
			this.playAnimate("show");
		} else if (type == LyReward.Type.Coin) {
			this.playAnimate("showNoVideo");
		}
		this.handleKey(true);
		if (game.Data.isWeiXin) {
			this.btnVideo.setBackgroundSpriteForState(new cc.Scale9Sprite(res.btn_fill_watch_weixin_png), cc.CONTROL_STATE_NORMAL);
		}

		this._tempControllerState = vee.Controller.cacheControllerState();
	},

	initController : function () {
		vee.Controller.initSelector(2,1,this.onClose.bind(this),cc.p(0,0));
		vee.Controller.registerItemByButton(this.btnRewardCoin, cc.p(0,0), this.onRewardCoin.bind(this), "res/mfi_btn_on_170.png");
		if (this.type == LyReward.Type.Video) {
			vee.Controller.registerItemByButton(this.btnVideo, cc.p(1,0), this.onVideo.bind(this), "res/mfi_btn_on_170.png");
		} else {
			vee.Controller.registerItemByButton(this.btnConfirm, cc.p(1,0), this.onVideo.bind(this), "res/mfi_btn_on_170.png");
		}
		vee.Controller.activeSelector();
	},

	onKeyBack : function(){
		this.onClose(true);
		return true;
	},

	onVideo : function () {
		if (this.isOver) return;
		this.isOver = true;
		this.onClose(true);
		// watch video
		if (this.type == LyReward.Type.Video) {
			var successCall = function (pPlugin, num, itemID) {
				if (game.Data.oLyGameOver) {
					game.Data.oLyGameOver.checkAvatar(500);
					game.Data.oLyGameOver.startProgress();
				}
				vee.Analytics.UGameEvent.showAdEvent("alert", "video", "lyReward_500coin");
			};

			if (game.Data.isWeiXin) {
				vee.IAPMgr.buyProduct(5, successCall);
			} else {
				vee.Ad.showVideoAd(successCall, "500CoinReward");
			}
		} else {
			vee.Ad.showVideoAd(function (pPlugin, num, itemID) {
				vee.Utils.scheduleOnce(function () {
					vee.PopMgr.alert(
						vee.Utils.getLocalizedStringForKey("There will be NO Ads before you quit this game. Enjoy it!"),
						vee.Utils.getLocalizedStringForKey("REMOVE ADS")
					);
				}, 0.2);
				game.Data.banAdThisGame = true;
			}, "lyReward");
		}
	},

	onRewardCoin : function () {
		if (this.isOver) return;
		this.isOver = true;
		// give coin
		this.onClose(true);
		if (game.Data.oLyGameOver) {
			game.Data.oLyGameOver.checkAvatar(this.randomCoin);
			game.Data.oLyGameOver.startProgress();
		}
	},

	onClose : function (force) {
		if (this.isOver && !force) return;
		this.isOver = true;
		vee.Controller.deactiveSelector();
		var closeFunc = function () {
			vee.Controller.reviveControllerState(this._tempControllerState);
			vee.PopMgr.closeLayerByCtl(this);
		}.bind(this);
		if (this.type == LyReward.Type.Video) {
			this.playAnimate("close", closeFunc);
		} else if (this.type == LyReward.Type.Coin) {
			this.playAnimate("closeNoVideo", closeFunc);
		}
	}
});

LyReward.hasShown = false;
LyReward.forceShowCoin = 500;

LyReward.Type = {
	Video : 1,
	Coin  : 2,
	BanAd : 3
};

LyReward.show = function (type) {
	if (!game.Data.isFreeGame) return;
	var node = vee.PopMgr.popCCB(res.vAlertboxPop_ccbi, {alpha:0});
	node.controller.setType(type);
	LyReward.hasShown = true;
};

LyReward.showLogic = function (isWin, coinOff) {
	if (LyReward.hasShown) {
		LyReward.hasShown = false;
		return;
	}
	var role = game.AvatarData.getNextAvatar();
	if (role && role.idx < 2) {
		return;
	}

	//jin change

	//var videoRate, coinRate;
	//if (isWin) {
	//	videoRate = 0.2;
	//	coinRate = 0.3;
	//} else {
	//	videoRate = 0.2;
	//	coinRate = 0.4;
	//}
	//var showVideo = vee.Utils.isLucky(videoRate);
	var popRate;
	if (isWin) {
		popRate = 0.9;
		//popRate = 0.3;
	} else {
		popRate = 0.9;
		//popRate = 0.4;
	}
	if (vee.Utils.isLucky(popRate)) {
		if (vee.Ad.checkCacheVideoAd() || game.Data.isWeiXin) {
			// show video
			LyReward.show(LyReward.Type.Video);
		} else{
			// just show coin
			LyReward.show(LyReward.Type.Coin);
		}
	}
};



