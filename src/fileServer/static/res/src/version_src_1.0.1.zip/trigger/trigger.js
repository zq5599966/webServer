/**
 * Created with AppCode.
 * User: WanThirty
 * Date: 15/6/1
 * Time: 下午4:00
 * To change this template use File | Settings | File Templates.
 */

var Trigger = cc.Class.extend({
	_eleType : game.EleType.Trigger,
	name : null,
	type : null,
	func : function() {
		cc.log("Trigger : '" + name + "' didn`t implement a function.");
	}
});
Trigger.resetTriggerSign = function () {
	Trigger.TutorialStep.triggerSign = {};
};

Trigger.getTrigger = function(grid) {
	return game.Logic.objMap.getObject(grid);
}

Trigger.setTrigger = function(grid, trigger) {
	game.Logic.objMap.setObject(trigger, grid);
}

Trigger.create = function(triggerInfo) {
	if (!triggerInfo.type) {
		cc.log("triggerInfo.type is empty!");
		return;
	}
	if (!Trigger[triggerInfo.type]) {
		cc.log("Trigger Constructor is not found :" + triggerInfo.type);
	}
	var t = new Trigger[triggerInfo.type]();
	t.name = triggerInfo.name;
	t.type = triggerInfo.type;
//	vee.Utils.logObj(triggerInfo, "trigger info===");
	t.grid = cc.p(triggerInfo.x, triggerInfo.y);
	return t;
};

Trigger.SwitchTriggerType = {
	Show : 1,
	Hide : 2,
	Toggle : 3
};

Trigger.showCCB = function(ccbname, grid, callback, animateName){
	if (this._isPlaying) return;
	this._isPlaying = true;
	var node = cc.BuilderReader.load(res.tip1_ccbi);
	game.Data.oLyGame.lyMap.addChild(node);
	var pos = game.Logic.getTilePosByGrid(grid);
	node.setPosition(cc.p(pos.x + game.Data.tileSizeWidth / 2, pos.y + game.Data.tileSizeWidth / 2));
	node.runAction(cc.sequence(
		cc.delayTime(node.animationManager._sequences[0]._duration),
		cc.callFunc(function() {
			if (animateName) node.controller.playAnimate(animateName);
		}),
		cc.callFunc(callback),
		cc.callFunc(function () {
			this._isPlaying = false;
		}.bind(this)),
		cc.callFunc(function () {
			this.removeFromParent();
		}.bind(node))
	));
};

Trigger.ShowCCB = Trigger.extend({
	func : function (grid, dir) {
		var arrArgs = this.name.split(',');
		if (arrArgs < 2) {
			Trigger.showCCB("res/" + this.name + ".ccbi", grid);
		} else {
			Trigger.showCCB("res/" + arrArgs[0] + ".ccbi", grid, null, arrArgs[1]);
		}
	}
});

Trigger.TutorialStep = Trigger.extend({
	func : function (grid, dir) {
		if (EleGuide.ctl) {
			var arrArgs = this.name.split(",");
			if (arrArgs.length != 4) {
				cc.log("Error in Trigger.TutorialStep, name = " + this.name);
				return;
			}
			if (Trigger.TutorialStep.triggerSign[arrArgs[3]]) {
				cc.log("tutorial step has shown");
				return;
			}
			Trigger.TutorialStep.triggerSign[arrArgs[3]] = true;
			var argGrid = cc.p(parseInt(arrArgs[0]), parseInt(arrArgs[1]));
			argGrid = vee.Utils.pAdd(argGrid, grid);
			if (arrArgs[2] == 'hide') {
				EleGuide.showGuide(argGrid, arrArgs[2], function () {
					vee.PopMgr.closeLayerByCtl(EleGuide.ctl);
				});
			} else {
				EleGuide.showGuide(argGrid, arrArgs[2], null);
			}
		}
	}
});
Trigger.TutorialStep.triggerSign = {};

Trigger.ShowFinger = Trigger.extend({
	func : function (grid, dir) {
		if (this._isPlaying) return false;
		this._isPlaying = true;

		var node = cc.BuilderReader.load(res.tipsFinger_ccbi);
		var pos = game.Logic.getTilePosByGrid(grid);
		node.setPosition(cc.p(pos.x + game.Data.tileSizeWidth / 2, pos.y + game.Data.tileSizeWidth / 2));
		game.Data.oLyGame.lyMap.addChild(node, 99);
		var name;
		if (this.name == "right") {
			name = "0";
		} else if (this.name == "top_right") {
			name = "45";
		} else if (this.name == "top") {
			name = "90";
		} else if (this.name == "top_left") {
			name = "45";
			node.setScaleX(-1);
		} else if (this.name == "left") {
			name = "0";
			node.setScaleX(-1);
		} else if (this.name == "bottom_left") {
			name = "-45";
			node.setScaleX(-1);
		} else if (this.name == "bottom") {
			name = "-90";
		} else if (this.name == "bottom_right") {
			name = "-45";
		}
		node.controller.playAnimate(name, function () {
			node.controller.playAnimate(name + "_out", function () {
				node.removeFromParent();
				this._isPlaying = false;
			}.bind(this));
		}.bind(this));
		return true;
	}
});

Trigger.DeadZone = Trigger.extend({

	dead : false,

	getRevivePoint : function () {
		var pointStr = this.name;
		if(pointStr && pointStr != ""){
			pointStr = pointStr.replace("(", "");
			pointStr = pointStr.replace(")", "");
			var point = pointStr.split(",");
			if(point.length != 2){
				cc.log("zq debug fuck deadzone revive point error!!!grid==x=%d y=%d", this.grid.x, this.grid.y);
				return null;
			}
			return cc.p(point[0], point[1]);
		}
		return null;
	},

	func : function (grid, dir) {
		if (this.dead) return;
		if (game.Data.playerHawk) {
			game.Data.oPlayerCtl.reviveFloat();
			return;
		}

		var revivePoint = this.getRevivePoint();
        cc.log("zq debug revival count=====%d", game.Logic._deadZoneRevivalCount);
		if(null != revivePoint && game.Data.isFreeGame && vee.Ad.checkCacheVideoAd() && game.Logic._deadZoneRevivalCount > 0){
		// if(null != revivePoint){
			cc.log("zq debug show revival video alert pop");
            game.Logic._deadZoneRevivalCount = game.Logic._deadZoneRevivalCount - 1;
			game.Data.oPlayerCtl.reviveGrid = revivePoint;
			ccbRevivalVideoAlert.show(ccbRevivalVideoAlert.revivalType.DEADZONE);
			return;
		}

		this.dead = true;
		this.overEvent();

	},

	overEvent : function () {
		cc.log("zq debug deadzone 11111111111111");
		game.Data.gameFail();
		cc.log("zq debug deadzone 22222222222222");
		game.Data.oLyGame.gameSlow();
		cc.log("zq debug deadzone 33333333333333");
		game.Data.stageFinish(game.FinishType.DEAD);
		cc.log("zq debug deadzone 44444444444444");
		game.Data.oPlayerCtl.gameOverFall(function () {
			cc.log("zq debug deadzone 5555555555");
			vee.GameModule.SceneMgr.openOver();
		}.bind(this));
		cc.log("zq debug deadzone 66666666666666");
	}
});

Trigger.cameraYFreezed = false;
Trigger.CameraYFreeze = Trigger.extend({
	func : function (grid, dir) {
		game.Data.oLyGame.setCameraYFreeze(true, game.Data.oPlayerCtl.getElePosition().y);
		Trigger.cameraYFreezed = true;
		if (game.Data.oPlayerCtl._isReviveFloat) {
			Trigger.CameraYResume.entityFunc();
		}
	}
});

Trigger.CameraYResume = Trigger.extend({
	func : function (grid, dir) {
		if (Trigger.cameraYFreezed) {
			game.Data.cameraYPos -= (game.Data.oLyGame._freezeY - game.Data.oPlayerCtl._pos.y);
			game.Data.cameraYrevived = false;
			game.Data.oLyGame.setCameraYFreeze(false, 0);
			Trigger.cameraYFreezed = false;
		}
	}
});
Trigger.CameraYResume.entityFunc = function () {
	if (Trigger.cameraYFreezed) {
		game.Data.cameraYPos -= (game.Data.oLyGame._freezeY - game.Data.oPlayerCtl._pos.y);
		game.Data.cameraYrevived = false;
		game.Data.oLyGame.setCameraYFreeze(false, 0);
		Trigger.cameraYFreezed = false;
	}
};

Trigger.HideMask = Trigger.extend({
	func : function (grid, dir) {
		if (this.name) ly = game.Logic._tmxMap.getLayer(this.name);
		else ly = game.Logic._tmxLayerHide;
		if (ly) {
			if (ly.getOpacity() == 255) vee.Audio.playEffect(res.inGame_event_maskOff_mp3);
			ly.setCascadeOpacityEnabled(true);
			ly.stopAllActions();
			ly.runAction(cc.fadeTo(0.3, 0));
		}
	}
});

Trigger.ShowMask = Trigger.extend({
	func : function (grid, dir) {
		if (this.name) ly = game.Logic._tmxMap.getLayer(this.name);
		else ly = game.Logic._tmxLayerHide;
		if (ly) {
			ly.setCascadeOpacityEnabled(true);
			ly.stopAllActions();
			ly.runAction(cc.fadeTo(0.3, 255));
		}
	}
});

Trigger.HideExtra = Trigger.extend({
	_switchType : Trigger.SwitchTriggerType.Hide,
	func : function (grid, dir) {
		var arrArg = this.name.split(",");
		if (arrArg.length > 1 && dir == vee.Direction.Origin) {
			return;
		}
		Trigger.HideExtra.func(grid, dir, arrArg[0], this);
	}
});

Trigger.HideExtra.func = function (grid, dir, name, triggerObj) {
	var extraLayer = game.Logic._tmxMap.getLayer(name);
	if (extraLayer && extraLayer.isVisible()) {
		extraLayer.runAction(cc.sequence(
			cc.fadeTo(0.2, 0),
			cc.hide()
		));
		for (var x = extraLayer.originX; x <= extraLayer.maxX; ++x) {
			for (var y = extraLayer.originY; y <= extraLayer.maxY; ++y) {
				var checkGrid = cc.p(x,y);
				var td = game.Logic.map.getObject(checkGrid);
				if (td && td.layer == extraLayer) {
					// Remove extra tile data
					game.Logic.map.removeObject(checkGrid);
					var exobj = game.Logic.mapex.getObject(checkGrid);
					if (exobj && exobj.layer == extraLayer) {
						game.Logic.mapex.removeObject(checkGrid);
					}
					var obj = game.Logic.objMap.getObject(checkGrid);
					if (obj && obj._container) {
						obj._container.removeFromParent();
						game.Logic.objMap.removeObject(checkGrid);
					}
					// Reset main tile data
					var tileInfo = game.Logic.getTileData(checkGrid, game.Logic._tmxLayer);
					if (tileInfo && game.Logic.isExObjType(tileInfo.tileInfo.type)) {
						game.Logic.mapex.setObject(tileInfo, checkGrid);
					} else {
						game.Logic.map.setObject(tileInfo, checkGrid);
					}
					game.Logic.createItemByGrid(checkGrid);
					game.Logic.createEnemyByGrid(checkGrid);
				}
			}
		}

		if (triggerObj && triggerObj._switchType == Trigger.SwitchTriggerType.Hide) {
//			extraLayer.hideTileGrid = grid;
		}
		Trigger.switchTriggerReset(game.BlockType.SwitchHide, extraLayer);
		// hide extra background
		var extraBgLayer = game.Logic._tmxMap.getLayer("bg_"+name);
		if (extraBgLayer) {
			extraBgLayer.setVisible(false);
			extraBgLayer.runAction(cc.sequence(
				cc.fadeTo(0.2, 0),
				cc.hide()
			));
		}
	}
};

Trigger.ShowExtra = Trigger.extend({
	_switchType : Trigger.SwitchTriggerType.Show,
	func : function (grid, dir) {
		var arrArg = this.name.split(",");
		if (arrArg.length > 1 && dir == vee.Direction.Origin) {
			return;
		}
		Trigger.ShowExtra.func(grid, dir, arrArg[0], this);
	}
});

Trigger.ShowExtra.func = function (grid, dir, name, triggerObj) {
	var extraLayer = game.Logic._tmxMap.getLayer(name);
	if (extraLayer && !extraLayer.isVisible()) {

		if (triggerObj) {
//			if (triggerObj._switchType == Trigger.SwitchTriggerType.Show) {
//				extraLayer.showTileGrid = grid;
//			}
			Trigger.switchTriggerReset(game.BlockType.SwitchShow, extraLayer);
		}
		extraLayer.setVisible(true);
		extraLayer.setOpacity(0);
		extraLayer.runAction(cc.fadeTo(0.2, 255));
		game.Logic.addExtraTileToMap(extraLayer);
		if (game.Data.oPlayerCtl) {
			game.Logic.deployTileConfig(game.Data.oPlayerCtl._grid, false, extraLayer);
		}

		// show extra background
		var extraBgLayer = game.Logic._tmxMap.getLayer("bg_"+name);
		if (extraBgLayer) {
			extraBgLayer.setVisible(true);
			extraBgLayer.setOpacity(0);
			extraBgLayer.runAction(cc.fadeTo(0.2, 255));
		}
	}
};

Trigger.ToggleExtra = Trigger.extend({
	_switchType : Trigger.SwitchTriggerType.Toggle,
	func : function (grid, dir) {
		var extraLayer = game.Logic._tmxMap.getLayer(this.name);
		if (extraLayer) {
//			if (this._switchType == Trigger.SwitchTriggerType.Toggle) {
//				extraLayer.toggleTileGrid = grid;
//			}
			if (extraLayer.isVisible()) {
				Trigger.HideExtra.func(grid, dir, this.name, this);
				Trigger.switchTriggerReset(game.BlockType.SwitchHide, extraLayer);
			} else {
				Trigger.ShowExtra.func(grid, dir, this.name, this);
				Trigger.switchTriggerReset(game.BlockType.SwitchShow, extraLayer);
			}
		}
	}
});

Trigger.switchTriggerReset = function (type, extLayer) {
	// reset hide tile
	if (extLayer.hideTileGrid) {
		var len = extLayer.hideTileGrid.length;
		var checkGrid = null;
		for (var i = 0; i < len; ++i) {
			checkGrid = extLayer.hideTileGrid[i];
			var tdHide = game.Logic.map.getObject(checkGrid);
			var tempGID, newGID;
			if (tdHide) {
				tempGID = tdHide.layer.getTileGIDAt(checkGrid);
				newGID  = type == game.BlockType.SwitchShow ? game.BlockType.SwitchHide : game.BlockType.SwitchDisable;
				tdHide.layer.setTileGID(newGID, checkGrid);
				// show efx
				if (tempGID == newGID) {
					cc.log("1");
					cc.log("===");
				} else {
					EfxSwitch.create(game.Logic.getTilePosCenterByGrid(checkGrid),
						EfxSwitch.gid2Str(tempGID),
						EfxSwitch.gid2Str(newGID));
					vee.Audio.playEffect(res.inGame_event_switchOn_mp3);
				}
			}
		}
	}
	// reset show tile
	if (extLayer.showTileGrid) {
		var len = extLayer.showTileGrid.length;
		var checkGrid = null;
		for (var i = 0; i < len; ++i) {
			checkGrid = extLayer.showTileGrid[i];
			var tdShow = game.Logic.map.getObject(checkGrid);
			if (tdShow) {
				tempGID = tdShow.layer.getTileGIDAt(checkGrid);
				newGID  = type == game.BlockType.SwitchShow ? game.BlockType.SwitchDisable : game.BlockType.SwitchShow;
				tdShow.layer.setTileGID(newGID, checkGrid);
				// show efx
				if (tempGID == newGID) {
					cc.log("2");
					cc.log("===");
				} else {
					EfxSwitch.create(game.Logic.getTilePosCenterByGrid(checkGrid),
						EfxSwitch.gid2Str(tempGID),
						EfxSwitch.gid2Str(newGID));
					vee.Audio.playEffect(res.inGame_event_switchOff_mp3);
				}

			}
		}
	}
	// reset toggle tile
	if (extLayer.toggleTileGrid) {
		var len = extLayer.toggleTileGrid.length;
		var checkGrid = null;
		for (var i = 0; i < len; ++i) {
			checkGrid = extLayer.toggleTileGrid[i];
			var tdTog = game.Logic.map.getObject(checkGrid);
			if (tdTog) {
				tempGID = tdTog.layer.getTileGIDAt(checkGrid);
				newGID  = type == game.BlockType.SwitchShow ? game.BlockType.SwitchHide : game.BlockType.SwitchShow;
				tdTog.layer.setTileGID(type == game.BlockType.SwitchShow ? game.BlockType.SwitchHide : game.BlockType.SwitchShow, checkGrid);
				// show efx
				if (tempGID != newGID) {
					EfxSwitch.create(game.Logic.getTilePosCenterByGrid(checkGrid),
						EfxSwitch.gid2Str(tempGID),
						EfxSwitch.gid2Str(newGID));
					if (newGID == game.BlockType.SwitchShow) {
						vee.Audio.playEffect(res.inGame_event_switchOff_mp3);
					} else {
						vee.Audio.playEffect(res.inGame_event_switchOn_mp3);
					}
				}
			}
		}
	}
};

Trigger.DoorIn = Trigger.extend({
	func : function (grid, dir) {
		if (game.Logic._tmxMap) {
			game.Logic._tmxMap.removeFromParent();
		}
		game.Data.oPlayerCtl.stopUpdate();
		vee.Utils.scheduleOnce(function () {
			game.Data.isDoorIn = true;
			game.Data.oLyGame.showTMX("res/"+this.name+".tmx");
		}.bind(this), 0.1);
	}
});

Trigger.DoorOut = Trigger.extend({
	func : function (grid, dir) {
		if (game.Logic._tmxMap) {
			game.Logic._tmxMap.removeFromParent();
		}
		game.Data.oPlayerCtl.stopUpdate();
		var arrArgs = this.name.split(",");
		if (arrArgs.length == 3) {
			this.name = arrArgs[0];
			game.Data.doorOutOffset = cc.p(parseInt(arrArgs[1]), -parseInt(arrArgs[2]));
		} else {
			game.Data.doorOutOffset = cc.p(-1,0);
		}
		vee.Utils.scheduleOnce(function () {
			game.Data.isDoorIn = false;
			game.Data.oLyGame.showTMX("res/"+this.name+".tmx");
		}.bind(this), 0.1);
		arrArgs = null;
	}
});

Trigger.Exchange = Trigger.extend({
	func : function () {
		if (game.Data.playerType == parseInt(this.name)) return;
		game.Data.playerType = parseInt(this.name);
		var playerContent = ElePlayer.create(parseInt(this.name));
		playerContent.controller.setElePosition(game.Data.oPlayerCtl.getElePosition());
		game.Data.oPlayerCtl._container.removeFromParent();
		game.Data.oPlayerCtl = playerContent.controller;
		game.Data.oLyGame.lyMap.addChild(playerContent.container, 2);
	}
});

Trigger.ShowSusliks = Trigger.extend({
	func : function () {
		if (!EnemySusliks.arrSusliks) game.Logic.showSequenceSusliks(this.name);
	}
});

Trigger.ChangeBG = Trigger.extend({
	func : function () {
		if (game.Data.isChangingBG || (game.Data.oLyGame.bgCtl && game.Data.oLyGame.bgCtl.bgName == this.name)) return;
		var lyGame = game.Data.oLyGame;
		var bg = LyDynamicBG.create(this.name);
		bg.setLocalZOrder(1);
		lyGame.lyBG.addChild(bg);
		if (lyGame.bgCtl) {
			lyGame.bgCtl.rootNode.setLocalZOrder(2);
			lyGame.bgCtl.disappear();
		}
		lyGame.bgCtl = bg.controller;
	}
});

Trigger.Event = Trigger.extend({
	func : function (grid, dir) {
		if (game.Data.oLvCtl) {
			var arr = this.name.split(';');
			var func = game.Data.oLvCtl["event"+arr[0]];
			if (_.isFunction(func)) {
				game.Data.oLvCtl["event"+arr[0]](grid, dir, arr);
			} else {
				cc.log("ERROR: event name invalid : event "+arr[0], this.name);
			}
		}
	}
});

Trigger.AddItem = Trigger.extend({
	func : function (grid, dir, td) {
		if (this.triggered) return;
		this.triggered = true;
		if (dir != vee.Direction.Origin) {
			var type = game.itemStringMap[this.name];
			if (type) {
				var item = Item.createWithInfo({type : type});
				if (item) {
					// show item
					var pos = game.Logic.getTilePosByGrid(grid);
					item.controller.initPosition(cc.p(pos.x + game.Data.tileSizeWidth/2, pos.y + game.Data.tileSizeWidth/2));
					if (td) {
						item.controller._layerBelong = td.layer;
					} else {
						item.controller._layerBelong = game.Logic._tmxLayer;
					}
					var cointd = game.Logic.getTileDataByGid(game.BlockType.Coin, grid);
					game.Logic.objMap.setObject(item.controller, grid);
					item.controller.setGridInMap(grid);
					game.Logic.mapex.setObject(cointd, grid);
				}
			}
		}
	}
});

Trigger.ForceMove = Trigger.extend({
	func : function () {
		game.Data.oLyGame.leftBtnUp();
		game.Data.oLyGame.rightBtnUp();
		if (!this.name || this.name == "right") game.Data.oPlayerCtl.moveRight();
		else game.Data.oPlayerCtl.moveLeft();
		vee.Utils.scheduleOnce(function () {
			game.Data.oLyGame.leftBtnUp();
			game.Data.oLyGame.rightBtnUp();
		}, 0.35);
	}
});

Trigger.StageOver = Trigger.extend({
	_isOver : false,
	func : function (grid, dir) {
		if (this._isOver) return;
		this._isOver = true;
		game.Data.oLyGame.stopCamera = true;
		game.Data.oLyGame.freezeButton = true;

		game.Data.oPlayerCtl.gameOverOut(function() {
			vee.Transition.out(res.MapTransition_ccbi, function () {
				var playerNode = game.Data.oPlayerCtl.getContainerNode();
				playerNode.setPosition(cc.p(0,0));
				game.Data.oPlayerCtl.playAnimate("huxi_2", function() {
					game.Data.oPlayerCtl.randomBreath();
				});
				playerNode.retain();
				playerNode.removeFromParent();
				vee.PopMgr.closeAll();
				var winNode = LyGameWin.show();
				winNode.controller.nodeAvatar.addChild(playerNode);
				playerNode.release();
			});
		});

//		game.Data.oPlayerCtl.moveRight();
//		var pos = game.Logic.getTilePosCenterByGrid(grid);
//		var targetPos = game.Logic.getTilePosCenterByGrid(game.Data.getPointFromString(this.name));
//		var off = vee.Utils.pSub(pos, targetPos);
//		game.Data.oLyGame.lyContainer.runAction(cc.sequence(
//			cc.EaseExponentialOut.create(cc.moveBy(2, off)),
//			cc.delayTime(1),
//			cc.callFunc(function () {
//				vee.GameModule.SceneMgr.openMain();
//			})
//		));
	}
});


Trigger.ShowCoins = Trigger.extend({
	_isOver : false,
	func : function(grid, dir) {
		if (this._isOver) return;
		this._isOver = true;
		game.Logic.showSequenceCoin(this.name);
	}
});

Trigger.BigCoin = Trigger.extend({
	_isGetted : false,
	func : function (grid, dir) {
		if (dir == vee.Direction.Origin) return;
		if (this._isGetted) return;
		this._isGetted = true;
		var coinIdx = parseInt(this.name);
		if (game.LevelData.selectedLevel) {
			cc.log("level coin idx = "+coinIdx);
			game.LevelData.selectedLevel.starAchieved(coinIdx);

			var tempStar = game.LevelData.selectedLevel.getCurrentStarAchieved();
			cc.log("getted star : "+tempStar);

			game.Data.oLyGame.unlockStar(coinIdx);
			++game.Data.collectedStarCount;
		}
	}
});

Trigger.HighlightAction = Trigger.extend({
	func : function(grid, dir) {
		if (this.isOver) return;
		this.isOver = true;
		game.Data.oLyGame.setHighlightControlButton(LyGame.ControlButtonType.ActionButton, parseInt(this.name));
	}
});

Trigger.Story = Trigger.extend({
	_isOver : false,
	func : function(grid, dir) {
		if (this._isOver) return;
		this._isOver = true;
		Story.showStory(this.name, grid);
	}
});

Trigger.Parkour = Trigger.extend({
	func : function (grid, dir) {
		var param = parseInt(this.name);
		game.Logic.setForParkour(param > 0);
		if(game.Data.oPlayerCtl){
			game.Data.oPlayerCtl.parkourMove();
		}
	}
});
