/**
 * Created with AppCode.
 * User: WanThirty
 * Date: 15/9/12
 * Time: 下午8:04
 * To change this template use File | Settings | File Templates.
 */

var LyIndex = vee.Class.extend({
	_isOver : false,
	btnPlay : null,
	btnHelp : null,
	btnInfo : null,
	btnGoogle : null,
	btnSaveGame : null,
	labSaveGame : null,
	ccbEfxLogo : null,
	nodePlayer : null,
	playerNode : null,

	spChildhood : null,
	ccbBalloon : null,

	spL : null,

	onCreate : function () {
//		cc.spriteFrameCache.addSpriteFrames(res.img_Logo_a_plist, res.img_Logo_a_png);
//		cc.spriteFrameCache.addSpriteFrames(res.img_Logo_h_plist, res.img_Logo_h_png);
//		cc.spriteFrameCache.addSpriteFrames(res.img_Logo_m_plist, res.img_Logo_m_png);
//		cc.spriteFrameCache.addSpriteFrames(res.img_Logo_n_plist, res.img_Logo_n_png);
//		cc.spriteFrameCache.addSpriteFrames(res.img_Logo_o_plist, res.img_Logo_o_png);
//		cc.spriteFrameCache.addSpriteFrames(res.img_Logo_p_plist, res.img_Logo_p_png);
//		cc.spriteFrameCache.addSpriteFrames(res.img_Logo_t_plist, res.img_Logo_t_png);
//		cc.spriteFrameCache.addSpriteFrames(res.img_Logo_txt_cat_plist, res.img_Logo_txt_cat_png);
	},

	ccbInit : function () {
		this.handleKey(true);
		var avatar = game.AvatarData.getCurrentAvatar();
		this.playerNode = cc.BuilderReader.load(avatar.role);
		vee.Audio.playEffect(res.outGame_efx_showLogo_mp3);
		// vee.Audio.playEffect(res.inGame_function_win_mp3);
		this.playerNode.controller.playAnimate("huxi_1", function() {
			this.playerNode.controller.randomBreath();
		}.bind(this));
		this.nodePlayer.addChild(this.playerNode);

		this.btnSaveGame.setVisible(game.Data.isAndroid);
		this.labSaveGame.setVisible(game.Data.isAndroid);
		this.spL.setVisible(game.Data.isAndroid);

		if (vee.isFirstPlay) {
			vee.PopMgr.alert("单机游戏，数据无法同步到其他设备；卸载游戏会导致数据丢失。", "提示", function () {});
		}



		//if (game.Data.is61) {
		//	var lang = vee.Utils.getLocalizedStringForKey("lang");
		//	if ((lang == "cn_s" || lang == "cn_t") && this.spChildhood) {
		//		this.spChildhood.setTexture(res.index_ChildCN_png);
		//	}
		//	if (this.ccbBalloon) {
		//		this.ccbBalloon.controller.show();
		//	}
		//}

		vee.IAPMgr.getServicePriceList();

		//zq debug
		// for(var i = 0; i < 10; i++){
		// 	vee.VIPValues.setValue('avatar_' + i, 1);
		// }
		// vee.VIPValues.save();
		//debug end
	},

	onExit : function () {
//		cc.spriteFrameCache.removeSpriteFramesFromFile(res.img_Logo_a_plist);
//		cc.spriteFrameCache.removeSpriteFramesFromFile(res.img_Logo_h_plist);
//		cc.spriteFrameCache.removeSpriteFramesFromFile(res.img_Logo_m_plist);
//		cc.spriteFrameCache.removeSpriteFramesFromFile(res.img_Logo_n_plist);
//		cc.spriteFrameCache.removeSpriteFramesFromFile(res.img_Logo_o_plist);
//		cc.spriteFrameCache.removeSpriteFramesFromFile(res.img_Logo_p_plist);
//		cc.spriteFrameCache.removeSpriteFramesFromFile(res.img_Logo_t_plist);
//		cc.spriteFrameCache.removeSpriteFramesFromFile(res.img_Logo_txt_cat_plist);
	},

	// ccb animate callback
	showLogo : function () {
		if (this.ccbEfxLogo) {
			this.ccbEfxLogo.setVisible(true);
			this.ccbEfxLogo.controller.loop();
		}
	},

	// ccb animate callback
	initController : function () {
		// vee.Controller.registerGlobalButtonAction(this.onPlay.bind(this));

		vee.Controller.clearAllButtonAction();
		vee.Controller.activeButton();

		vee.Controller.registerButtonAction(
			[vee.KeyCode.BUTTON_A, vee.KeyCode.BUTTON_DPAD_CENTER],
			function () {
				this.onPlay();
			}.bind(this)
		);

		vee.Controller.registerButtonAction(
			[vee.KeyCode.BUTTON_LEFT_SHOULDER,vee.KeyCode.AXIS_LEFT_TRIGGER],
			function () {
				this.onSave();
			}.bind(this)
		);
	},

	onPlay : function () {

		cc.log("zq debug fuck data save load start!!!!");
		game.initPhantomCatData();
		cc.log("zq debug fuck data save load end!!!!");

		// if(game.Data.version.isMidAutumn){
		// 	game.LevelData.coreData.lockStatus["7"] = 3;
		// }

		if (this._isOver) return;

		if (game.Data.isFreeGame) {
			if (vee.Ad.showInterstitialAndBlockButton("start_btn")) {
				cc.log("zq debug onplay click============");
				return;
			}
		}

		this._isOver = true;
		vee.Controller.clearGlobalButtonAction();


		//*change by zq, preload audio cache 20161028
		vee.Transition.out(res.MapTransition_ccbi, function () {
			LyLevelSelect.show();
		});
		//*/
		/*
		LyLevelLoading.show();
		vee.Audio.startPreloadAudio(function () {
			if(game.Data.oLvLoadingCtl){
				game.Data.oLvLoadingCtl.loaded();
				LyLevelSelect.show();
			}
		});
		*/

		//end
	},

	onSave : function (){
		cc.log("zq debug on save btn click");
		vee.GameCenter.saveGameData(jsb.fileUtils.getWritablePath());
		vee.PopMgr.popLoading();
	},

	onKeyBack : function(){
		vee.Controller.clearGlobalButtonAction();
		VeeQuitBox.show(function () {
			vee.Controller.registerGlobalButtonAction(this.onPlay.bind(this));
			app.closeGame();
		}.bind(this));
		if (vee.data["stad"]) {

		}
		return true;
	}
});

LyIndex.show = function () {
	vee.PopMgr.closeAll();
	var ccbName = null;
	//if (game.Data.is61) {
	//	ccbName = res.index_Child_ccbi;
	//} else {
	//	ccbName = res.index_ccbi;
	//}
	ccbName = res.index_ccbi;
	var node = vee.PopMgr.popCCB(ccbName);
	node.controller.ccbInit();
};

var LyIndexWeiXin = LyIndex.extend({

	onQQ : function() {
		vee.IAPMgr.QQLogin();
	},

	onWeiXin : function() {
		vee.IAPMgr.WeiXinLogin();
	},

	onPlayNoLogin : function() {
		vee.IAPMgr.logout();
		LyIndexWeiXin.playGame();
		game.loginPlatform = "normal";
		game.initPhantomCatData();
	},

	onKeyBack : function () {
		return true;
	},

	onExit : function () {
		vee.IAPMgr.removeAllCallback();
	}
});

LyIndexWeiXin.playGame = function () {
	if (vee.isFirstPlay) {
		vee.isFirstPlay = true;
		vee.PopMgr.closeAll();
		cc.director.purgeCachedData();
		vee.PopMgr.popCCB("res/veeGameLayer.ccbi");
		game.Data.oLyGame.onLoaded();
		game.Data.oLyGame.initStage('Story1');
	} else {
		vee.Controller.clearGlobalButtonAction();
		vee.Transition.out(res.MapTransition_ccbi, function () {
			LyLevelSelect.show();
		});
	}
};

LyIndexWeiXin.show = function () {
	var node = vee.PopMgr.popCCB(res.indexWeixin_ccbi);
	node.controller.ccbInit();

	vee.IAPMgr.LoginSuccessCallback = function () {
		LyIndexWeiXin.playGame();
	};

	vee.IAPMgr.LoginFailedCallback = function () {
		vee.Utils.scheduleBack(function () {
			vee.PopMgr.alert("登陆失败，请重新登陆", "登陆失败", function () {});
		});
	};
};

var LyWeiXinOpen = vee.Class.extend({

	ccbInit : function () {
		this.playAnimate("play", function () {
			vee.PopMgr.closeLayer();
			LyIndexWeiXin.show();
		});
	}
});

LyWeiXinOpen.show = function () {
	var node = vee.PopMgr.popCCB(res.lyWeixinOpen_ccbi);
	node.controller.ccbInit();
};

vee.IAPMgr.NeedLoginCallback = function () {
	LyWXLogin.show();
};

var EfxChildBalloon = vee.Class.extend({
	show : function () {
		this.playAnimate("loop");
		this.rootNode.runAction(cc.sequence(
			cc.delayTime(0.3),
			cc.callFunc(function () {
				this.rootNode.setVisible(true);
			}.bind(this))
		));
	}
});