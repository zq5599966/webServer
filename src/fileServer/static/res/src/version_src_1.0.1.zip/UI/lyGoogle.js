/**
 * Created with AppCode.
 * User: WanThirty
 * Date: 15/11/19
 * Time: 下午1:57
 * To change this template use File | Settings | File Templates.
 */

var LyGoogle = vee.Class.extend({
	btnClose : null,
	btnLeaderBoard : null,
	btnAchievement : null,
	isOver : false,

	ccbInit : function () {
		this.handleKey(true);

		this.initController();
	},
	
	initController : function () {

		vee.Controller.initSelector(1, 2, this.onClose.bind(this), cc.p(0, 0));
		vee.Controller.registerItemByButton(this.btnLeaderBoard, cc.p(0,0), this.onLeaderBoard.bind(this), res.mfi_pause_btn_big_png);
		vee.Controller.registerItemByButton(this.btnAchievement, cc.p(0,1), this.onAchievement.bind(this), res.mfi_pause_btn_big_png);
		vee.Controller.activeSelector();

		vee.Controller.registerButtonAction(
			vee.KeyCode.BUTTON_B,
			this.onClose.bind(this)
		);
		vee.Controller.activeButton();
	},

	onKeyBack : function () {
		this.onClose();
		return true;
	},

	onLeaderBoard : function () {
		//if (game.Data.isAutoLoginGoogle) {
		//	vee.GameCenter.showLeaderboard(0);
		//} else {
		//	vee.PopMgr.alert(
		//		vee.Utils.getLocalizedStringForKey("Do you want to login Google Play Game Services?"),
		//		vee.Utils.getLocalizedStringForKey("GooglePlay"),
		//		function() {
		//			vee.GameCenter.showLeaderboard(0);
		//		},
		//		function() {
		//			this.onClose();
		//		}.bind(this)
		//	);
		//}
		vee.GameCenter.showLeaderboard(0);
	},

	onAchievement : function () {
		//if (game.Data.isAutoLoginGoogle) {
		//	vee.GameCenter.showAchievements();
		//} else {
		//	vee.PopMgr.alert(
		//		vee.Utils.getLocalizedStringForKey("Do you want to login Google Play Game Services?"),
		//		vee.Utils.getLocalizedStringForKey("GooglePlay"),
		//		function() {
		//			vee.GameCenter.showAchievements();
		//		},
		//		function() {
		//			this.onClose();
		//		}.bind(this)
		//	);
		//}
		vee.GameCenter.showAchievements();
	},

	onClose : function () {
		if (this.isOver) return;
		this.isOver = true;
		this.playAnimate("hide", function () {
			vee.PopMgr.closeLayerByCtl(this);
		}.bind(this));
	}
});

LyGoogle.show = function () {
	var node = vee.PopMgr.popCCB(res.index_GooglePlay_ccbi, {alpha:0});
	node.controller.ccbInit();
};