/**
 * Created with AppCode.
 * User: WanThirty
 * Date: 16/5/26
 * Time: 下午3:51
 * To change this template use File | Settings | File Templates.
 */

var LyTipsDesc = vee.Class.extend({
	lbContent : null,
	ccbInit : function () {
		this.playAnimate("show");
		this.setDescIdx(0);
	},

	onChange1 : function () {
		if (game.Logic._mapTips) this.setDescIdx(0);
	},
	onChange2 : function () {
		if (game.Logic._mapTips) this.setDescIdx(1);
	},
	onChange3 : function () {
		if (game.Logic._mapTips) this.setDescIdx(2);
	},

	_idx : null,
	setDescIdx : function (idx) {
		if (idx == this._idx) {
			return;
		} else {
			this._idx = idx;
			this.lbContent.setString(game.Logic._mapTips[this._idx]);
			for (var i = 1; i < 4; ++i)
			{
				var btn = this["btn"+i];
				if (i == (idx+1)) { // idx = tag - 1
					btn.setBackgroundSpriteForState(cc.Scale9Sprite.create("res/btn_tips_"+i+"_on.png"), cc.CONTROL_STATE_NORMAL);
				} else {
					btn.setBackgroundSpriteForState(cc.Scale9Sprite.create("res/btn_tips_"+i+"_off.png"), cc.CONTROL_STATE_NORMAL);
				}
			}
		}
	},

	onClose : function () {
		this.playAnimate("hide", function () {
			vee.PopMgr.closeLayerByCtl(this);
		}.bind(this));
	}
});

LyTipsDesc.show = function () {
	var node = vee.PopMgr.popCCB(res.lyTipsDesc_ccbi, { alpha :     0 });
	node.controller.ccbInit();
};