/**
 * Created with AppCode.
 * User: WanThirty
 * Date: 15/9/11
 * Time: 下午3:39
 * To change this template use File | Settings | File Templates.
 */

var LyPause = vee.Class.extend({

	btnQuit : null,
	btnControl : null,
	btnResume : null,
	btnChange : null,
	ccbMusicBtn : null,
	ccbSoundBtn : null,
	lbChangeDesc : null,

	_isOver : false,

	onCreate : function () {
		vee.Audio.pauseMusic();
//		vee.Audio.stopMusic();
		game.Data.oPauseCtl = this;
	},

	onKeyBack : function(){
		this.onResume();
		return true;
	},

	ccbInit : function () {
		if (vee.data["stad"]) {
			
		}
		this.playAnimate("show", function () {
//			cc.director.pause();
			game.Data.oLyGame.rootNode.pause();
		});
		this.handleKey(true);
		this.btnChange.setSelected(game.Data.isStaticBG());
		vee.Audio.playEffect(res.inGame_menu_showPausePage_mp3);
		this.btnChange.setVisible(game.Data.isAndroid);
		this.lbChangeDesc.setVisible(game.Data.isAndroid);

		vee.Controller.cacheControllerState(this);
	},

	onExit : function () {
		game.Data.oPauseCtl = null;
	},

	_tempControllerState : null,
	initController : function () {
		vee.Controller.initSelector(4,3,this.onResume.bind(this), cc.p(1,0));
		this.createItem();
		vee.Controller.activeSelector();
	},
	createItem : function () {
		vee.Controller.registerItemByButton(this.btnResume, cc.p(1,0), this.onResume.bind(this), "res/mfi_pause_btn_big.png");
		vee.Controller.registerItemByButton(this.btnQuit, cc.p(2,0), this.onQuit.bind(this), "res/mfi_pause_btn_small.png");
		var soundBtnCtl = this.ccbSoundBtn.controller;
		vee.Controller.registerItemByButton(
			soundBtnCtl.btnChange,
			cc.p(1,1),
			soundBtnCtl.onChange.bind(soundBtnCtl),
			"res/mfi_pause_btn_small.png");
		var musicBtnCtl = this.ccbMusicBtn.controller;
		vee.Controller.registerItemByButton(
			musicBtnCtl.btnChange,
			cc.p(2,1),
			musicBtnCtl.onChange.bind(musicBtnCtl),
			"res/mfi_pause_btn_small.png");
		if (game.Data.isAndroid) vee.Controller.registerItemByButton(this.btnChange, cc.p(0,2), this.onChange.bind(this), "res/mfi_pause_btn_small.png");
	},

	// ccb button bindings...
	onQuit : function () {
		if (this._isOver) return;
		vee.Audio.playEffect(res.inGame_menu_showMessage_mp3);
		vee.PopMgr.alert(
			vee.Utils.getLocalizedStringForKey("Do you want to return to the Stage Select page? (Your game progress will not be saved.)"),
			vee.Utils.getLocalizedStringForKey("QUIT"),
			function () {
//				cc.director.resume();
				this._isOver = true;
				game.Data.oLyGame.rootNode.resume();
				game.Data.oPauseCtl = null;
				vee.PopMgr.resume();
				this.playAnimate("empty", function () {
					game.Data.stageFinish(game.FinishType.QUIT);
					vee.Transition.out(res.MapTransition_ccbi, function () {
						LyLevelSelect.show();
					});
					vee.Controller.deactiveSelector();
				});
			}.bind(this),
			function () {}
		);
	},

	onChange : function () {
		var staticBG = game.Data.isStaticBG();
		this.btnChange.setSelected(!staticBG);
		game.Data.setStaticBG(!staticBG);
	},

	onControl : function () {
		if (this._isOver) return;
		LyPosSetting.show();
	},

	onResume : function () {
		vee.Controller.deactiveButton();
		vee.Controller.deactiveSelector();

		vee.Audio.resumeMusic();
//		vee.Audio.playLastMusic();

		if (this._isOver) return;
		this._isOver = true;
		cc.director.resume();
		game.Data.oPauseCtl = null;
		vee.Audio.playEffect(res.inGame_menu_hidePausePage_mp3);
		this.playAnimate("hide", function () {
			vee.PopMgr.closeLayer();
			vee.PopMgr.resume();
			if (game.Data.oLyGame) {
				game.Data.oLyGame.resumeGame();
				vee.Controller.reviveControllerStateByCtl(this);
			}
		}.bind(this));

		game.Data.oLyGame.lyBG.removeAllChildren();
		if (game.Data.bgName) {
			if (game.Data.isStaticBG()) {
				var bg = new cc.Sprite("res/"+game.Data.bgName+".png");
				bg.setAnchorPoint(cc.p(0,0));
				game.Data.oLyGame.lyBG.addChild(bg, 1);
				game.Data.oLyGame.bgCtl = null;
			} else {
				var bg = LyDynamicBG.create(game.Data.bgName);
				game.Data.oLyGame.lyBG.addChild(bg, 1);
				game.Data.oLyGame.bgCtl = bg.controller;
			}
		}

		if(game.Data.stageType == game.StageType.Parkour && game.Data.oPlayerCtl != null){
			game.Data.oPlayerCtl.moveRight();
		}
	}
});

LyPause.show = function () {
	var node = vee.PopMgr.popCCB(res.gamePuase_ccbi, {alpha : 0});
	node.controller.ccbInit();
};