/**
 * Created with AppCode.
 * User: WanThirty
 * Date: 15/7/22
 * Time: 下午6:12
 * To change this template use File | Settings | File Templates.
 */

var ItemDrawer = Item.extend({
	_type : game.ObjectType.Drawer,
	_drawerDir : null,
	_drawerDirNum : null,
	inMapBack : true,

	spDrawer : null,

	onCreate : function() {
		this.resetBoxInfo();
		this.afterCreate();
	},

	bornWithPos : function(pos) {
		game.Data.registerUpdateObj(this);
		var mapConfig = game.Logic.configMap.getObject(this._gridInMap);
		var dir = null;
		if (mapConfig) {
			dir = vee.Direction.string2Direction(mapConfig.name);
		} else {
			var arrDir = this.getDirArr();
			for (i in arrDir) {
				var checkDir = arrDir[i];
				var td = game.Logic.map.getObject(vee.Utils.pAdd(this._gridInMap, vee.Direction.direction2Point(checkDir)));
				if (game.Logic.isBlock(td)) {
					dir = checkDir;
				}
			}
		}
		dir = dir ? dir : vee.Direction.Left;
		this._drawerDir = vee.Direction.revert(dir);
		this.setFaceTo(dir);
		this._drawerDirNum = -vee.Direction.direction2Point(dir).x;
		this.setElePosition(cc.p(this._pos.x - (this._drawerDirNum * TILE_WIDTH_HALF), this._pos.y));
		this.nodeBox.setContentSize(cc.size(this.boxSize.width + TILE_WIDTH_HALF, this.boxSize.height + TILE_WIDTH));
		this.resetBoxInfo();

		// run action
		this.playAnimate("out");
	},

	getEleRect : function() {
		var pos = this.getElePosition();
		var scaleX = this.spDrawer.getScaleX();
		var rectX;
		if (this._drawerDirNum > 0) {
			rectX = 0;
		} else {
			rectX = (this.boxOffset.x - this.boxSize.width) * scaleX;
		}
		rectX += pos.x;
		var width = this.boxSize.width * scaleX;
		var rect = cc.rect(
			rectX,
			pos.y + this.boxOffset.y - this.boxSize.height/2,
			width,
			this.boxSize.height
		);
		return rect;
	},

	updatePos : function(dt) {
		this._rectEnemy = this.getEleRect();
		this.checkEleCollide(game.Data.oPlayerCtl);
		this._lastPos = vee.Utils.pAdd(this._pos, this.nodeBox.getPosition());
	},

	checkEleCollide : function (nodeCtl) {
		// calc player next frame position...
		var castNextPos = nodeCtl.getNextCastPos();

		if (cc.rectContainsPoint(this._rectEnemy, castNextPos)) {
			var playerPos = nodeCtl._pos;

			if (playerPos.y >= this._rectEnemy.y + this._rectEnemy.height)
			{
				if (nodeCtl._speedY <= 0) {
					this.pushTo(vee.Direction.Top, playerPos, this._rectEnemy, nodeCtl);
				}
			}
			else if (playerPos.y <= this._rectEnemy.y)
			{
				this.pushTo(vee.Direction.Bottom, playerPos, this._rectEnemy, nodeCtl);
			}
			else if (playerPos.x <= this._rectEnemy.x)
			{
				this.pushTo(vee.Direction.Left, playerPos, this._rectEnemy, nodeCtl);
			}
			else if (playerPos.x >= this._rectEnemy.x + this._rectEnemy.width)
			{
				this.pushTo(vee.Direction.Right, playerPos, this._rectEnemy, nodeCtl);
			}
			else
			{
				this.pushTo(this._drawerDir, playerPos, this._rectEnemy, nodeCtl);
			}
		}
	},

	getPosZone : function (pos) {

	},

	pushTo : function (dir, posPlayer, rectEnemy, nodeCtl) {
		if (!dir) return;
		switch (dir) {
			case vee.Direction.Top : {
				// player should stand
				nodeCtl.downToBarrier();
				nodeCtl.needUpdateState = false;
				nodeCtl.setJumping(false);
				nodeCtl.isUpdateY = false;
				nodeCtl.updateState();
				nodeCtl.setElePosition(cc.p(posPlayer.x, rectEnemy.y + rectEnemy.height)); // + posOff.y
			}
				break;
			case vee.Direction.Bottom : {
				// up to barrier98
				nodeCtl.setElePosition(cc.p(posPlayer.x, rectEnemy.y - 5));
				nodeCtl.upToBarrier();
				nodeCtl.stopRunning();
			}
				break;
			case vee.Direction.Left : {
				nodeCtl.setElePosition(cc.p(rectEnemy.x, posPlayer.y));
				nodeCtl.rightToBarrier();
				nodeCtl.stopRunning();
			}
				break;
			case vee.Direction.Right : {
				nodeCtl.setElePosition(cc.p(rectEnemy.x + rectEnemy.width, posPlayer.y));
				nodeCtl.leftToBarrier();
				nodeCtl.stopRunning();
			}
				break;
			default :
				break;
		}
		this._tempDir = dir;
	},

	getPosOff : function() {
		return vee.Utils.pSub(vee.Utils.pAdd(this.getElePosition(), this.nodeBox.getPosition()), this._lastPos);
	},

	getInhaleController : function () {
		return null;
	},

	getDirArr : function () {
		var arrDir = [];
		arrDir.push(vee.Direction.Left);
		arrDir.push(vee.Direction.Right);
//		arrDir.push(vee.Direction.Top);
//		arrDir.push(vee.Direction.Bottom);
		return arrDir;
	},

	removeOnGridChange : function () {
		game.Data.removeUpdateObj(this);
	}
});