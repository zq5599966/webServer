/**
 * Created with AppCode.
 * User: WanThirty
 * Date: 15/9/13
 * Time: 上午11:36
 * To change this template use File | Settings | File Templates.
 */

var UIEnergy = vee.Class.extend({
	lbCounter : null,
	nodeEnergy : null,

	//jin
	lbPowerNum : null,
	lbPowerCounter : null,
	powerTimeLeft : null,
	mTimer : null,
	spProgress : null,

	timeLeft : null,

	onCreate : function () {
		game.Data.oEnergyCtl = this;
		this.showEnergy();
	},

	onExit : function () {
		game.Data.oEnergyCtl = null;
		vee.Utils.unscheduleAllCallbacksForTarget(this.rootNode);
	},

	showEnergy : function () {
		var energy = game.Data.getEnergy();
		for (var i = 1; i < 6; ++i) {
			var node = this.nodeEnergy.getChildByTag(i);
			if (!node) {
				node = UIEnergyCell.create();
				this.nodeEnergy.addChild(node);
				node.setTag(i);
				node.setPositionX(i*38-46);
			}
			if (i <= energy) node.controller.show();
			else node.controller.hide();
		}

		vee.Utils.unscheduleAllCallbacksForTarget(this.rootNode);
		//cc.log("时间记录：" + parseInt(vee.data["power_ts"]));
		// show time counter
		if (energy < 5) {
			// calc time left
			this.playAnimate("empty");
			var ts = game.Data.getEnergyReviveTs();
			var nowTs = new Date().getTime();
			this.timeLeft = parseInt((ts - nowTs)/1000);

			// show
			this.setTimeStr();

			// update
			vee.Utils.scheduleCallbackForTarget(this.rootNode, this.updateTimeCounter.bind(this), 1);
		} else if (parseInt(vee.dataManager.getPowerTs()) > 0) {
			if (parseInt(game.Data.getPowerLeftTime()) > 0){
				this.powerTimeLeft = parseInt(game.Data.getPowerLeftTime());
				//cc.log("剩余时间：" + this.powerTimeLeft);
				this.playAnimate("unlimiting");
				this.nodeEnergy.setVisible(false);
				//this.initProgress();
				this.setPowerTimeStr();
				this.updateProgressBar(this.powerTimeLeft / (game.Data.energyUnlimitedTime * 60));
				vee.Utils.scheduleCallbackForTarget(this.rootNode, this.updatePowerTimeCounter.bind(this), 1);
				this.spProgress.setVisible(true);
			} else {
				vee.Utils.scheduleOnce(function() {
					this.playAnimate("powerOver");
				}.bind(this), 1.0);
				vee.dataManager.setPowerTs(0);
			}
		} else {
			this.playAnimate("full");
			this.lbCounter.setVisible(true);
			this.lbCounter.setString("MAX");
		}

		//show power
		var power = game.Data.getPower();
		this.lbPowerNum.setString("x" + power);
	},

	//jin
	onBuyPower : function() {
		AlertGetPower.show(game.LifeEmptyType.Select);
	},

	usePower : function() {
		this.powerTimeLeft = parseInt(game.Data.getPowerLeftTime());
		this.playAnimate("usePower", function() {
			// show
			this.setPowerTimeStr();
			// update
			vee.Utils.unscheduleAllCallbacksForTarget(this.rootNode);
			vee.Utils.scheduleCallbackForTarget(this.rootNode, this.updatePowerTimeCounter.bind(this), 1);
			this.spProgress.setVisible(true);
			//this.initProgress();
		}.bind(this));
		vee.saveData();
	},

	setPowerTimeStr : function () {
		// cast time string
		var m = Math.floor((this.powerTimeLeft) / 60);
		var s = Math.floor((this.powerTimeLeft - m * 60));
		var strM = m < 10 ? "0"+m : m;
		var strS = s < 10 ? "0"+s : s;
		this.lbPowerCounter.setString(strM + ":" + strS);
	},

	updatePowerTimeCounter : function () {
		//cc.log("剩余时间 : " + this.powerTimeLeft);
		this.powerTimeLeft -= 1;
		if (this.powerTimeLeft > 0) {
			// refresh counter
			this.setPowerTimeStr();
			this.updateProgressBar(this.powerTimeLeft / (game.Data.energyUnlimitedTime * 60));
		} else {
			// power time up
			vee.Utils.unscheduleAllCallbacksForTarget(this.rootNode);
			this.playAnimate("powerOver", function() {
				//this.removeProgressBar();
				this.showEnergy();
				this.nodeEnergy.setVisible(true);
			}.bind(this));
			vee.dataManager.setPowerTs(0);
			vee.saveData();
		}
	},

	//progressTimer
	initProgress : function() {
		//this.removeProgressBar();
		//this.mTimer = cc.ProgressTimer.create(new cc.Sprite("ProgressTimer_A4.png"));
		//this.nodeProgress.addChild(this.mTimer);
		//this.mTimer.setPosition(cc.p(100, 0));
		////this.mTimer.type = cc.ProgressTimer.TYPE_BAR;
		//this.mTimer.setMidpoint(cc.p(0, 0));
		//this.mTimer.setBarChangeRate(cc.p(1, 0));
	},

	updateProgressBar : function(percentage) {
		//if (this.mTimer) {
		//	cc.log("进度：" + percentage);
		//	this.mTimer.setPercentage(percentage);
		//}
		//cc.log("进度：" + percentage);
		this.spProgress.setScaleX(5.55 * percentage);
		this.spProgress.setPositionX(-111);
	},

	removeProgressBar : function() {
		//if (this.mTimer) {
		//	this.mTimer.removeFromParent();
		//	this.mTimer = null;
		//}
		//this.spProgress.setScaleX(5.55);
	},
	//jin

	costAnimate : function () {
		var node = this.nodeEnergy.getChildByTag(game.Data.getEnergy());
		if (node) node.controller.use();
		else cc.log("error : invalid energy tag = "+game.Data.getEnergy());
	},

	// depends 'this.timeLeft'
	setTimeStr : function () {
		// cast time string
		var m = Math.floor((this.timeLeft) / 60);
		var s = Math.floor((this.timeLeft - m * 60));
		var strM = m < 10 ? "0"+m : m;
		var strS = s < 10 ? "0"+s : s;
		this.lbCounter.setString(strM + ":" + strS);
	},

	updateTimeCounter : function () {
		this.timeLeft -= 1;
		if (this.timeLeft > 0) {
			// refresh counter
			this.setTimeStr();
		} else {
			// add energy
			game.Data.addEnergy(1);
			var e = parseInt(vee.dataManager.getEnergy());
			if (e < 5) vee.dataManager.setEnergyTs(game.Data.nextEnergyTsFromNow());
			this.showEnergy();
		}
	}
});

var UIEnergyTemp = vee.Class.extend({

});