/**
 * Created with AppCode.
 * User: yop
 * Date: 15/10/27
 * Time: 下午3:33
 * To change this template use File | Settings | File Templates.
 */

LevelController.LevelMini202 = LevelController.extend({
	eventStory1 : function(grid, dir) {
		this.showStory(1, grid, ""+
		"RemoveEnemy;"+
		"MoveCamera,64,18,2;"+
		"SelectNpc;"+
		"ShowDialog,"+ vee.Utils.getLocalizedStringForKey("Oh I just forget one thing.", "哦，我忘了件事儿。") +";"+
		"ShowDialog,"+ vee.Utils.getLocalizedStringForKey("(Snap) Here's your bonus.", "(响指)你的奖励。") +";"+
		"HideDialog;"+
		"TimeLine,huxi_2;"+
		"Delay,1;"+
		"AddCoin," + vee.Utils.getObjByPlatform('400','700','400') + ";"+
		"Delay,2;"+
		"GameOver"+
		"");
	}
});
