/**
 * Created with AppCode.
 * User: Yop Chan
 * Date: 15-5-27
 * Time: 下午3:42
 * To change this template use File | Settings | File Templates.
 */

/*

FrameProcess 的设计原意是为了加载资源的时候，把代码从一帧拆分成数帧，从而不阻断 loading 动画
注意：FrameProcess 只会增加代码运行时间，使用 FrameProcess 是为了更好的 Loading 体验

如何使用 FrameProcess

比如原代码为：

for (var i = 0; i < 100; i++){
	for (var j = 0; j < 100; j++) {
		var sp = cc.Sprite.create('image_' + i + '_' + j + '.png');     // 加载资源会阻断 UI
		sp.setPosition(i * 100, j * 100);
		scene.addChild(sp);
	}
}

可以修改为：

var proc = new FrameProcess();
for (var i = 0; i < 100; i++) {
	for (var j = 0; j < 100; j++) {
		var context = {
			i : i,
			j : j,
			scene : scene
		};
		proc.addFragment(
			function(context){
                var sp = cc.Sprite.create('image_' + context.i + '_' + context.j + '.png');     // 每帧执行，不阻断 UI
                sp.setPosition(context.i * 100, context.j * 100);
                context.scene.addChild(sp);
                scene.udpateProcess( this.getProcess() *100 ); // 每执行一个代码，在 UI 中更新进度
			},
			context // 把需要的参数传递进去 fragment 里面
		);
	}
}

proc.run();


 */

var vee = vee = vee || {};

var FrameProcess = cc.Class.extend({
	/**
	 * add new function for next frame
	 * @param callback
	 * @param cx normally pass 'this'
	 */
	addFragment : function(callback, data){
		if (!this._fragments) this._fragments = [];
		this._fragments.push({callback : callback, data : data});
	},

	_fragments : null,
	_runFrame : function(){
		this._currentObj = this._fragments.shift();
		this._currentObj.callback.apply(this, this._currentObj.data);
		if (this._callback) this._callback(this);
		if (this._fragments.length == 0) {
			vee.Utils.unscheduleAllCallbacksForTarget(this);
		}
	},

	_currentObj : null,
	_interval : 1/60,
	_totalCount : 0,
	_callback : null,

	setInterval : function(interval) {
		this._interval = interval;
	},

	/**
	 * start process
	 */
	run : function(callback){
		if (callback) this._callback = callback;
		this._totalCount = this._fragments.length;
		vee.Utils.scheduleCallbackForTarget(this, this._runFrame, this._interval, cc.REPEAT_FOREVER);
	},

	getProgressInPercentage : function() {
		return (this._totalCount - this._fragments.length)/this._totalFrames;
	},

	getProgress : function() {
		return (this._totalCount - this._fragments.length);
	},

	getTotal : function() {
		return this._totalCount || this._fragments.length;
	}


});

