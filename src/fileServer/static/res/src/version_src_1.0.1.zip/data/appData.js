/**
 * Created by john on 2016/11/25.
 */
/*
var app = app = app || {};

app.data = {
    // AppID : 1041873285,                  //
    AppName : "SuperCat",
    AppAlias : "supercat",
    AppURL : null,

    IAPs : [],                  //
    LeaderboardIDs : [],        //
    RateURL : null,
    PromoURL : "http://www.veewo.com",
    PromoChannel : "promo",
    PromoBannerEnable : true,
    PromoFullScreenEnable : true,

    //plugin
    GameCenterPluginName : "SocialGameCenter",
    GameCenterPluginConfig : {"appid" : "1041873285"},  //

    //plugin
    AnalyticsPluginName : "AnalyticsUmengGame",
    AnalysticsPluginConfig : "08F4D0E63C085EE97F3C961A5B481DD3",    //分为免费版和付费版

    AnalyticsPluginADTrackName : "AnalyticsMAT",
    AnalyticsPluginADTrackConfig : {                    //
        // Platform depends
    },

    IAPPluginName : "IAPManager",
    IAPConfig : null,                                   //

    AdVideoPluginName : "AdsVungle",
    AdVideoPluginConfig : {                             //
        AdsVungle : "com.veewo.supercat"
    },

    AdBannerPluginName : "AdsAdapter",                  //广告plugin类名
    // AdBannerPluginConfig : {                            //广告id
    //     AdvertiserID : "164496",
    //     ConversionKey : "1b0e697a2fa9501dcafa6a08e2c1c017"
    // },

    AdInterstialPluginName : "AdsAdapter",
    AdInterstialPluginCoinfig : null,

    IsBannerEnabled : true,
    IsInterestialEnabled : true,

    AdPosConfig : [],
    AdPosEntityConfig : [],

    ShareKTPlay_IOS_cn : {
        key : "1czpLrGVUp",
        secret : "9bdb56cbb77c3eaae133fa1071624e896c85f5ba"
    },

    ShareKTPlay_android : {
        key : "19ypSjYv6D",
        secret : "96f8fb00696a9f83add4c0b8afdd19af801e54fb"
    }
};

app.data.ios = {
    AppID : 1041873285,

    AnalyticsPluginADTrackConfig : {                            //不知道什么鬼 init plugin
        AdvertiserID : "164496",
        ConversionKey : "1b0e697a2fa9501dcafa6a08e2c1c017"
    },

    GameCenterPluginConfig : {"appid" : "1041873285"},

    //广告位id
    AdBannerPluginConfig : {
        AppGoogleBannerId: "ca-app-pub-4587184008612513/3196418381",            //未启用

        AppGoogleInterstialId: "ca-app-pub-1777019132527367/9535896334",        //多处修改

        //AppFaceBookBannerId : "324268734426400_478726335647305",
        AppFaceBookInterstialId : "150931201938556_234107046954304",            //多处修改

        AppGoogleRewardedVideoId : "ca-app-pub-1777019132527367/7773351931"     //多处修改
    },

    //vungle视频广告id
    AdVideoPluginConfig : {
        AdsVungle : "1041873285"
    },

    //排行榜id
    LeaderboardIDs : ["com.veewo.stars"],

    Achievements : [                        //成就
        "com.veewo.star1",   // star 1
        "com.veewo.star2",   // star 2
        "com.veewo.star3",   // star 3
        "com.veewo.star4",   // star 4
        "com.veewo.star5",   // star 5
        "com.veewo.flash",   // flash
        "com.veewo.jump",    // jump
        "com.veewo.heart",   // heart
        "com.veewo.coin"     // coin
    ],

    //内购id
    IAPs : [
        {ProductID: "com.veewo.unlock", NonConsumable:"false"},
        {ProductID: "com.veewo.allcat", NonConsumable:"true"},
        {ProductID: "com.veewo.power", NonConsumable:"false"}
    ],

    // 自定义广告位 未启用
    AdOdd      : "ca-app-pub-1777019132527367/1974641134",
    AdEven     : "ca-app-pub-1777019132527367/4442904336",
    AdPause    : "ca-app-pub-1777019132527367/2966171130",
    AdGameOver : "ca-app-pub-1777019132527367/7396370731",
    AdStartUp  : "ca-app-pub-1777019132527367/8873103936",
    AdExit     : "ca-app-pub-1777019132527367/3451374331"


};

app.data.android = {
    AppID : "com.veewo.supercat",

    AnalyticsPluginADTrackConfig : {
        AdvertiserID : "164496",
        ConversionKey : "1b0e697a2fa9501dcafa6a08e2c1c017"
    },

    GameCenterPluginConfig : {"appid" : "com.veewo.supercat"},

    AdBannerPluginConfig : {
        AppGoogleBannerId: "ca-app-pub-4587184008612513/3196418381",            //未启用

        AppGoogleInterstialId: "ca-app-pub-1777019132527367/2533549534",        //多处修改
        //change end

        //AppFaceBookBannerId : "324268734426400_478726335647305",
        AppFaceBookInterstialId : "150931201938556_150931438605199",            //多处修改

        AppGoogleRewardedVideoId : "ca-app-pub-1777019132527367/7083425138"     //多处修改
    },

    AdVideoPluginConfig : {
        AdsVungle : "com.veewo.supercat"
    },

    LeaderboardIDs : ["CgkIu7e9p-oLEAIQCQ"],

    Achievements : [
        "CgkIu7e9p-oLEAIQAQ",   // star 1
        "CgkIu7e9p-oLEAIQAg",   // star 2
        "CgkIu7e9p-oLEAIQAw",   // star 3
        "CgkIu7e9p-oLEAIQBA",   // star 4
        "CgkIu7e9p-oLEAIQBQ",   // star 5
        "CgkIu7e9p-oLEAIQAA",   // flash
        "CgkIu7e9p-oLEAIQBg",   // jump
        "CgkIu7e9p-oLEAIQBw",   // heart
        "CgkIu7e9p-oLEAIQCg"    // coin
    ],

    IAPs : [
        {ProductID: "com.veewo.unlocklevels", NonConsumable:"false"},
        {ProductID: "com.veewo.allcat", NonConsumable:"true"},
        {ProductID: "com.veewo.power", NonConsumable:"false"},
        {ProductID: "com.veewo.moon", NonConsumable:"true"}
    ],

    // Custom...
    AdOdd      : "ca-app-pub-1777019132527367/1974641134",
    AdEven     : "ca-app-pub-1777019132527367/4442904336",
    AdPause    : "ca-app-pub-1777019132527367/2966171130",
    AdGameOver : "ca-app-pub-1777019132527367/8516174730",
    AdStartUp  : "ca-app-pub-1777019132527367/2609241934",
    AdExit     : "ca-app-pub-1777019132527367/3451374331",

    IAPConfig : {IAPID : "MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAhb+hA/lLAbVynW5AOQAurv4nsgDTRh4PsuHH3smCq01FGc4VqR4r/Uc1sOHZ3cR0ocHc2ISycIXd2A8/FW6ZQ9nRVHunYXqKwGSMZiImrPKH3qz4bChdxs42AtSTMutDBVIc3AVjbkOD5yaPh09xUxZ9lJDmJrXRoj0sKvn2FCyYpSYQyJZjTBOZs1+fGjaUK9ytiF5lZkhdIfsHkZA256kwq1uYGOi/KQk59qeCqfMg8ovA1Kgno+mitR2aG8A9PimG7WNPneqy3Ss7Lo68C5tT8RaWnXg2ZnLaWbZveyVfJFY2jGrI/K1CV8f+MJ7OqSu24nFXlPbgG22IuJaBhQIDAQAB"},
    packageName : "com.veewo.supercat",

};
*/

app.data.free = {
    AnalysticsPluginConfig : "8D7311350BF429B979C6101EA7D97F44",
    AdPosEntityConfig : ["AdsAdapter","AdsAdapter","AdsAdapter"],
}

app.data.iosFree_CN = {
    AppID : 1065433630,
    AdBannerPluginConfig : {
        AppGoogleBannerId: "ca-app-pub-4587184008612513/3196418381",            //未启用
        // AppGoogleInterstialId: "ca-app-pub-1777019132527367/9535896334",        //多处修改
        AppGoogleInterstialId : "ca-app-pub-1777019132527367/2672393133",
        //AppFaceBookBannerId : "324268734426400_478726335647305",
        AppFaceBookInterstialId : "150931201938556_234107046954304",            //多处修改
        AppGoogleRewardedVideoId : "ca-app-pub-1777019132527367/7773351931"     //多处修改
    },

    IAPs : [
        {ProductID: "com.veewo.unlock.glb", NonConsumable:"false"},
        {ProductID: "com.veewo.allcat", NonConsumable:"true"},
        {ProductID: "com.veewo.power", NonConsumable:"false"},
        {ProductID: "com.veewo.moonworld", NonConsumable:"true"}
    ],

    Achievements : [
        "com.veewo.star1",   // star 1
        "com.veewo.star2",   // star 2
        "com.veewo.star3",   // star 3
        "com.veewo.star4",   // star 4
        "com.veewo.star5",   // star 5
        "com.veewo.flash",   // flash
        "com.veewo.jump",    // jump
        "com.veewo.heart",   // heart
        "com.veewo.coin"     // coin
    ],
}

app.data.iosFree = {
    AppID : 1065433630,
    AdBannerPluginConfig : {
        AppGoogleInterstialId: "ca-app-pub-1777019132527367/8229937532",
        AppFaceBookInterstialId : "150931201938556_243303672701308",
        AppGoogleRewardedVideoId : "ca-app-pub-1777019132527367/7773351931"
    },

    IAPs : [
        {ProductID: "com.veewo.unlock.glb", NonConsumable:"false"},
        {ProductID: "com.veewo.allcat", NonConsumable:"true"},
        {ProductID: "com.veewo.power", NonConsumable:"false"},
        {ProductID: "com.veewo.moonworld", NonConsumable:"true"}
    ],

    Achievements : [
        "com.veewo.star1",   // star 1
        "com.veewo.star2",   // star 2
        "com.veewo.star3",   // star 3
        "com.veewo.star4",   // star 4
        "com.veewo.star5",   // star 5
        "com.veewo.flash",   // flash
        "com.veewo.jump",    // jump
        "com.veewo.heart",   // heart
        "com.veewo.coin"     // coin
    ],
}

app.ConfigManager = {
    // getAppID : function () {
    //     if(game.Data.isAndroid){
    //         return
    //     }
    //     else{
    //         return app.
    //     }
    // }
};