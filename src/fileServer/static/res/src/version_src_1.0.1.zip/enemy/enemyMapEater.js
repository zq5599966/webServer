/**
 * Created with AppCode.
 * User: WanThirty
 * Date: 15/11/27
 * Time: 下午3:26
 * To change this template use File | Settings | File Templates.
 */

var EnemyMapEater = Enemy.extend({
	objType : game.ObjectType.MapEater,
	_speedXLimit : 100,
	_speedXLimitForSet : 100,

	bornWithPos : function () {
		this._hasG = false;
		this._needSafePos = false;
		this._hasCollide = true;
		this._accX = 100;
	},

	checkCollide : function () {
		if (!this._hasCollide) return;
		var rectEnemy = this.getEleRect();
//		game.Data.oLyGame.drawNode.clear();
//		game.Logic.drawRect(rectEnemy);
//		game.Logic.drawRect(rectForCheck);
		if (cc.rectContainsPoint(rectEnemy, game.Data.oPlayerCtl._pos)) {
			this.collide();
		}
	},

	onGridChanged : function() {

	},

	collide : function(dir) {
		if (!this._hasCollide) return;
		this._hasCollide = false;
		this._accX = 0;
		game.Data.oPlayerCtl.getShock(vee.Direction.Right);
		game.Data.costLife(99);
	}
});