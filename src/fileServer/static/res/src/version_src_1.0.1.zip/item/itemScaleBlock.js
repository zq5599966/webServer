/**
 * Created with AppCode.
 * User: ZQ
 * Date: 16/8/22
 * Time: 下午3:22
 * To change this template use File | Settings | File Templates.
 */

var ItemScaleBlock = Item.extend({
	_type : game.ObjectType.ScaleBlock,


	ccbInit : function () {
		game.Data.registerUpdateObj(this);
		this.nodeRect = this.nodeBox;
//		vee.Utils.logObj(this.nodeRect, "zq debug ==========");
		this.updateBoxData();
	},

	showScaleAnimate : function (animateName, callback) {
		this.playAnimate(animateName, function () {
			if (callback) callback();
			this.die();
		}.bind(this));
	},

	// Called in component AccurateBlock
	onPlayerStepOn : function (dir) {

	},

	onDead : function(){
		game.Data.removeUpdateObj(this);
	},

	updatePos : function(dt){
		this.updateBoxData();
		this._rectEnemy = this.getEleRect();
		this.checkEleCollide(game.Data.oPlayerCtl);
	},

	updateBoxData : function () {
		this.boxOffset = this.nodeRect.getPosition();
		this.boxSize = this.nodeRect.getContentSize();
		this.boxSizeHalf = cc.size(this.boxSize.width/2, this.boxSize.height/2);
		this.playerSize = game.Data.oPlayerCtl.boxSize;
		this.playerSizeHalf = cc.size(this.playerSize.width/2, this.playerSize.height/2);
	},

	getEleRect : function() {
		var scaleX = this.nodeRect.getScaleX();
		var rectX = this.boxOffset.x - (this.boxSizeHalf.width * scaleX) - this.playerSizeHalf.width;
		var scaleY = this.nodeRect.getScaleY();
		var rectY = this.boxOffset.y - (this.boxSizeHalf.height * scaleY) - this.playerSizeHalf.height;
		var pos = this.getElePosition();
		rectX += pos.x;
		rectY += pos.y;
		var width = this.boxSize.width * scaleX + this.playerSize.width;
		var height = this.boxSize.height * scaleY + this.playerSize.height;
		var rect = cc.rect(rectX, rectY, width, height);
		return rect;
	},

	checkEleCollide : function (nodeCtl) {
		// calc player next frame position...
		var castNextPos = nodeCtl.getNextCastPos();

		if (cc.rectContainsPoint(this._rectEnemy, castNextPos)) {
			var playerPos = nodeCtl._pos;

			if (playerPos.y >= this._rectEnemy.y + this._rectEnemy.height)
			{
				if (nodeCtl._speedY <= 0) {
					this.pushTo(vee.Direction.Top, playerPos, this._rectEnemy, nodeCtl);
				}
			}
			else if (playerPos.y <= this._rectEnemy.y)
			{
				this.pushTo(vee.Direction.Bottom, playerPos, this._rectEnemy, nodeCtl);
			}
			else if (playerPos.x <= this._rectEnemy.x)
			{
				this.pushTo(vee.Direction.Left, playerPos, this._rectEnemy, nodeCtl);
			}
			else if (playerPos.x >= this._rectEnemy.x + this._rectEnemy.width)
			{
				this.pushTo(vee.Direction.Right, playerPos, this._rectEnemy, nodeCtl);
			}
			else
			{
				var hostCenterPos = vee.Utils.pAdd(this.getElePosition(), this.boxOffset);
				var farthestDir = this.getFarthestDir(playerPos, hostCenterPos);
				this.pushTo(farthestDir, playerPos, this._rectEnemy, nodeCtl);
			}
		}
	},

	getFarthestDir : function (playerPos, hostPos) {
		var off = vee.Utils.pSub(hostPos, playerPos);
		if ( Math.abs(off.x) > Math.abs(off.y) ) {
			return off.x > 0 ? vee.Direction.Left : vee.Direction.Right;
		} else {
			return off.y > 0 ? vee.Direction.Bottom : vee.Direction.Top;
		}
	},

	pushTo : function (dir, posPlayer, rectEnemy, nodeCtl) {
		if (!dir) return;
		switch (dir) {
			case vee.Direction.Top : {
				// player should stand
				nodeCtl.downToBarrier();
//				nodeCtl.needUpdateState = false;
				nodeCtl.setJumping(false);
				nodeCtl.isUpdateY = false;
				nodeCtl.updateState();
				nodeCtl.setElePosition(cc.p(posPlayer.x, rectEnemy.y + rectEnemy.height)); // + posOff.y
			}
				break;
			case vee.Direction.Bottom : {
				// up to barrier98
				nodeCtl.setElePosition(cc.p(posPlayer.x, rectEnemy.y- 5));
				nodeCtl.upToBarrier();
//				nodeCtl.stopRunning();
			}
				break;
			case vee.Direction.Left : {
				nodeCtl.setElePosition(cc.p(rectEnemy.x, posPlayer.y));
				nodeCtl.rightToBarrier();
				nodeCtl.stopRunning();
			}
				break;
			case vee.Direction.Right : {
				nodeCtl.setElePosition(cc.p(rectEnemy.x + rectEnemy.width, posPlayer.y));
				nodeCtl.leftToBarrier();
				nodeCtl.stopRunning();
			}
				break;
			default :
				break;
		}

		if (this.onPlayerStepOn) this.onPlayerStepOn(dir);
	}

});

ItemScaleBlock.show = function (grid, dir, isScaleUp, aniCallback) {
	// Create item content
	var content = Item.createWithInfo(game.TileInfo.TileItemScaleBlock, grid);
	content.controller.ccbInit();
	// Set position
	var pos = game.Logic.getTilePosCenterByGrid(grid);
	content.controller.initPosition(pos);
	// Show animation
	var animateName = vee.Direction.direction2String(dir);
	if (isScaleUp) {
		animateName += "_scaleup";
	} else {
		animateName += "_scaledown";
	}

	content.controller.showScaleAnimate(animateName, aniCallback);
};