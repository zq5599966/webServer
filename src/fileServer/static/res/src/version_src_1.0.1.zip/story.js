/**
 * Created with AppCode.
 * User: WanThirty
 * Date: 15/10/22
 * Time: 下午6:48
 * To change this template use File | Settings | File Templates.
 */

var Story = {
	selectedNPC : null,
	grid : null,
	arrScript : [],
	isShowStory : false,
	tempCameraPos : null,
	isSkip : false,
	handSkip : false,
	storyId : null,

	showStory : function (storyScript, grid, isSkip, id, handSkip) {
		cc.log("show story called!");
		if (!Story.isSkip) {
			Story.isSkip = isSkip;
		}
		this.storyId = id;
		this.handSkip = handSkip;

		var storyHasPlayed = game.Data.getStoryHasPlayed(game.Data.performingTMXIdx, id);
		if (storyHasPlayed) {
			if (Story.isSkip) {
				if (!handSkip) {
					if (id == 1) {
						handSkip = true;
					} else {
						cc.log("001");
						Story.callSkipFunc(Story.storyId);
						return;
					}
				}
			} else {
				game.Data.oLyGame.setSkipButtonVisible(true);
			}
		} else {
			cc.log("story "+id+" and hand skip is "+handSkip);
			if (handSkip) {
				Story.handSkip = false;
				cc.log("002");
				return;
			}
			Story.isSkip = false;
		}
		cc.log("story "+id+" played!");
		game.Data.setStoryHasPlayed(game.Data.performingTMXIdx, id, true);
		vee.saveData();

		if (!handSkip) {
			game.Data.oLyGame.stopCamera = true;
			game.Data.oLyGame.freezeButton = true;
			game.Data.oLyGame.showStoryBlackEdge();
			Story.isShowStory = true;
			if (game.Data.oPlayerCtl) {
				game.Data.oPlayerCtl._freezeMoveButton = true;
				game.Data.oPlayerCtl._speedX = 0;
				game.Data.oPlayerCtl._accX = 0;
				game.Data.oLyGame.leftBtnUp();
				game.Data.oLyGame.rightBtnUp();
				// about camera
				game.Data.cameraRestoreY = false;
				this.tempCameraPos = game.Data.oLyGame.lyContainer.getPosition();
			}
		}

		if (grid) {
			Story.grid = cc.p(grid.x, grid.y);
		}
		Story.arrScript = storyScript.split(";");
		Story.showNext();
	},

	showNext : function () {
		if (Story.arrScript.length > 0) {
			var storyFunc = Story.arrScript.shift();
			var arrArgs = storyFunc.split(",");
			var funcName = arrArgs.shift();
			if ((funcName != "SelectNpc"
				&& funcName != "MoveCamera"
				&& funcName != "Delay"
				&& funcName != "UnlockRole"
				&& funcName != "Trigger"
				&& funcName != "RemoveEnemy"
				&& funcName != "AddCoin"
				&& funcName != "GameOver") && !Story.selectedNPC) {
				cc.log("Error in "+funcName+": you should select a npc first."+Story.getDebugDesc());
			}
			var func = Story[funcName];
			if (_.isFunction(func)) {
				if (arrArgs.length == 0) {
					func();
				} else {
					func(arrArgs);
				}
			} else {
				cc.log("Error in story function name: '"+funcName+"', check spell!");
			}
		} else {
			if (Cinema.isCinema) {
				Cinema.storyOver();
				game.Data.oLyGame.hideStoryBlackEdge();
			} else {
				if (Story.handSkip) {
					Story.handSkip = false;
					return;
				}
				if (Story.isSkip) Story.callSkipFunc(Story.storyId);
				if (game.Data.oLyGame.nodeSkip.isVisible()) {
					game.Data.oLyGame.setSkipButtonVisible(false);
				}
				var playerPos = game.Data.oPlayerCtl.getElePosition();
				var targetPos = cc.p(0,0);
				targetPos.y = 60;
				game.Data.cameraYPos = -60;
				targetPos.x = game.Data.oPlayerCtl._faceTo == vee.Direction.Left ? -game.Data.cameraXPosLimit : game.Data.cameraXPosLimit;
				game.Data.cameraXPos = -targetPos.x;
				targetPos = cc.p(568-targetPos.x, 384-targetPos.y);
				targetPos = cc.p(targetPos.x - playerPos.x, targetPos.y - playerPos.y);
				game.Data.oPlayerCtl._offsetX = 0;
				game.Data.oPlayerCtl._offsetY = 0;
				game.Data.oLyGame.lyContainer.runAction(cc.sequence(
					cc.EaseInOut.create(cc.moveTo(0.8, targetPos), 3),
					cc.callFunc(function () {
						game.Data.oLyGame.stopCamera = false;
						game.Data.oLyGame.freezeButton = false;
						game.Data.oPlayerCtl._freezeMoveButton = false;
						Story.isShowStory = false;
						game.Data.oLyGame.hideStoryBlackEdge();
						// game.Data.oLyGame.showButtons(true);
						if(game.Data.playerType != game.PlayerType.Normal){
							game.Data.oLyGame.showControlButton(LyGame.ControlButtonType.ActionButton, true);
						}
						game.Data.oLyGame.showControlButton(LyGame.ControlButtonType.JumpButton, true);
						if(game.Data.isInParkour()){
							game.Data.oPlayerCtl.parkourMove();
						}
						else{
							game.Data.oLyGame.showControlButton(LyGame.ControlButtonType.MoveButton, true);
						}
					})
				));
			}
		}
	},

	skipStory : function () {
		game.Data.oLyGame.setSkipButtonVisible(false);
		Story.isSkip = true;
		game.Data.oLyGame.rootNode.stopAllActions();
		game.Data.oLyGame.lyContainer.stopAllActions();
		UIDialog.hide()
		if (Story.selectedNPC && Story.selectedNPC._container) {
			Story.selectedNPC._container.stopAllActions();
		}
		Story.showNext();
	},

	callSkipFunc : function(funcIdx) {
		if (game.Data.oLvCtl) {
			if (_.isFunction(game.Data.oLvCtl["skip"+Story.storyId])) {
				game.Data.oLvCtl["skip"+funcIdx]();
			}
		}
	},

	// story functions...
	SelectNpc : function(args) {    // npc name
		if (!args) args = "defaultNpc";
		Story.selectedNPC = game.Data.npcmap[args];

		if (!Story.selectedNPC) {
			cc.log("Error in selectnpc: wrong npc name "+args+Story.getDebugDesc());
		}
		Story.showNext();
	},

	TimeLine : function (args) {    // timeline name
		if (Story.isSkip) {
			Story.showNext();
		} else {
			if (_.isArray(args)) {
				Story.selectedNPC.playAnimate(args[0]);
			} else {
				Story.selectedNPC.playAnimate(args);
			}
			Story.showNext();
		}
	},

	Delay : function (args) {   // delay duration
		if (Story.isSkip) {
			Story.showNext();
		} else {
			var dur = parseFloat(args);
			if (game.Data.oLyGame) {
				game.Data.oLyGame.rootNode.runAction(cc.sequence(
					cc.delayTime(dur),
					cc.callFunc(function () {
						Story.showNext();
					})
				));
			}
		}
	},

	ShowDialog : function (args) {  // dialog content
		if (Story.isSkip) {
			Story.showNext();
		} else {
			var text = "";
			var len = args.length;
			for (var i = 0; i < len; ++i) {
				text += args[i];
				if (i != len-1) {
					text+=',';
				}
			}
			UIDialog.show(text);
		}
	},

	HideDialog : function () {
		if (Story.isSkip) {
			Story.showNext();
		} else {
			UIDialog.hide();
		}
	},

	FaceTo : function (args) {  // direction
		if (!Story.isSkip) {
			if (args == "left") {
				Story.selectedNPC.setFaceTo(vee.Direction.Left, true);
			} else {
				Story.selectedNPC.setFaceTo(vee.Direction.Right, true);
			}
		}
		Story.showNext();
	},

	PlaySound : function (args) {
		if (!Story.isSkip) {
			var arrArgs = (''+args).split(",");
			var snd = arrArgs.shift();
			var snd = "res/" + snd + vee.Utils.randomChoice(arrArgs) + ".mp3";
			vee.Audio.playEffect(snd);
		}
		Story.showNext();
	},

	Jump : function (args) {    // target grid X, target grid Y, jump height(optional)
		var arrArgs = (''+args).split(",");
		var len = arrArgs.length;
		if (len >= 2) {
			var targetGrid = cc.p(parseInt(arrArgs[0]), parseInt(arrArgs[1]));
			var targetPos = game.Logic.getTilePosCenterByGrid(targetGrid);

			if (Story.isSkip) {
				if (Story.selectedNPC) {
					Story.selectedNPC._container.setPosition(targetPos);
				}
				Story.showNext();
			} else {
				var height = 3;
				if (len > 2) {
					height = arrArgs[2];
				}
				height = height * TILE_WIDTH;
				Story.selectedNPC._container.runAction(cc.sequence(
					cc.delayTime(0),
					cc.callFunc(function () {
						Story.selectedNPC.playAnimate("run_jump_up");
					}),
					cc.jumpTo(0.7, targetPos.x, targetPos.y, height, 1),
					cc.callFunc(function () {
						Story.selectedNPC.playAnimate("huxi_1");
						Story.showNext();
					})
				));
			}

		} else {
			cc.log("Error in jump: arguments number invalid."+Story.getDebugDesc());
			Story.showNext();
		}
	},

	MoveRole : function (args) {    // target grid X, target grid Y
		var arrArgs = (''+args).split(",");
		var len = arrArgs.length;
		if (len >= 2) {
			var targetGrid = cc.p(parseInt(arrArgs[0]), parseInt(arrArgs[1]));
			var targetPos  = game.Logic.getTilePosCenterByGrid(targetGrid);

			if (Story.isSkip) {
				if (Story.selectedNPC) {
					Story.selectedNPC._container.setPosition(targetPos);
				}
				Story.showNext();
			} else {
				var nowPos     = Story.selectedNPC._container.getPosition();
				var nowGrid    = game.Logic.getTileGridByPos(nowPos);

				var offX = targetGrid.x - nowGrid.x;
				if (offX) {
					if (offX > 0) Story.selectedNPC.setFaceTo(vee.Direction.Right);
					else Story.selectedNPC.setFaceTo(vee.Direction.Left);
				}

				var dis = vee.Utils.manhattanDistance(vee.Utils.pSub(targetGrid, nowGrid));
				var dur = dis*0.2;

				Story.selectedNPC.playAnimate("run");
				Story.selectedNPC._container.runAction(cc.sequence(
					cc.moveTo(dur, targetPos),
					cc.callFunc(function () {
						Story.selectedNPC.playAnimate("huxi_1");
						Story.showNext();
					})
				));
			}

		} else {
			cc.log("Error in moverole: arguments number invalid."+Story.getDebugDesc());
			Story.showNext();
		}
	},

	ResetRole : function (args) {    // target grid X, target grid Y
		var arrArgs = (''+args).split(",");
		var len = arrArgs.length;
		if (len >= 2) {
			var targetGrid = cc.p(parseInt(arrArgs[0]), parseInt(arrArgs[1]));
			var targetPos  = game.Logic.getTilePosCenterByGrid(targetGrid);
			Story.selectedNPC._container.setPosition(targetPos);
		} else {
			cc.log("Error in moverole: arguments number invalid."+Story.getDebugDesc());
		}
		Story.showNext();
	},

	MoveCamera : function (args) {  // target grid X, target grid Y, dur
		if (Story.isSkip) {
			Story.showNext();
		} else {
			var arrArgs = (''+args).split(",");
			var len = arrArgs.length;
			if (len >= 3) {
				var targetGrid = cc.p(parseInt(arrArgs[0]), parseInt(arrArgs[1]));
				var targetPos  = game.Logic.getTilePosCenterByGrid(targetGrid);
				var dur = parseFloat(arrArgs[2]);
				game.Data.oLyGame.lyContainer.runAction(cc.sequence(
					cc.EaseInOut.create(cc.moveTo(dur, cc.p((568-targetPos.x), (384-targetPos.y))), 3),
					cc.callFunc(function () {
						Story.showNext();
					})
				));
			} else {
				cc.log("Error in movecamera: arguments number invalid."+Story.getDebugDesc());
				Story.showNext();
			}
		}
	},

	RemoveRole : function () {
		if (Story.selectedNPC) {
			var npcName = Story.selectedNPC.npcname;
			if (npcName) {
				game.Data.npcmap[npcName] = null;
			} else {
				for (var i in game.Data.npcmap) {
					game.Data.npcmap[i] = null;
				}
			}
			Story.selectedNPC._container.removeFromParent();
			Story.selectedNPC = null;
		}
		Story.showNext();
	},

	UnlockRole : function () {
		game.Data.setUnlocking(true);
		// refresh coin frame
		var nextAvatar = game.AvatarData.getNextAvatar();
		if (nextAvatar) {
			ItemCoin.coinFrameName = nextAvatar.coinFrame;
			game.Data.oLyGame.spCoinIcon.setSpriteFrame(ItemCoin.coinFrameName);
			ItemCoin.refreshAllCoin();
		} else {
			ItemCoin.coinFrameName = null;
		}
		Story.showNext();
	},

	Trigger : function (args) { // target grid X, target grid Y, dir(optional)
		var arrArgs = (''+args).split(",");
		var len = arrArgs.length;
		if (len >= 2) {
			var targetGrid = cc.p(parseInt(arrArgs[0]), parseInt(arrArgs[1]));
			var dir = vee.Direction.Origin;
			if (len >= 3) {
				dir = vee.Direction.string2Direction(arrArgs[2]);
			}
			var trigger = game.Logic.triggerMap.getObject(targetGrid);
			if (trigger) {
				trigger.func(targetGrid, dir);
			} else {
				cc.log("Error in Trigger: trigger does not exist."+Story.getDebugDesc());
			}
		}
		Story.showNext();
	},

	AddCoin : function (args) { // coin count
		game.Data.oLyGame.hideStoryBlackEdge();
		var coins = parseInt(args);
		Story._showCoinParticle(coins);
	},

	RemoveEnemy : function () {
		var objs = game.Logic.dynamicObjMap.getObjects();
		for (var i in objs) {
			var obj = objs[i];
			if (obj && obj._eleType == game.EleType.Enemy) {
				obj.die();
			}
		}
		Story.showNext();
	},

	GameOver : function () {
		game.Data.oLyGame.stopCamera = true;
		game.Data.oLyGame.freezeButton = true;
		Story.isShowStory = false;

		EfxStageEnd.show(game.Data.oPlayerCtl._pos);
		game.Data.oPlayerCtl.gameOverOut(function() {
			var container = game.Data.oPlayerCtl.getContainerNode();
			var rootNode = game.Data.oPlayerCtl.rootNode;
			container.setPosition(cc.p(0,0));
			container.retain();
			container.removeFromParent();
			var winNode = LyGameWin.show();
			winNode.controller.nodeAvatar.addChild(container);
			container.release();
			game.Data.oLyGameOver.oPlayer = rootNode;
			rootNode.controller.playAnimate("huxi_2", function() {
				if (game.Data.oLyGameOver) {
					game.Data.oLyGameOver.oPlayer.controller.randomBreath();
				}
			});
		});
	},

	getDebugDesc : function () {
		return " map idx = "+game.Data.performingTMXIdx+" grid.x = "+Story.grid.x+" grid.y = "+Story.grid.y;
	},

	// Add Coin...
	_coinOff : 0,
	_coinItr : 0,
	_coinFrameName : null,
	coinStartPos : null,
	coinPos : null,
	_showCoinParticle : function (coinOff) {
		Story._coinOff = coinOff;
		if (coinOff > 40) {
			Story._coinItr = Math.ceil(coinOff / 40);
		} else {
			Story._coinItr = 1;
		}
		cc.log(Story._coinItr);
		// coin start position...
		var rolePos = Story.selectedNPC._container.getPosition();
		var posInScreen = game.Data.oLyGame.getElePosInScreen(rolePos);
		Story.coinStartPos = vee.Utils.pAdd(posInScreen, cc.p(0, TILE_WIDTH_HALF));
		// coin end position...
		Story.coinPos = game.Data.oLyGame.getCoinIconPos();

		var targetAvatar = game.AvatarData.getNextAvatar();
		if (targetAvatar) {
			Story._coinFrameName = targetAvatar.coinFrame;
		} else {
			Story._coinFrameName = "coin_fist.png";
		}
		vee.Utils.scheduleCallbackForTarget(game.Data.oLyGame.blackEdgeBL, Story.updateShowCoin, 0.05);
	},

	updateShowCoin : function (dt) {
		if (Story._coinOff > 0) {
			if (Story._coinItr > Story._coinOff) {
				Story._coinItr = Story._coinOff;
			}
			Story._coinOff -= Story._coinItr;
			var sp = new cc.Sprite("#"+Story._coinFrameName);
			// start pos
			sp.setPosition(Story.coinStartPos);
			sp.itr = Story._coinItr;
			if (Story._coinOff <= 0) sp.isOver = true;
			sp.runAction(cc.sequence(
				cc.jumpTo(0.5, Story.coinPos.x, Story.coinPos.y, 80, 1),
				cc.callFunc(function () {
					game.Data.addTempCoin(sp.itr);
					if (sp.isOver) Story.showNext();
					sp.removeFromParent();
					vee.Audio.playEffect(res.inGame_function_countCoins_mp3);
				})
			));
			game.Data.oLyGame.rootNode.addChild(sp, 10);
		} else {
			vee.Utils.unscheduleAllCallbacksForTarget(game.Data.oLyGame.blackEdgeBL);
		}
	}
};