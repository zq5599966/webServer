/**
 * Created with AppCode.
 * User: yop
 * Date: 15/10/30
 * Time: 下午7:02
 * To change this template use File | Settings | File Templates.
 */


LevelController.LevelEvent201 = LevelController.extend({
	eventStory1 : function(grid, dir) {
		this.showStory(1, grid, ""+
			"SelectNpc,Flash;"+
			"FaceTo,right;"+
			"MoveCamera,30,13,2;"+
			"FaceTo,left;"+
			"MoveRole,31,13;"+
			"ShowDialog,"+ vee.Utils.getLocalizedStringForKey("Come closer, friend!", "朋友，靠近我一点！") +";"+
			"ShowDialog,"+ vee.Utils.getLocalizedStringForKey("A new friend has joined us!", "新的小伙伴已经加入我们的豪华套餐！") +";"+
			"ShowDialog,"+ vee.Utils.getLocalizedStringForKey("Do you mind if I chat with him/her/it?", "不和他/她/它交流一下吗？") +";"+
			"HideDialog;"+
			"SelectNpc;"+
			"MoveRole,32,13;"+
			"ShowDialog,"+ vee.Utils.getLocalizedStringForKey("Greetings!", "你好！") +";"+
			"ShowDialog,"+ vee.Utils.getLocalizedStringForKey("The data we have collected seems very interesting!", "我收集到的数据似乎有点微妙！") +";"+
			"ShowDialog,"+ vee.Utils.getLocalizedStringForKey("Could you help me analyze it?", "能否请你帮我分析一下？") +";"+
			"HideDialog;"+
			"UnlockRole;"+
			"TimeLine,huxi_2;"+
			"Delay,1;"+
			"Trigger,32,14;"+
			"Delay,1.5;"+
			"ShowDialog,"+ vee.Utils.getLocalizedStringForKey("So, please collect it!", "那麻烦你收集一下咯！") +";"+
			"ShowDialog,"+ vee.Utils.getLocalizedStringForKey("And I'm looking forward to you~", "期待你的表现～") +";"+
			"HideDialog;"+
			"Delay,1"+
		"");
	}
});