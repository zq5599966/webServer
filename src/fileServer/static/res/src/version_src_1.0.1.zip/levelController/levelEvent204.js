/**
 * Created with AppCode.
 * User: yop
 * Date: 15/11/2
 * Time: 下午5:49
 * To change this template use File | Settings | File Templates.
 */


LevelController.LevelEvent204 = LevelController.extend({
	eventStory1 : function(grid, dir) {
		this.showStory(1, grid, ""+
		"SelectNpc,Flash;"+
		"FaceTo,right;"+
		"MoveCamera,26,12,2;"+
		"FaceTo,left;"+
		"MoveRole,28,12;"+
		"ShowDialog,"+ vee.Utils.getLocalizedStringForKey("Good timing, my friend!", "来的正好，我的朋友！") +";"+
		"ShowDialog,"+ vee.Utils.getLocalizedStringForKey("A new friend is expecting you!", "新的小伙伴期待着与你相见呢！") +";"+
		"ShowDialog,"+ vee.Utils.getLocalizedStringForKey("Of course, with fresh data!", "当然，也带来了最新的数据！") +";"+
		"HideDialog;"+
		"SelectNpc;"+
		"MoveRole,27,12;"+
		"ShowDialog,"+ vee.Utils.getLocalizedStringForKey("Yahoo!", "你好！") +";"+
		"ShowDialog,"+ vee.Utils.getLocalizedStringForKey("Let's exchange some data?", "要不要交换一下数据？") +";"+
		"HideDialog;"+
		"ShowDialog,"+ vee.Utils.getLocalizedStringForKey("Try something new!", "新数据，新体验哦！") +";"+
		"ShowDialog,"+ vee.Utils.getLocalizedStringForKey("So you can be as strong as I am!", "这样你也可以这么强壮了。") +";"+
		"HideDialog;"+
		"UnlockRole;"+
		"TimeLine,huxi_2;"+
		"Delay,1;"+
		"Trigger,27,14;"+
		"MoveCamera,26,10,1;"+
		"Delay,1;"+
		"MoveCamera,26,12,1;"+
		"ShowDialog,"+ vee.Utils.getLocalizedStringForKey("Don't forget to share your new data with me!", "以后如果有新数据了，记得分享给我哦！") +";"+
		"ShowDialog,"+ vee.Utils.getLocalizedStringForKey("Good luck!", "祝你好运~") +";"+
		"HideDialog;"+
		"Delay,1"+
		"");
	}
});