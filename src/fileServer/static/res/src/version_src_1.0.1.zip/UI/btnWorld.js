/**
 * Created with AppCode.
 * User: WanThirty
 * Date: 16/3/17
 * Time: 下午1:01
 * To change this template use File | Settings | File Templates.
 */

var BtnWorld = vee.Class.extend({
	spBtnL : null,
	spNew  : null,
	_lvCtl : null,
	btnReverseWorld : null,

	isCanClick : true,

	onCreate : function () {
		vee.Controller.registerControllerSprite(this.spBtnL);
		this.spNew.setVisible(false);
		this.showMoon();
		BtnWorld.instance = this;
	},

	onExit : function () {
		vee.Controller.removeControllerSprite(this.spBtnL);
	},

	setLvCtl : function (ctl) {
		this._lvCtl = ctl;
	},

	setNew : function (isNew) {
		this.spNew.setVisible(isNew);
	},

	onReverseWorld : function () {

		// if(true){
		// 	vee.Ad.showVideoAd();
		// 	return;
		// }

		if (!this.rootNode.isVisible() || !this.isCanClick) return;
		var lvCtl = game.Data.oLvSelectCtl;
		var mapType = lvCtl._mapType;
		if (mapType == LyLevelSelect.MapType.MAP_NORMAL)
		{
			if ((game.Data.isAndroid || game.Data.version.isNewIosVersion) && game.Data.isFreeGame) {
				if (vee.data["moon"]) {
					// turn moon
					this._isSun = false;
					lvCtl.showLevelMap(LyLevelSelect.MapType.MAP_REVERSE);
				} else {
					cc.log("showMoonWorld2");
					LyUnlockedMoonWorld.show(true);
				}
			} else {
				this._isSun = false;
				lvCtl.showLevelMap(LyLevelSelect.MapType.MAP_REVERSE);
			}
		}
		else if (mapType == LyLevelSelect.MapType.MAP_REVERSE)
		{
			// turn sun
			this._isSun = true;
			lvCtl.showLevelMap(LyLevelSelect.MapType.MAP_NORMAL);
		}
	},

	// ccb animates...
	showSun : function() {
		this.playAnimate("Moon_show");
	},

	showMoon : function() {
		this.playAnimate("Sun_show");
	}

});

BtnWorld.instance = null;