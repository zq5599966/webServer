/**
 * Created with AppCode.
 * User: WanThirty
 * Date: 15/7/3
 * Time: 下午6:16
 * To change this template use File | Settings | File Templates.
 */

var ItemFallingBlock = ItemGravityPlatform.extend({
	_type : game.ObjectType.FallingBlock,
	_dangerCloseBottom : null,
	_dangerCloseTop : null,
	_moveDirH : null,
	_moveDirV : null,
	_createByPlatform : false,
	_isInit : false,

	bornWithPos : function(pos) {
		if (this._isInit) return;
		this._isInit = true;
		var mapConfig = game.Logic.configMap.getObject(this._grid);
		// Reset size
		var w = mapConfig.width || 3;
		var h = mapConfig.height || 0.5;
		this.nodeBox.setContentSize(cc.size((w+1)*game.Data.tileSizeWidth ,(h+1)*game.Data.tileSizeWidth));
		var texSize = cc.size((w)*game.Data.tileSizeWidth ,(h)*game.Data.tileSizeWidth);
		this.spPlatform.setContentSize(texSize);
		this.resetBoxInfo();
		this._checkPosWidth = this.boxSize.width/2;

		// Reset position
		var posOff = cc.p(texSize.width/2-game.Data.tileSizeWidth/2, texSize.height/2-game.Data.tileSizeWidth/2);
		var elePos = vee.Utils.pAdd(pos, posOff);
		this._container.setPosition(elePos);

		var arrArg = mapConfig.name.split(";");
		var targetGrid = game.Data.getPointFromString1(arrArg[0]);
		targetGrid = vee.Utils.pAdd(targetGrid, this._grid);
		var targetPos = game.Logic.getTilePosCenterByGrid(targetGrid);
		targetPos = vee.Utils.pAdd(targetPos, posOff);

		var lastGrid = targetGrid;
		if (!this._createByPlatform) {
			var argLen = arrArg.length;
			for (var i = 1; i < argLen; ++i) {
				var nextGrid = game.Data.getPointFromString1(arrArg[i]);
				nextGrid = vee.Utils.pAdd(lastGrid, nextGrid);
				game.Logic.createItemByGrid(nextGrid, true);
				lastGrid = cc.p(nextGrid.x, nextGrid.y);
			}
		}

		var movePosOff = vee.Utils.pSub(targetPos, elePos);
		var offX = 0;
		if (movePosOff.x > 0) {
			offX = -10;
		} else if (movePosOff.x < 0) {
			offX = 10;
		}
		var offY = 0;
		if (movePosOff.y > 0) {
			offY = -10;
		} else if (movePosOff.y < 0) {
			offY = 10;
		}

		this._moveDirH = (movePosOff.x > 0 ? vee.Direction.Right : vee.Direction.Left);
		this._moveDirV = (movePosOff.y > 0 ? vee.Direction.Top : vee.Direction.Bottom);
		var dur = vee.Utils.distanceBetweenPoints(targetPos, elePos)/100;
		this._container.runAction(cc.repeat(cc.sequence(
			cc.EaseIn.create(cc.moveTo(dur, targetPos), 6),
			cc.callFunc(function () {
				this._moveDirH = vee.Direction.revert(this._moveDirH);
				this._moveDirV = vee.Direction.revert(this._moveDirV);
			}.bind(this)),
			cc.moveTo(0.04, cc.p(targetPos.x+offX, targetPos.y+offY)),
			cc.moveTo(0.04, targetPos),
			cc.moveTo(0.02, cc.p(targetPos.x+offX, targetPos.y+offY)),
			cc.moveTo(0.02, targetPos),
			cc.delayTime(0.6),
			cc.moveTo(dur*1.3, elePos),
			cc.delayTime(1),
			cc.callFunc(function () {
				this._moveDirH = vee.Direction.revert(this._moveDirH);
				this._moveDirV = vee.Direction.revert(this._moveDirV);
			}.bind(this))
		), 9999));
		vee.Utils.scheduleCallbackForTarget(this.rootNode, this.updatePos.bind(this));
	},

	updatePos : function(dt) {
		this._dt = dt;
		var posPlayer = game.Data.oPlayerCtl.getElePosition();
		var posEnemy = this.getElePosition();
		if (posPlayer.x < posEnemy.x - this._checkPosWidth || posPlayer.x > posEnemy.x + this._checkPosWidth) {
			this._lastPos = posEnemy;
			this.afterUpdate(dt);
			return;
		}
		var rectEnemy = this.getEleRect();
		var posPrev = game.Data.oPlayerCtl._lastPosition;
		if (cc.rectContainsPoint(rectEnemy, posPlayer)) {
			if (posPrev.y >= rectEnemy.y + rectEnemy.height)
			{
				this.pushTo(vee.Direction.Top, posPlayer, rectEnemy, game.Data.oPlayerCtl);
			}
			else if (posPrev.y <= rectEnemy.y)
			{
				this.pushTo(vee.Direction.Bottom, posPlayer, rectEnemy, game.Data.oPlayerCtl);
			}
			else if (posPrev.x <= rectEnemy.x)
			{
				this.pushTo(vee.Direction.Left, posPlayer, rectEnemy, game.Data.oPlayerCtl);
			}
			else if (posPrev.x >= rectEnemy.x + rectEnemy.width)
			{
				this.pushTo(vee.Direction.Right, posPlayer, rectEnemy, game.Data.oPlayerCtl);
			}
			else
			{
				if (!this._tempDir) {
					if (posPlayer.x < rectEnemy.x + 10) {
						this.pushTo(vee.Direction.Left, posPlayer, rectEnemy, game.Data.oPlayerCtl);
					} else if (posPlayer.x > rectEnemy.x + rectEnemy.width - 10) {
						this.pushTo(vee.Direction.Right, posPlayer, rectEnemy, game.Data.oPlayerCtl);
					} else if (posPlayer.y > rectEnemy.y + rectEnemy.height/2) {
						this.pushTo(vee.Direction.Top, posPlayer, rectEnemy, game.Data.oPlayerCtl);
					} else {
						this.pushTo(vee.Direction.Bottom, posPlayer, rectEnemy, game.Data.oPlayerCtl);
					}
				} else {
					this.pushTo(this._tempDir, posPlayer, rectEnemy, game.Data.oPlayerCtl);
				}
			}
		} else {
			this._tempDir = null;
		}
		this._lastPos = posEnemy;
		this.afterUpdate(dt);
	},

	_rectEnemy : null,
	_posEnemy : null,

	checkEleCollide : function (nodeCtl) {
		if (!nodeCtl) return;
		nodeCtl.squeezingDir = null;
		var posNode = nodeCtl.getElePosition();
		if (posNode.x < this._posEnemy.x - this._checkPosWidth || posNode.x > this._posEnemy.x + this._checkPosWidth) {
			return;
		}
		if (cc.rectContainsPoint(this._rectEnemy, posNode)) {
			if (posNode.y >= this._rectEnemy.y + this._rectEnemy.height)
			{
				this.pushTo(vee.Direction.Top, posNode, this._rectEnemy, nodeCtl);
			}
			else if (posNode.y <= this._rectEnemy.y)
			{
				this.pushTo(vee.Direction.Bottom, posNode, this._rectEnemy, nodeCtl);
			}
			else if (posNode.x <= this._rectEnemy.x)
			{
				this.pushTo(vee.Direction.Left, posNode, this._rectEnemy, nodeCtl);
			}
			else if (posNode.x >= this._rectEnemy.x + this._rectEnemy.width)
			{
				this.pushTo(vee.Direction.Right, posNode, this._rectEnemy, nodeCtl);
			}
			else
			{
				if (posNode.x < this._rectEnemy.x + 10) {
					this.pushTo(vee.Direction.Left, posNode, this._rectEnemy, nodeCtl);
				} else if (posNode.x > this._rectEnemy.x + this._rectEnemy.width - 10) {
					this.pushTo(vee.Direction.Right, posNode, this._rectEnemy, nodeCtl);
				} else if (posNode.y > this._rectEnemy.y + this._rectEnemy.height/2) {
					this.pushTo(vee.Direction.Top, posNode, this._rectEnemy, nodeCtl);
				} else {
					this.pushTo(vee.Direction.Bottom, posNode, this._rectEnemy, nodeCtl);
				}
			}
		} else {
		}
	},

	pushTo : function (dir, posPlayer, rectEnemy, nodeCtl) {
		if (!dir || !nodeCtl) return;
		switch (dir) {
			case vee.Direction.Top : {
				// player should stand
				nodeCtl.downToBarrier();
				nodeCtl.needUpdateState = false;
				nodeCtl.setJumping(false);
				nodeCtl.updateState();
				this.playerOnTop();
				var posOff = this.getPosOff();
				if (!nodeCtl.squeeze(vee.Direction.Bottom)) nodeCtl.setElePosition(cc.p(posPlayer.x + posOff.x, rectEnemy.y + rectEnemy.height - 5));
			}
				break;
			case vee.Direction.Bottom : {
				// up to barrier
				nodeCtl.upToBarrier();
				nodeCtl.stopRunning();
				if (this._moveDirV == vee.Direction.Bottom) {
					if (!nodeCtl.squeeze(vee.Direction.Top)) nodeCtl.setElePosition(cc.p(posPlayer.x, rectEnemy.y - 10));
				}
			}
				break;
			case vee.Direction.Left : {
				nodeCtl.rightToBarrier();
				nodeCtl.stopRunning();
//				if (this._moveDirH == vee.Direction.Left) {
					if (!nodeCtl.squeeze(vee.Direction.Right)) nodeCtl.setElePosition(cc.p(rectEnemy.x, posPlayer.y));
//				}
			}
				break;
			case vee.Direction.Right : {
				nodeCtl.leftToBarrier();
				nodeCtl.stopRunning();
//				if (this._moveDirH == vee.Direction.Right) {
					if (!nodeCtl.squeeze(vee.Direction.Left)) nodeCtl.setElePosition(cc.p(rectEnemy.x + rectEnemy.width, posPlayer.y));
//				}
			}
				break;
			default :
				break;
		}
		this._tempDir = dir;
	},

	playerOnTop : function () {},

	afterUpdate : function () {},
	die : function () {}
});