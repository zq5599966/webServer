/**
 * Created with AppCode.
 * User: WanThirty
 * Date: 16/1/20
 * Time: 下午12:22
 * To change this template use File | Settings | File Templates.
 */

var EleSmallCat = vee.Class.extend({
	_eleType : game.EleType.Player,
	_container : null,
	_triggerObj : true,

	nodeBox : null,
	boxOffset : null,
	boxSize : null,
	_speedX : 0,
	_speedY : 0,
	_accX : 0,
	_accY : 0,
	_speedXLimit : 0,
	_decay : 0,
	_G : 0,

	_isJumping : true,
	_isBrake : false,
	_pos : null,
	_grid : cc.p(0,0),
	_lastPosition : null,
	_lastGrid : null,
	_faceTo : vee.Direction.Right,
	_moveDir : vee.Direction.Origin,
	_isBounce : false,
	_isOver : false,

	onCreate : function () {
		this.boxOffset = this.nodeBox.getPosition();
		this.boxSize = this.nodeBox.getContentSize();
		this._speedXLimit = game.Data.playerXSpeedLimit;
		this._decay = 6000;
		this._G = game.Data.G;
	},

	ccbInit : function() {},

	setContainerNode : function(node) {
		this._container = node;
	},
	getContainerNode : function () {
		return this._container;
	},

	getElePosition : function() {
		return this._container.getPosition();
	},
	setElePosition : function(pos) {
		var grid = game.Logic.getTileGridByPos(pos);
		if (!game.Logic.isGridSame(grid, this._grid)) {
			this._lastGrid = cc.p(this._grid.x, this._grid.y);
			this._grid = grid;
			this.onGridChanged();
		}
		this._lastPosition = this._container.getPosition();
		this._offsetX = this._lastPosition.x - pos.x;
		this._offsetY = this._lastPosition.y - pos.y;
		this._container.setPosition(pos);
		game.Data.onPlayerChangePos(pos);
		this._pos = cc.p(pos.x, pos.y);
	},
	setFaceTo : function(dir,force) {
		if (this._faceTo == dir && !force) return;
		this._isBrake = false;
		this._faceTo = dir;
		if (dir == vee.Direction.Left) {
			this.rootNode.setScaleX(-1);
		} else {
			this.rootNode.setScaleX(1);
		}
	},
	getNextCastPos : function () {
		var ret = cc.p(this._pos.x, this._pos.y);
		var castSpeedY = this._speedY;
		var castDt = 0.017;
		castSpeedY += (this._accY + (this._jumpSpeedProtect ? 0 : game.Data.G))*castDt;
		if (this.isLimitY) castSpeedY =  (castSpeedY < game.Data.playerYSpeedLimit ? game.Data.playerYSpeedLimit : castSpeedY);
		ret.y = ret.y + castSpeedY*castDt;

		var castSpeedX = this._speedX;
		castSpeedX += this._accX * castDt * (this._isBounce ? 0.1 : 1);
		castSpeedX = (castSpeedX > this._speedXLimit ? this._speedXLimit : (castSpeedX < -this._speedXLimit ? -this._speedXLimit : castSpeedX));
		ret.x = ret.x + castSpeedX*castDt;

		return ret;
	},
	isJumping : function () {
		return this._isJumping;
	},
	setJumping : function(isJumping) {
		this._isJumping = isJumping;
	},

	moveLeft : function() {
		this.setFaceTo(vee.Direction.Left);
		this._accX = -game.Data.playerXacc;
	},
	moveRight: function() {
		this.setFaceTo(vee.Direction.Right);
		this._accX = game.Data.playerXacc;
	},

	stopMove : function() {
		this._accX = 0;
	},

	leftToBarrier : function(td) {
		this._speedX = 0;
	},

	rightToBarrier : function(td) {
		this._speedX = 0;
	},


	upToBarrier : function(td) {
		// hit block sfx
		this._speedY = 0;
		this._accY = 0;
	},

	_gidForCheck : 0,
	downToBarrier : function(td) {
		this._speedY = 0;
		this._accY = 0;
	},

	onGridChanged : function() {
		if (!this._grid || !this._lastGrid) return;
		// Check trigger when grid changed
		game.Logic.checkNewGrids(this._lastGrid, vee.Utils.pSub(this._grid, this._lastGrid));
		game.Logic.checkTileTrigger(this._grid, vee.Direction.Origin, null, this);
		game.Data.onPlayerGridChange(this._grid);
	},

	// Updates...
	_speedScaleRate : null,
	_safePos : null,
	_dtCounter : 0,
	updatePos : function(timeDelta) {
		// calc speed
		this.calcX(timeDelta);
		this.calcY(timeDelta);
		this.calcMoveDir();

		// calc safe postion...
		var castPos = this.getCastPos(timeDelta);
		this.setElePosition(game.Logic.safePos(castPos, this));
		if (this.elf) this.elf.follow(timeDelta);

		// refresh signs
		if (this._speedY != 0) this.setJumping(true);
		if (this._isBounce || this._isFlying) return;

		// Calc decay...
		this.calcDecay(timeDelta);
	},
	calcX : function (timeDelta) {
		this._speedX += this._accX * timeDelta * (this._isBounce ? 0.1 : 1);
		this._speedX = (this._speedX > this._speedXLimit ? this._speedXLimit : (this._speedX < -this._speedXLimit ? -this._speedXLimit : this._speedX));
	},
	isLimitY : true,
	isUpdateY : true,
	calcY : function (timeDelta) {
		if (this.isUpdateY) {
			this._speedY += (this._accY + (this._jumpSpeedProtect ? 0 : this._G))*timeDelta;
			if (this.isLimitY) this._speedY =  (this._speedY < game.Data.playerYSpeedLimit ? game.Data.playerYSpeedLimit : this._speedY);
		}
	},
	calcMoveDir : function () {
		this._moveDir = game.Logic.getMoveDirectionBySpeedX(this._speedX);
	},
	getCastPos : function (timeDelta) {
		var ret = cc.p(this.getElePosition().x + this._speedX*timeDelta*this._speedScaleRate, this.getElePosition().y + this._speedY*timeDelta);
		ret.x = ret.x < 96 ? 96 : ret.x;
		if (this._isJumpLimitY) {
			ret.y = ret.y > this._jumpHeightLimitY ? this._jumpHeightLimitY : ret.y;
		}
		return ret;
	},
	calcDecay : function (timeDelta) {
		if (this._accX > 0 && this._speedX < 0) {
			this._speedX += this._decay*timeDelta;
		} else if (this._accX < 0 && this._speedX > 0) {
			this._speedX -= this._decay*timeDelta;
		} else if (this._accX == 0 && this._speedX != 0) {
			if (this._speedX > 0) {
				this._speedX -= this._decay*timeDelta;
				if (this._speedX <= 0) this._speedX = 0;
			} else if (this._speedX <= 0) {
				this._speedX += this._decay*timeDelta;
				if (this._speedX >= 0) this._speedX = 0;
			}
		} else {
			this._isBrake = false;
		}
	}
});

EleSmallCat.create = function() {
	var node = cc.BuilderReader.load(res.hero_smallcat_ccbi);
	var container = cc.Node.create();
	container.addChild(node);
	node.controller.setContainerNode(container);
	return {container : container, controller : node.controller};
};