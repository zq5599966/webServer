/**
 * Created with AppCode.
 * User: WanThirty
 * Date: 16/4/20
 * Time: 下午2:02
 * To change this template use File | Settings | File Templates.
 */

var EfxBubble = vee.Class.extend({
	_callback : null,
	ccbInit : function (callback) {
		this._callback = callback;
		this.playAnimate("show", function () {
			if (this._callback) {
				this._callback();
			}
			this.boom();
		}.bind(this));
		this.rootNode.runAction(cc.sequence(
			cc.delayTime(0.5),
			cc.callFunc(function () {
				if (game.Data.oPlayerCtl) {
					game.Data.oPlayerCtl._canReviveFloat = true;
				}
			})
		));
	},

	boom : function () {
		this.playAnimate("boom", function () {
			this.rootNode.removeFromParent();
		});
	}
});

EfxBubble.show = function (callback) {
	var node = cc.BuilderReader.load(res.efx_bubble_ccbi);
	node.controller.ccbInit(callback);
	return node;
};