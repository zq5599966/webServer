/**
 * Created with AppCode.
 * User: yop
 * Date: 15/10/30
 * Time: 下午7:02
 * To change this template use File | Settings | File Templates.
 */


LevelController.LevelEvent203 = LevelController.extend({
	eventStory1 : function(grid, dir) {
		this.showStory(1, grid, ""+
			"SelectNpc,Flash;"+
			"FaceTo,right;"+
			"MoveCamera,24,12,2;"+
			"FaceTo,left;"+
			"MoveRole,26,12;"+
			"ShowDialog,"+ vee.Utils.getLocalizedStringForKey("Hey, you come!", "嘿，你来啦，") +";"+
			"ShowDialog,"+ vee.Utils.getLocalizedStringForKey("I'm just talking with my friend!", "我在跟我的小伙伴聊天呢。") +";"+
			"ShowDialog,"+ vee.Utils.getLocalizedStringForKey("You know? In the phantom world,", "你知道吗？在幻影世界里，") +";"+
			"ShowDialog,"+ vee.Utils.getLocalizedStringForKey("You could change your image into anything,", "你可以变成任何形象，") +";"+
			"ShowDialog,"+ vee.Utils.getLocalizedStringForKey("Just like this!", "像这样————") +";"+
			"HideDialog;"+
			"TimeLine,tip;"+
			"Delay,2.5;"+
			"SelectNpc;"+
			"MoveRole,25,12;"+
			"ShowDialog,"+ vee.Utils.getLocalizedStringForKey("Don't panic, it's not that hard.", "别被吓到了，没那么难。") +";"+
			"ShowDialog,"+ vee.Utils.getLocalizedStringForKey("You can made it too -- as long as you get enough data!", "你只要收集足够多的角色数据就可以了。") +";"+
			"ShowDialog,"+ vee.Utils.getLocalizedStringForKey("I already have enough data, so...", "我已经收集了很多数据了，") +";"+
			"ShowDialog,"+ vee.Utils.getLocalizedStringForKey("Here you are!!", "给你一些吧~") +";"+
			"HideDialog;"+
			"UnlockRole;"+
			"TimeLine,huxi_2;"+
			"Delay,1;"+
			"Trigger,23,6;"+
			"Trigger,24,6;"+
			"MoveCamera,13,12,2;"+
			"Delay,2;"+
			"MoveCamera,24,12,1;"+
			"ShowDialog,"+ vee.Utils.getLocalizedStringForKey("Try to collect them all!", "试试把它们全部收集起来吧") +";"+
			"ShowDialog,"+ vee.Utils.getLocalizedStringForKey("Good luck to you!", "祝你好运~") +";"+
			"HideDialog;"+
			"Delay,1"+
		"");
	}
});