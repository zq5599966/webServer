/**
 * Created with AppCode.
 * User: Yop Chan
 * Date: 15/12/17
 * Time: 下午2:29
 * To change this template use File | Settings | File Templates.
 */


var LyGestureController = vee.GestureControllerDelegate.extend({

	_enabled : false,
	/** @type {vee.GestureController} */
	_gestureController : null,

	/** @type {cc.Point} */
	_origin : null,

	_bufferOffsetX : 25,
	_maxOffsetX : 50,
	_bufferOffsetY : 50,
	_bufferOffsetSmash : 120,

	_isOnLeft : false,
	_isOnRight : false,
	_isOnJump : false,

	/** @type {LyGestureDrawNode} */
	_drawCtl : null,

	setScale : function(scale){
		if (this._enabled) {
			this._bufferOffsetX = 25 * scale;
			this._maxOffsetX = 50 * scale;
			this._bufferOffsetY = 50 * scale;
			this._bufferOffsetSmash = 120 * scale;
			this._drawCtl.setScale(scale);
		}
	},

	setEnabled : function(e) {
		if (e == this._enabled) return;
		this._enabled = e;
		if (e) {
			this._drawCtl = LyGestureDrawNode.create();
			this.rootNode.addChild(this._drawCtl.rootNode);
			this._gestureController = vee.GestureController.registerController(this.rootNode, this, false);
			game.Data.oLyGame.hideControlButton(LyGame.ControlButtonType.MoveButton);
			game.Data.oLyGame.hideControlButton(LyGame.ControlButtonType.JumpButton);
			game.Data.oLyGame.hideControlButton(LyGame.ControlButtonType.ActionButton);
		} else {
			if (this._drawCtl) {
				this._drawCtl.gestureController.unregister();
			}
			this._drawCtl = null;
			if (this._gestureController) {
				this._gestureController.unregister();
			}
			game.Data.oLyGame.showControlButton(LyGame.ControlButtonType.MoveButton, false, false);
			game.Data.oLyGame.showControlButton(LyGame.ControlButtonType.JumpButton, false, false);
			if (game.Data.playerType != game.PlayerType.Normal) game.Data.oLyGame.showControlButton(LyGame.ControlButtonType.ActionButton, false, false);
		}
	},

	getEnabled : function() {
		return this._enabled;
	},

	/**
	 * @param {vee.GestureController} gestureController
	 */
	onGestureBegin : function(gestureController) {
		this._origin = gestureController.getBeginPoint();
		return true;
	},

	/**
	 * @param {vee.GestureController} gestureController
	 * @param {cc.Point} offset, 与上一次 move 之间的距离
	 */
	onGestureMove : function(gestureController, offset) {
		var pos = gestureController.getLastPoint();

		if ( Math.abs(offset.x) < 50 || this._isOnLeft || this._isOnRight ) {  //屏蔽划动操作
			if (pos.x - this._origin.x > this._bufferOffsetX) {
				if (pos.x - this._origin.x > this._maxOffsetX) {
					this._origin.x = pos.x - this._maxOffsetX;
				}
				this.onRight();
			} else if (pos.x - this._origin.x < -this._bufferOffsetX) {
				if (pos.x - this._origin.x < -this._maxOffsetX) {
					this._origin.x = pos.x + this._maxOffsetX;
				}
				this.onLeft();
			} else {
				this.onLeftRelease();
				this.onRightRelease();
			}
		}

		if (!this._isOnJump) {
			//if (pos.y - this._origin.y > this._bufferOffsetY) {
			//	this.onJump();
			//}
			if (offset.y < 0) this._origin.y = pos.y;
			else if (pos.y - this._origin.y > this._bufferOffsetY) this.onJump();
		} else {
			if (offset.y < 0) this.onJumpRelease();
			//if (pos.y - this._origin.y < this._bufferOffsetY) {
			//	this.onJumpRelease();
			//}
		}
	},

	/**
	 *
	 * @param {vee.GestureController} gestureController
	 * @param angle
	 * @param distance
	 */
	onGestureSwipe : function (gestureController, angle, distance) {
		if (distance < this._bufferOffsetSmash) return;
		//if (angle > 300 || angle < 60) {
		//	this._isOnJump = true;
		//	this.onJumpRelease();
		//	game.Data.oPlayerCtl.jumpImmediately();
		//	if (angle > 20 && angle < 60) {
		//		this.onRight();
		//		game.Data.oPlayerCtl._accX = game.Data.playerXacc;
		//	}
		//	else if (angle < 330) {
		//		this.onLeft();
		//		game.Data.oPlayerCtl._accX = -game.Data.playerXacc;
		//	}
		//	return;
		//}
		switch (game.Data.playerType) {
			case game.PlayerType.Bullet:
			case game.PlayerType.Bomb:
			case game.PlayerType.Teleport:
			{
				if (angle > 60 && angle < 120) {
					this.onRight();
					this.onRightRelease();
					this.onSmash();
				} else if (angle > 240 && angle < 300) {
					this.onLeft();
					this.onLeftRelease();
					this.onSmash();
				}
				break;
			}
			case game.PlayerType.Smash:
			{
				if (angle > 150 && angle < 210) {
					this.onSmash();
				}
				break;
			}
			default:
				break;
		}
	},


	onGestureTap : function (gestureController) {
		switch (game.Data.playerType) {
			case game.PlayerType.Bullet:
			case game.PlayerType.Bomb:
			{
				this.onSmash();
				break;
			}
			default:
				break;
		}
	},

	/**
	 * @param {vee.GestureController} gestureController
	 */
	onGestureLeave : function(gestureController) {
		this.onLeftRelease();
		this.onRightRelease();
		this.onJumpRelease();
	},

	onLeft : function () {
		this._isOnLeft = true;
		game.Data.oLyGame.onLeft(this, cc.CONTROL_EVENT_TOUCH_DOWN);
	},

	onLeftRelease : function () {
		if (this._isOnLeft) {
			game.Data.oLyGame.onLeft(this, cc.CONTROL_EVENT_TOUCH_UP_INSIDE);
		}
		this._isOnLeft = false;
	},

	onRight : function () {
		this._isOnRight = true;
		game.Data.oLyGame.onRight(this, cc.CONTROL_EVENT_TOUCH_DOWN);
	},

	onRightRelease : function () {
		if (this._isOnRight) {
			game.Data.oLyGame.onRight(this, cc.CONTROL_EVENT_TOUCH_UP_INSIDE);
		}
		this._isOnRight = false;
	},

	onJump : function () {
		this._isOnJump = true;
		game.Data.oLyGame.onJump(this, cc.CONTROL_EVENT_TOUCH_DOWN);
	},

	onJumpRelease : function () {
		this._isOnJump = false;
		game.Data.oLyGame.onJump(this, cc.CONTROL_EVENT_TOUCH_UP_INSIDE);
	},

	onSmash : function () {
		game.Data.oLyGame.onSmash(this, cc.CONTROL_EVENT_TOUCH_DOWN);
		game.Data.oLyGame.onSmash(this, cc.CONTROL_EVENT_TOUCH_UP_INSIDE);
	}
});