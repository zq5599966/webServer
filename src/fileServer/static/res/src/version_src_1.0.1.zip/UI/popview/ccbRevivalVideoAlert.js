/**
 * Created with AppCode.
 * User: WanThirty
 * Date: 15/12/18
 * Time: 下午4:21
 * To change this template use File | Settings | File Templates.
 */

var ccbRevivalVideoAlert = vee.Class.extend({
	
	btnVideo : null,
	lbTitle : null,
	lbDetail : null,
	layerType : null,

	ccbInit : function (revivalType) {

		this.handleKey(true);

		this.revivalType = revivalType;
		vee.Audio.playEffect(res.inGame_function_unlockAvator_mp3);
		this.playAnimate("show");

		this._tempControllerState = vee.Controller.cacheControllerState();

		this.initController();

	},

	initController : function () {
		vee.Controller.clearAllButtonAction();
		vee.Controller.initSelector(1,1,this.onClose.bind(this),cc.p(0,0));
		vee.Controller.registerItemByButton(this.btnVideo, cc.p(0,0), this.onVideo.bind(this), "res/mfi_btn_on_170.png");
		vee.Controller.activeSelector();

		// vee.Controller.registerButtonAction(vee.KeyCode.BUTTON_B, this.onClose.bind(this));
		// vee.Controller.activeButton();
	},

	onVideo : function () {

		vee.Utils.scheduleOnce(function () {
			if(this.revivalType != ccbRevivalVideoAlert.revivalType.DEADZONE){
				this.revivalByNormal();
			}
			else{
				this.revivalByDeadZone();
			}
			game.Data.oLyGame.resumeGame();
			vee.PopMgr.closeLayer();
			vee.Controller.reviveControllerState(this._tempControllerState);

		}.bind(this), 0.2);

		vee.Controller.reviveControllerState(this._tempControllerState);
		game.Data.willShowVideoAd = true;

		vee.Controller.deactiveSelector();
	},

	revivalByNormal : function () {
		// vee.Utils.scheduleOnce(function () {
			game.Data.addLife();
			game.Data.oPlayerCtl._container.stopAllActions();
			game.Data.oPlayerCtl.hurtInvisible(12);
			game.Data.oPlayerCtl.hurtShock();
		// }, 0.1);
	},
	
	revivalByDeadZone : function () {
		game.Data.oPlayerCtl.revivalByDeadZone();
	},

	onClose : function () {
		game.Data.oLyGame.resumeGame();
		this.playAnimate("hide", function () {
			vee.PopMgr.closeLayerByCtl(this);
			// if (this.layerType == LyVideoAlert.Type.FOR_LIFE) {
				game.Data.gameOver();
			// }
			vee.Controller.reviveControllerState(this._tempControllerState);
		}.bind(this));
		vee.Controller.deactiveSelector();
	},

	onKeyBack : function () {
		this.onClose();
		return true;
	}
});

ccbRevivalVideoAlert.show = function (revivalType) {
	// if (!layerType) layerType = LyVideoAlert.Type.FOR_LIFE;
	if (game.Data.zqdebug || vee.Ad.checkCacheVideoAd()) {
		var node = vee.PopMgr.popCCB(res.ccbRevivalVideoAlert_ccbi, { alpha : 0 });
		node.controller.ccbInit(revivalType);
		game.Data.oLyGame.pauseGame();
		return true;
	} else {
		return false;
	}
};

ccbRevivalVideoAlert.revivalType = {
	NORMAL : 1,			//普通复活
	DEADZONE : 2		//悬崖复活
}

// LyVideoAlert.Type = {
// 	FOR_HAWK : 1,
// 	FOR_LIFE : 2
// };