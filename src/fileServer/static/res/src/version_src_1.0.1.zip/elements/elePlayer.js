/**
 * Created with AppCode.
 * User: WanThirty
 * Date: 4/16/15
 * Time: 5:55 PM
 * To change this template use File | Settings | File Templates.
 */
var MoveState = {
	Breath       : 0,
	Dash         : 1,
	DashBrake    : 2,
	DashHolding  : 3,
	Bounce       : 4,
	Moving       : 5,
	Brake        : 6,
	JumpUp       : 7,
	JumpDown     : 8,
	DashJumpUp   : 9,
	DashJumpDown : 10,
	SmashRolling : 11,
	Smash        : 12,
	SmashShake   : 13,
	SmashReset   : 14,
	Spit         : 15,

	Hanged       : 20
};

var ElePlayer = vee.Class.extend({
	_eleType : game.EleType.Player,
	_triggerObj : true,
	boxOffset : null,
	boxSize : null,
	nodeBox : null,
	_container : null,
	extendController : null,

	// Arguments...
	_speedX : 0,
	_speedY : 0,
	_accX : 0,
	_accY : 0,
	_speedXLimit : 0,
	_speedYLimit : 0,
	_jumpCount : 1,
	_offsetX : 0,
	_offsetY : 0,
	_G : 0,
	_decay : 0,

	// Status...
	_moveState : MoveState.Moving,
	_isJumping : true,
	_isBrake : false,
	_isBounce : false,
	_isFlying : false,
	_isTeleport : false,
	_lastPosition : null,
	_grid : cc.p(0,0),
	_lastGrid : null,
	_faceTo : vee.Direction.Right,
	_moveDir : vee.Direction.Origin,
	pushedDir : null,
	_isOver : false,

	_holdingDir : null,

	elf : null,

	_streak : null,     //add by zq 20161102 拖尾特效
	_partice : null,

	onCreate : function () {
		this.boxOffset = this.nodeBox.getPosition();
		this.boxSize = this.nodeBox.getContentSize();
		this._speedXLimit = game.Data.playerXSpeedLimit;
		this._speedYLimit = game.Data.playerYSpeedLimit;
		this._decay = game.Data.playerXdecay;
		this._G = game.Data.G;
	},

	addMotionStreak : function (isBlackCat) {
		// this._streak = [];

		var streakImg = res.streak_png;
		var particleCCB = res.particles_parkour_ccbi;

		if(isBlackCat){
			streakImg = res.super_streak_png;
			particleCCB = res.particles_super_parkour_ccbi;
		}

		var streak = new cc.MotionStreak(0.4, 0, 40, cc.color.WHITE, streakImg);
		streak.setFastMode(true);
		streak.setBlendFunc(1, 0x0303);
		// streak.setBlendFunc(0x0300, 0x0304);
		game.Data.oLyGame.lyMap.addChild(streak);
		// this._streak.push(streak);
		this._streak = streak;

		var particle = cc.BuilderReader.load(particleCCB);
		game.Data.oLyGame.lyMap.addChild(particle);
		// particle.ps1.x = this.getElePosition().x;
		// particle.ps1.y = this.getElePosition().y;
		particle.x = this.getElePosition().x;
		particle.y = this.getElePosition().y;
		this._partice = particle;
		this._particeDelay = 0;
	},
	
	updateMotionStreak : function (dt) {
		// if(this._streak && this._streak.length > 0){
		// 	for(var i = 0; i < this._streak.length; i++){
		// 		var streak = this._streak[i];
		// 		streak.x = this.getElePosition().x;
		// 		streak.y = this.getElePosition().y;
		// 	}
		// }
		if(this._streak){
			this._streak.x = this.getElePosition().x;
			this._streak.y = this.getElePosition().y;
		}

		if(this._partice){// && this._particeDelay++ % 3 == 0){
			this._particeDelay += dt;
			if(this._particeDelay > 0.03){
				// this._partice.x = this.getElePosition().x;
				// this._partice.y = this.getElePosition().y;
				this._particeDelay -= 0.03;
				this._partice.runAction(cc.moveTo(0.025, this.getElePosition()));
			}
		}
	},

	hideStreak : function () {
		if(this._streak){
			// this._streak.opacity = 0;
			// cc.log("zq debug hide streak");
			this._streak.setVisible(false);
			this._partice.setVisible(false);
		}
	},

	showStreak : function () {
		if(this._streak){
			// this._streak.opacity = 255;
			// cc.log("zq debug show streak");
			this._streak.setVisible(true);
			this._partice.setVisible(true);
		}
	},

	ccbInit : function () {
		var category = game.LevelData.selectedCategory;
		if (category && category.idx > 99) {
			this.setFaceTo(vee.Direction.Left, true);
		}

		// this.addMotionStreak();
	},

	isCanOperatByParkour : false,
	// zqdebug : true,
	playerInAninate : function () {
		this.setMoveState(MoveState.JumpDown);
		this.rootNode.setVisible(false);
		vee.Utils.scheduleOnceForTarget(this.rootNode, function () {
			this.rootNode.setVisible(true);
			ItemStageEnd.show(this.getElePosition());
			vee.Audio.playEffect(res.inGame_efx_entrance_mp3);
			cc.log("zq debug player in aninate");
			this.playAnimate("start_in", function () {
				var level = game.LevelData.selectedLevel;

				if(game.Data.isInParkour() && game.LevelData.selectedCategory.idx == 9 && level.idx == 0 && level.getLevelState() == 1){
					AlertParkourTip.show(function () {
						this.isCanOperatByParkour = true;
						this.startUpdate();
					}.bind(this));
				}
				else{
					this.playAnimate("huxi_1");
					this.startUpdate();
				}


				/*
				if(this.zqdebug){
					LyGetBlackCat.show();
					this.zqdebug = false;
				}
				else{
					this.playAnimate("huxi_1");
					this.startUpdate();
				}
				*/

			}.bind(this));
		}.bind(this), 1);
	},

	onExit : function() {
	},

	_eleSize : cc.size(game.Data.tileSizeWidth,game.Data.tileSizeWidth),

	// Animates...
	AniTimeLine : {
		breath1 : "huxi_1",
		breath2 : "huxi_2",
		run : "run",
		run_brake : "run_brake",
		dash : "fast_run",
		dash_brake : "fast_run_brake",
		injure : "injure",
		jump_up : "run_jump_up",
		jump_down : "run_jump_down",
		dash_jump_up : "run_jump_up",
		dash_jump_down : "run_jump_down",
		out : "out",
		fall : "fall",
		// Mario
		smash_rolling : "smash_rolling",
		smash : "smash",
		smash_reset : "smash_huxi",
		// Karby
		inhale_ready : "inhale_ready",
		inhale_loop : "inhale_loop",
		inhale_end : "inhale_end",
		spit : "attack_fat",

		hang : "hang",
		run_fast : "run_fast"
	},

	_isOverFall : false,
	gameOverFall : function (callBack) {
		if (this._isOverFall) return;
		this._isOverFall = true;
		this.gameOver();
		vee.Audio.playEffect(res.inGame_event_deathInstant_mp3);
		this.playAnimate("fall", function() {
			if (callBack) callBack();
		});
	},

	_isOverOut : false,
	_callback : null,
	gameOverOut : function (callBackFunc) {
		this._callback = callBackFunc;
		if (this._isOverOut) return;
		if (this.elf) this.elf.hide();
		this._speedX = 0;
		this._accX = 0;
		this._isOverOut = true;
		this.gameOver();
//		EfxPlayerOut.show(this.getElePosition());
		vee.Audio.playEffect(res.inGame_efx_exit_mp3);
		this.playAnimate("out", function () {
			if (this._callback) this._callback();
		}.bind(this));
	},

	gameOver : function () {
		this.stopUpdate();
		this._isBounce = true;

		game.Data.playOverGid = cc.p(this._grid.x, this._grid.y);	//add by zq

		game.Data.oLyGame.gameOver();
		if (this.elf) this.elf.hide();
		this._isOver = true;
	},

	stopUpdate : function() {
		game.Data.isUpdatePlayerPos = false;
	},
	startUpdate : function() {
		game.Data.isUpdatePlayerPos = true;
	},

	setContainerNode : function(node) {
		this._container = node;
	},
	getContainerNode : function () {
		return this._container;
	},

	getElePosition : function() {
		return this._container.getPosition();
	},

	getPosition4Symbol : function() {
		return vee.Utils.pAdd(this._container.getPosition(), (this._faceTo == vee.Direction.Right ? cc.p(-45, 30) : cc.p(45,30)));
	},

	jumpSign : false,
	isJumping : function () {
		if (this.jumpSign) return true;
		else return this._isJumping;
	},

	_pos : null,
	setElePosition : function(pos) {
		var grid = game.Logic.getTileGridByPos(pos);
		if (!game.Logic.isGridSame(grid, this._grid)) {
			this._lastGrid = cc.p(this._grid.x, this._grid.y);
			this._grid = grid;
			this.onGridChanged();
		}
		this._lastPosition = this._container.getPosition();
		this._offsetX = this._lastPosition.x - pos.x;
		this._offsetY = this._lastPosition.y - pos.y;
		this._container.setPosition(pos);
		game.Data.onPlayerChangePos(pos);
		this._pos = cc.p(pos.x, pos.y);
	},
	getEleRect : function() {
		var pos = this.getElePosition();
		var rect = cc.rect(
			pos.x + this.boxOffset.x - this.boxSize.width/2,
			pos.y + this.boxOffset.y - this.boxSize.height/2,
			this.boxSize.width,
			this.boxSize.height
		);
		return rect;
	},
	getNextCastPos : function () {
		var ret = cc.p(this._pos.x, this._pos.y);
		var castSpeedY = this._speedY;
		var castDt = 0.02;
		castSpeedY += (this._accY + (this._jumpSpeedProtect ? 0 : game.Data.G))*castDt;
		if (this.isLimitY) castSpeedY =  (castSpeedY < this._speedYLimit ? this._speedYLimit : castSpeedY);
		ret.y = ret.y + castSpeedY*castDt;

		var castSpeedX = this._speedX;
		castSpeedX += this._accX * castDt * (this._isBounce ? 0.1 : 1);
		castSpeedX = (castSpeedX > this._speedXLimit ? this._speedXLimit : (castSpeedX < -this._speedXLimit ? -this._speedXLimit : castSpeedX));
		ret.x = ret.x + castSpeedX*castDt;

		return ret;
	},
	resetPlayerState : function() {
		this._speedX = 0;
		this._speedY = 0;
		this._accX = 0;
		this._accY = 0;
		this._offsetX = 0;
		this._offsetY = 0;
	},
	stepAnimate : function() {
		if (!this.extendController) EfxDust.show(this.getElePosition(), DustType.RunDust, this._faceTo);
	},

	_isRandonBreath : true,
	randomBreath : function() {
		if (!this._isRandonBreath) return;
		this.playAnimate(this.AniTimeLine["breath"+vee.Utils.randomChoice([1,2,1,1])], function() {
			if (this._moveState == MoveState.Breath) {
				this.randomBreath();
			}
		}.bind(this));
	},
	setMoveState : function(state) {
		if (this._moveState == state || this._isBounce || this._isOver) return;
		var isSmashing = false;
		switch (state) {
			case MoveState.Breath:
				if (this._isBrake || this._isSmashing) return;
				this.playAnimate("huxi_1", function() {
					if (this._moveState == MoveState.Breath) {
						this.randomBreath();
					}
				}.bind(this));
				if (this._moveState != MoveState.Brake) {
					EfxDust.isJump = false;
					if (!this.extendController) EfxDust.show(this.getElePosition(), DustType.JumpDust);
					else {
						this.extendController.touchGround();
					}
					EfxApplause.Analysis.onLand(this._grid);
					vee.Audio.playEffect(res.inGame_event_toGround_mp3);
				}
				break;
			case MoveState.Moving:
				if (this._isBrake || this._isSmashing) return;
				this.rootNode.stopAllActions();
				// this.playAnimate(this.AniTimeLine.run);
				this.setMovingAnima();
				if (this._moveState == MoveState.JumpDown) {
					EfxDust.isJump = false;
					if (!this.extendController) EfxDust.show(this.getElePosition(), DustType.JumpDust);
					else {
						this.extendController.touchGround();
					}
					EfxApplause.Analysis.onLand(this._grid);
					vee.Audio.playEffect(res.inGame_event_toGround_mp3);
				}
				break;
			case MoveState.Brake:
				if (this._isJumping || this._isSmashing) return;
				this.setFaceTo(this._faceTo, true);
				this._isBrake = true;
				this.playAnimate(this.AniTimeLine.run_brake);
				break;
			case MoveState.JumpUp:
				EfxApplause.Analysis.onJump(this._grid);
				this.playAnimate(this.AniTimeLine.jump_up);
				break;
			case MoveState.JumpDown:
				if (this._isSmashing) {
					return;
				}
				EfxApplause.Analysis.onJump(this._grid);
				this.playAnimate(this.AniTimeLine.jump_down);
				break;
			case MoveState.DashJumpUp:
				this.playAnimate(this.AniTimeLine.dash_jump_up);
				break;
			case MoveState.DashJumpDown:
				this.playAnimate(this.AniTimeLine.dash_jump_down);
				break
			case MoveState.Spit:
				this.playAnimate(this.AniTimeLine.spit);
				break;
			case MoveState.Dash:
				this.rootNode.stopAllActions();
				this.playAnimate(this.AniTimeLine.dash);
				break;
			case MoveState.DashBrake:
				this.playAnimate(this.AniTimeLine.dash_brake);
				break;
			case MoveState.DashHolding:
				break;
			case MoveState.Bounce:
				this._isBounce = true;
				this.playAnimate(this.AniTimeLine.injure);
				this.hideStreak();
				break;
			case MoveState.Smash:
			case MoveState.SmashRolling:
			case MoveState.SmashShake:
				isSmashing = true;
				this.playAnimate("smash");
				break;
			case MoveState.SmashReset:
				isSmashing = true;
				break;
			default :
				break;
		}
		this._isSmashing = isSmashing;
		this._moveState = state;
	},
	setFaceTo : function(dir,force) {
		if (this._faceTo == dir && !force) return;
		this._isBrake = false;
		this._faceTo = dir;
		if (dir == vee.Direction.Left) {
			this.rootNode.setScaleX(-1);
		} else {
			this.rootNode.setScaleX(1);
		}
	},
	getFaceToNumber : function() {
		return this._faceTo == vee.Direction.Left ? -1 : 1;
	},

	_isSmashing : false,
	isSmashing : function () {
		return this._isSmashing;
	},

	// Actions...
	_jumpAccY : 1600,
	_jumpAccYmini : 600,
	holdJump : false,
	jump : function(force) {
		if (this.holdJump
			|| this.extendController
			|| this._freezeMoveButton
			|| this._isSmashing
			|| this._isTeleport) return;
		if (this._isReviveFloat) {
			this.cancelReviveFloat();
			return;
		}
		if (this._jumpCount > 0 || force) {
			++game.Data.jumpCount;
			this.rootNode.setScaleY(0.7);
			this.rootNode.setPosition(cc.p(0, -10));
			this.startJumpCounter();
			this._jumpHeightLimitY = this.getElePosition().y + game.Data.playerJumpHeight;
			--this._jumpCount;

			this.setJumping(true);
		}
	},

	jumpImmediately : function () {
		if (this._jumpCount > 0) {
			this._isJumpLimitY = true;
			this._speedY = 1400;
			this._jumpHeightLimitY = this.getElePosition().y + game.Data.playerJumpHeight;
			++game.Data.jumpCount;
			--this._jumpCount;
			this.setJumping(true);
		}
	},

	resetJumpCount : true,
	setJumping : function(isJumping) {
		if (this._moveState == MoveState.Smash && isJumping == false) return;
		this._isJumping = isJumping;
		if (!isJumping) {
			this._jumpCount = 1;// = 2
			this._speedScaleRate = 1;
		} else {
			if (this.resetJumpCount) this._jumpCount = 0;
			else this.resetJumpCount = true;
			this._speedScaleRate = 0.8;
		}
	},
	resetDTCounter : function () {
		this._timeChecked = false;
		this._dtCounter = 0;
	},

	checkTime : function () {
		if (!this.extendController && this.elf) this.elf.show();
	},

	_timeChecked : true,
	checkDTCounter : function (dt) {
		this._dtCounter += dt;
		if (this._dtCounter > game.Data.BButtonCDTime && !this._timeChecked) {
			this._timeChecked = true;
			this.checkTime();
		}
	},
	_BBtnDown : false,
	/* B Button funcs... */
	BButton : function (buttonUp) {
		if (this.extendController || this.isSmashing()) return;
		if (buttonUp) this._BBtnDown = false;
		else this._BBtnDown = true;

		switch (game.Data.playerType) {
			case game.PlayerType.Smash:
				this.BButtonSmash(buttonUp);
				break;
			case game.PlayerType.Teleport:
				this.BButtonTeleport(buttonUp);
				break;
			case game.PlayerType.Bullet:
				this.BButtonBullet(buttonUp);
				break;
			case game.PlayerType.Bomb:
				this.BButtonBomb(buttonUp);
				break;
			default :
				break;
		}
	},

	beginSmashPos : null,
	BButtonSmash : function (buttonUp) {
		// Smash!
		if (buttonUp || this._dtCounter < game.Data.BButtonCDTime) return;
		this.setMoveState(MoveState.SmashRolling);
		this.beginSmashPos = this.getElePosition();
		if (!this._isJumping) {
			game.Data.detachAllGrabbedPlatform();
			var moveHeight = 0;
			for (var i = 1; i < 3; ++i) {
				var checkGrid = cc.p(this._grid.x, this._grid.y - i);
				var td = game.Logic.map.getObject(checkGrid);
				if (td && td.check) {
					break;
				} else {
					moveHeight += TILE_WIDTH;
				}
			}
			this.setElePosition(cc.p(this._pos.x, this._pos.y + moveHeight));
			if (!Cinema.isCinema && !game.Data.oLyGame._isFreezeY) game.Data.cameraYPos += moveHeight;
			this.stopUpdate();
			game.Data.playerInvisible = true;
			EfxSmashFlash.show(this.getElePosition());
			this._container.setVisible(false);
			vee.Utils.scheduleOnce(function () {
				this._accX = 0;
				this._speedX = 0;
				this._speedY = 0;
				this.playAnimate(this.AniTimeLine.smash_rolling, function() {
					vee.Audio.playEffect(res.inGame_action_smashStart_mp3);
					this._container.setVisible(true);
					EfxSmashFlash.show(this.getElePosition());
					this.startUpdate();
					this.setMoveState(MoveState.Smash);
					EfxApplause.Analysis.onJump(this._grid);
					this._speedY = -1300;
				}.bind(this));
			}.bind(this));
			this.setJumping(false);
		} else {
			vee.Audio.playEffect(res.inGame_action_smashStart_mp3);
			game.Data.playerInvisible = true;
			this._accX = 0;
			this._speedX = 0;
			this._speedY = 0;
			EfxSmashFlash.show(this.getElePosition());
			this.setMoveState(MoveState.Smash);
			EfxApplause.Analysis.onJump(this._grid);
			this._speedY = -1300;
		}
		this.isLimitY = false;
		this.resetDTCounter();
		if (this.elf) this.elf.hide();
	},
	BButtonTeleport : function (buttonUp) {
		// Teleport!
		if (!buttonUp && this._dtCounter > game.Data.BButtonCDTime && !this._isJumping) {
			// calc target pos...
			game.Data.detachAllGrabbedPlatform();
			var faceToNum = this.getFaceToNumber();
			var targetGrid = cc.p(this._grid.x + faceToNum*game.Data.playerTeleportLength, this._grid.y);
			var offsetX = Math.abs(targetGrid.x - this._grid.x);
			var td = null;
			var safeGrid = targetGrid;
			for (var i = 0; i <= offsetX; ++i) {
				var checkGrid = cc.p(targetGrid.x + i*(-faceToNum), targetGrid.y);
				td = game.Logic.map.getObject(checkGrid);
				if (td) {
					if (!td.check
						|| td.tileInfo.type == game.ObjectType.BlockOneWay
						|| td.tileInfo.type == game.ObjectType.BlockBounce) {
						safeGrid = checkGrid;
						break;
					}
					if (i == 0) {
						var nextGrid = cc.p(targetGrid.x + faceToNum, targetGrid.y);
						var nextTd = game.Logic.map.getObject(nextGrid);
						if (nextTd) {
							if (!nextTd.check
								|| nextTd.tileInfo.type == game.ObjectType.BlockOneWay
								|| nextTd.tileInfo.type == game.ObjectType.BlockBounce) {
								safeGrid = nextGrid;
								break;
							}
						} else {
							safeGrid = nextGrid;
							break;
						}
					}
				} else {
					safeGrid = checkGrid;
					break;
				}
			}
			var newPos = game.Logic.getTilePosCenterByGrid(safeGrid);
			newPos.x = newPos.x < 96 ? 96 : newPos.x;

			game.Data.setPlayerInvisible(true);
			this._isBounce = true;
			vee.Audio.playEffect(res.inGame_action_teleport_mp3);
			EfxTeleportDust.create(this.getElePosition(), this._faceTo);
			this._isTeleport = true;
			this.playAnimate("shunyi_out", function () {
				this.setElePosition(newPos);
				game.Data.cameraXPos -= this._offsetX;
				game.Data.cameraXrevived = false;
				this.playAnimate("shunyi_in", function () {
					this._isTeleport = false;
					game.Data.setPlayerInvisible(false);
					this._isBounce = false;
					this.setMoveState(MoveState.Breath);
				}.bind(this));
			}.bind(this));

			this.resetDTCounter();
			if (this.elf) this.elf.hide();
		}
	},
	BButtonBullet : function (buttonUp) {
		// Bullet!
		if ((!buttonUp && this._dtCounter > game.Data.BButtonCDTime && game.Data.bulletCount > 0)){// || game.Data.bulletCount > 1
			vee.Audio.playEffect(res.inGame_action_bullet_mp3);
			--game.Data.bulletCount;
//			this.resetDTCounter();
			var elePos = this.getElePosition();
			EfxBulletShoot.create(elePos, this._faceTo, this._container);

			var dirOff = vee.Direction.direction2Point(this._faceTo);
			dirOff.x *= (game.Data.tileSizeWidth/2);
			dirOff.y *= -(game.Data.tileSizeWidth/2);
			if (dirOff.x) dirOff.x += (dirOff.x > 0 ? 5 : -5);
			if (dirOff.y) dirOff.y += (dirOff.y > 0 ? 5 : -5);
			ItemSpitStar.create(vee.Utils.pAdd(elePos, dirOff), this.getFaceToNumber());
			if (game.Data.bulletCount <= 0) {
				if (this.elf) this.elf.hide();
			}
		}
	},
	BButtonBomb : function (buttonUp) {
		// Bomb!
		if (!buttonUp && !this._isJumping && this._dtCounter > game.Data.BButtonCDTime) {
			var faceToNum = this.getFaceToNumber();

			var posNextX = this.getNextCastPos();
			var bombGrid = game.Logic.getTileGridByPos(posNextX, this._pos.y);

			var targetGrid = cc.p(bombGrid.x + faceToNum, bombGrid.y);
			var td = game.Logic.map.getObject(targetGrid);
			var tdEx = game.Logic.mapex.getObject(targetGrid);
			var tempData = null;
			if (td || tdEx) {
				if ( (td
					&& td.check
					&& td.tileInfo.type != game.ObjectType.BlockOneWay
					&& td.tileInfo.type != game.ObjectType.BlockBounce)
					||
					(tdEx && (tdEx.tileInfo.type == game.ObjectType.Susliks
					|| tdEx.tileInfo.type == game.ObjectType.SusliksHawk)) )
				{
					targetGrid = cc.p(this._grid.x, this._grid.y);
					var tdCenter = game.Logic.map.getObject(targetGrid);
					if (tdCenter && tdCenter.tileInfo.slope != 0 && tdCenter.tileInfo.slope != undefined) {
						tempData = tdCenter;
					}
				} else if (td) {
					tempData = td;
				}
			}
			// push player
			if (game.Logic.isGridSame(this._grid, targetGrid)) {
				var playerNewGrid = cc.p(targetGrid.x - faceToNum, targetGrid.y);
				var newGridTd = game.Logic.map.getObject(playerNewGrid);
				if (newGridTd && newGridTd.check && (newGridTd.tileInfo.type != game.ObjectType.BlockOneWay && newGridTd.tileInfo.type != game.ObjectType.BlockBounce)) {
					// there`s a tile behind player, cannot push player back
					return;
				} else {
					var playerNewPos = game.Logic.getTilePosCenterByGrid(playerNewGrid);
					game.Data.cameraXPos -= (this._pos.x - playerNewPos.x);
					game.Data.cameraXrevived = false;
					this.setElePosition(playerNewPos);
				}
			}
			this._speedX = 0;
			game.Logic._tmxLayer.setTileGID(game.BlockType.BombBlock, targetGrid);
			var bombTd = game.Logic.getTileData(targetGrid, game.Logic._tmxLayer);
			bombTd.tempData = tempData;
			bombTd.isPlayerBomb = true;
			var tile = game.Logic._tmxLayer.getTileAt(targetGrid);
			tile.setVisible(false);
			game.Logic.map.setObject(bombTd, targetGrid);
			// push enemy
			var objs = game.Logic.dynamicObjMap.getObjects();
			for (var i in objs) {
				var obj = objs[i];
				if (obj && obj._eleType == game.EleType.Enemy) {
					if (obj._grid.x <= targetGrid.x + 1 && obj._grid.x >= targetGrid.x - 1 && obj._grid.y == targetGrid.y) {
						var playerPos = game.Logic.getTilePosCenterByGrid(targetGrid);
						var enemyPos = obj.getElePosition();
						if (enemyPos.x > playerPos.x) {
							var targetPos = game.Logic.getTilePosByGrid(cc.p(targetGrid.x+1, targetGrid.y));
							if (enemyPos.x <= targetPos.x) {
								obj.moveRight();
								obj.setElePosition(game.Logic.getTilePosCenterByGrid(cc.p(targetGrid.x + 1, targetGrid.y)));
								obj._speedY = 0;
							}
						} else {
							var targetPos = game.Logic.getTilePosByGrid(cc.p(targetGrid.x-1, targetGrid.y));
							if (enemyPos.x >= targetPos.x) {
								obj.moveLeft();
								obj.setElePosition(game.Logic.getTilePosCenterByGrid(cc.p(targetGrid.x - 1, targetGrid.y)));
								obj._speedY = 0;
							}
						}
					}
				}
			}

			bombTd.collide(this, vee.Direction.Origin, true);
			this.resetDTCounter();
			if (this.elf) this.elf.hide();
		}
	},

	/* B Button funcs end */
	_freezeMoveButton : false,
	moveLeft : function() {
		if (this.extendController) {
			return;
		}
		if ((this.isSmashing() || this._isBounce || this._freezeMoveButton) && this._moveState != MoveState.SmashReset) return;
		if (this._moveState == MoveState.Dash || this._moveState == MoveState.DashJumpUp || this._moveState == MoveState.DashJumpDown) {
			if (!this._isJumping && this._moveDir != vee.Direction.Left) {
				this._accX = -game.Data.playerXacc;
				this.setMoveState(MoveState.DashBrake);
				this.setFaceTo(vee.Direction.Left);
			}
		}
		else {
			this.setFaceTo(vee.Direction.Left);
			this._accX = -game.Data.playerXacc;
		}
	},
	moveRight: function() {
		if (this.extendController) {
			return;
		}
		if ((this.isSmashing() || this._isBounce || this._freezeMoveButton) && this._moveState != MoveState.SmashReset) return;
		if (this._moveState == MoveState.Dash || this._moveState == MoveState.DashJumpUp || this._moveState == MoveState.DashJumpDown) {
			if (!this._isJumping && this._moveDir != vee.Direction.Right) {
				this._accX = game.Data.playerXacc;
				this.setMoveState(MoveState.DashBrake);
				this.setFaceTo(vee.Direction.Right);
			}
		}
		else {
			this.setFaceTo(vee.Direction.Right);
			this._accX = game.Data.playerXacc;
		}
	},

	getShock : function(dir, isHurt) {
		if (this._isBounce) return;
		if (this.extendController) {
			this.extendController.touchGround(true);
		}
		game.Data.oPlayerCtl.setJumping(true);
		this.setMoveState(MoveState.Bounce);
		vee.Audio.playEffect(res.inGame_event_hurted_mp3);
		this._accX = 0;
		this._speedXLimit = game.Data.playerXSpeedLimit;
		if (dir == vee.Direction.Left) {
			this._speedX = -200;
		} else if (dir == vee.Direction.Right) {
			this._speedX = 200;
		} else {
			this._speedX = this._speedX > 0 ? -200 : 200;
		}
		this._isJumpLimitY = false;
		this._speedY = 1000;
		this._accY = 0;
		this._jumpSpeedProtect = false;
		this.stopJumpCounter();
		var isShock = true;
		if (isHurt) {
			isShock = game.Data.costLife();
			this.hurtInvisible();
		}
		if (isShock) {
			this.hurtShock();
		}
		EfxApplause.Analysis.onLand(this._grid);
	},

	hurtInvisible : function (times) {
		var repeatTime = times ? times : 6;
		game.Data.playerInvisible = true;
		this._container.runAction(cc.sequence(
			cc.repeat(cc.sequence(
				cc.delayTime(0.2),
				cc.hide(),
				cc.callFunc(function () {
					this.hideStreak();
				}.bind(this)),
				cc.delayTime(0.2),
				cc.show(),
				cc.callFunc(function () {
					this.showStreak();
				}.bind(this))
			), repeatTime),
			cc.callFunc(function(){
				var objBL = game.Logic.map.getObject(cc.p(this._grid.x-1, this._grid.y+1));
				var objB  = game.Logic.map.getObject(cc.p(this._grid.x, this._grid.y+1));
				var objBR = game.Logic.map.getObject(cc.p(this._grid.x+1, this._grid.y+1));
				var isInvisible = false;
				for (var i = -1; i < 2; ++i) {
					var obj = game.Logic.map.getObject(cc.p(this._grid.x+i, this._grid.y+1));
					if (obj && game.Logic.isHurtBlock(obj.gid)) {
						isInvisible = true;
						break;
					}
				}
				var objCenter = game.Logic.map.getObject(cc.p(this._grid.x, this._grid.y));
				if (objCenter && game.Logic.isHurtBlock(objCenter.gid))
				{
					isInvisible = true;
				}
				if (isInvisible) {
					this.hurtInvisible();
				} else {
					game.Data.playerInvisible = false;
					if(game.Data.isInParkour()){
						this.parkourMove();
						this.showStreak();
					}
				}
			}.bind(this))
		));
	},

	hurtShock : function () {
		var amplitudeX = 4;
		var amplitudeY = 20;
		var dur = 0.05;
		game.Data.oLyGame.rootNode.runAction(cc.Sequence.create(
			cc.MoveBy.create(dur, -amplitudeX, amplitudeY),
			cc.MoveBy.create(dur, amplitudeX*2, -amplitudeY*2),
			cc.MoveBy.create(dur, -amplitudeX*2, amplitudeY*2),
			cc.MoveBy.create(dur, amplitudeX, -amplitudeY)
			// cc.callFunc(function () {
			// 	this.showStreak();
			// }.bind(this))
		));
	},

	revivalByDeadZone : function () {
		this.stopUpdate();

		var pos = game.Logic.getTilePosByGrid(this.reviveGrid);
		pos.y += game.Data.tileSizeWidthHalf;
		pos.x += game.Data.tileSizeWidthHalf;
		this.setElePosition(pos);

		var playerPos = game.Data.oPlayerCtl.getElePosition();
		var targetPos = cc.p(0,0);
		targetPos.y = 60;
		game.Data.cameraYPos = -60;
		targetPos.x = game.Data.oPlayerCtl._faceTo == vee.Direction.Left ? -game.Data.cameraXPosLimit : game.Data.cameraXPosLimit;
		game.Data.cameraXPos = -targetPos.x;
		targetPos = cc.p(568-targetPos.x, 384-targetPos.y);
		targetPos = cc.p(targetPos.x - playerPos.x, targetPos.y - playerPos.y);
		game.Data.oPlayerCtl._offsetX = 0;
		game.Data.oPlayerCtl._offsetY = 0;
		game.Data.oLyGame.lyContainer.runAction(cc.sequence(
			cc.EaseInOut.create(cc.moveTo(0.3, targetPos), 3),
			cc.callFunc(function () {
				game.Data.oLyGame.stopCamera = false;
				game.Data.oLyGame.freezeButton = false;
				game.Data.oPlayerCtl._freezeMoveButton = false;

				game.Data.cameraYrevived = false;
				game.Data.oLyGame.setCameraYFreeze(false, 0);

				ItemStageEnd.show(pos);
			}.bind(this))
		));

		this.playAnimate("start_in", function () {
			this.playAnimate("huxi_1");
			this.startUpdate();
		}.bind(this));


		// game.Data.cameraYPos -= (game.Data.oLyGame._freezeY - game.Data.oPlayerCtl._pos.y);
		// game.Data.cameraYrevived = false;
		// game.Data.oLyGame.setCameraYFreeze(false, 0);


	},


	_isReviveFloat : false,
	_canReviveFloat : true,
	_bubbleCtl : null,
	reviveFloat : function () {
		game.Data.playerInvisible = true;
		this._isReviveFloat = true;
		this._canReviveFloat = false;
		this._speedYLimit = 200;
		this._jumpSpeedProtect = true;
		this._speedY = 0;
		this._accY = 100;
		if (this._moveState == MoveState.Bounce) {
			this._isBounce = false;
			this.setMoveState(MoveState.Breath);
		}
		var beginPos = EfxApplause.Analysis.getBeginPos();
		if (beginPos) {
			this._isJumpLimitY = true;
			this._jumpHeightLimitY = game.Logic.getTilePosByGrid(beginPos).y + TILE_WIDTH*2;
		}
		var bubble = EfxBubble.show(this.cancelReviveFloat.bind(this));
		bubble.setPosition(cc.p(0,10));
		this._bubbleCtl = bubble.controller;
		this._container.addChild(bubble);
	},

	cancelReviveFloat : function () {
		if (this._isReviveFloat && this._canReviveFloat) {
			game.Data.playerInvisible = false;
			if (this._bubbleCtl) {
				this._bubbleCtl.boom();
				this._bubbleCtl = null;
			}
			this._isReviveFloat = false;
			this._speedYLimit = game.Data.playerYSpeedLimit;
			this._accY = 0;
			this._jumpSpeedProtect = false;
			if (this._isJumpLimitY) {
				this._isJumpLimitY = false;
			}
		}
	},

	stopMove : function() {
		this._accX = 0;
	},

	stopRunning : function () {
		this._speedX = 0;
	},

	leftToBarrier : function(td) {
		this.pushedDir[vee.Direction.Left] = 1;
		game.Logic.triggerTileCallback(td, this, vee.Direction.Left);
		this._speedX = 0;
	},

	rightToBarrier : function(td) {
		this.pushedDir[vee.Direction.Right] = 1;
		game.Logic.triggerTileCallback(td, this, vee.Direction.Right);
		this._speedX = 0;
	},


	upToBarrier : function(td) {
		// hit block sfx
		this.pushedDir[vee.Direction.Top] = 1;
		if (td) {
			vee.Audio.playEffect(res.inGame_event_hitBlock_mp3);
		}
		game.Logic.triggerTileCallback(td, this, vee.Direction.Top);
		this._speedY = 0;
		this._accY = 0;
		this.stopJumpCounter();
	},

	_gidForCheck : 0,
	downToBarrier : function(td) {
//		cc.log("zq debug down to barrier============");
		this._isJumpLimitY = false;
		this.pushedDir[vee.Direction.Bottom] = 1;
		this._isFlying = false;
		this.stopJumpCounter();
		if (this._moveState == MoveState.SmashShake || this._moveState == MoveState.SmashReset) return;

		if (td) {
			this._gidForCheck = td.gid;
			game.Data.detachAllGrabbedPlatform();
		} else {
			this._gidForCheck = -1;
		}

		if (this.isSmashing() && !game.Logic.isBreakableBlock(this._gidForCheck)) {
			if (Cinema.isCinema) Cinema.smashCallback();
			vee.Audio.playEffect(res.inGame_action_smashOver_mp3);
			this.isLimitY = true;
			this.setMoveState(MoveState.SmashShake);
			var dur = 0.03;
			var amplitudeY = 18;
			game.Data.oLyGame.rootNode.runAction(cc.Sequence.create(
				cc.MoveBy.create(dur,   0, -amplitudeY),
				cc.MoveBy.create(dur,   0, amplitudeY*2),
				cc.MoveBy.create(dur,   0, -amplitudeY),
				cc.MoveBy.create(dur/2, 0, amplitudeY),
				cc.MoveBy.create(dur/2, 0, -amplitudeY*2),
				cc.MoveBy.create(dur/2, 0, amplitudeY)
			));
			this.playAnimate(this.AniTimeLine.smash_reset, function () {
				this._isSmashing = false;
				this.setMoveState(MoveState.Breath);
				game.Data.playerInvisible = false;
			}.bind(this));
			EfxSmashDust.show(this.getElePosition());
			game.Logic.triggerTileCallback(td, this, vee.Direction.Bottom);

			return;
		} else {
			this._speedY = 0;
			this._accY = 0;
		}
		game.Data.cameraRestoreY = false;
		if (game.Data.oLyGame._holdLeft) {
			this.moveLeft();
		} else if (game.Data.oLyGame._holdRight) {
			this.moveRight();
		}
		if (this._moveState == MoveState.DashJumpUp || this._moveState == MoveState.DashJumpDown) {
			this.setMoveState(MoveState.Dash);
		}
		if (this._moveState == MoveState.Bounce) {
			this._isBounce = false;
			if(game.Data.isInParkour()){
				this._container.runAction(cc.sequence(
					cc.delayTime(0.2),
					cc.callFunc(function () {
						this.parkourMove();
					}.bind(this))
				));
			}
			else{
				this.setMoveState(MoveState.Breath);
			}
		}
		game.Logic.triggerTileCallback(td, this, vee.Direction.Bottom);
	},

	squeeze : function (dir) {
		if (this.pushedDir[vee.Direction.revert(dir)]) {
			// die!!!!!

			vee.GameModule.SceneMgr.openOver();
			game.Data.gameFail();
		}
	},

	onGridChanged : function() {
		if (!this._grid || !this._lastGrid) return;
		// Check trigger when grid changed
		game.Logic.checkNewGrids(this._lastGrid, vee.Utils.pSub(this._grid, this._lastGrid));
		game.Logic.checkTileTrigger(this._grid, vee.Direction.Origin, null, this);
		game.Data.onPlayerGridChange(this._grid);
	},

	// Updates...
	_speedScaleRate : null,
	_safePos : null,
	needUpdateState : true,
	_dtCounter : 0,
	updatePos : function(timeDelta) {
//		timeDelta = parseFloat(timeDelta.toFixed(3));
//		if (timeDelta > 0.02) {
//			cc.log("warning : dt = "+timeDelta);
//			timeDelta = 0.02;
//		}

		this.updateMotionStreak(timeDelta);

		this.checkDTCounter(timeDelta);
		this.pushedDir = [];
		if (this.extendController && this.extendController.objType != game.ObjectType.Flight) return;

		// calc speed
		this.calcX(timeDelta);
		this.calcY(timeDelta);
		this.calcMoveDir();

		// calc safe postion...
		var castPos = this.getCastPos(timeDelta);
		this.setElePosition(game.Logic.safePos(castPos, this));
		if (this.elf) this.elf.follow(timeDelta);

		//for Parkour
		if(game.Data.isInParkour() && this._moveState == MoveState.Hanged){
			this.parkourMove();
		}

		// refresh signs
		if (this.needUpdateState) this.updateState();
		else this.needUpdateState = true;
		if (this._speedY != 0) this.setJumping(true);
		if (this._isBounce || this._isFlying) return;

		// Calc decay...
		this.calcDecay(timeDelta);

	},
	calcX : function (timeDelta) {
		if (!this._freezeMoveButton) {
			this._speedX += this._accX * timeDelta * (this._isBounce ? 0.1 : 1);
			this._speedX = (this._speedX > this._speedXLimit ? this._speedXLimit : (this._speedX < -this._speedXLimit ? -this._speedXLimit : this._speedX));
		}
	},
	isLimitY : true,
	isUpdateY : true,
	resetUpdateY : true,
	calcY : function (timeDelta) {
		if (!this.isUpdateY) {
			if (this.resetUpdateY) this.isUpdateY = true;
			return;
		}
		this._speedY += (this._accY + (this._jumpSpeedProtect ? 0 : this._G))*timeDelta;
		if (this.isLimitY) this._speedY =  (this._speedY < this._speedYLimit ? this._speedYLimit : this._speedY);
	},
	calcMoveDir : function () {
		this._moveDir = game.Logic.getMoveDirectionBySpeedX(this._speedX);
	},
	getCastPos : function (timeDelta) {
		var ret = cc.p(this._pos.x + this._speedX*timeDelta*this._speedScaleRate, this._pos.y + this._speedY*timeDelta);
		ret.x = ret.x < 96 ? 96 : ret.x;
		ret.x = ret.x > game.Data.mapRightEdge ? game.Data.mapRightEdge : ret.x;
		if (this._isJumpLimitY) {
			ret.y = ret.y > this._jumpHeightLimitY ? this._jumpHeightLimitY : ret.y;
		}
		return ret;
	},
	calcDecay : function (timeDelta) {
		if (this._accX > 0 && this._speedX < 0) {
			this.setMoveState(MoveState.Brake);
			this._speedX += this._decay*timeDelta;
		} else if (this._accX < 0 && this._speedX > 0) {
			this.setMoveState(MoveState.Brake);
			this._speedX -= this._decay*timeDelta;
		} else if (this._accX == 0 && this._speedX != 0) {
			this.setMoveState(MoveState.Brake);
			if (this._speedX > 0) {
				this._speedX -= this._decay*timeDelta;
				if (this._speedX <= 0) this._speedX = 0;
			} else if (this._speedX <= 0) {
				this._speedX += this._decay*timeDelta;
				if (this._speedX >= 0) this._speedX = 0;
			}
		} else {
			this._isBrake = false;
		}
	},
	updateState : function () {
		if (this._speedY == 0) {
			if (!this._isJumping) {
				if (this._speedX == 0) {
					if (!this._isSmashing) {
						this.setMoveState(MoveState.Breath);
						this.setFaceTo(this._faceTo);
					}
				} else {
					this.setMoveState(MoveState.Moving);
				}
			}
		} else {
			this.setMoveState( this._speedY > 0 ? MoveState.JumpUp : MoveState.JumpDown);
		}
	},

	isDashing : function () {
		return false;
	},

	// Time counter for control jump speed by strength
	_jumpButtonReleased : false,
	_jumpSpeedProtect : false,
	_jumpTimeCounter : 0,
	_jumpTimeChecker : 0.2,
	_jumpHeightLimitY : 0,
	_isJumpLimitY : false,
	updateJumpCounter : function(dt) {
		this._jumpTimeCounter += dt;
		if (this._jumpTimeCounter > 0.15) {
			this.stopJumpCounter();
			this._accY = 0;
			if (this._jumpButtonReleased) {
				this._speedY = this._jumpAccYmini;
			}
		} else if (this._jumpTimeCounter > 0.05) {
			if (this._isBounce) {
				this.stopJumpCounter();
			} else {
				this._speedY = game.Data.playerYJumpSpeed - (0.05*this._jumpTimeCounter)*2000;
				this._accY = this._jumpAccY;
			}
			this._isJumpLimitY = true;
			this.rootNode.setScaleY(1);
			this.rootNode.setPosition(cc.p(0, 0));
		}
	},

	startJumpCounter : function() {
		if (this._isBounce) return;
		this.stopJumpCounter();
		this._jumpSpeedProtect = true;
		this._jumpButtonReleased = false;
		this._jumpTimeChecker = 0.3;
		vee.Audio.playEffect(res.inGame_action_jump_mp3);
		vee.Utils.scheduleCallbackForTarget(this.nodeBox, this.updateJumpCounter.bind(this));
	},

	stopJumpCounter : function(force) {
		if (this._jumpTimeCounter <= 0.05 && !force) return;
		vee.Utils.unscheduleAllCallbacksForTarget(this.nodeBox);
		this._jumpTimeCounter = 0;
		this._jumpSpeedProtect = false;
	},

	copyPlayerState : function (copyObj) {
		this._grid.x = copyObj._grid.x;
		this._grid.y = copyObj._grid.y;
		if (this._lastGrid && this._lastPosition) {
			this._lastGrid.x = copyObj._grid.y;
			this._lastGrid.y = copyObj._grid.y;
			this._lastPosition.x = copyObj._pos.x;
			this._lastPosition.y = copyObj._pos.y;
		}
		this._container.setPosition(copyObj._pos);
		this._isJumpLimitY = false;
//		this.setElePosition(copyObj._pos);
		this.setFaceTo(copyObj._faceTo);
		this.setMoveState(copyObj._moveState);
		this._offsetX   = 0;
		this._offsetY   = 0;
		this._pos       = cc.p(copyObj._pos.x, copyObj._pos.y);
		this.elf        = copyObj.elf;
		this.elf.attach(this.getPosition4Symbol.bind(this));
		this._jumpCount = copyObj._jumpCount;
		if (Story.isShowStory) {
			this._speedX = 0;
			this._speedY = 0;
			this._accX = 0;
			this._accY = 0;
		} else {
			this._speedX = copyObj._speedX;
			this._speedY = copyObj._speedY;
			this._accX = copyObj._accX;
			this._accY = copyObj._accY;
			if (game.Data.oLyGame._holdLeft) {
				this.moveLeft();
			} else if (game.Data.oLyGame._holdRight) {
				this.moveRight();
			}
		}
	},

	setMovingAnima : function () {
		if (game.Data.isInParkour()) {
			this.playAnimate(this.AniTimeLine.run_fast);
		} else {
			this.playAnimate(this.AniTimeLine.run);
		}
	},

	parkourMove : function(){
		if (game.Data.isInParkour()) {
			if (this._moveState === MoveState.Hanged && this.extendController != null) {
				this.extendController.onMoveBtnDown((this._faceTo === vee.Direction.Right) ? vee.Direction.Left : vee.Direction.Right);
			} else if (this._faceTo === vee.Direction.Right) {
				this.moveRight();
				this.setMovingAnima();
			} else if (this._faceTo === vee.Direction.Left) {
				this.moveLeft();
				this.setMovingAnima();
			}
		} else {
			this.stopMove();
		}
	},
});

ElePlayer.create = function(ccbName) {
	var node = cc.BuilderReader.load(ccbName);
	var container = cc.Node.create();
	container.addChild(node);
	node.controller.setContainerNode(container);
	node.controller.ccbName = ccbName;
	node.controller.ccbInit();
	return {container : container, controller : node.controller};
};

ElePlayer.transformTo = function (newCCBName) {

	// variable prepare...
	if (game.Data.oPlayerCtl.ccbName == newCCBName) return;
	var newCtl = null;
	if (ElePlayer.tempPlayerCtl && ElePlayer.tempPlayerCtl.ccbName == newCCBName) {
		newCtl = ElePlayer.tempPlayerCtl;
	} else {
		var newPlayerContent = ElePlayer.create(newCCBName);
		game.Data.oLyGame.lyMap.addChild(newPlayerContent.container, 2);
		newCtl = newPlayerContent.controller;
	}

	// transfer states...
	newCtl.copyPlayerState(game.Data.oPlayerCtl);
	ElePlayer.tempPlayerCtl = game.Data.oPlayerCtl;
	game.Data.oPlayerCtl = newCtl;
	// don`t forget to do some effect!
};

ElePlayer.efxMarioGrow = function () {
	if (!ElePlayer.tempPlayerCtl) return;
	// pause game
	game.Data.oLyGame.pauseGame(true);
	// only player can perform animate
	game.Data.oPlayerCtl._container.resume();
	ElePlayer.tempPlayerCtl._container.resume();
	game.Data.oPlayerCtl._container.stopAllActions();
	ElePlayer.tempPlayerCtl._container.stopAllActions();
	ElePlayer.tempPlayerCtl.setMoveState(game.Data.oPlayerCtl._moveState);

	// show animate and resume game when finish
	game.Data.oPlayerCtl._container.setVisible(true);
	game.Data.oPlayerCtl._container.runAction(cc.blink(0.5, 5));
	ElePlayer.tempPlayerCtl._container.setVisible(false);
	ElePlayer.tempPlayerCtl._container.runAction(cc.sequence(
		cc.delayTime(0.05),
		cc.callFunc(function () {
			ElePlayer.tempPlayerCtl._container.setVisible(true);
		}),
		cc.blink(0.4, 4),
		cc.callFunc(function () {
			ElePlayer.tempPlayerCtl._container.setVisible(false);
			cc.log("ctl name = "+ElePlayer.tempPlayerCtl.ccbName);
			game.Data.oLyGame.resumeGame();
		}),
		cc.delayTime(1),
		cc.callFunc(function () {
			cc.log("ctl name = "+ElePlayer.tempPlayerCtl.ccbName);
			cc.log("visible state = "+ElePlayer.tempPlayerCtl._container.isVisible());
		})
	));
};

ElePlayer.efxMarioShrink = function () {
	if (!ElePlayer.tempPlayerCtl) return;
	// pause game
	game.Data.oLyGame.pauseGame(true);
	// only player can perform animate
	game.Data.oPlayerCtl._container.resume();
	ElePlayer.tempPlayerCtl._container.resume();
	game.Data.oPlayerCtl._container.stopAllActions();
	ElePlayer.tempPlayerCtl._container.stopAllActions();

	// show animate and resume game when finish
	game.Data.oPlayerCtl._container.setVisible(true);
	game.Data.oPlayerCtl._container.runAction(cc.blink(1, 5));
	ElePlayer.tempPlayerCtl._container.setVisible(false);
	ElePlayer.tempPlayerCtl._container.runAction(cc.sequence(
		cc.delayTime(0.1),
		cc.callFunc(function () {
			ElePlayer.tempPlayerCtl._container.setVisible(true);
		}),
		cc.blink(0.8, 4),
		cc.callFunc(function () {
			ElePlayer.tempPlayerCtl._container.setVisible(false);
			ElePlayer.tempPlayerCtl.setMoveState(MoveState.Breath);
			ElePlayer.tempPlayerCtl.playAnimate("huxi_1");
			ElePlayer.tempPlayerCtl._container.stopAllActions();
			cc.log("ctl name = "+ElePlayer.tempPlayerCtl.ccbName);
			cc.log("visible states = "+ElePlayer.tempPlayerCtl._container.isVisible());
			game.Data.oLyGame.resumeGame();
			game.Data.oPlayerCtl.hurtInvisible();
		})
	));
};

ElePlayer.tempPlayerCtl = null;