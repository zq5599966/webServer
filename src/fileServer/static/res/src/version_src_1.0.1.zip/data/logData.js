/**
 * Created with AppCode.
 * User: ZQ
 * Date: 16/7/18
 * Time: 下午2:14
 * 友盟数据统计
 */

game.Log = {
	moonWorld_whiteSceenTag_start : "moonWorld_whiteSceenTag_start",
	monnWorld_whiteSceenTag_end : "moonWorld_whiteSceenTag_end"
}
