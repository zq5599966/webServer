/**
 * Created by john on 2016/12/7.
 */

var vee = vee = vee || {};

vee.Analytics.UGameEvent = {

    startGuideLevel : function () {
        vee.Analytics.ugameLogEvent("GuideLevel", null);
    },


    getLevelType : function (str) {
        if(null == str || str == ""){
            str = "normal";
        }
        return str;
    },

    registerSuperProperty : function (key, value) {
        vee.Analytics.registerSuperProperty(key, value);
    },

    //事件id = GameLevelStart
    gameStartEventParam : {
        level : "",             //关卡名称 大关卡+0+小关卡
        levelType : "",         //关卡类型 normal event mini
        remainEnergy : "",      //剩余能量
        roleId : "",            //角色id
    },

    /**
     * add by zq
     * @param levelType
     * //@param param{vee.Analytics.UGameEvent.gameStartEventParam}
     */
    gameStartEvent : function (levelType) {
        levelType = this.getLevelType(levelType);
        this.gameStartEventParam.level = "" + levelType + (game.LevelData.selectedCategory.idx + 1) + "0" + (game.LevelData.selectedLevel.idx + 1);
        this.gameStartEventParam.levelType = "" + levelType;
        this.gameStartEventParam.remainEnergy = "" + game.Data.getEnergy();
        this.gameStartEventParam.roleId = "" + vee.VIPValues.getValue('currentAvatar');

        vee.Analytics.ugameLogEvent("GameLevelStart", this.gameStartEventParam);
    },


    //事件id = GameLevelEnd
    gameEndEventParam : {
        level : "",             //关卡名称 大关卡+0+小关卡
        levelType : "",         //关卡类型 normal event mini
        remainEnergy : "",      //剩余能量
        roleId : "",            //角色id
        endState : "",          //结束状态，success、fail
        starNum : "",           //获得大星星数
        star1 : "",             //是否获得第一个大星星
        star2 : "",             //是否获得第二个大星星
        star3 : "",             //是否获得第三个大星星
        coinNum : "",           //获得的金币
        remainCoin : "",        //关卡内剩余金币
        getLife : "",           //关卡内获得的生命值
        costLife : "",          //关卡内消耗的生命值
        endGid : "",            //关卡结束时角色坐标 gid
        videoRevival : "",      //是否看视频复活 true false
        blackCat : "",          //是否开启幻影模式 true false
        costTime : "",          //关卡耗时 秒
    },

    /**
     * add by zq
     * @param param{vee.Analytics.UGameEvent.gameEndEventParam}
     */
    gameEndEvent : function (levelType, endState) {
        levelType = this.getLevelType(levelType);
        this.gameEndEventParam.level = "" + (game.LevelData.selectedCategory.idx + 1) + "0" + (game.LevelData.selectedLevel.idx + 1);
        this.gameEndEventParam.levelType = "" + levelType;
        this.gameEndEventParam.remainEnergy = "" + game.Data.getEnergy();
        this.gameEndEventParam.roleId = "" + vee.VIPValues.getValue('currentAvatar');
        this.gameEndEventParam.endState = "" + endState;
        this.gameEndEventParam.starNum = "" + game.LevelData.selectedLevel.getAchievedStarCount();
        this.gameEndEventParam.star1 = "" + game.LevelData.selectedLevel.isStarAchieved(1);
        this.gameEndEventParam.star2 = "" + game.LevelData.selectedLevel.isStarAchieved(2);
        this.gameEndEventParam.star3 = "" + game.LevelData.selectedLevel.isStarAchieved(3);
        this.gameEndEventParam.coinNum = "" + game.Data.getTempCoin();
        this.gameEndEventParam.remainCoin = "" + (game.Data.stageMaxCoin - game.Data.getTempCoin());
        this.gameEndEventParam.getLife = "" + game.Data.oLyGame._tmpHeartNum;
        this.gameEndEventParam.costLife = "" + game.Data.oLyGame._tmpCostLifeNum;
        vee.Utils.logObj(game.Data.playOverGid, "playover gid===");
        this.gameEndEventParam.endGid = "" + game.Data.playOverGid.x + ", " + game.Data.playOverGid.y;
        this.gameEndEventParam.videoRevival = "" + game.Data.willShowVideoAd;
        this.gameEndEventParam.blackCat = "" + game.Data.oLyGame._isBlackCatModel;
        this.gameEndEventParam.costTime = "" + Math.floor((new Date().getTime() - game.Data.oLyGame._startDateTime)/1000);

        vee.Analytics.ugameLogEvent("GameLevelEnd", this.gameEndEventParam);


        //for ugame default
        vee.Analytics.ugameLogEvent("um_level", {
            um_level_id : this.gameEndEventParam.level,
            um_level_amount : this.gameEndEventParam.costTime,
            um_level_result : this.gameEndEventParam.endState
        });
    },


    gameStopEvent : function () {
        var gameEndParam = {};
        if(game.LevelData.selectedCategory && game.LevelData.selectedLevel){
            gameEndParam.level = "" + (game.LevelData.selectedCategory.idx + 1) + "0" + (game.LevelData.selectedLevel.idx + 1);
            gameEndParam.starNum = "" + game.LevelData.selectedLevel.getAchievedStarCount();
            gameEndParam.star1 = "" + game.LevelData.selectedLevel.isStarAchieved(1);
            gameEndParam.star2 = "" + game.LevelData.selectedLevel.isStarAchieved(2);
            gameEndParam.star3 = "" + game.LevelData.selectedLevel.isStarAchieved(3);
            gameEndParam.coinNum = "" + game.Data.getTempCoin();
            gameEndParam.remainCoin = "" + (game.Data.stageMaxCoin - game.Data.getTempCoin());
            gameEndParam.getLife = "" + game.Data.oLyGame._tmpHeartNum;
            gameEndParam.costLife = "" + game.Data.oLyGame._tmpCostLifeNum;
            vee.Utils.logObj(game.Data.playOverGid, "playover gid===");
            gameEndParam.endGid = "" + game.Data.oPlayerCtl.getElePosition().x + ", " + game.Data.oPlayerCtl.getElePosition().y;
            gameEndParam.videoRevival = "" + game.Data.willShowVideoAd;
            gameEndParam.blackCat = "" + game.Data.oLyGame._isBlackCatModel;
            gameEndParam.costTime = "" + Math.floor((new Date().getTime() - game.Data.oLyGame._startDateTime)/1000);
        }
        else if(game.Data.curSceen){
            gameEndParam.level = game.Data.curSceen;
        }
        // gameEndParam.levelType = "" + levelType;
        gameEndParam.remainEnergy = "" + game.Data.getEnergy();
        gameEndParam.roleId = "" + vee.VIPValues.getValue('currentAvatar');
        // gameEndParam.endState = "" + endState;


        vee.Analytics.ugameLogEvent("GameStop", this.gameEndEventParam);
    },


    payEventParam : {
        payId : "",             //支付id
        // playCount : "",         //关卡总进入数
        selectLevel : "",       //当前选择关卡 大关卡+0+小关卡
    },

    /**
     * add by zq
     * @param param{vee.Analytics.UGameEvent.payEventParam}
     */
    payEvent : function (payId) {
        this.payEventParam.payId = "" + payId;
        // this.payEventParam.playCount = "" + game.Data.getTotalPlayCount();
        // this.payEventParam.selectLevel = "" + (game.LevelData.selectedCategory.idx + 1) + "0" + (game.LevelData.selectedLevel.idx + 1);
        vee.Analytics.ugameLogEvent("pay", this.payEventParam);

        //for ugame default
        var payType = game.Data.isAndroid ? "googleplay" : "appstore";
        vee.Analytics.ugameLogEvent("um_pay", {
            um_pay_money : 1,
            um_pay_type : payType,
            um_pay_iap : this.payEventParam.payId,
            gametype : this.payEventParam.payId
        });
    },


    showAdEventParam : {
        adPos : "",         //广告显示时机
        adState : "",       //广告类型 video、interstial
        adReward : "",      //广告奖励 解锁关卡、0生命复活、悬崖复活、解锁角色
    },

    showAdEvent : function (info, type, reward) {
        this.showAdEventParam.adPos = "" + info;
        this.showAdEventParam.adState = "" + type;
        this.showAdEventParam.adReward = "" + reward || "";
        vee.Analytics.ugameLogEvent("showAd", this.showAdEventParam);
    },

    unlockRoleEventParam : {
        pos : "",           //解锁时机  商店看视频解锁、全三星解锁
        roleId : "",        //角色id
    },

    unlockRoleEvent : function (posId, roleId) {
        this.unlockRoleEventParam.pos = "" + posId;
        this.unlockRoleEventParam.roleId = "" + roleId;

        vee.Analytics.ugameLogEvent("unlockRole", this.unlockRoleEventParam);
    },

    clickButtonParam : {
        clickEvent : "",    //按钮点击事件
    },

    clickButtonEvent: function (clickEvent) {
        this.clickButtonParam.clickEvent = "" + clickEvent;

        vee.Analytics.ugameLogEvent("buttonClick", this.clickButtonParam);
    },


    rateClickEvent : function (starNum) {

        var param = {
            starNum : 0
        }

        param.starNum = "" + starNum

        vee.Analytics.ugameLogEvent("rateStar", param);
    }

}