/**
 * Created with AppCode.
 * User: yop
 * Date: 15/9/2
 * Time: 上午11:00
 * To change this template use File | Settings | File Templates.
 */

var LevelCell = vee.Class.extend({
	/** @type {cc.ControlButton} */
	btnSelect : null,

	/** @type {cc.Sprite} */
	spBG : null,
	/** @type {cc.Sprite} */
	spStar1 : null,
	/** @type {cc.Sprite} */
	spStar2 : null,
	/** @type {cc.Sprite} */
	spStar3 : null,
	/** @type {cc.Sprite} */
	spCoin : null,
	/** @type {cc.Sprite} */
	spMoon : null,
	/** @type {cc.Label} */
	lbLevelNo : null,
	/** @type {cc.Node} */
	lyContent : null,

	ccbBtnShop : null,

	idx : 0,


	checkLevelLockByParkour : function () {

		// if(game.Data.zqdebug){
		// 	return false;
		// }

		if(game.LevelData.selectedCategory.idx == 9 && this.idx > 0 && !game.LevelData.checkParkourlevelUnlock(this.idx)){
			return true;
		}
		return false;
	},

	onSelectEvent : function () {
		vee.Audio.playEffect(res.outGame_menu_chooseLevel_mp3);
		var startCallback = function () {
			var category = game.LevelData.selectedCategory;
			var ctl = category.getLevelDataController(this.idx);
			game.LevelData.selectedLevel = category.getLevelDataController(this.idx);
			game.LevelData.selectedLevel.idx = this.idx;
			vee.PopMgr.closeAll();
			cc.director.purgeCachedData();
			var node = vee.PopMgr.popCCB("res/veeGameLayer.ccbi");
			cc.log('opening level: ' + game.LevelData.levelMap[ctl.getLevelNo()-1]);
			game.Data.oLyGame.onLoaded();
			game.Data.oLyGame.initStage(game.LevelData.levelMap[ctl.getLevelNo()-1]);
		}.bind(this);
		game.Data.oLvSelectCtl.startLevel(startCallback);
	},


	onSelect : function(){
		if (game.Data.oLvSelectCtl._isOver) return;

		/*
		if (game.Data.isFreeGame) {
			if (vee.Ad.showInterstitialAndBlockButton("level_btn")) {
				return;
			}
		}
		*/

		cc.log("zq debug on level cell click");
		cc.log("zq debug selected category idx===%d   level idx===%d", game.LevelData.selectedCategory.idx, this.idx);

		var category = game.LevelData.selectedCategory;
		game.Data.setSelectedLvIdx(game.LevelData.selectedCategory.idx + 1);
		var ctl = category.getLevelDataController(this.idx);
		// for demo
		if (ctl.getLevelState() != 0 || game.Data.isAllLevelOpen ) {
			if(this.checkLevelLockByParkour()){
				ccbAlertUnlockLevel.show(this.idx, this.onSelectEvent.bind(this));
			}
			else{
				this.onSelectEvent();
			}
		}
		else if (category.idx > 99 && game.LevelData.selectedCategory) {
			AlertMoonLocked.show(this.idx, true);
		}

		return true;
	},

	updateContent : function() {
		var category = game.LevelData.selectedCategory;
		if (!category) {
			cc.log("error no selected category data");
			return;
		}
		var beginIdx = Math.ceil((7 - category.levelCount)/2) + 1;
		var tag = parseInt(this.rootNode.getTag());
		if (tag < beginIdx || tag >= (beginIdx + category.levelCount)) {
			this.lyContent.setVisible(false);
			return;
		}
		this.idx = tag - beginIdx;
		var ctl = category.getLevelDataController(this.idx);
		this.lyContent.setVisible(true);
		var state = ctl.getLevelState();

//		vee.Utils.logObj(ctl, "ctl===");
//		vee.Utils.logObj(state, "state===");

		this.lbLevelNo.setString(tag - beginIdx + 1);

		switch (state) {
			case 0 :
				if (game.Data.isSelectingReverseWorld) {
					this.playAnimate('lock_moon');
				} else {
					this.playAnimate('lock');
				}
				break;
			case 1 :
				this.playAnimate('unlock');
				break;
			case 2 :
			{
				this.playAnimate('played');
				this.spStar1.initWithFile(ctl.isStarAchieved(1) ? res.level_icon_star_on_png : res.level_icon_star_off_png);
				this.spStar2.initWithFile(ctl.isStarAchieved(2) ? res.level_icon_star_on_png : res.level_icon_star_off_png);
				this.spStar3.initWithFile(ctl.isStarAchieved(3) ? res.level_icon_star_on_png : res.level_icon_star_off_png);
				this.spCoin.initWithFile(ctl.isAllCoinCollect() ? res.level_icon_coin_on_png : res.level_icon_coin_off_png);

				if(game.Data.isReverseWorldOpen && game.Data.version.newVersion){
					if(vee.data["moon"] && !game.Data.isSelectingReverseWorld && category.checkHasUnlockMoon()){
						this.spMoon.initWithFile(ctl.isLevelReverseKeyCollected() ? res.level_icon_moon_on_png : res.level_icon_moon_off_png);
						this.spMoon.setVisible(true);
					}
					else{
						this.spMoon.setVisible(false);
					}
				}
				else if (game.Data.isShowBtnWorld() && !game.Data.isSelectingReverseWorld && category.checkHasUnlockMoon()) {
					this.spMoon.initWithFile(ctl.isLevelReverseKeyCollected() ? res.level_icon_moon_on_png : res.level_icon_moon_off_png);
					this.spMoon.setVisible(true);
				} else {
					this.spMoon.setVisible(false);
				}
			}

				break;
			default :
				cc.log("error getLevelState error: " + state);
				return;
		}
	}

});


var EfxLevelCells = vee.Class.extend({
	onCreate : function() {
		this.rootNode.setVisible(false);
	},

	show : function(callback){
		vee.Audio.playEffect(res.outGame_menu_chooseSection_mp3);
		this.playAnimate('Show', callback);
	},

	hide : function(callback) {
		vee.Audio.playEffect(res.outGame_menu_leaveSection_mp3);
		this.playAnimate('Hide', callback);
	},

	updateCells : function() {
		var len = this.rootNode.getChildrenCount();
		var children = this.rootNode.getChildren();
		for( var i = 0; i < len; i++) {
			children[i].controller.updateContent();
		}
	}
});