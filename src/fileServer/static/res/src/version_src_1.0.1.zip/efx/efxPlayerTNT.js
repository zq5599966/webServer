/**
 * Created with AppCode.
 * User: WanThirty
 * Date: 15/9/2
 * Time: 下午3:51
 * To change this template use File | Settings | File Templates.
 */

var EfxPlayerTNT = vee.Class.extend({
	ps1 : null,
	_container : null,
	isStatic : true,
	boomed : false,
	boomFunc : null,
	onLoaded : function () {
		this.ps1.setPositionType(1);
	},

	breathAnimate : function () {
		this.playAnimate("breath");
	},

	bornAnimate : function () {
		this.playAnimate("in", function () {
			this.isStatic = false;
			this.boomAnimate();
		}.bind(this));
	},

	boomAnimate : function (immediately) {
		if (this.boomed) return;
		if (immediately) {
			this.boomAnimateExplode();
			return;
		}

		//vee.Audio.playEffect(res.inGame_efx_bombExplode_mp3);
		this.playAnimate("boom", function () {
			this.boomAnimateExplode();
		}.bind(this));
	},

	boomAnimateExplode : function (immediately) {
		this.playAnimate("boom3", function () {
			this.die();
		}.bind(this));
	},

	setBoomFunc : function (boomFunc) {
		this.boomFunc = boomFunc;
	},

	startBoom : function () {
		vee.Audio.playEffect(res.inGame_efx_bombExplode_mp3);
		this.boomed = true;
	},

	boom : function () {
		if (this.boomFunc) {
			this.boomFunc();
		}
	},

	die : function () {
		this.rootNode.removeFromParent();
	}
});

EfxPlayerTNT.create = function (pos) {
	var node = cc.BuilderReader.load(res.efx_PlayerTNT_ccbi);
	var container = cc.Node.create();
	node.controller._container = container;
	container.addChild(node);
	container.setPosition(pos);
	game.Data.oLyGame.lyMap.addChild(container, 11);
	return node.controller;
};

var EfxTNT = EfxPlayerTNT.extend({
	onLoaded : function () {

	},

	boomAnimate : function (immediately) {
		if (immediately) return;
		this.playAnimate("boom", function () {
			this.die();
		}.bind(this));
	}
});

EfxTNT.create = function (pos) {
	var node = cc.BuilderReader.load(res.efx_TNT_ccbi);
	var container = cc.Node.create();
	node.controller._container = container;
	node.controller.isStatic = false;
	container.addChild(node);
	container.setPosition(pos);
	game.Data.oLyGame.lyMap.addChild(container, 11);
	return node.controller;
}