/**
 * Created with AppCode.
 * User: WanThirty
 * Date: 15/6/18
 * Time: 下午7:48
 * To change this template use File | Settings | File Templates.
 */

var EleKarby = ElePlayer.extend({
	_isFat : false,

	updateJumpCounter : function(dt) {
		this._jumpTimeCounter += dt;
		if (this._isFat) {
			if (this._jumpTimeCounter > 0.05) {
				this.stopJumpCounter();
				this._speedY = 500;
				this._isJumpLimitY = false;
				this.rootNode.setScaleY(1);
				this.rootNode.setPosition(cc.p(0, 0));
			}
		} else {
			if (this._jumpTimeCounter > 0.15) {
				this.stopJumpCounter();
				this._accY = 0;
				if (this._jumpButtonReleased) {
					this._speedY = this._jumpAccYmini;
				}
			} else if (this._jumpTimeCounter > 0.05) {
				if (this._isBounce) {
					this.stopJumpCounter();
				} else {
					this._speedY = game.Data.playerYJumpSpeed;
					this._accY = this._jumpAccY;
				}
				this.rootNode.setScaleY(1);
				this.rootNode.setPosition(cc.p(0, 0));
			}
		}
	},

	setFat : function (isfat) {
		this._isFat = isfat;
		if (isfat) {
			this._speedXLimit = 250;
			this.setMoveState(MoveState.Inhaled);
		} else {
			this._speedXLimit = game.Data.playerXSpeedLimit;
		}
	},

	BButton : function (buttonUp) {
		if (this._isFat) {
			// There`s something inside
			if (buttonUp) {

			} else {
				// spit
				if (this._moveState != MoveState.Spit) {
					this.setMoveState(MoveState.Spit);
					ItemSpitStar.create(this.getElePosition(), this.getFaceToNumber());
				}
			}

		} else {
			if (this._isJumping) return;
			// There`s nothing inside
			if (buttonUp) {
				// Stop sucking!;
				this.stopSucking();
				this._moveState = MoveState.Breath;
				this.playAnimate("huxi");
				this._freezeMoveButton = false;
			} else {
				// Start now!
				this.setMoveState(MoveState.InhalePrepare);
				this._freezeMoveButton = true;
//				this._speedX = 0;
				this._accX = 0;
			}
		}
	},

	feed : function (inhaleController) {
		this.setMoveState(MoveState.Inhaled);
		this.setFat(true);
		this.stopSucking();
	},

	setMoveState : function(state) {
		if (this._moveState == state) return;
		if (this._isBrake && state == MoveState.Moving) return;
		if (this._isJumping && state == MoveState.Brake) return;
		if (this._isBounce) return;
		switch (state) {
			case MoveState.Breath:
				if (this._isBrake || this.isInhaling() || this._moveState == MoveState.Spit) return;
				if (this._isFat) this.playAnimate("huxi_fat");
				else this.playAnimate("huxi");
				break;
			case MoveState.Dash:
				this.rootNode.stopAllActions();
				this.playAnimate(this.AniTimeLine.dash);
				break;
			case MoveState.DashBrake:
				this.playAnimate(this.AniTimeLine.dash_brake);
				break;
			case MoveState.DashHolding:
//				this.rootNode.setScaleX(-this.rootNode.getScaleX());
				break;
			case MoveState.Bounce:
				this._isBounce = true;
				this._freezeMoveButton = false;
				this._moveState = null;
				if (this._isFat) this.playAnimate(this.AniTimeLine.dash_stop);
				else this.playAnimate("fast_run_stop2");
				break;
			case MoveState.Moving:
				if (this.isInhaling() || this._moveState == MoveState.Spit) return;
				this.rootNode.stopAllActions();
				if (this._isFat) this.playAnimate(this.AniTimeLine.run+"_fat");
				else this.playAnimate(this.AniTimeLine.run);
				break;
			case MoveState.Brake:
				if (this.isInhaling() || this._moveState == MoveState.Spit) return;
				this.setFaceTo(this._faceTo, true);
				this._isBrake = true;
				this.playAnimate(this.AniTimeLine.run_brake);
				break;
			case MoveState.JumpUp:
				if (this._isFat) this.playAnimate("jump_fat");
				else this.playAnimate(this.AniTimeLine.jump_up);
				break;
			case MoveState.JumpDown:
				if (this._isSmashing) return;
				if (this._isFat) this.playAnimate("jump_down_fat");
				else this.playAnimate(this.AniTimeLine.jump_down);
				break;
			case MoveState.DashJumpUp:
				this.playAnimate(this.AniTimeLine.dash_jump_up);
				break;
			case MoveState.DashJumpDown:
				this.playAnimate(this.AniTimeLine.dash_jump_down);
				break;
			case MoveState.InhalePrepare:
				this.playAnimate(this.AniTimeLine.inhale_ready, function() {
					this.setMoveState(MoveState.Inhaling);
				}.bind(this));
				break;
			case MoveState.Inhaling:
				this.playAnimate(this.AniTimeLine.inhale_loop);
				// Start sucking
				this.startSucking();
				break;
			case MoveState.Inhaled:
				this.playAnimate(this.AniTimeLine.inhale_end, function () {
					this._freezeMoveButton = false;
					this._moveState = MoveState.Breath;
					if (this._isFat) this.playAnimate("huxi_fat");
					else this.playAnimate("huxi");
				}.bind(this));
				break;
			case MoveState.Spit:
				this._freezeMoveButton = true;
				this.playAnimate(this.AniTimeLine.spit, function () {
					this.setFat(false);
					this._moveState = MoveState.Breath;
					this.playAnimate("huxi");
					this._freezeMoveButton = false;
				}.bind(this));
				break;
			default :
				break;
		}
		this._moveState = state;
	},

	/* Sucks */
	_arrSuckedObj : null,
	_arrSuckMap : null,
	startSucking : function () {
		vee.Utils.scheduleCallbackForTarget(this._container, this.updateSucking.bind(this));
		this._arrSuckedObj = [];
		this._mapDangerArea = vee.Map.create(game.Logic._tmxMapSize, game.Logic._tmxTileSize);
		var faceToNum = this.getFaceToNumber();

		var grid = null;
		for (var j = -1; j < 2; ++j) {
			for (var i = 1; i < 4; ++i) {
				grid = cc.p(this._grid.x + faceToNum*i, this._grid.y+j);
				var ti = game.Logic.getTileInfoAt(grid);
				if (ti && ti.type == game.ObjectType.Block) break;
				this._mapDangerArea.setObject(true, grid);
			}
		}
	},
	stopUpdateSucking : function () {
		vee.Utils.unscheduleAllCallbacksForTarget(this._container);
	},
	stopSucking : function () {
		vee.Utils.unscheduleAllCallbacksForTarget(this._container);
		// Release sucked obj
		if (this._arrSuckedObj) {
			var len = this._arrSuckedObj.length;
			for (var i = 0; i < len; ++i) {
				this._arrSuckedObj[i].releaseObj();
			}
			this._arrSuckedObj = null;
		}

		this._arrSuckMap = null;
	},
	updateSucking : function () {
		// Check dynamic objects...
		game.Logic.dynamicObjMap.forEachObjects(function (obj) {
			if (this._mapDangerArea.getObject(obj._grid)) {
				var controller = obj.getInhaleController();
				if (controller) {
					controller.inhaleObj();
					this._arrSuckedObj.push(controller);
				}
			}
		}.bind(this));
		// Check static objects...
		var faceToNum = this.getFaceToNumber();
		var grid = null;
		for (var j = -1; j < 2; ++j) {
			for (var i = 1; i < 4; ++i) {
				grid = cc.p(this._grid.x + faceToNum*i, this._grid.y+j);
				if (!this._mapDangerArea.getObject(grid)) break;
				var ctl = game.Logic.objMap.getObject(grid);
				if (ctl && ctl._eleType == game.EleType.Item) {
					game.Logic.removeMapExObjectByGrid(grid);
					game.Logic.objMap.removeObject(grid);
					ctl.setDynamic(0,0);
				}
			}
		}
	},
	/* Sucks end */

	randomBreath : function () {},

	isInhaling : function () {
		if (this._moveState == MoveState.InhalePrepare ||
			this._moveState == MoveState.Inhaling ||
			this._moveState == MoveState.Inhaled) {
			return true;
		}
		return false;
	}
});