/**
 * Created with AppCode.
 * User: yop
 * Date: 15/10/27
 * Time: 下午3:33
 * To change this template use File | Settings | File Templates.
 */

LevelController.LevelMini203 = LevelController.extend({
	eventStory1 : function(grid, dir) {
		this.showStory(1, grid, ""+
		"RemoveEnemy;"+
		"MoveCamera,8,12,2;"+
		"SelectNpc;"+
		"ShowDialog,"+ vee.Utils.getLocalizedStringForKey("Exit, negative height.", "出口，负高度处。") +";"+
		"ShowDialog,"+ vee.Utils.getLocalizedStringForKey("Bonus, lead the way.", "奖励，指引方向。") +";"+
		"HideDialog;"+
		"TimeLine,huxi_2;"+
		"Delay,1;"+
		"AddCoin," + vee.Utils.getObjByPlatform('600','800','600') + ";"+
		"Delay,2;"+
		"GameOver"+
		"");
	}
});
