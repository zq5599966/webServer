/**
 * Created with AppCode.
 * User: WanThirty
 * Date: 16/1/14
 * Time: 下午12:14
 * To change this template use File | Settings | File Templates.
 */

var EfxHawkLight = vee.Class.extend({
	ccbInit : function () {
		this.playAnimate("drop light", function () {
			this.rootNode.removeFromParent();
		}.bind(this));
	}
});

EfxHawkLight.show = function (pos) {
	var node = cc.BuilderReader.load(res.ele_HeroLightDrop_ccbi);
	game.Data.oLyGame.lyMap.addChild(node, 1);
	node.setPosition(pos);
	node.controller.ccbInit();
};