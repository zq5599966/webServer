/**
 * Created with AppCode.
 * User: WanThirty
 * Date: 15/8/6
 * Time: 下午6:45
 * To change this template use File | Settings | File Templates.
 */

var mario = mario || {};

mario.initGame = function(idx) {
	var layer = cc.Layer.create();
	layer.setContentSize(cc.size(1136, 768));
	vee.PopMgr.popLayer(layer);
	mario.JsAdapter.getInstance().initGame(layer, 100);
}