/**
 * Created with AppCode.
 * User: WanThirty
 * Date: 15/9/8
 * Time: 下午7:31
 * To change this template use File | Settings | File Templates.
 */

var UIStar = vee.Class.extend({
	_lock : null,
	spBack : null,

	setGettedStar : function () {
		var starFileName = res.ga_ui_star_off_2_png;
		if (game.Data.checkIs61()) {
			starFileName = res.ga_ui_starChild_off_png;
		}
		this.spBack.setTexture(starFileName);
		this.spBack.setColor(cc.color(255,255,255));
		this.spBack.setOpacity(255);
	},

	setLocked : function (locked) {
		this._lock = locked;
		if (locked) {
			this.playAnimate("dark");
		} else {
			this.playAnimate("light");
		}
	},

	unlockAnimate : function () {
		if (this._lock) this.playAnimate("show");
	}
});

UIStar.create = function(locked) {
	var ccbName = res.uiStar_ccbi;
	if (game.Data.checkIs61()) {
		ccbName = res.uiStarChild_ccbi;
	}
	var node = cc.BuilderReader.load(ccbName);
	node.controller.setLocked(locked);
	return node;
};