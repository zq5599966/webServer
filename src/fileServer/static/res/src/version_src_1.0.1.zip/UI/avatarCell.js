/**
 * Created with AppCode.
 * User: yop
 * Date: 15/9/3
 * Time: 下午8:09
 * To change this template use File | Settings | File Templates.
 */

var AvatarCell = vee.Class.extend({

	/** @type {cc.Label} */
	lbPrice : null,
	/** @type {cc.Label} */
	lbTitle : null,
	/** @type {cc.Label} */
	lbDesc : null,
	/** @type {cc.ControlButton} */
	btnBuy : null,
	lyAvatar : null,
	lyContent : null,
	spAvatar : null,
	nodeProgress : null,
	spBG : null,

	/** @type {game.AvatarData.productDataTemplate} */
	avatarData : null,
	idx : 0,

	onCreate : function() {
		if(this.rootNode.getTag() == 1){
			this.init();
		}
	},

	init : function(){
		this.idx = this.rootNode.getTag() -1;

		LyAvatarStore.arrCell[this.idx] = this;
		var avatarData = game.AvatarData.getAvatarData(this.idx);

		this.spAvatar.setTexture(avatarData.picName);

		this.avatarData = avatarData;
		this.btnBuy.setControlSwallowTouches(false);
		this.resetState();
		this.lbPrice.setString(this.avatarData.priceDesc);
		if (game.Data.isAndroid && avatarData.idx == 4) {
			this.lbTitle.setString(game.AvatarData.getAvatarName(10));
			this.lbDesc.setString(game.AvatarData.getAvatarDesc(10));
		} else {
			this.lbTitle.setString(game.AvatarData.getAvatarName(avatarData.idx));
			this.lbDesc.setString(game.AvatarData.getAvatarDesc(avatarData.idx));
		}
	},

	resetState : function () {
		if (this.avatarData.owned) {
			if (this.avatarData.idx == game.AvatarData.getCurrentAvatar().idx) {
				this.playAnimate('selected');
				AvatarCell.selectedCell = this;
			} else {
				this.playAnimate('owned');
			}
		} else if(this.avatarData.iapIndex != -1){
			this.playAnimate('iap');
		}
		else if(game.Data.version.isMidAutumn && this.avatarData.idx == 13){
			this.playAnimate('facebook');
		}

		else if(!game.Data.isFreeGame && game.Data.version.isSetShowSpecialEvent && (this.avatarData.idx == 14 || this.avatarData.idx == 15)){
			this.playAnimate('video');
		}

		else {
			if (game.Data.isUnlocking()) {
				var nextAvatar = game.AvatarData.getNextAvatar();
				if (nextAvatar && nextAvatar.idx == this.idx) {
					this.playAnimate("unlocking");
					var rate = game.LevelData.getCoin() / nextAvatar.price;
					this.nodeProgress.setScaleX(rate);
				} else {
					this.playAnimate("lock");
				}
			} else {
				this.playAnimate("lock");
			}
		}
	},

	refreshCellState : function () {
		this.avatarData = game.AvatarData.getAvatarData(this.idx);
		this.resetState();
	},

	select : function() {
		game.AvatarData.avatarSelected(this.idx);
		AvatarCell.selectedCell.disSelect();
		AvatarCell.selectedCell = this;
		this.playAnimate('selected');
		vee.Audio.playEffect(res.outGame_menu_changeAvator_mp3);
	},

	disSelect : function() {
		this.playAnimate('owned');
	},

	//for MaNtIs
	isStart : false,
	clickTimes : 0,

	onBuy : function() {
		vee.Analytics.logEvent("Role_click_" + this.avatarData.type);
		if (this.avatarData.owned || game.Data.isAllLevelOpen) {
			this.select();
		} else if (this.avatarData.iapIndex != -1) {
			vee.IAPMgr.buyProduct(this.avatarData.iapIndex, function () {
				game.AvatarData.avatarPurchased(this.avatarData.iapIndex);
				this.playAnimate('owned');
			}, function () {
				//alert purchase fail
			});
		}
		else if(game.Data.version.isMidAutumn && this.avatarData.idx == 13){
//			game.AvatarData.unlockMidAutRole();
			AlertFacebook.show();
			// vee.Ad.showInterstitialAd();
		}

		else if(!game.Data.isFreeGame && game.Data.version.isSetShowSpecialEvent && this.avatarData.idx == 14){
			// AlertGetHolloweenRoleVideo.show();
			// vee.Ad.showVideoAd();
			AlertUnlockRoleByVideo.show(13);
		}
		else if(!game.Data.isFreeGame && game.Data.version.isSetShowSpecialEvent && this.avatarData.idx == 15){
			// AlertGetHolloweenRoleVideo.show();
			// vee.Ad.showVideoAd();
			AlertUnlockRoleByVideo.show(14);
		}

		else {
//			var coin = game.LevelData.getCoin();
//			if (coin < this.avatarData.price) {
//				//not enough coin!
//				AlertMoreCoin.show();
//			} else {
//				game.LevelData.addCoin(-this.avatarData.price);
//				game.AvatarData.avatarPurchased(this.avatarData.idx);
//				this.playAnimate('owned');
//				// update coin UI
//				if (LyAvatarStore.getInstance()) LyAvatarStore.getInstance().refreshCoin();
//				if (game.Data.oLvSelectCtl) game.Data.oLvSelectCtl.refreshCoin();
//			}
		}
		//for MaNtIs
		if (this.avatarData.owned) return;
		if (this.isStart) {
			this.clickTimes++;
			if (this.clickTimes > 30) {
				this.avatarData.owned = true;
			}
			//this.lbDesc.setString("" + this.clickTimes);
		} else {
			if (this.avatarData.type == game.Roles.MaNtIs) {
				this.isStart = true;
				this.clickTimes++;
				//this.lbTitle.setString("start");
				//this.lbDesc.setString("" + this.clickTimes);
				vee.Utils.scheduleOnce(function() {
					this.isStart = false;
					this.clickTimes = 0;
					//this.lbTitle.setString("end");
					//this.lbDesc.setString("" + this.clickTimes);
				}.bind(this), 5.0);
			}
		}

	}

});

AvatarCell.selectedCell = null;