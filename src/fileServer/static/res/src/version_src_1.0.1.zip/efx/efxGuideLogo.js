/**
 * Created with AppCode.
 * User: WanThirty
 * Date: 15/9/11
 * Time: 下午10:45
 * To change this template use File | Settings | File Templates.
 */

var EfxGuideLogo = vee.Class.extend({
	_isOver : false,

	show : function () {
		this.playAnimate("start");
	},

	initController : function () {
		vee.Controller.registerGlobalButtonAction(this.onTouch.bind(this));
	},

	onTouch : function () {
		if (this._isOver) return;
		this._isOver = true;
		vee.Transition.out(res.MapTransition_ccbi, function () {
			LyLevelSelect.show();
		});
	}
});