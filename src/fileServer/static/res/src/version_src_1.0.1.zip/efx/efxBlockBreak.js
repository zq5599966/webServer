/**
 * Created with AppCode.
 * User: WanThirty
 * Date: 15/9/4
 * Time: 下午8:20
 * To change this template use File | Settings | File Templates.
 */

var EfxBlockBreak = vee.Class.extend({
	ps1 : null,
	removeFunc : null,

	onCreate : function () {
		this.ps1.setPositionType(1);
	},

	show : function () {
		this.playAnimate("show", function () {
			this.rootNode.setVisible(false);
			EfxBlockBreak.pool.push(this);
		}.bind(this));
	},

	setRemoveFunc : function (func) {
		this.removeFunc = func;
	},

	breakBlock : function () {
		if (this.removeFunc) this.removeFunc();
	}
});

EfxBlockBreak.show = function (pos, removeFunc) {
	var efxCtl = EfxBlockBreak.pool.pop();
	if (!efxCtl) {
		var node = cc.BuilderReader.load(res.efx_blockBreak_ccbi);
		game.Data.oLyGame.lyMap.addChild(node, 8);
		efxCtl = node.controller;
	}
	efxCtl.rootNode.setVisible(true);
	efxCtl.rootNode.setPosition(pos);
	efxCtl.setRemoveFunc(removeFunc);
	efxCtl.show();
};

EfxBlockBreak.pool = null;