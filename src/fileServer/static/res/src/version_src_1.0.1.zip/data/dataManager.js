/**
 * Created with AppCode.
 * User: ZQ
 * Date: 16/7/11
 * Time: 下午5:05
 * 游戏本地存储数据管理类.
 */

vee.dataManager = {

	setData : function(key, value){
		vee.data[key] = value;
		vee.saveData();
	},

	getData : function(key){
		return vee.data[key];
	},

	/*Deprecated
	veewocheck          //初始化时设置ok,游戏内未发现使用位置
	isRequestNewPlayer  //纯净版用，发送新用户统计，add by zq
	*/



	/* using
	 power              //能量瓶可玩次数
	 power_ts           //能量瓶计时

	 tag_61             //61关卡标记
	 level61_ts         //61关卡计时

	 leavets

	 energy             //可玩次数
	 energy_ts          //可玩次数补充计时

	 ultE_ts
	 ultEitv

	 skipSign+xxxx      //过场动画标识

	 btnpos1            //移动按钮pos坐标   //按钮只看到获取的地方没看到写入的地方
	 btnpos2            //技能按钮pos坐标
	 btnpos3            //跳跃按钮pos坐标

	 stad


	 savePointIdx       //复活点地图标记

	 tpcoin             //关卡内获取金币数量，进入关卡时清0

	 selectedLvIdx      //选中大关卡id，从1开始

	 */

	/**
	 * 能量瓶数量
	 * @returns {*}
	 */
	getPower : function(){
		return this.getData("power");
	},

	setPower : function(value){
		this.setData("power", value);
	},

	getPowerTs : function(){
		return this.getData("power_ts");
	},

	setPowerTs : function(value){
		this.setData("power_ts", value);
	},


	/**
	 * 可玩次数
	 * @returns {*}
	 */
	getEnergy : function(){
		return this.getData("energy");
	},

	setEnergy : function(value){
		this.setData("energy", value);
	},

	getEnergyTs : function(){
		return this.getData("energy_ts");
	},

	setEnergyTs : function(value){
		this.setData("energy_ts", value);
	},


	/**
	 * 复活点地图标记
	 * @returns {*}
	 */
	getSavePointIdx : function(){
		return this.getData("savePointIdx");
	},

	setSavePointIdx : function(value){
		this.setData("savePointIdx", value);
	},


	/**
	 * 关卡内获取金币数量
	 */
	getTpCoin : function(){
		return this.getData("tpcoin");
	},

	setTpCoin : function(value){
		this.setData("tpcoin", value);
	},


	/**
	 * 选中关卡id，从1开始
	 */
	getSelectLvIdx : function(){
		var selectLvIdx = this.getData("selectedLvIdx");
		return parseInt((selectLvIdx ? selectLvIdx : 1));
	},

	setSelectLvIdx : function(value){
		this.setData("selectedLvIdx", value);
	},



	getIsFirstClickCategory9 : function () {
		return this.getData("isFirstClickThanksgivingCategory");
	},

	setIsFirstClickCategory9 : function (isFirst) {
		this.setData("isFirstClickThanksgivingCategory", "false");
	},

	isUnlockParkourLevel : function (levelId) {
		return this.getData("parkourLevelUnlock_" + levelId);
	},

	unlockParkourLevel : function (levelId) {
		this.setData("parkourLevelUnlock_" + levelId, "true");
	},

	isOldPlayerInParkour : function () {
		return this.getData("isOldPlayerInParkour");
	},

	setOldplayerInParkour : function (value) {
		this.setData("isOldPlayerInParkour", value);
	},

	isAllParkourLevelUnlock : function () {
		return this.getData("allParkourLevelUnlock");
	},

	setAllParkourLevelUnlock : function () {
		this.setData("allParkourLevelUnlock", "true");
	},


	/*************************************
	 * 累计登录 start
	 *************************************/
	getPreloginTime : function () {
		// var time = parseInt(this.getData("loginTime"));
		// return time;
		return this.getData("loginTime");
	},
	
	checkHasContinuousLogin : function () {
		var preTime = this.getPreloginTime();
		if(preTime){
			var curTime = new Date();
			var preArry = preTime.split("|");
			var curDate = new Date(curTime.getFullYear(), curTime.getMonth(), curTime.getDate());
			var preDate = new Date(preArry[0], preArry[1], preArry[2]);
			var dateIndex = (curDate - preDate) / 86400000;
			if(dateIndex > 1){
				vee.Analytics.UGameEvent.registerSuperProperty("super_countionDay", dateIndex * -1);
			}

			cc.log("date index ======" + dateIndex);

			if(dateIndex == 1){
				// this.setContinuousLoginDays(1);

				if(this.getContinuousLoginDays() == 0){
					cc.log("zq debug getContinuousLoginDays 1111");
					this.setIsSuccessContinuousLogin("true");
				}

				this.setContinuousLoginDays(this.getContinuousLoginDays() + 1);

				vee.Analytics.UGameEvent.registerSuperProperty("super_countionDay", this.getContinuousLoginDays());
				return true;
			}
			else if(dateIndex > 1){

				var tmpIndex = this.getContinuousLoginDays() - dateIndex + 1;

				if(this.getContinuousLoginDays() > 4){
					tmpIndex = 4 - dateIndex + 1;
				}

				var tmpDate = tmpIndex > 0 ? tmpIndex : 0;
				cc.log("zq debug getContinuousLoginDays 22222 ====" + tmpDate);
				this.setIsSuccessContinuousLogin(tmpDate == 0 ? "true" : "false");

				this.setContinuousLoginDays(tmpDate);


				return tmpDate > 0 ? true : false;
			}
		}
		return false;
	},
	
	setLoginTime : function () {
		var curTime = new Date();
		this.setData("loginTime", "" + curTime.getFullYear() + "|" + curTime.getMonth() + "|" + curTime.getDate());
	},

	getContinuousLoginDays : function () {
		var days = parseInt(this.getData("continuousDays"));
		return days ? days : 0;
	},

	setContinuousLoginDays : function (days) {
		// if(days == 1 && this.getContinuousLoginDays()){
		// 	days = this.getContinuousLoginDays() + 1;
		// }

		if(days == 3){
			cc.log("push no ad notiction");
		}

		// var tmp = days > 4 ? 4 : days;
		// cc.log("setContinuousLoginDays days=====" + tmp);
		this.setData("continuousDays", "" + days);
	},

	isSuccessContinuousLogin : function () {
		var isSuccess = this.getData("isSuccessContinuousLogin");
		return isSuccess == "true";
	},
	
	setIsSuccessContinuousLogin : function (isSuccess) {
		this.setData("isSuccessContinuousLogin", "" + isSuccess);
	},
	/*************************************
	 * 累计登录 end
	 *************************************/


	/**
	 *新版本评价弹窗
	 */
	isNewVersionRate : function () {

		if(this.getData("version_code_rate_" + game.Data.version.codeVersion) != "false"){
			return true;
		}
		return false;
	},

	setVersionRateFalse : function () {
		this.setData("version_code_rate_" + game.Data.version.codeVersion, "false");
	},
	/**
	 *新版本评价弹窗 end
	 */



	/***************************************
	 * 版本更新
	 ***************************************/
	setResVersionCode : function () {
		
	}

	/***************************************
	 * 版本更新 end
	 ***************************************/
}
