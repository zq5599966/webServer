/**
 * Created by john on 2016/12/1.
 */

var ccbAlertUnlockLevel = vee.Class.extend({

    btnBuy : null,
    btnWatch : null,
    lbWatch : null,

    levelId : null,
    videoCallback : null,
    closeCallback : null,
    //
    // emptyType : 0,
    //
    labPrice : null,


    // onCreate : function () {
    //
    //
    //
    //     /*
    //     if (!vee.Ad.checkCacheVideoAd() || parseInt(vee.dataManager.getEnergy()) == 5) {
    //         this.btnWatch.setEnabled(false);
    //     }
    //     if (game.Data.isWeiXin) {
    //         this.btnWatch.setEnabled(true);
    //         this.btnWatch.setBackgroundSpriteForState(new cc.Scale9Sprite(res.btn_power_2_watch_weixin_png), cc.CONTROL_STATE_NORMAL);
    //         this.lbWatch.setString("购买获得一点生命");
    //     }
    //     this.playAnimate("show");
    //     this.handleKey(true);
    //     vee.Controller.cacheControllerState(this);
    //
    //     vee.IAPMgr.setPriceLabByServer(vee.IAPMgr.goodsKey.POWER, this.labPrice);
    //     */
    // },
    
    init : function (levelId, videoCallback, closeCallback) {
        // this.btnWatch.setEnabled(vee.Ad.checkCacheVideoAd());
        this.levelId = levelId;
        this.videoCallback = videoCallback;
        this.closeCallback = closeCallback;

        this.handleKey(true);
        this.playAnimate("show", this.initController.bind(this));


        vee.Controller.cacheControllerState(this);

        vee.IAPMgr.setPriceLabByServer(vee.IAPMgr.goodsKey.UNLOCK_PARKOUR_LEVELS, this.labPrice);

        this.btnWatch.setEnabled(vee.Ad.checkCacheVideoAd());
    },

    onKeyBack : function(){
        this.onClose();
        return true;
    },

    initController : function () {
        vee.Controller.initSelector(2,1,this.onClose.bind(this),cc.p(0,0));
        vee.Controller.registerItemByButton(this.btnWatch, cc.p(0,0), this.onWatch.bind(this), "res/mfi_btn_on_170.png");
        vee.Controller.registerItemByButton(this.btnBuy, cc.p(1,0), this.onBuy.bind(this), "res/mfi_btn_on_170.png");
        vee.Controller.activeSelector();
    },


    onBuy : function () {

        cc.log("zq debug buy parkour all levels");

        vee.IAPMgr.buyProduct(4, function () {
           this.onClose(true);
            vee.dataManager.setAllParkourLevelUnlock();
            if(this.videoCallback){
                this.videoCallback();
            }
        }.bind(this));

        /*
        vee.IAPMgr.buyProduct(2, function () {
            this.onClose();
            vee.dataManager.setPower(vee.dataManager.getPower() + 3);
            if (game.Data.oEnergyCtl) game.Data.oEnergyCtl.showEnergy();
            vee.Analytics.logChargeSuccess(game.Data.orderId);
            AlertUsePower.show(this.emptyType);
        }.bind(this), function () {
        }.bind(this));
        game.Data.orderId = new Date().getTime();
        vee.Analytics.logChargeRequest(game.Data.orderId, 2, 0.99);
        */
    },

    onWatch : function() {

        if (!this.btnWatch.isEnabled()) return;

        vee.Ad.showVideoAd(function(){
            this.onClose(true);

            vee.dataManager.unlockParkourLevel(this.levelId);
            if(this.videoCallback){
                this.videoCallback();
            }

            vee.Analytics.UGameEvent.showAdEvent("alert", "video", "unlockParkourLv_" + this.levelId);
        }.bind(this), "unlockParkourLv");


        // vee.dataManager.unlockParkourLevel(this.levelId);
        // this.videoCallback();


        /*
        var successCallback = function (pPlugin, num, itemID) {
            vee.PopMgr.closeLayerByCtl(this);
            game.Data.addEnergy(1);
            if (game.Data.oEnergyCtl) game.Data.oEnergyCtl.showEnergy();
            vee.Utils.scheduleOnce(function () {
                vee.PopMgr.alert(
                    vee.Utils.getLocalizedStringForKey("You`ve got an energy!"),
                    vee.Utils.getLocalizedStringForKey("CONGRATULATION")
                );
            }, 0.2);
        }.bind(this);

        if (game.Data.isWeiXin) {
            vee.IAPMgr.buyProduct(3, successCallback);
        } else {
            vee.Ad.showVideoAd(successCallback);
        }
        */
    },

    btnClose : null,
    _isOver : false,
    onClose : function (isClick) {
        if (this._isOver) return;
        this._isOver = true;
        vee.Controller.deactiveSelector();
        vee.Controller.reviveControllerStateByCtl(this);

        this.playAnimate("hide", function () {
            vee.PopMgr.closeLayerByCtl(this);
            if(isClick != true && this.closeCallback){
                this.closeCallback();
            }
        }.bind(this));
    }
});

ccbAlertUnlockLevel.show = function (levelId, videoCallback, closeCallback) {
    var unlockPop = vee.PopMgr.popCCB(res.ccbAlertUnlockLevel_ccbi, {alpha : 0});
    unlockPop.controller.init(levelId, videoCallback, closeCallback);
    // unlockPop.controller.setEmptyType(emptyType);
};