/**
 * Created by john on 2016/12/23.
 * ccb = ccbUI/dailyMission.ccb
 */

var ccbContinuousLoginAlert = vee.Class.extend({

    contiunsDays : 0,

    ccbSignNode_1 : null,
    ccbSignNode_2 : null,
    ccbSignNode_3 : null,
    ccbSignNode_4 : null,

    ccbParticleCoin : null,

    init : function (contiunsDays) {

        this._tempControllerState = vee.Controller.cacheControllerState();

        if(game.Data.zqdebug || contiunsDays < 4 && vee.dataManager.isSuccessContinuousLogin()){
            game.LevelData.addCoin(contiunsDays * 50);
            this.ccbParticleCoin.setVisible(true);
            this.ccbParticleCoin.setEmissionRate(100 * contiunsDays);
            this.playAnimate("show_coin", function () {
                game.Data.oLvSelectCtl.refreshCoin();
                this.initController();
            }.bind(this));
        }
        else{
            this.ccbParticleCoin.setVisible(false);
            this.playAnimate("show", function () {
                this.initController();
            }.bind(this));
        }

        cc.log("zq debug ccbContinuousLoginAlert =====%d", contiunsDays);
        for (var i = 0; i < 4; i++){

            if(i == contiunsDays - 1){
                if(i == 3){
                    this["ccbSignNode_" + (i+1)].animationManager.setCompletedAnimationCallback(this, function () {
                        this.playAnimate("get");
                    }.bind(this));
                }
                this["ccbSignNode_" + (i+1)].animationManager.runAnimationsForSequenceNamedTweenDuration("show", 0, false);
            }
            else if(i < contiunsDays){
                this["ccbSignNode_" + (i+1)].animationManager.runAnimationsForSequenceNamedTweenDuration("on", 0, false);
            }
            else{
                this["ccbSignNode_" + (i+1)].animationManager.runAnimationsForSequenceNamedTweenDuration("normal", 0, false);
            }
        }
    },
    
    initController : function () {
        vee.Controller.clearAllButtonAction();

        vee.Controller.registerButtonAction(
            vee.KeyCode.BUTTON_B,
            this.onClose.bind(this)
        );
        vee.Controller.activeButton();
    },
    
    onClose : function () {
        if (this._isOver) return;
        this._isOver = true;

        // vee.Controller.deactiveSelector();
        // vee.Controller.reviveControllerStateByCtl(this);
        vee.Controller.reviveControllerState(this._tempControllerState);

        this.playAnimate("hide", function () {
            vee.PopMgr.closeLayerByCtl(this);
        }.bind(this));
    }
});


ccbContinuousLoginAlert.show = function (contiunsDays) {
    var pop = vee.PopMgr.popCCB(res.dailyMission_ccbi, {alpha : 0});
    pop.controller.init(contiunsDays);
};