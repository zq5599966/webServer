/**
 * Created with AppCode.
 * User: yop
 * Date: 15/10/27
 * Time: 下午7:01
 * To change this template use File | Settings | File Templates.
 */


LevelController.Level236 = LevelController.extend({
	eventStory1 : function(grid, dir) {
		this.showStory(1, grid, ""+
		"SelectNpc,Flash;"+
		"FaceTo,left;"+
		"MoveCamera,48,20,2;"+
		"ShowDialog,"+ vee.Utils.getLocalizedStringForKey("Well...", "哦……") +";"+
		"ShowDialog,"+ vee.Utils.getLocalizedStringForKey("Look, there's a new kind of sprite.", "看，那里有个新种类的精灵。") +";"+
		"HideDialog;"+
		"MoveCamera,43,17,2;"+
		"Delay,1;"+
		"MoveCamera,48,20,2;"+
		"ShowDialog,"+ vee.Utils.getLocalizedStringForKey("Try it, you might find something interesting!", "试试看，会很有趣的哦！") +";"+
		"HideDialog;"+
		"MoveRole,59,20;"+
		"ResetRole,86,23"+
		"");
	},

	skip1 : function() {
		cc.log("skip 1 called!");
		this.skipStory(2);
		this.skipStory(3);
	},

	eventStory2 : function(grid, dir) {
		this.showStory(2, grid, ""+
		"SelectNpc,Flash;"+
		"FaceTo,left;"+
		"MoveCamera,83,23,1.5;"+
		"ShowDialog,"+ vee.Utils.getLocalizedStringForKey("Okay, I'm trapped!", "好吧，我居然被困住了……") +";"+
		"ShowDialog,"+ vee.Utils.getLocalizedStringForKey("I need your help!", "帮我一把！") +";"+
		"HideDialog;"+
		"MoveCamera,90,12,2;"+
		"Delay,1;"+
		"MoveCamera,83,23,2;"+
		"ShowDialog,"+ vee.Utils.getLocalizedStringForKey("Use your new power!", "使用你的新能力！") +";"+
		"HideDialog"+
		"");
	},

	skip2 : function() {
		cc.log("skip 2 called!");
		this.skipStory(3);
		this.blockStory(3,true);
	},

	eventStory3 : function(grid, dir) {
		this.showStory(3, grid, ""+
		"SelectNpc,Flash;"+
		"FaceTo,left;"+
		"MoveCamera,85,24,2;"+
		"ShowDialog,"+ vee.Utils.getLocalizedStringForKey("Well done!", "干的不错！") +";"+
		"ShowDialog,"+ vee.Utils.getLocalizedStringForKey("Use your new power wisely!", "要活用你的新能力哦！") +";"+
		"HideDialog;"+
		"MoveRole,87,23;"+
		"Jump,89,26;"+
		"MoveRole,93,26;"+
		"RemoveRole"+
		"");
	},

	skip3 : function() {
		cc.log("skip 3 called!");
	}	
});
