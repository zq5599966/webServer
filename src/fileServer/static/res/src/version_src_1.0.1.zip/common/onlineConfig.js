/**
 * Created with AppCode.
 * User: WanThirty
 * Date: 15/6/3
 * Time: 下午2:56
 * To change this template use File | Settings | File Templates.
 */

var vee = vee = vee || {};

vee.OnlineConfig = {
	pOnlineConfigPlugin : null,
	activate : function (onlineConfigPlugin) {
		this.pOnlineConfigPlugin = onlineConfigPlugin;
	},
	getConfigParam : function (keyString, defaultValue) {
		defaultValue = defaultValue ? defaultValue : 0;
		if (this.pOnlineConfigPlugin) {
			var ret = this.pOnlineConfigPlugin.callStringFuncWithParam("getOnlineConfig",  new plugin.PluginParam(plugin.PluginParam.ParamType.TypeStringMap, {
				"key": keyString
			}));

			return ret == null ? defaultValue : ret;
		} else {
			cc.log("Plugin online config not found!");
			return defaultValue;
		}
	}
};