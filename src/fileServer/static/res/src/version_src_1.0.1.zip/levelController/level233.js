/**
 * Created with AppCode.
 * User: WanThirty
 * Date: 15/11/18
 * Time: 下午6:21
 * To change this template use File | Settings | File Templates.
 */
LevelController.Level233 = LevelController.extend({

	complete : function () {
		if (game.Data.playerLife == game.Data.playerMaxLife) {
			vee.GameCenter.unlockAchievement(7);
		}
	}
});