/**
 * Created with AppCode.
 * User: WanThirty
 * Date: 15/5/19
 * Time: 上午11:16
 * To change this template use File | Settings | File Templates.
 */

var Item = vee.Class.extend({
	nodeBox : null,
	boxOffset : null,
	boxSize : null,

	_eleType : game.EleType.Item,
	_objType : game.ObjectType.None,
	_container : null,
	_grid : null,
	_gridInMap : null,

	_layerBelong : 1,
	_speedX : 0,
	_speedY : 0,
	_accX : 0,
	_accY : 0,
	_speedXLimit : 500,
	_speedYLimit : -1300,
	_faceTo : vee.Direction.Right,
	_moveDir : vee.Direction.Origin,
	_decayX : 2200,
	_eleSize : null,
	_checkForDieW : 17,

	_type : null,

	onCreate : function() {
		this.resetBoxInfo();
		this.afterCreate();
		this.AILogic();
	},

	resetBoxInfo : function () {
		if (this.nodeBox) {
			this.boxOffset = this.nodeBox.getPosition();
			this.boxSize = this.nodeBox.getContentSize();
		} else {
			this.boxOffset = cc.p(0, 0);
			this.boxSize = cc.size(game.Data.tileSizeWidth, game.Data.tileSizeWidth);
		}
	},

	afterCreate : function () {

	},

	initPosition : function(pos) {
		this._isOver = false;
		this._eleSize = this.rootNode.getContentSize();
		this.setElePosition(pos);
		this.bornWithPos(pos);
	},

	getElePosition : function() {
		return this._container.getPosition();
	},

	setGridInMap : function (grid) {
		this._gridInMap = grid;
	},

	_pos : null,
	setElePosition : function(pos) {
		if (this._isOver) return;
		this._container.setPosition(pos);
		this._grid = game.Logic.getTileGridByPos(pos);
		this._pos = cc.p(pos.x, pos.y);
	},

	setContainerNode : function(node) {
		this._container = node;
	},

	setFaceTo : function(dir,force) {
		if (this._faceTo == dir && !force) return;
		dir = dir ? dir : vee.Direction.Left;
		this._faceTo = dir;
		if (dir == vee.Direction.Left) {
			this.rootNode.setScaleX(-1);
		} else {
			this.rootNode.setScaleX(1);
		}
	},

	jump : function() {
		if (!this._isJumping) {
			this._speedY = 12;
			this.setJumping(true);
		}
	},

	setJumping : function(isJumping) {
		this._isJumping = isJumping;
	},

	getEleRect : function() {
		var pos = this.getElePosition();
		var rect = cc.rect(
			pos.x + this.boxOffset.x - this.boxSize.width/2,
			pos.y + this.boxOffset.y - this.boxSize.height/2,
			this.boxSize.width,
			this.boxSize.height
		);
		return rect;
	},

	moveLeft : function() {
		this._faceTo = vee.Direction.Left;
		this._accX = -game.Data.playerXacc;
	},

	moveRight: function() {
		this._faceTo = vee.Direction.Right;
		this._accX = game.Data.playerXacc;
	},

	stopMove : function() {
		this._accX = 0;
	},

	leftToBarrier : function() {

	},

	rightToBarrier : function() {

	},

	upToBarrier : function() {
		this._speedY = 0;
		this._accY = 0;
	},

	downToBarrier : function() {
		this._speedY = 0;
		this._accY = 0;
	},

	disappear : function() {
		if (this._gridInMap) {
			game.Logic.objMap.setObject(null, this._gridInMap);
		}
		this._container.removeFromParent();
	},

	die : function () {
		this.onDead();
		this.inhaleController = null;
		this._isOver = true;
		if (this._gridInMap) {
			if (!this._staticItem) {
				game.Logic.dynamicObjMap.setObject(null, this._gridInMap);
			} else {
				game.Logic.objMap.setObject(null, this._gridInMap);
				game.Logic.removeMapExObjectByGrid(this._gridInMap);
			}
		}
		this._container.removeFromParent();
	},

	onDead : function () {

	},

	onGridChanged : function() {
		if (!this._grid || !this._lastGrid) return;
	},

	_isOver : false,
	_staticItem : true,
	_haveDecay : true,
	updatePos : function(timeDelta) {
		if (this._isOver) return;
		this.AILogicPerFrame(timeDelta);
		if (!this._staticItem) {
			// calc speed X...
			this.calcX(timeDelta);
			var dirX = game.Logic.getMoveDirectionBySpeedX(this._speedX);
			this._moveDir = dirX;

			// calc speed Y...
			this.calcY(timeDelta);

			// calc safe postion...
			this.refreshPosition(timeDelta);
		}

		this.checkCollide();

		if (this._speedY != 0) {
			this.setJumping(true);
		}

		this.calcDecay(timeDelta);

		this.afterUpdatePos();
	},

	calcX : function (timeDelta) {
		this._speedX += this._accX*timeDelta;
		if (Math.abs(this._speedX) > this._speedXLimit) {
			var dir = this._speedX > 0 ? 1 : -1;
			this._speedX = this._speedXLimit*dir;
		}
	},

	_hasG : true,
	calcY : function (timeDelta) {
		this._speedY += this._accY*timeDelta;
		if (this._hasG) this._speedY += game.Data.G*timeDelta;
		if (this._speedY < this._speedYLimit) this._speedY = this._speedYLimit;
	},

	_safePos : null,
	refreshPosition : function (timeDelta) {
		var castPos = cc.p(this.getElePosition().x + this._speedX*timeDelta, this.getElePosition().y + this._speedY*timeDelta);
		var lastGrid = game.Logic.getTileGridByPos(this.getElePosition());
		if (!this._lastGrid || lastGrid.x != this._lastGrid.x || lastGrid.y != this._lastGrid.y) {
			this.onGridChanged();
			this._lastGrid = lastGrid;
		}
		this.setElePosition(game.Logic.safePos(castPos, this));
	},

	_hasCollide : true,
	checkCollide : function () {
		if (!this._hasCollide || !game.Data.oPlayerCtl) return;
		var rectEnemy = this.getEleRect();
		var rectPlayer = game.Data.oPlayerCtl.getEleRect();
		if (cc.rectIntersectsRect(rectEnemy, rectPlayer)) {
			if (rectEnemy.y < rectPlayer.y) {
				var offset = vee.Utils.pSub(this.getElePosition(), game.Data.oPlayerCtl.getElePosition());
				var unslope = offset.x/offset.y;
				if (unslope > -1.4 && unslope < 1.4) {
					this.collide(vee.Direction.Top);
				} else {
					if (rectPlayer.x + game.Data.tileSizeWidth/2 > this.getElePosition().x) {
						this.collide(vee.Direction.Right);
					} else {
						this.collide(vee.Direction.Left);
					}
				}
			} else {
				this.collide(vee.Direction.Bottom);
			}
		}
	},

	calcDecay : function (timeDelta) {
		if (!this._staticItem && this._haveDecay) {
			if (this._speedY != 0) {
				this.setJumping(true);
			}

			// Calc decay...
			if (this._accX > 0 && this._speedX < 0) {
				this._speedX += this._decayX*timeDelta;
			} else if (this._accX < 0 && this._speedX > 0) {
				this._speedX -= this._decayX*timeDelta;
			} else if (this._accX == 0 && this._speedX != 0) {
				if (this._speedX > 0) {
					this._speedX -= this._decayX*timeDelta;
					if (this._speedX <= 0) this._speedX = 0;
				} else if (this._speedX <= 0) {
					this._speedX += this._decayX*timeDelta;
					if (this._speedX >= 0) this._speedX = 0;
				}
			}
		}
	},

	isDashing : function () {
		return false;
	},

	inhaleController : null,
	getInhaleController : function () {
		if (this.inhaleController) {
			return null;
		}
		this.inhaleController = new InhaleObj();
		this.inhaleController.obj = this;
		return this.inhaleController;
	},
	getAte : function () {
		this.die();
	},

	setDynamic : function(speedX, speedY) {
		if (speedX == undefined) speedX = 300;
		if (speedY == undefined) speedY = 0;
		this._staticItem = false;
		this._haveDecay = false;
		this._speedX = speedX;
		this._speedY = speedY;
		this._tempSpeedY = speedY;
		game.Logic.dynamicObjMap.setObject(this, this._grid);
	},

	hitByStar : null,

	// For overwrite
	bornWithPos : function(pos) {},
	AILogic : function() {},
	AILogicPerFrame : function() {},
	collide : function(dir) {},
	afterUpdatePos : function() {},
	removeOnGridChange : function() {}
});



/*--  Item create function  --*/
Item.createWithInfo = function(info, grid, layer) {
	var ccbName = null;
//	vee.Utils.logObj(grid, "zq debug item create");
	switch (info.type) {
		case game.ObjectType.Coin:
			if (game.Data.checkIs61()) {
				ccbName = res.itemCoinChild_ccbi;
			} else {
				ccbName = res.itemCoin_ccbi;
			}
			break;
		case game.ObjectType.BigCoin:
			if (game.Data.checkIs61()) {
				ccbName = res.itemBigCoinChild_ccbi;
			} else {
				ccbName = res.itemBigCoin_ccbi;
			}
			break;
		case game.ObjectType.Egg:
			ccbName = res.itemEgg_ccbi;
			break;
		case game.ObjectType.Heart:
			ccbName = res.itemHeart_ccbi;
			break;
		case game.ObjectType.DynamicBlock:
			ccbName = res.itemDynamicBlock_ccbi;
			break;
		case game.ObjectType.MovingPlatform:
			ccbName = res.itemMovingPlatform_ccbi;
			break;
		case game.ObjectType.GravityPlatform:
			ccbName = res.itemGravityPlarform_ccbi;
			break;
		case game.ObjectType.FallingBlock:
			ccbName = res.itemFallingBlock_ccbi;
			break;
		case game.ObjectType.Fire:
			ccbName = res.itemFire_ccbi;
			break;
		case game.ObjectType.BoxSmash:
			if (game.Data.playerType != game.PlayerType.Smash) {
				ccbName = res.itemEgg2_ccbi;
			} else {
				ccbName = null;
				return false;
			}
			break;
		case game.ObjectType.BoxBullet:
			if (game.Data.playerType != game.PlayerType.Bullet) {
				ccbName = res.itemEgg2_ccbi;
			} else {
				ccbName = null;
				return false;
			}
			break;
		case game.ObjectType.BoxTeleport:
			if (game.Data.playerType != game.PlayerType.Teleport) {
				ccbName = res.itemEgg2_ccbi;
			} else {
				ccbName = null;
				return false;
			}
			break;
		case game.ObjectType.BoxBomb:
			if (game.Data.playerType != game.PlayerType.Bomb) {
				ccbName = res.itemEgg2_ccbi;
			} else {
				ccbName = null;
				return false;
			}
			break;
		case game.ObjectType.BoxHawk:
			if (game.Data.playerType != game.PlayerType.Hawk) {
				ccbName = res.itemEgg2_ccbi;
			} else {
				ccbName = null;
				return false;
			}
			break;
		case game.ObjectType.Drawer:
			ccbName = res.itemDrawer_ccbi;
			break;
		case game.ObjectType.ReverseKey: {
			var category = game.LevelData.selectedCategory;
			var level = game.LevelData.selectedLevel;

			if(game.Data.version.newVersion){
				var isUnlockReverseWorld = vee.data["moon"];
			}
			else{
				var isUnlockReverseWorld = game.Data.isShowBtnWorld();
			}

			var isCategoryAllUnlock;
			if(game.Data.version.newVersion){
				isCategoryAllUnlock = category && category.levels[0].isLevelPassed;
			}
			else{
				isCategoryAllUnlock = category && category.levels[category.levels.length - 1].isLevelPassed;
			}

			cc.log("fuck reverseworld open-----111-----");

			var isKeyCollected = level && level.isLevelReverseKeyCollected();

			vee.Utils.logObj(isCategoryAllUnlock, "category all unlock");
			vee.Utils.logObj(isKeyCollected, "isKeyCollected all unlock");
			vee.Utils.logObj(game.Data.isReverseWorldOpen, "game.Data.isReverseWorldOpen");
			vee.Utils.logObj(isUnlockReverseWorld, "isUnlockReverseWorld");

			// test code
			if (game.Data.isReverseWorldOpen && isCategoryAllUnlock && !isKeyCollected && isUnlockReverseWorld) {
//				if (game.Data.isAndroid && game.Data.isFreeGame) {
				if ((game.Data.isAndroid || game.Data.version.isNewIosVersion) && game.Data.isFreeGame) {
					if (vee.data["moon"]) {
						ccbName = res.itemReverseKey_ccbi;
					}
				} else {
					ccbName = res.itemReverseKey_ccbi;
				}
			} else if (game.Data.isReverseWorldOpen && !isKeyCollected && grid) {
				vee.Utils.logObj(grid, "key grid");
				var tileData = game.Logic.getTileDataByGid(1, grid, layer);
				game.Logic.map.setObject(tileData, grid);
			} else {
				return false;
			}
		}
			break;
		case game.ObjectType.SavePoint:
			ccbName = res.savePoint_ccbi;
			break;
		case game.ObjectType.StageEnd:
			ccbName = res.efx_GamePiont_ccbi;
			break;

		case game.ObjectType.ScaleBlock:
			ccbName = res.itemScaleBlock_ccbi;
			break;

		default :
			break;
	}
	if (ccbName) {
		if (info.type == game.ObjectType.Coin && game.Data.itemCoinPool.length > 0) {
			var nodeCtl = game.Data.itemCoinPool.shift();
			nodeCtl._container.setVisible(true);
			return {container : nodeCtl._container, controller : nodeCtl};
		} else {
			var node = null;
			node = cc.BuilderReader.load(ccbName);
			var container = cc.Node.create();
			container.addChild(node);
			node.controller.setContainerNode(container);
			node.controller._objType = info.type;
			if (node.controller.inMapBack) {
				game.Data.oLyGame.lyMapBack.addChild(container);
			} else {
				game.Data.oLyGame.lyMap.addChild(container);
			}
			return {container : container, controller : node.controller};
		}
	} else {
//		cc.log("Create item failed, wrong item type : "+type);
		return null;
	}
};

Item.createDynamicCoin = function(pos, speedX, speedY) {
	var node = Item.createWithType(game.ObjectType.Coin);
	node.controller.initPosition(pos);
	node.controller.setDynamic(speedX, speedY);
	node.controller._hasG = true;
	return {container : node.container, controller : node.controller};
};
/*--  Item create function  --*/



/*  Items...  */
var ItemCoin = Item.extend({
	_type       : game.ObjectType.Coin,
	_tempSpeedY : 600,
	spCoin      : null,
	/** @type {cc.Sprite} */
	spParticle  : null,

	afterCreate : function () {
		//this.psLight.setPositionType(1);
		this.spParticle.getTexture().setAliasTexParameters();
		ItemCoin.pool.push(this);
//		var animation = null;
//		if (ItemCoin.originCoin) {
//			this.animate = ItemCoin.originCoin.controller.animate.clone();
//			this.rootNode.runAction(this.animate);
//		} else {
//			animation = new cc.Animation();
//			for (var i = 1; i < 8; ++i) {
//				var spFrame = cc.spriteFrameCache.getSpriteFrame("Coin_small_00"+i+".png");
//				animation.addSpriteFrame(spFrame);
//			}
//			animation.setDelayPerUnit(4/60);
//			animation.setRestoreOriginalFrame(false);
//			animation.setLoops(9999);
//			this.animate = cc.animate(animation);
//			this.rootNode.runAction(this.animate);
//		}
//		this.spParticle.getTexture().setAliasTexParameters();
	},

	//called by ccb timeline "Show"
	onShow : function() {
		this.spParticle.setRotation(10*vee.Utils.randomInt(0,36));
	},

	bornWithPos : function (pos) {
		this.refreshCoinFrame();
	},

	refreshCoinFrame : function () {
		if (game.Data.checkIs61()) return;
		if (ItemCoin.coinFrameName) {
			this.spCoin.setSpriteFrame(ItemCoin.coinFrameName);
		}
	},

	AILogic : function() {

	},

	leftToBarrier : function() {
		this._speedX = 300;
	},

	rightToBarrier : function() {
		this._speedX = -300;
	},

	downToBarrier : function() {
		if (this._tempSpeedY > 100) {
			this._tempSpeedY = this._tempSpeedY/1.4;
			this._speedY = this._tempSpeedY;
		} else {
			this._haveDecay = true;
		}
	},

	onDead : function () {
		this.stopUpdate();
		game.Logic.showGetCoinEfx(this.getElePosition());
		game.Data.addTempCoin();
		if (this._gridInMap) {
			var trigger = game.Logic.triggerMap.getObject(this._grid);
			if (trigger) {
				trigger.func(this._grid);
			}
		}
	},

	setSequenceCoin : function () {
		vee.Utils.scheduleCallbackForTarget(this.nodeBox, this.checkCollide.bind(this), 0.1);
	},

	stopUpdate : function () {
		vee.Utils.unscheduleAllCallbacksForTarget(this.nodeBox);
	},

	collide : function(dir) {
		var nowTs = new Date().getTime();
		if (ItemCoin.lastGetTs) {
			if (nowTs - ItemCoin.lastGetTs < ItemCoin.soundLvUpTs) {
				if (ItemCoin.coinSoundIdx < 8) ++ItemCoin.coinSoundIdx;
			} else {
				ItemCoin.coinSoundIdx = 1;
			}
		} else {
			ItemCoin.coinSoundIdx = 1;
		}
		vee.Audio.playEffect("res/inGame_pick_coin_"+ItemCoin.coinSoundIdx+".mp3");
		ItemCoin.lastGetTs = nowTs;
		EfxApplause.Analysis.onGetCoin();
		this.die();
	}
});

ItemCoin.soundLvUpTs = 300;
ItemCoin.lastGetTs = null;
ItemCoin.coinSoundIdx = 0;
ItemCoin.coinFrameName = null;
ItemCoin.pool = [];
ItemCoin.refreshAllCoin = function () {
	var len = ItemCoin.pool.length;
	var coin = null;
	for (var i = 0; i < len; ++i) {
		coin = ItemCoin.pool[i];
		if (coin) {
			coin.refreshCoinFrame();
		}
	}
};

var ItemBigCoin = Item.extend({
	_type : game.ObjectType.BigCoin,
	_tempSpeedY : 600,

	initPosition : function(pos) {
		var trigger = game.Logic.triggerMap.getObject(this._gridInMap);
		if (trigger) {
			if (trigger.type == "BigCoin") {
				if (game.LevelData.selectedLevel && game.LevelData.selectedLevel.isTempStarAchieved(parseInt(trigger.name))) {
					// star has archived
					this.die();
					return;
				}
			}
		}

		pos = vee.Utils.pAdd(pos, cc.p(game.Data.tileSizeWidth/2, game.Data.tileSizeWidth/2));
		this._eleSize = this.rootNode.getContentSize();
		this.setElePosition(pos);
		this.bornWithPos(pos);
	},

	bornWithPos : function(pos) {
		vee.Utils.scheduleCallbackForTarget(this.rootNode, this.updatePos.bind(this));
	},

	onExit : function () {
		vee.Utils.unscheduleAllCallbacksForTarget(this.rootNode);
	},

	leftToBarrier : function() {
		this._speedX = 300;
	},

	rightToBarrier : function() {
		this._speedX = -300;
	},

	downToBarrier : function() {
		if (this._tempSpeedY > 100) {
			this._tempSpeedY = this._tempSpeedY/1.4;
			this._speedY = this._tempSpeedY;
		} else {
			this._haveDecay = true;
		}
	},

	collide : function(dir) {
		if (!dir) return;
		vee.Audio.playEffect(res.inGame_pick_bigCoin_mp3);
		vee.Audio.playEffect(res.inGame_function_star_mp3);
		EfxGetBigCoin.create(this.getElePosition());
		this._isOver = true;
		this.playAnimate("out", function(){this.die()});
		vee.Utils.logObj(this._gridInMap, "coin grid");
		if (this._gridInMap) {
			var trigger = game.Logic.triggerMap.getObject(this._gridInMap);
			if (trigger) {
				trigger.func(this._gridInMap);
			}
		}
	},

	inhaleController : null,
	getInhaleController : function () {
		if (this.inhaleController) {
			return null;
		}
		this.inhaleController = new InhaleObj();
		this.inhaleController.obj = this;
		return this.inhaleController;
	}
});

var ItemEgg = Item.extend({
	_type : game.ObjectType.Egg,
	_HP : 1,
	_isMovingEgg : false,
	spEgg : null,
	lbHPNum : null,
	_hasG : false,

	bornWithPos : function(pos) {
//		vee.Utils.scheduleCallbackForTarget(this.rootNode, this.updatePos.bind(this));
		this.setDynamic(0,0);
		var mapConfig = game.Logic.configMap.getObject(this._grid);
		if (mapConfig) {
			if (mapConfig.type == "egg") {
				this._HP = parseInt(mapConfig.name);
				this._isMovingEgg = true;
				if (this._HP > 1) {
					this.spEgg.setSpriteFrame("item_egg_run.png");
					this.lbHPNum.setVisible(true);
					this.lbHPNum.setString(''+this._HP);
				}
			}
		}
	},

	afterUpdatePos : function() {
		if (!this._grid) return;
		var oPlayer = game.Data.oPlayerCtl;
		if (this._grid.x > oPlayer._grid.x + this._checkForDieW ||
			this._grid.x < oPlayer._grid.x - this._checkForDieW ||
			this._grid.y > oPlayer._grid.y + this._checkForDieW ||
			this._grid.y < oPlayer._grid.y - this._checkForDieW)
		{
			this.disappear();
		}
	},

	disappear : function() {
		if (this._gridInMap) {
			game.Logic.dynamicObjMap.removeObject(this._gridInMap);
			game.Logic.objMap.setObject(null, this._gridInMap);
		}
		this._container.removeFromParent();
	},

	_cachedDir : null,
	collide : function(dir) {
		if (dir == vee.Direction.Left && game.Data.oPlayerCtl._speedX > 0) {
			game.Data.oPlayerCtl.setElePosition(cc.p(this.getElePosition().x - this.boxSize.width/2 - game.Data.oPlayerCtl.boxSize.width/2, game.Data.oPlayerCtl.getElePosition().y));
			game.Data.oPlayerCtl.stopRunning();
		} else if (dir == vee.Direction.Right && game.Data.oPlayerCtl._speedX < 0) {
			game.Data.oPlayerCtl.setElePosition(cc.p(this.getElePosition().x + this.boxSize.width/2 + game.Data.oPlayerCtl.boxSize.width/2, game.Data.oPlayerCtl.getElePosition().y));
			game.Data.oPlayerCtl.stopRunning();
		} else if (dir == vee.Direction.Top && game.Data.oPlayerCtl._speedY < 0) {
			if (game.Data.isHoldJumpButtom) {
				game.Data.oPlayerCtl._speedY = 1300;
			} else {
				game.Data.oPlayerCtl._speedY = 800;
			}
			game.Data.oPlayerCtl._isJumpLimitY = false;
			this.costHP(dir);
			EfxHitBlock.create(this.getElePosition(), dir);
		} else if (dir == vee.Direction.Bottom && game.Data.oPlayerCtl._speedY > 0) {
			game.Data.oPlayerCtl.upToBarrier();
			this._cachedDir = dir;
			this.costHP(dir);
		}
	},

	remove : function () {
		this.die();
	},

	die : function () {
		this.onDead();
		if (this._gridInMap) {
			if (!this._staticItem) {
			} else {
				game.Logic.objMap.setObject(null, this._gridInMap);
				if (!this._isMovingEgg) {
//					game.Logic.removeMapObjectByGrid(this._gridInMap);
				}
			}
			game.Logic.removeMapExObjectByGrid(this._gridInMap);
		}
		this._container.removeFromParent();
	},


	costHP : function (dir) {
		--this._HP;
		if (this.lbHPNum) {
			this.lbHPNum.setString(''+this._HP);
		}
		var pos = this.getElePosition();

		if (this._HP <= 0) {
			game.Logic.dynamicObjMap.setObject(null, this._gridInMap);
			vee.Utils.scheduleOnce(function() {
				Item.createDynamicCoin(pos, dir == vee.Direction.Left ? -300 : 300, 1700);
			}, 0.2);
			vee.Utils.unscheduleAllCallbacksForTarget(this.rootNode);
			this._hasCollide = false;
			this.playAnimate("ready");
		} else {
			this._container.runAction(cc.moveTo(0.1, vee.Utils.pAdd(this.getElePosition(), cc.p(game.Data.tileSizeWidth,0))));
		}
	},

	onDead : function() {
	},

	getAte : function () {
		game.Data.oPlayerCtl.feed();
		game.Logic.dynamicObjMap.setObject(null, this._gridInMap);
		this.die();
	},

	hitByStar : function (dir) {
		var pos = this.getElePosition();
		this.costHP(dir);
	}
});

var ItemHeart = Item.extend({
	spHeart : null,
	_type : game.ObjectType.Heart,
	ps1 : null,
	bornWithPos : function(pos) {
		if (game.Data.checkIs61()) {
			this.spHeart.setTexture(res.ga_ui_Childheart_png);
		}
		if (this.ps1) this.ps1.setPositionType(1);
	},
	collide : function() {
		game.Data.oLyGame._tmpHeartNum += 1;
		game.Data.addLife();
		vee.Audio.playEffect(res.inGame_pick_heart_mp3);
		EfxGetLife.show(this.getElePosition());
		this.die();
	}
});

var ItemAccelerater = Item.extend({
	_type : game.ObjectType.Accelerater,

	collide : function() {
	}
});

var ItemSpitStar = Item.extend({
	_type : game.ObjectType.Bullet,
	_hasCollide : false,
	_haveDecay : false,
	_staticItem : false,
	_hasG : false,
	_triggerObj : true,
	_speedXLimit : 750,
	_checkForDieW : 10,

	bornWithPos : function(pos) {
		this.playAnimate("show2");
		vee.Utils.scheduleCallbackForTarget(this.rootNode, this.updatePos.bind(this));
	},

	onExit : function () {
		vee.Utils.unscheduleAllCallbacksForTarget(this.rootNode);
	},

	_rectStar : null,
	_rectObj : null,
	AILogicPerFrame : function () {
		var obj = game.Logic.objMap.getObject(this._grid);
		if (obj && obj._type == game.ObjectType.Egg) {
			obj.hitByStar(this._moveDir);
		} else {
			this._rectStar = this.getEleRect();
			var objs = game.Logic.dynamicObjMap.getObjects();
			for (var i in objs) {
				obj = objs[i];
				if (obj && obj.hitByStar) {
					this._rectObj = obj.getEleRect();
					if (cc.rectIntersectsRect(this._rectStar, this._rectObj)) {
						obj.hitByStar(this._moveDir);
						this.dieEffect();
						var dur = 0.03;
						var amplitudeY = 18;
//						game.Data.oLyGame.rootNode.runAction(cc.Sequence.create(
//							cc.delayTime(0.03),
//							cc.callFunc(function () {
//								game.Data.oLyGame.rootNode.setPosition(cc.p(-5,5));
//							}),
//							cc.delayTime(0.03),
//							cc.callFunc(function () {
//								game.Data.oLyGame.rootNode.setPosition(cc.p(2,4));
//							}),
//							cc.delayTime(0.02),
//							cc.callFunc(function () {
//								game.Data.oLyGame.rootNode.setPosition(cc.p(-3,-3));
//							}),
//							cc.delayTime(0.01),
//							cc.callFunc(function () {
//								game.Data.oLyGame.rootNode.setPosition(cc.p(2,-1));
//							})
//						));
						break;
					}
				}
			}
		}

		obj = null;
	},
	stopMove : function() {
	},
	isDashing : function () {
		return true;
	},

	refreshPosition : function (timeDelta) {
		var castPos = cc.p(this.getElePosition().x + this._speedX*timeDelta, this.getElePosition().y + this._speedY*timeDelta);
		var lastGrid = game.Logic.getTileGridByPos(this.getElePosition());
		if (!this._lastGrid || lastGrid.x != this._lastGrid.x || lastGrid.y != this._lastGrid.y) {
			this.onGridChanged();
			this._lastGrid = lastGrid;
		}
		this.setElePosition(castPos);
	},

	onGridChanged : function () {
		var td = game.Logic.map.getObject(this._grid);
		if (td && game.Logic.isBlock(td)) {
			this.checkBarrier(td);
		} else {
			var pos = this.getElePosition();
			var gridPos = game.Logic.getTilePosCenterByGrid(this._grid);
			if (pos.y > gridPos.y + 10) {
				var checkGrid = cc.p(this._grid.x, this._grid.y-1);
				td = game.Logic.map.getObject(checkGrid);
				if (td && game.Logic.isBlock(td)) this.checkBarrier(td, checkGrid);
			} else if (pos.y < gridPos.y - 10) {
				var checkGrid = cc.p(this._grid.x, this._grid.y+1);
				td = game.Logic.map.getObject(checkGrid);
				if (td && game.Logic.isBlock(td)) this.checkBarrier(td, checkGrid);
			}
		}

		var oPlayer = game.Data.oPlayerCtl;
		if (oPlayer && (this._grid.x > oPlayer._grid.x + this._checkForDieW ||
			this._grid.x < oPlayer._grid.x - this._checkForDieW ||
			this._grid.y > oPlayer._grid.y + this._checkForDieW ||
			this._grid.y < oPlayer._grid.y - this._checkForDieW))
		{
			this._isOver = true;
			this.reviveBullet();
			this.die();
		}
	},

	checkBarrier : function (td, checkGrid) {
		if (this._faceTo == vee.Direction.Left) {
			this.leftToBarrier(td, checkGrid);
		} else {
			this.rightToBarrier(td, checkGrid);
		}
	},

	onDead : function () {
	},

	dieEffect : function () {
		this._isOver = true;
		this._accX = 0;
		this._speedX = 0;
		this.playAnimate("out", function () {
			this.die();
		}.bind(this));
		this.reviveBullet();
	},

	reviveBullet : function () {
		if (!game.Data.oPlayerCtl) return;
		if (game.Data.bulletCount == 0) game.Data.oPlayerCtl.resetDTCounter();
		++game.Data.bulletCount;
		if (game.Data.roleType == game.Roles.Cop && game.Data.bulletCount > 2) game.Data.bulletCount = 2;
		else if (game.Data.roleType != game.Roles.Cop && game.Data.bulletCount > 1) game.Data.bulletCount = 1;
	},

	leftToBarrier : function(td, grid) {
		if (!grid) grid = this._grid;
		game.Logic.checkTileTrigger(grid, vee.Direction.Left, td, this);
		game.Logic.triggerTileCallback(td, this, vee.Direction.Left);
		if (td) {
			this.setElePosition(cc.p(td.right, this.getElePosition().y));
		}
		this.dieEffect();
	},

	rightToBarrier : function(td, grid) {
		if (!grid) grid = this._grid;
		game.Logic.checkTileTrigger(grid, vee.Direction.Right, td, this);
		game.Logic.triggerTileCallback(td, this, vee.Direction.Right);
		if (td) {
			this.setElePosition(cc.p(td.left, this.getElePosition().y));
		}
		this.dieEffect();
	}
});
ItemSpitStar.create = function (pos, dirNum) {
	var node = cc.BuilderReader.load(res.itemSpitStar_ccbi);
	var container = new cc.Node();
	container.addChild(node);
	node.controller.setContainerNode(container);
	node.controller.initPosition(pos);
	node.controller._speedX = node.controller._speedXLimit*dirNum;
	node.controller.setFaceTo(node.controller._speedX > 0 ? vee.Direction.Right : vee.Direction.Left, true);
	game.Data.oLyGame.lyMap.addChild(container);
};