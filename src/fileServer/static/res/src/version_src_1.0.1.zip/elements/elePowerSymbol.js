/**
 * Created with AppCode.
 * User: yop
 * Date: 15/8/25
 * Time: 下午3:13
 * To change this template use File | Settings | File Templates.
 */


var ElePowerSymbol = vee.Class.extend({
	_getPosition : null,

	nodeBox : null,

	_speedX : 0,
	_speedY : 0,

	ps1 : null,
	ps2 : null,
	psDust : null,

	_isShow : false,

	show : function(force) {
		if (this._isShow && !force) return;
		this._isShow = true;
		this.nodeBox.setPosition(this._getPosition());
		var animateStr = this.getAnimateStr();
		if (animateStr) this.playAnimate(animateStr + "_in");
//		this.nodeBox.setVisible(true);
	},

	getAnimateStr : function () {
		switch (game.Data.playerType) {
			case game.PlayerType.Smash:
				return "smash";
			case game.PlayerType.Bullet:
				return "bullet";
			case game.PlayerType.Teleport:
				return "teleport";
			case game.PlayerType.Bomb:
				return "bomb";
		}
	},

	hide : function() {
		if (!this._isShow || game.Data.playerType == game.PlayerType.Normal) return;
		this._isShow = false;
		this.playAnimate("out");
//		this.nodeBox.setVisible(false);
	},

	follow : function(dt) {
		var pos = this.nodeBox.getPosition();
		var offset = vee.Utils.pSub(this._getPosition(), pos);

		this._speedX = offset.x * 5;
		pos.x += this._speedX * dt;

		this._speedY = offset.y * 5;
		pos.y += this._speedY * dt;

		this.nodeBox.setPosition(pos);
	},

	attach : function(posFunc) {
		this._getPosition = posFunc;
	}

});

ElePowerSymbol.create = function(target) {
	var ctl = cc.BuilderReader.load(res.eleElf_ccbi).controller;
	var node = new cc.Node();
	node.addChild(ctl.rootNode);
	ctl.nodeBox = node;
	node.controller = ctl;
	if (target.getPosition4Symbol) {
		ctl.attach(target.getPosition4Symbol.bind(target));
	} else {
		ctl.attach(function(){
			return target;
		});
	}
	return ctl;
}