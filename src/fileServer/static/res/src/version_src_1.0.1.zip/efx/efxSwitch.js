/**
 * Created with AppCode.
 * User: WanThirty
 * Date: 15/9/5
 * Time: 上午11:53
 * To change this template use File | Settings | File Templates.
 */

var EfxSwitch = vee.Class.extend({
	ps1 : null,
	ps2 : null,

	init : function () {
		this.ps1.setPositionType(1);
		this.ps2.setPositionType(1);
	},

	show : function (from, to) {
		var animate = from+"To"+to;
		this.playAnimate(animate, function () {
			this.removeEfx();
		}.bind(this));
	},

	removeEfx : function () {
		this.rootNode.setVisible(false);
		EfxSwitch.pool.push(this);
	}
});

EfxSwitch.Status = {
	ON      : 1,
	OFF     : 2,
	DISABLE : 3
};
EfxSwitch.StatusStr = {
	ON      : "On",
	OFF     : "Off",
	DISABLE : "Dis"
};

EfxSwitch.gid2Str = function (gid) {
	switch (gid) {
		case game.BlockType.SwitchShow:
			return EfxSwitch.StatusStr.ON;
		case game.BlockType.SwitchHide:
			return EfxSwitch.StatusStr.OFF;
		case game.BlockType.SwitchDisable:
			return EfxSwitch.StatusStr.DISABLE;
	}
};

EfxSwitch.pool = [];

EfxSwitch.create = function (pos, from, to) {
	if (!from || !to) return null;
	var node = null;
	if (EfxSwitch.pool.length > 0) {
		node = EfxSwitch.pool.pop().rootNode;
		node.setVisible(true);
	} else {
		var node = cc.BuilderReader.load(res.efx_switch_ccbi);
		game.Data.oLyGame.lyMap.addChild(node, 8);
		node.controller.init();
	}
	node.setPosition(pos);
	node.controller.show(from, to);
	return node.controller;
};