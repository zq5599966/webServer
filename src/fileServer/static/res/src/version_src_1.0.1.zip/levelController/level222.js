/**
 * Created with AppCode.
 * User: yop
 * Date: 15/11/2
 * Time: 下午3:19
 * To change this template use File | Settings | File Templates.
 */


LevelController.Level222 = LevelController.extend({
	eventStory1 : function(grid, dir) {
		this.showStory(1, grid, ""+
		"SelectNpc,Flash;"+
		"FaceTo,left;"+
		"MoveCamera,87,24,2;"+
		"ShowDialog,"+ vee.Utils.getLocalizedStringForKey("Hey!", "嘿！") +";"+
		"ShowDialog,"+ vee.Utils.getLocalizedStringForKey("Here's a different sprite!", "这儿有个不一样的小精灵，") +";"+
		"HideDialog;"+
		"MoveCamera,90,23,1;"+
		"ShowDialog,"+ vee.Utils.getLocalizedStringForKey("It can make you more powerful !", "它可以给你全新的力量。") +";"+
		"ShowDialog,"+ vee.Utils.getLocalizedStringForKey("Try it!", "快试试看吧~") +";"+
		"HideDialog"+
		"");
	},

	skip1 : function() {
		cc.log("skip 1 called!");
		this.skipStory(2);
	},

	eventStory2 : function(grid, dir) {
		this.showStory(2, grid, ""+
		"Trigger,83,27;"+
		"SelectNpc,Flash;"+
		"FaceTo,left;"+
		"MoveCamera,85,31,1.5;"+
		"Delay,0.5;"+
		"MoveCamera,85,26,2;"+
		"ShowDialog,"+ vee.Utils.getLocalizedStringForKey("Amazing!", "太棒了，") +";"+
		"ShowDialog,"+ vee.Utils.getLocalizedStringForKey("Here is a secret path!", "这里有一条隐藏的通道。") +";"+
		"ShowDialog,"+ vee.Utils.getLocalizedStringForKey("We can walk through it!", "我们可以从这里走！") +";"+
		"HideDialog;"+
		"MoveRole,90,25;"+
		"Jump,87,28;"+
		"MoveRole,82,28;"+
		"Jump,82,33,1;"+
		"RemoveRole"+
		"");
	},

	skip2 : function() {
		cc.log("skip 2 called!");
	}
});