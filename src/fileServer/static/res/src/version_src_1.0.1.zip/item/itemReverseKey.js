/**
 * Created with AppCode.
 * User: WanThirty
 * Date: 16/3/16
 * Time: 下午12:00
 * To change this template use File | Settings | File Templates.
 */

var ItemReverseKey = Item.extend({
	_type : game.ObjectType.ReverseKey,
	_isOver : false,

	bornWithPos : function (pos) {
		cc.log("key create!");
	},

	collide : function (dir) {
		if (this._isOver) return;
		this._isOver = true;
		vee.Audio.playEffect(res.inGame_function_unlockAvator_mp3);
		var selectedLevel = game.LevelData.selectedLevel;
		if (selectedLevel) {
			selectedLevel.tempReverseKeyCollected();
		}
		this.playAnimate("Hide", function () {
			this.die();
		}.bind(this));
		EfxGetMoonKey.show();
	}
});