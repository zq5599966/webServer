/**
 * Created with AppCode.
 * User: WanThirty
 * Date: 15/10/23
 * Time: 下午4:13
 * To change this template use File | Settings | File Templates.
 */

var UIDialog = vee.Class.extend({
	lbDialogContent : null,
	nodeRole : null,
	btnNext : null,
	_ready : false,
	_isOver : false,
	_soundData : null,

	ccbInit : function () {
//		vee.Controller.deactiveButton();
		vee.Controller.registerGlobalButtonAction(this.onNext.bind(this));
	},

	onExit : function () {
		UIDialog.ctl = null;
	},

	showDialog : function (desc) {
		if (this._ready) {
			this.lbDialogContent.setString(desc);
		} else {
			this.rootNode.setVisible(true);
			var roleNode = cc.BuilderReader.load(Story.selectedNPC.ccbName);
			roleNode.controller.playAnimate("huxi_1");
			this._soundData = game.RoleSoundData[Story.selectedNPC.npcname];
			this.nodeRole.addChild(roleNode);
			this.lbDialogContent.setString(desc);
			this.playAnimate("show", function () {
				this._ready = true;
			}.bind(this));
		}
		this.showRoleVoice();
	},

	showRoleVoice : function () {
		var voiceIdx = vee.Utils.randomInt(1, this._soundData.soundIdxRange);
		var sfxFileName = "res/inGame_character_" + this._soundData.soundFileCharacterName + "_" + voiceIdx + ".mp3";
		vee.Audio.playEffect(sfxFileName);
	},

	hideDialog : function () {
		vee.Controller.clearGlobalButtonAction();
//		vee.Controller.activeButton();
		this._isOver = true;
		this.playAnimate("out", function () {
			vee.PopMgr.closeLayerByCtl(UIDialog.ctl);
			UIDialog.ctl = null;
			if (!Story.isSkip) {
				Story.showNext();
			}
		});
	},

	onNext : function () {
		if (!this._ready || this._isOver) return;
		Story.showNext();
	}
});

UIDialog.ctl = null;

UIDialog.show = function (desc) {
	if (UIDialog.ctl) {
		UIDialog.ctl.showDialog(desc);
	} else {
		var node = vee.PopMgr.popCCB(res.guideDialog_ccbi)
		node.setVisible(false);
		node.controller.ccbInit();
		node.controller.showDialog(desc);
		UIDialog.ctl = node.controller;
	}
};

UIDialog.hide = function () {
	if (UIDialog.ctl) {
		UIDialog.ctl.hideDialog();
	}
};

