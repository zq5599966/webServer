/**
 * Created with AppCode.
 * User: yop
 * Date: 15/10/28
 * Time: 下午2:05
 * To change this template use File | Settings | File Templates.
 */

LevelController.Level231 = LevelController.extend({
	eventStory1 : function(grid, dir) {
		this.showStory(1, grid, ""+
		"SelectNpc,Flash;"+
		"FaceTo,left;"+
		"MoveCamera,21,18,1.5;"+
		"ShowDialog,"+ vee.Utils.getLocalizedStringForKey("You made it! It seems like you’re already getting used to the Phantom World.", "你过来了啊，看来你已经习惯了幻影世界。") +";"+
		"ShowDialog,"+ vee.Utils.getLocalizedStringForKey("But you'd better watch out!", "不过还是要小心点，") +";"+
		"ShowDialog,"+ vee.Utils.getLocalizedStringForKey("Be careful not to fall off the platforms or you will lose the game!", "看，从这里掉下去就会失败哦。") +";"+
		"HideDialog;"+
		"MoveCamera,21,21,0.75;"+
		"Delay,1.5;"+
		"MoveCamera,21,18,0.75;"+
		"ShowDialog,"+ vee.Utils.getLocalizedStringForKey("Take care, buddy!", "总之，小心点吧，") +";"+
		"ShowDialog,"+ vee.Utils.getLocalizedStringForKey("I gotta go, catch you later, buddy!", "我先走啦，跟过来哦！") +";"+
		"FaceTo,right;"+
		"HideDialog;"+
		"MoveRole,24,18;"+
		"Jump,27,17;"+
		"MoveRole,30,17;"+
		"Jump,33,16;"+
		"RemoveRole"+
		"");
	},

	skip1 : function() {
		cc.log("skip 1 called!");
	}
});