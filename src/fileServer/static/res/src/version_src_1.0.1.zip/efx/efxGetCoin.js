/**
 * Created with AppCode.
 * User: WanThirty
 * Date: 15/6/23
 * Time: 下午12:45
 * To change this template use File | Settings | File Templates.
 */

var EfxGetCoin = vee.Class.extend({
	showAnimate : function () {
		this.playAnimate("Show", function () {
			this.rootNode.setVisible(false);
			EfxGetCoin.pool.push(this);
		}.bind(this));
	}
});

EfxGetCoin.pool = null;

EfxGetCoin.show = function (pos) {
	var nodeCtl = EfxGetCoin.pool.pop();
	if (!nodeCtl) {
		var node = cc.BuilderReader.load(res.efx_EatSmallCoin_Star_ccbi);
		game.Data.oLyGame.lyMap.addChild(node, 8);
		nodeCtl = node.controller;
	}
	nodeCtl.rootNode.setVisible(true);
	nodeCtl.rootNode.setPosition(pos);
	nodeCtl.showAnimate();
};




















