/**
 * Created with AppCode.
 * User: WanThirty
 * Date: 15/7/9
 * Time: 上午10:25
 * To change this template use File | Settings | File Templates.
 */

var DustType = {
	JumpDust : 1,
	RunDust : 2,
	SmashDust : 3,
	ForceJumpDust : 4
};

var EfxDust = {
	jumpDustPool : null,
	runDustPool : null,
	smashDustPool : null,

	isJump : false,

	init : function () {
		this.jumpDustPool = [];
		this.runDustPool = [];
		this.smashDustPool = [];
	},
	show : function (pos, type, dir) { // 'dir' is for move animate
		var dustName = this.getDustName(type);
		if (!dustName) return;
		var dustPool = this[dustName+"DustPool"];
		var dustNode = null;
		if (dustPool && dustPool.length > 0) {
			var dustCtl = dustPool.pop();
			dustCtl.show();
			dustNode = dustCtl.rootNode;
			dustNode.setVisible(true);
		} else {
			var ccbName = "res/efx_Dust_"+dustName+".ccbi";
			var node = cc.BuilderReader.load(ccbName);
			game.Data.oLyGame.lyMap.addChild(node, 11);
			node.controller.show(dustName);
			dustNode = node;
		}
		dustNode.setPosition(pos);
		if (dir) {
			if (dir == vee.Direction.Left) {
				dustNode.setScaleX(-1);
			} else {
				dustNode.setScaleX(1);
			}
		}
	},

	getDustName : function (type) {
		switch (type) {
			case DustType.JumpDust:
				if (this.isJump) return null;
				return "jump";
				break;
			case DustType.RunDust:
				return "run";
				break;
			case DustType.SmashDust:
				return "smash";
				break;
			case DustType.ForceJumpDust:
				return "jump";
				break;
			default :
				break
		}
	}
};

var EfxDustCtl = vee.Class.extend({
	_name : null,
	show : function (name) {
		this._name = name ? name : this._name;
		this._aniCall = function () {
			EfxDust[this._name+"DustPool"].push(this);
			this.rootNode.setVisible(false);
		}.bind(this);
		this.playAnimate(this._name, this._aniCall);
	}
});