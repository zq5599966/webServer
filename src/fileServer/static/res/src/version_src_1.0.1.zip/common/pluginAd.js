
var vee = vee = vee || {};

vee.Ad = {
	adBanner : null,
	adInterstitial : null,
	adVideo : null,
	adPluginLoaded : false,
	debug: false,
	isInReview : true,
	adBannerPos : null,
	_callback : null,
	_apiVersion : 1,
	_adSize : 0,
	_from : null,
	_bannerEnabled : false,
	_interstitialEnabled : false,

	isNoAd : false,

	receiveConfig : function(data){
		if (data.err || data.error) return;
		vee.Utils.saveObj(data, "adConfig");

		this._bannerEnabled = data.IsBannerEnabled;
		this._interstitialEnabled = data.IsInterestialEnabled;
	},

	/**
	 * 根据插件名加载插件
	 * @param pluginName
	 * @param config
	 * @returns {*}
	 */
	loadPlugin : function(pluginName, config) {
		if (vee.data.adEnabled && pluginName && config) {
			var pi = plugin.PluginManager.getInstance().loadPlugin(pluginName);
			if (pi) {
//				pi.setDebugMode(this.debug);
				pi.configDeveloperInfo(config);
				cc.log("Load Plugin:\t" + pluginName + " OK!");
			} else {
				cc.log("Ad ERROR : Fail to load Plugin:\t" + pluginName);
			}
		} else {
			cc.log("load plugin " + pluginName + " fail!");
			cc.log("vee.data.adEnabled is : " + vee.data.adEnabled);
			cc.log("pluginName is : " + pluginName);
			cc.log("config is : " + config);
		}
		return pi;
	},

	setInterstitialADConfig : function (config) {
		if (this.adInterstitial) {
			this.adInterstitial.configDeveloperInfo(config);
		} else {
			cc.log("Warning in setInterstitialADConfig: Interstitial is not init!");
		}
	},

	/**
	 * 加载全部插件
	 * @param callback
	 */
	loadPlugins : function(callback) {
		/** @type {app.Config} */
		/*获取配置*/
		var config = this.getConfig();
		this._bannerEnabled = config.IsBannerEnabled;
		this._interstitialEnabled = config.IsInterestialEnabled;
		//添加Banner广告
		if (config.AdBannerPluginName) {
			cc.log(">>>>>>>>>>> add banner plugin");
			var pi = this.loadPlugin(config.AdBannerPluginName, config.AdBannerPluginConfig);
			if (config.IsBannerEnabled) this.adBanner = pi;
			if (config.IsInterestialEnabled) {
				cc.log("zq debug is interestialEnabled ==================");
				this.adInterstitial = pi;
			}
			if(game.Data.version.isAdmobAd && config.AdBannerPluginConfig.AppGoogleRewardedVideoId) vee.Ad.adVideo = pi;
		}

		/*
		//添加Banner广告和插入广告
		if (config.AdInterstialPluginName && config.IsInterestialEnabled) {
			var pi = this.loadPlugin(config.AdInterstialPluginName, config.AdInterstialPluginCoinfig);
			if (pi) this.adInterstitial = pi;
		}
		*/

		/*change by zq 20160811
		//添加视频广告
		if (config.AdVideoPluginName) {
			cc.log(">>>>>>>>>>> add adsvideo plugin");
			vee.Ad.adVideo = this.loadPlugin(config.AdVideoPluginName, config.AdVideoPluginConfig);
		}
		*/

//		if(config.AdBannerPluginConfig && config.AdBannerPluginConfig.AppGoogleRewardedVideoId){
//			var pi = this.loadPlugin(config.AdBannerPluginName, config.AdBannerPluginConfig.AppGoogleRewardedVideoId);
//			if(pi) vee.Ad.adVideo = pi;
//		}
		//change end
		if (callback) callback();
	},

	/**
	 * 显示横幅广告
	 * @param {vee.Ad.Position} pos
	 */
	showBannerAd : function(pos){
		/*
		if (!vee.data.adEnabled || !this._bannerEnabled) return;
		if (this.adBanner){
			if (pos != undefined) this.adBannerPos = pos;
			this.adBanner.showAds(
				{type : vee.Ad.Type.BANNER, size : String(this._adSize) },
				this.adBannerPos);
		} else {
			cc.log("Ad ERROR : No banner plugin found!");
		}
		*/
	},

	/**
	 * 隐藏横幅广告
	 */
	hideBannerAd : function(){
		if (this.adBanner){
			this.adBanner.hideAds({type : String(vee.Ad.Type.BANNER)});
		}
	},
	/**
	 * 检查当前缓存视频广告
	 * @returns {*}
	 */
	checkCacheVideoAd: function(){

		if(game.Data.zqdebug){
			return true;
		}

		if(vee.Ad.adVideo){
			cc.log("zq debug check cache video ad");
			return vee.Ad.adVideo.callBoolFuncWithParam("checkCacheVideoAd");
		}else{
			cc.log("Ad ERROR : No video plugin found!");
			return false;
		}
	},
	
	showExitGamePop : function () {
		vee.Ad.adVideo.callFuncWithParam("exitGame");
	},

	setVideoAdListener : function (callback) {
		if (!vee.Ad.adVideo.listener) {
			vee.Ad.adVideo.listener = {
				onPlayerGetPoints : function(pPlugin, num, itemID){
					if (callback) {
						vee.Ad.adVideo._callback(pPlugin, num, itemID);
					}
				},
				onAdsResult : function(code,msg){
					if (code == vee.Ad.AdsResult.AdsNotReady) {
						cc.log(">>>>>>> video ad msg : " + msg);
						//关闭loading
						vee.PopMgr.removeLoading();
					}
					if (code == vee.Ad.AdsResult.AdsShown) {
						cc.log(">>>>>>> video ad  msg : " + msg);
						vee.PopMgr.removeLoading();
						game.Data.isVideoAding = true;
					}
					cc.log("vee.Ad.adVideo.isWaittingCache       " + vee.Ad.adVideo.isWaittingCache);
					if (code == vee.Ad.AdsResult.AdsReceived && !vee.Ad.adVideo.isWaittingCache) {
						cc.log(">>>>>>> video ad  msg : " + msg);
						//vee.Ad.adVideo.showAds({}, 1);
					}
					if (code == vee.Ad.AdsResult.AdsDismissed) {
						cc.log(">>>>>>> video ad  msg : " + msg);
						vee.Audio.playLastMusic();
// 							vee.Audio.resumeAllEffects();
					}
				}
			};
			vee.Ad.adVideo.setListener(vee.Ad.adVideo.listener);
		}
	},
	
	setAdmobVideoAdListener : function (callback) {
		// if (!vee.Ad.adVideo.videoListener) {
			vee.Ad.adVideo.videoListener = {
				onPlayerGetPoints : function(pPlugin, num, itemID){
					if (callback) {
						vee.Ad.adVideo._callback(pPlugin, num, itemID);
					}
				},
				onAdsResult : function(code,msg){
					if (code == vee.Ad.AdsResult.AdsNotReady) {
						cc.log(">>>>>>> video ad msg : " + msg);
						//关闭loading
						vee.PopMgr.removeLoading();
					}
					if (code == vee.Ad.AdsResult.AdsShown) {
						cc.log(">>>>>>> video ad  msg : " + msg);
						vee.PopMgr.removeLoading();
						game.Data.isVideoAding = true;
					}
					cc.log("vee.Ad.adVideo.isWaittingCache       " + vee.Ad.adVideo.isWaittingCache);
					if (code == vee.Ad.AdsResult.AdsReceived && !vee.Ad.adVideo.isWaittingCache) {
						cc.log(">>>>>>> video ad  msg : " + msg);
						//vee.Ad.adVideo.showAds({}, 1);
					}
					if (code == vee.Ad.AdsResult.AdsDismissed) {
						cc.log(">>>>>>> video ad  msg : " + msg);
						vee.Audio.playLastMusic();
// 							vee.Audio.resumeAllEffects();
					}
				}
			};
			vee.Ad.adVideo.setVideoListener(vee.Ad.adVideo.videoListener);
		// }
	},

	/**
	 * add by zq for revival
	 */
	showRevivalVideoAd : function (callback) {
		game.Data.willShowVideoAd = false;
		game.Data.shownVideoAd = true;
		this.showVideoAd(function () {
			if(callback){
				vee.Utils.scheduleOnce(callback, 0.2);
				// callback();
			}
		}.bind(this), "revival");
	},

	/**
	 * 显示视频广告
	 * @param callback
	 */
	showVideoAd : function(callback, adInfo) {
        cc.log("video callback js----fuck 11111");
		if (vee.Ad.adVideo) {
			vee.Ad.adVideo.isWaittingCache = true;
			vee.PopMgr.popLoading(function(){
				vee.Ad.adVideo.isWaittingCache = false;
			});
			// vee.Audio.pauseMusic();
			// vee.Audio.pauseAllEffects();
			vee.Audio.stopMusicWithSave();
			vee.Audio.stopAllEffcts();
			vee.Ad.adVideo._callback = callback;

			if(game.Data.version.isAdmobAd){
				this.setAdmobVideoAdListener(callback);
			}
			else{
				this.setVideoAdListener(callback);
			}
			vee.Ad.adVideo.showAds({type : vee.Ad.Type.VIDEO, info : String(adInfo)}, 1);

			vee.Utils.scheduleOnce(function () {
				vee.PopMgr.removeLoading();
			}, 3);
			return true;
		} else {
			cc.log("Ad ERROR : No video plugin found!");
			return false;
		}
	},

	showNative : function () {
		if(vee.Ad.adVideo){
			vee.Ad.adVideo.showAds({type : vee.Ad.Type.NATIVE}, 1);
		}
	},

	/**
	 * 显示插屏广告
	 */
	showInterstitialAd : function(posId, dismissCallback, notRetryCallback){

		if(this.isNoAd) return;

		cc.log("zq debug show Interstitial Ad 1111111111");
		if (!vee.data.adEnabled || !this._interstitialEnabled) {
			if(notRetryCallback){
				notRetryCallback();
			}
			return;
		}

		cc.log("zq debug show Interstitial Ad 2222222222");

		if (null !== this.adInterstitial){
			// if (!this.adInterstitial.listener) {
			cc.log("zq debug show Interstitial Ad 333333333");
				this.adInterstitial.listener = {
					onAdsResult : function(code){
						if (code == vee.Ad.AdsResult.AdsShown) {
							game.Data.isVideoAding = true;
						}
						else if (code == vee.Ad.AdsResult.AdsDismissed) {
							if(dismissCallback){
								vee.Utils.scheduleOnce(dismissCallback, 0.2);
							}
						}
						else if(code == vee.Ad.AdsResult.AdsNotReady){
							if(notRetryCallback){
								vee.Utils.scheduleOnce(notRetryCallback, 0.2);
							}
						}
					}
				};
				// this.adInterstitial.setListener(this.adInterstitial.listener);
				this.adInterstitial.setVideoListener(this.adInterstitial.listener);
			// }

			// if(game.Data.zqdebug){
			// 	vee.PopMgr.alert("show interstial ad", "Debug", pi.listener);
			// }

			cc.log("zq debug show Interstitial Ad");

			this.adInterstitial.showAds({type : vee.Ad.Type.FULLSCREEN, size : String(this._adSize),  info : String(posId)}, 1);
			game.Data.isVideoAding = true;
		} else {
			cc.log("Ad ERROR : No interstitial plugin found!");
		}
	},

	activate : function(callback, version) {
		if (version) this._apiVersion = version;
		else this._apiVersion = 1;
		if (vee.data.adEnabled) {
			vee.Ad.loadPlugins(callback);
		}

		if(!game.Data.version.isAdmobAd){
			this.activateVideoAd();
		}

	},

	activateVideoAd : function() {
		//添加视频广告
		var config = this.getConfig();
		if (config.AdVideoPluginName) {
			cc.log(">>>>>>>>>>> add adsvideo plugin");
			vee.Ad.adVideo = this.loadPlugin(config.AdVideoPluginName, config.AdVideoPluginConfig);
		}
	},

	banAd : function(){
		vee.data.adEnabled = false;
		vee.Promo.isActivated = false;
		vee.Ad.hideBannerAd();
		vee.Promo.hideMoreGameBanner();
		vee.saveData();
	},

	getConfig : function(){
		var config = vee.Utils.loadObj("adConfig");
		if (!config) config = app.Config;
		return config;
	},

	/**
	 * @param {String}strId 用于保存计数的唯一标识字符串
	 * @param {Number}countLimit 计数 >= countLimit 便显示广告
	 */
	showFullScreenAd : function(strId, countLimit) {
		var count = parseInt(vee.data["FullScreenAdFor"+strId]);
		if (count || count == 0) {
			if (count >= countLimit) {
				vee.data["FullScreenAdFor"+strId] = 0;
				vee.saveData();
				vee.Ad.showInterstitialAd();
				return true;
			} else {
				vee.data["FullScreenAdFor"+strId] = ++count;
			}
		} else {
			vee.data["FullScreenAdFor"+strId] = 0;
			vee.saveData();
			vee.Ad.showFullScreenAd(strId, countLimit);
		}
		return false;
	},

	// New fullsereen ad logic
	// default online config values...
	blockRate : 0.2,
	blockDelay : 0.5,
	showAdChance : 0,
	showAdChanceDelay : 0.2,
	showLoadingRate : 0,
	showLoadingDuration : 0.5,
	showAdAfterCount : 0,   
	showAdMaxCount : 9999,
	showCloseAdCount : 10,
	showAdInterval : 1,
	// sign...
	lastAdTimestamp : 0,
	isHideAdToday : false,
	showCount : 0,

	/**
	 * 初始化友盟配置参数
	 * @param banAdIAPIDX 去广告的内购idx, 没有传就不显示购买去广告按钮
	 */
	initAdOnlineConfig : function (banAdIAPIDX) {
		this._refreshOnlineConfig();
		if (banAdIAPIDX > -1) {
			LyCloseAd.BanAdIAPIDX = banAdIAPIDX;
			LyCloseAd.ShowType = LyCloseAd.type.VIDEO_AND_BUY;
		} else {
			LyCloseAd.ShowType = LyCloseAd.type.VIDEO_ONLY;
		}

		var lastDate = vee.data["adlastday"];
		var nowDate = new Date().getDate();
		if (lastDate != nowDate) {
			for (var i in app.Config.AdPosConfig) {
				var config = app.Config.AdPosConfig[i];
				this._resetAdShowCount(config.adConfigId.AdName);
			}
		}
		vee.data["adlastday"] = nowDate;
		vee.saveData();

		vee.Utils.scheduleOnce(function () {
			vee.Ad._refreshOnlineConfig();
		}, 1);
		cc.log("Ad with online config has init!");
	},

	/**
	 * 如果弹出广告则中断按钮事件
	 * @returns {boolean} 是否中断事件
	 */
	showInterstitialAndBlockButton : function (AdPosId) {
		if (vee.data.adEnabled) {
			var blockRate = parseFloat(vee.OnlineConfig.getConfigParam(AdPosId+"_block_button_rate",   this.blockRate));
			var blockDelay = parseFloat(vee.OnlineConfig.getConfigParam(AdPosId+"_block_button_delay", this.blockDelay));
			cc.log("block = "+blockRate+" "+blockDelay);
			cc.log("1111 = "+this.showAdInterval);
			cc.log("show time "+vee.Ad.isAdShowTimeValid());
			if (vee.Utils.isLucky(blockRate) && vee.Ad.isAdShowTimeValid()) {
				vee.Utils.scheduleOnce(function () {
					vee.Ad.showInterstitialByOnlineConfig(AdPosId);
				}, blockDelay);
				return true;
			} else {
				return false;
			}
		} else {
			return false;
		}
	},

	isAdShowTimeValid : function () {
		var ts = new Date().getTime();
		return (ts - vee.Ad.lastAdTimestamp > vee.Ad.showAdInterval*1000);
	},

	refreshLastAdTimestamp : function () {
		vee.Ad.lastAdTimestamp = new Date().getTime();
	},

	_refreshOnlineConfig : function () {
		this.showCloseAdCount    = parseFloat(vee.OnlineConfig.getConfigParam("show_close_ad_count",   this.showCloseAdCount));
		this.showAdInterval      = parseFloat(vee.OnlineConfig.getConfigParam("show_ad_interval",      this.showAdInterval));
		cc.log("this.showCloseAdCount = " + this.showCloseAdCount);
		cc.log("this.showAdInterval = " + this.showAdInterval);
	},

	_getAdShowCount : function (AdPosId) {
		var count = vee.data[AdPosId+"showcount"];
		if (!count) {
			count = 0;
			vee.data[AdPosId+"showcount"] = 0;
			vee.saveData();
		}
		return parseInt(count);
	},

	_resetAdShowCount : function (AdPosId) {
		vee.data[AdPosId+"showcount"] = 0;
		vee.saveData();
	},

	getAdPlayCount : function () {
		var count = vee.data["adplaycount"];
		if (!count) {
			count = 0;
			vee.data["adplaycount"] = 0;
			vee.saveData();
		}
		return parseInt(count);
	},

	addAdPlayCount : function () {
		vee.data["adplaycount"] = parseInt(this.getAdPlayCount()) + 1;
		vee.saveData();
	},

	_addAdShowCount : function (AdPosId) {
		vee.data[AdPosId+"showcount"] = parseInt(this._getAdShowCount(AdPosId)) + 1;
		vee.saveData();
	},

	showInterstitialByOnlineConfig : function (AdPosId) {
		cc.log("zq debug show interstitial by online config");
		if (!vee.data.adEnabled) return;

		// if(game.Data.zqdebug){
		if(true){
			this.showInterstitialAd(AdPosId);
			// this.adInterstitial.showAds({type : vee.Ad.Type.FULLSCREEN, size : String(this._adSize),  info : String(AdPosId)}, 1);
			return;
		}

		var ts = new Date().getTime();
		cc.log("ts - vee.Ad.lastAdTimestamp = "+(parseInt(ts) - parseInt(vee.Ad.lastAdTimestamp)));
		cc.log("vee.Ad.showAdInterval*1000 = "+(vee.Ad.showAdInterval*1000));

		var showLoadingRate     = parseFloat(vee.OnlineConfig.getConfigParam(AdPosId+"_show_loading_rate",     this.showLoadingRate));
		var showLoadingDuration = parseFloat(vee.OnlineConfig.getConfigParam(AdPosId+"_show_loading_duration", this.showLoadingDuration));
		var showAdChance        = parseFloat(vee.OnlineConfig.getConfigParam(AdPosId+"_show_ad_chance", this.showAdChance));
		var showAdChanceDelay   = parseFloat(vee.OnlineConfig.getConfigParam(AdPosId+"_show_ad_chance_delay", this.showAdChanceDelay));

		var showAdAfterCount    = parseFloat(vee.OnlineConfig.getConfigParam(AdPosId+"_show_ad_after_count", this.showAdAfterCount));
		var showAdMaxCount      = parseFloat(vee.OnlineConfig.getConfigParam(AdPosId+"_show_ad_before_count", this.showAdMaxCount));
		var playCount           = vee.Ad.getAdPlayCount();
		var showCount           = vee.Ad._getAdShowCount(AdPosId);

		cc.log("vee.Ad.isAdShowTimeValid()   " + vee.Ad.isAdShowTimeValid());
		cc.log("vee.Ad.isHideAdToday   " + vee.Ad.isHideAdToday);
		cc.log("vee.Utils.isLucky(showAdChance)   " + vee.Utils.isLucky(showAdChance));
		cc.log("playCount >= showAdAfterCount   " + playCount >= showAdAfterCount);
		cc.log("showCount < showAdMaxCount   " + showCount < showAdMaxCount);

		cc.log("zq debug showloading rate=====" + showLoadingRate);
		cc.log("zq debug showLoadingDuration rate=====" + showLoadingDuration);
		cc.log("zq debug showAdChance rate=====" + showAdChance);
		cc.log("zq debug showAdChanceDelay rate=====" + showAdChanceDelay);
		cc.log("zq debug showAdAfterCount rate=====" + showAdAfterCount);
		cc.log("zq debug showAdMaxCount rate=====" + showAdMaxCount);
		cc.log("zq debug playCount rate=====" + playCount);
		cc.log("zq debug showCount rate=====" + showCount);

		if (vee.Ad.isAdShowTimeValid()
			&& !vee.Ad.isHideAdToday
			&& vee.Utils.isLucky(showAdChance) // check chance
			&& playCount >= showAdAfterCount
			&& showCount < showAdMaxCount
		) {
			cc.log("showing ad...");
			vee.Ad.refreshLastAdTimestamp();
			// TODO: show loading
			if (vee.Ad.showCount < vee.Ad.showCloseAdCount || !vee.Ad.checkCacheVideoAd()) {
				if (vee.Utils.isLucky(showLoadingRate)) {
					if (showAdChanceDelay > 0) {
						vee.Utils.scheduleOnce(function () {
							LyAdLoading.show(showLoadingDuration, AdPosId);
						}, showAdChanceDelay);
					} else {
						LyAdLoading.show(showLoadingDuration, AdPosId);
					}

				} else {
					if (showAdChanceDelay > 0) {
						vee.Utils.scheduleOnce(function () {
							vee.Ad.showInterstialByPos(AdPosId);
						}, showAdChanceDelay);
					} else {
						vee.Ad.showInterstialByPos(AdPosId);
					}
				}
				++vee.Ad.showCount;
				vee.Ad._addAdShowCount(AdPosId);
			} else {
				// LyCloseAd.show();
				vee.Ad.showCount = 0;
			}
		}
	},

	//add-tian----------------------------------------------------------------------------------------
	_adPosArr : {},

	/**
	 * 初始化方法
	 */
	activateWithPos : function(callback, version)
	{
		if (version) this._apiVersion = version;
		else this._apiVersion = 1;
		if (vee.data.adEnabled)
		{
			var config = app.Config;
			this.initAdPos(config.AdPosConfig);
			this.initAdEntities(config.AdPosEntityConfig);
			this.logAdPosArr();
			if (callback) callback();
		}
		//添加视频广告
		var config = app.Config;
		if (config.AdVideoPluginName) {
			cc.log(">>>>>>>>>>> add adsvideo plugin");
			vee.Ad.adVideo = this.loadPlugin(config.AdVideoPluginName, config.AdVideoPluginConfig);
		}
	},

	/**
	 * 初始化方法, 使用adEntityIdx时使用
	 */
	activateWithSettedEntityPos : function(callback, version)
	{
		if (version) this._apiVersion = version;
		else this._apiVersion = 1;

		if (vee.data.adEnabled)
		{
			var config = app.Config;
			var arrPi = this.createArrayEntities(config.AdPosEntityConfig);
			this.initAdPosWithConfigAndArr(config.AdPosConfig, arrPi);
			this.logAdPosArr();
			if (callback) callback();
		}

		//添加视频广告
		var config = app.Config;
		if (config.AdVideoPluginName) {
			cc.log(">>>>>>>>>>> add adsvideo plugin");
			vee.Ad.adVideo = this.loadPlugin(config.AdVideoPluginName, config.AdVideoPluginConfig);
		}
	},

	exchangeAdEntity : function(adPosOld, adPosNew, remove)
	{
		var pi = this.getPosAdEntityById(adPosOld);
		if(remove){
			this.setPosAdEntityById(adPosOld, null);
		}
		this.setPosAdEntityById(adPosNew, pi, true);
	},

	/**
	 * 按照posid的广告id设置广告实例
	 */
	changeEntityAdIDTo : function(AdPos)
	{
		return;
		var pi = this.getPosAdEntityById(AdPos);
		var apConfig = this.getPosAdConfigIdById(AdPos);
		if(pi){
			pi.configDeveloperInfo(apConfig.AdConfig);
			cc.log("----------广告对象：" + pi._piId + "   切换广告位 ： " + AdPos);
		}
	},

	/**
	 * 创建广告插件实例数组
	 */
	createArrayEntities : function(config)
	{
		var arrPi = [];
		for(var i = 0; i < config.length; i++)
		{
			var pi = this.createAdEntity(config[i]);
			if(pi)
			{
				pi._piId = i;
				arrPi.push(pi);
			}
		}
		return arrPi;
	},
	/**
	 * 创建广告插件实例
	 */
	createAdEntity : function(adName)
	{
		var pi = plugin.PluginManager.getInstance().createPlugin(adName);
		return pi;
	},
	/**
	 * 根据广告位配置和广告插件实例数组初始化 _adPosArr
	 */
	initAdPosWithConfigAndArr : function(posArr, piArr)
	{
		for(var i = 0; i < posArr.length; i++)
		{
			var data = posArr[i];
			this._adPosArr[data.adPosId] = {};
			this.setPosDataById(data.adPosId, data.adConfigId, piArr[data.adEntityIdx]);
		}
	},

	initAdPos : function(posArr)
	{
		for(var i = 0; i < posArr.length; i++)
		{
			var data = posArr[i];
			this._adPosArr[data.adPosId] = {};
			this.setPosDataById(data.adPosId, data.adConfigId, null);
		}
	},

	initAdEntities : function(arr)
	{
		for(var i = 0; i < arr.length; i++)
		{
			var name = arr[i];
			if(this._adPosArr[name])
			{
				var pi = this.getAdEntityByConfig(this._adPosArr[name]._adConfigId);
				if(!pi)
				{
					var pi = plugin.PluginManager.getInstance().createPlugin(this._adPosArr[name]._adConfigId.AdName);
					pi.configDeveloperInfo(this._adPosArr[name]._adConfigId.AdConfig);
				}
				this.setPosAdEntityById(name, pi, false);
			}
		}
	},

	checkAdConfigInterstialId : function(config_1, config_2)
	{
		return config_1.AdConfig.AppFaceBookInterstialId === config_2.AdConfig.AppFaceBookInterstialId;
	},

	getAdEntityByConfig : function(adConfigId)
	{
		for (var id in this._adPosArr)
		{
			if(this.checkAdConfigInterstialId(adConfigId, this._adPosArr[id]._adConfigId))
			{
				return this._adPosArr[id]._adEntity;
			}
		}
	},

	setPosDataById : function(adPosId, adConfigId, adEntity)
	{
		this._adPosArr[adPosId]._adConfigId = adConfigId;
		this._adPosArr[adPosId]._adEntity = adEntity;
	},

	getPosDataById : function(adPosId)
	{
		return this._adPosArr[adPosId];
	},

	getPosAdEntityById : function(adPosId)
	{
		if(this._adPosArr[adPosId])
		{
			return this._adPosArr[adPosId]._adEntity;
		}
		return null;
	},

	setPosAdEntityById : function(adPosId, adEntity, setConfig)
	{
		if(this._adPosArr[adPosId])
		{
			this._adPosArr[adPosId]._adEntity = adEntity;
			if(setConfig)
			{
				this._adPosArr[adPosId]._adEntity.configDeveloperInfo(this._adPosArr[adPosId]._adConfigId.AdConfig);
			}
		}
	},

	getPosAdConfigIdById : function(adPosId)
	{
		if(this._adPosArr[adPosId])
		{
			return this._adPosArr[adPosId]._adConfigId;
		}
		return null;
	},

	setPosAdConfigIdById : function(adPosId, adEntity)
	{
		if(this._adPosArr[adPosId])
		{
			this._adPosArr[adPosId]._adConfigId = adEntity;
		}
	},

	showInterstialByPos : function(AdPosId)
	{
		vee.Ad.showInterstitialAd();
		return;

		var pi = this.getPosAdEntityById(AdPosId);
		if(pi)
		{
			this.showInterstialPos(AdPosId, pi);
			cc.log("Ad SHOW :  -- Pos: " + AdPosId);
		}
		else
		{
			cc.log("Ad ERROR : No interstitial plugin found!" + "  -- Pos: " + AdPosId);
		}
	},

	showInterstialPos : function(AdPosId, pi, dismissCallback, notRetryCallback)
	{

		if(this.isNoAd) return;

		if (!vee.data.adEnabled) {
			if(notRetryCallback){
				notRetryCallback();
			}
			return;
		}
		if (null !== pi){
			if (!pi.listener) {
				pi.listener = {
					onAdsResult : function(code){
						if (code == vee.Ad.AdsResult.AdsDismissed) {
							if(dismissCallback){
								vee.Utils.scheduleOnce(dismissCallback, 0.2);
							}
						}
						if(code == vee.Ad.AdsResult.AdsNotReady){
							if(notRetryCallback){
								vee.Utils.scheduleOnce(notRetryCallback, 0.2);
							}
						}
					}
				};
				pi.setListener(pi.listener);
			}

			if(game.Data.zqdebug){
				vee.PopMgr.alert("show interstial ad", "Debug", pi.listener);
			}

			pi.showAds({type : vee.Ad.Type.FULLSCREEN, size : String(this._adSize), info : String(AdPosId) }, 1);

		} else {
			cc.log("Ad ERROR : No interstitial plugin found!");
		}

		this.showInterstialPosAfter(AdPosId);
	},

	showInterstialPosAfter : function(AdPosId)
	{

	},

	showBannerAdPos : function(AdPosId, pos)
	{
		if (!vee.data.adEnabled) return;

		var pi = this.getPosAdEntityById(AdPosId);
		if (pi)
		{
			//if (pos != undefined) this.adBannerPos = pos;
			pi.showAds({type : vee.Ad.Type.BANNER, size : String(this._adSize) }, pos);
		}
		else
		{
			cc.log("Ad ERROR : No banner plugin found!");
		}
	},

	hideBannerAdPos : function(AdPosId)
	{
		var pi = this.getPosAdEntityById(AdPosId);
		if (pi)
		{
			pi.hideAds({type : String(vee.Ad.Type.BANNER)});
		}
		else
		{
			cc.log("Ad ERROR : No banner plugin found!");
		}
	},





	logAdPosArr : function()
	{
		cc.log("================================================");
		for (var id in this._adPosArr)
		{
			cc.log("AdsPosId : " + id);
			cc.log("AdsConfigName : " + this._adPosArr[id]._adConfigId.AdName);
			cc.log("AdsConfigInterstialId : " + this._adPosArr[id]._adConfigId.AdConfig.AppFaceBookInterstialId);
			if (this._adPosArr[id]._adEntity) {
				cc.log("AdEntity index: " + this._adPosArr[id]._adEntity._piId);
			} else {
				cc.log("AdEntity not exist");
			}
			cc.log("");
		}
		cc.log("================================================");
	}
};

var LyCloseAd = vee.Class.extend({

	ccbInit : function () {
		if (LyCloseAd.ShowType == LyCloseAd.type.VIDEO_ONLY) {
			this.playAnimate("show");
		} else if (LyCloseAd.ShowType == LyCloseAd.type.VIDEO_AND_BUY) {
			this.playAnimate("show_both");
		}
	},

	onVideo : function () {
		vee.Ad.showVideoAd(function (pPlugin, num, itemID) {
			vee.PopMgr.closeLayerByCtl(this);
			vee.Utils.scheduleOnce(function () {
				vee.PopMgr.alert(
					vee.Utils.getLocalizedStringForKey("There will be NO Ads today. Enjoy it!"),
					vee.Utils.getLocalizedStringForKey("REMOVE ADS")
				);
			}.bind(this), 0.2);
		});
	},

	onBuy : function () {
		vee.IAPMgr.buyProduct(LyCloseAd.BanAdIAPIDX, function(productID){
			vee.Ad.banAd();
			vee.PopMgr.closeLayerByCtl(this);
			vee.PopMgr.alert(
				vee.Utils.getLocalizedStringForKey("Purchase success, Ads has removed!"),
				vee.Utils.getLocalizedStringForKey("CONGRATULATION")
			);
		}.bind(this));
	},

	onClose : function () {
		var closeFunc = function () {
			vee.PopMgr.closeLayerByCtl(this);
		}.bind(this);

		if (LyCloseAd.ShowType == LyCloseAd.type.VIDEO_ONLY) {
			this.playAnimate("hide", closeFunc);
		} else if (LyCloseAd.ShowType == LyCloseAd.type.VIDEO_AND_BUY) {
			this.playAnimate("hide_both", closeFunc);
		}
	}
});
LyCloseAd.show = function () {
	var node = vee.PopMgr.popCCB("res/vAlertboxCloseAd.ccbi", { alpha : 0 });
	node.controller.ccbInit();
};
LyCloseAd.type = {
	VIDEO_ONLY : 1,
	VIDEO_AND_BUY : 2
};
LyCloseAd.ShowType = LyCloseAd.type.VIDEO_ONLY;
LyCloseAd.BanAdIAPIDX = -1;

var LyAdLoading = vee.Class.extend({
	ccbInit : function (dur, AdPosId) {
		vee.Utils.scheduleOnce(function () {
			vee.PopMgr.closeLayerByCtl(this);
			vee.Ad.showInterstialByPos(AdPosId);
		}.bind(this), dur);
	}
});
LyAdLoading.show = function (dur, AdPosId) {
	var node = vee.PopMgr.popCCB("res/vAdLoading.ccbi", { alpha : 0 });
	node.controller.ccbInit(dur, AdPosId);
};

vee.Ad.Type = {
	BANNER : "0",
	FULLSCREEN : "1",
	VIDEO : "2",
	NATIVE : "3"
};

vee.Ad.Position = {
	Center: 0,
	Top : 1,
	TopLeft : 2,
	TopRight : 3,
	Bottom : 4,
	BottomLeft : 5,
	BottomRight : 6,
	Left : 7,
	Right: 8,
	Bottom_100 : 9
};

vee.Ad.AdsResult = {
	AdsReceived        : 0,
	AdsShown           : 1,
	AdsDismissed       : 2,
	PointsSpendSucceed : 3,
	PointsSpendFailed  : 4,
	NetworkError       : 5,
	UnknownError       : 6,
	VideoStart         : 7,
	VideoComplete      : 8,
	AdsNotReady        : 9
};
