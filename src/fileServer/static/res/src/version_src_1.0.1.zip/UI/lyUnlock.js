/**
 * Created with AppCode.
 * User: WanThirty
 * Date: 15/11/4
 * Time: 下午1:49
 * To change this template use File | Settings | File Templates.
 */

var LyUnlock = vee.Class.extend({
	nodePlayer : null,
	btnSwitch : null,

	_isOver : false,
	_idx : null,
	_tempSelectorState : null,
	_callback : null,

	ccbInit : function () {
		this.playAnimate("open");
		this.handleKey(true);
		this._tempSelectorState = vee.Controller.cacheControllerState();
	},

	initController : function () {
		vee.Controller.initSelector(1,1,null,cc.p(0,0));
		vee.Controller.registerItemByButton(this.btnSwitch, cc.p(0,0), this.onSwitch.bind(this), "res/mfi_btn_on_210.png");
		vee.Controller.activeSelector();
	},

	onKeyBack : function(){
		this.onSwitch();
		return true;
	},

	setIdx : function (idx) {
		this._idx = idx;
		var avatarData = game.AvatarData.getAvatarData(idx);
		var roleContent = ElePlayer.create(avatarData.role);
		this.nodePlayer.addChild(roleContent.container);
		roleContent.controller.playAnimate("huxi_1");
	},

	setCallback : function (callback) {
		this._callback = callback;
	},

	onSwitch : function () {
		if (this._isOver) return;
		this._isOver = true;
		vee.Controller.deactiveSelector();

		game.AvatarData.avatarSelected(this._idx);
		LyAvatarStore.refreshState();
		this.playAnimate("hide", function () {
			vee.Controller.reviveControllerState(this._tempSelectorState);
			vee.PopMgr.closeLayer();
			if(game.Data.oLyGameOver){
				game.Data.oLyGameOver.blockButton = false;
			}
			if (this._callback) this._callback();
		}.bind(this));
	}
});

LyUnlock.show = function (idx, callback) {
	var node = vee.PopMgr.popCCB(res.vGameOverUnlock_ccbi, {alpha:0});
	node.controller.ccbInit();
	node.controller.setIdx(idx);
	node.controller.setCallback(callback);
	vee.Audio.playEffect(res.inGame_function_unlockAvator_mp3);
};