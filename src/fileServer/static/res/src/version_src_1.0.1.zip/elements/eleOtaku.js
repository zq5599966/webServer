/**
 * Created with AppCode.
 * User: WanThirty
 * Date: 15/6/23
 * Time: 下午3:42
 * To change this template use File | Settings | File Templates.
 */

var EleOtaku = ElePlayer.extend({
});