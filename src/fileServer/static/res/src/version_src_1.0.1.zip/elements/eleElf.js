/**
 * Created with AppCode.
 * User: WanThirty
 * Date: 15/8/5
 * Time: 上午11:08
 * To change this template use File | Settings | File Templates.
 */

var EleElf = vee.Class.extend({
	psDust : null,
	_container : null,
	node1 : null,

	onExit : function () {
		EleElf.elf = null;
	},

	startUp : function () {
		EleElf.elf = this;
		this.playAnimate("show");
		this.psDust.setPositionType(1);
		this.changeDir();
		this._container.setPosition(cc.p(0,-50));
		this._container.runAction(cc.repeat(cc.sequence(
			cc.EaseInOut.create(cc.moveBy(1, cc.p(50,0)), 3.14),
			cc.EaseInOut.create(cc.moveBy(2, cc.p(-100,0)), 3.14),
			cc.EaseInOut.create(cc.moveBy(1, cc.p(50,0)), 3.14)
		),99999));
		this._container.runAction(cc.repeat(cc.sequence(
			cc.EaseInOut.create(cc.moveBy(2, cc.p(0,100)), 3.14),
			cc.EaseInOut.create(cc.moveBy(2, cc.p(0,-100)), 3.14)
		),99999));
		this._container.setVisible(false);
	},

	changeDir : function (dir) {
		return;
		if (dir == vee.Direction.Left) {
			this._container.stopAllActions();
			this._container.runAction(cc.EaseOut.create(cc.moveTo(0.4, cc.p(50, 50)), 3));
		} else {
			this._container.stopAllActions();
			this._container.runAction(cc.EaseOut.create(cc.moveTo(0.4, cc.p(-50, 50)), 3));
		}
	},

	_stopUpdateOffset : false,
	setOffset : function (offset) {
		return;
		if (this._stopUpdateOffset) return;
		var castPos = this._container.getPosition();
		castPos.x = castPos.x > 50 ? 50 : castPos.x;
		castPos.x = castPos.x < -50 ? -50 : castPos.x;
		castPos.y = 50;
		offset.y = offset.y < 0 ? offset.y : offset.y*2;
//		this._container.runAction(cc.moveTo(0.1, vee.Utils.pAdd(cc.p(offset.x*2, offset.y*2), castPos)));
		this._container.setPosition(vee.Utils.pAdd(cc.p(offset.x*2, offset.y), castPos));
//		this.node1.stopAllActions();
//		this.node1.runAction(cc.sequence(
//			cc.delayTime(0),
//			cc.callFunc(function () {
//				this._stopUpdateOffset = true;
//			}.bind(this)),
//			cc.moveTo(0.1, vee.Utils.pAdd(cc.p(offset.x*2, offset.y*2), castPos)),
//			cc.callFunc(function () {
//				this._stopUpdateOffset = false;
//			}.bind(this))
//		));
	}
});

EleElf.elf = null;

EleElf.addToPlayer = function (elf) {
	game.Data.oPlayerCtl._container.addChild(elf,999);
};

EleElf.changeElfDir = function(dir) {
	if (EleElf.elf) {
		EleElf.elf.changeDir(dir);
	}
};

EleElf.setElfOffset = function(offset) {
	if (EleElf.elf) {
		EleElf.elf.setOffset(offset);
	}
};

EleElf.create = function () {
	var node = cc.BuilderReader.load(res.eleElf_ccbi);
	var container = cc.Node.create();
	container.addChild(node);
	node.controller._container = container;
	node.controller.startUp();
	return container;
};