/**
 * Created with AppCode.
 * User: Yop Chan
 * Date: 14-3-19
 * Time: 下午4:11
 * To change this template use File | Settings | File Templates.
 */

var app = app = app || {};


/*Deprecated change by zq 20161227 see src/data/appConfig/appConfigManager.js
app.Config = {
	AppID : 1041873285,
	AppName : "SuperCat",
	AppAlias : "supercat",
	AppURL : null,

	// If there is removeAd IAP, it MUST be at the first place
	IAPs : [],
	LeaderboardIDs : ["com.veewo.stars"],

	// use for utils.rate()
	RateURL : null,
	// use for moregame button
	PromoURL : "http://www.veewo.com",
	// use for combine promo config download URL
	PromoChannel : "promo",
	PromoBannerEnable : true,
	PromoFullScreenEnable : true,

	//plugin
	GameCenterPluginName : "SocialGameCenter",
	GameCenterPluginConfig : {"appid" : "1041873285"},

	//plugin
	AnalyticsPluginName : "AnalyticsUmengGame",
	AnalysticsPluginConfig : "08F4D0E63C085EE97F3C961A5B481DD3",

	AnalyticsPluginADTrackName : "AnalyticsMAT",
	AnalyticsPluginADTrackConfig : {
		// Platform depends
	},

	IAPPluginName : "IAPManager",
	IAPConfig : null,

	AdVideoPluginName : "AdsVungle",
	AdVideoPluginConfig : {
		AdsVungle : "com.veewo.supercat"
	},

	AdBannerPluginName : "AdsAdapter",
	AdBannerPluginConfig : {
		AdvertiserID : "164496",
		ConversionKey : "1b0e697a2fa9501dcafa6a08e2c1c017"
	},

	AdInterstialPluginName : "AdsAdapter",
	AdInterstialPluginCoinfig : null,

	IsBannerEnabled : true,
	IsInterestialEnabled : true,

	AdPosConfig : [],
	AdPosEntityConfig : [],

	ShareKTPlay_IOS_cn : {
		key : "1czpLrGVUp",
		secret : "9bdb56cbb77c3eaae133fa1071624e896c85f5ba"
	},

	ShareKTPlay_android : {
		key : "19ypSjYv6D",
		secret : "96f8fb00696a9f83add4c0b8afdd19af801e54fb"
	}
};

app.Config.iOS = {
	AppID : 1041873285,
	AnalyticsPluginADTrackConfig : {
		AdvertiserID : "164496",
		ConversionKey : "1b0e697a2fa9501dcafa6a08e2c1c017"
	},
	GameCenterPluginConfig : {"appid" : "1041873285"},
	AdBannerPluginName : "AdsAdapter",
	AdBannerPluginConfig : {
		AppGoogleBannerId: "ca-app-pub-4587184008612513/3196418381",

		AppGoogleInterstialId: "ca-app-pub-1777019132527367/9535896334",

		//AppFaceBookBannerId : "324268734426400_478726335647305",
		AppFaceBookInterstialId : "150931201938556_234107046954304",

		AppGoogleRewardedVideoId : "ca-app-pub-1777019132527367/7773351931"
	},
	AdVideoPluginConfig : {
		AdsVungle : "1041873285"
	},
	LeaderboardIDs : ["com.veewo.stars"],
	Achievements : [
		"com.veewo.star1",   // star 1
		"com.veewo.star2",   // star 2
		"com.veewo.star3",   // star 3
		"com.veewo.star4",   // star 4
		"com.veewo.star5",   // star 5
		"com.veewo.flash",   // flash
		"com.veewo.jump",    // jump
		"com.veewo.heart",   // heart
		"com.veewo.coin"     // coin
	],
	IAPs : [
		{ProductID: "com.veewo.unlock", NonConsumable:"false"},
		{ProductID: "com.veewo.allcat", NonConsumable:"true"},
		{ProductID: "com.veewo.power", NonConsumable:"false"}
	],

	// Custom...
	AdOdd      : "ca-app-pub-1777019132527367/1974641134",
	AdEven     : "ca-app-pub-1777019132527367/4442904336",
	AdPause    : "ca-app-pub-1777019132527367/2966171130",
	AdGameOver : "ca-app-pub-1777019132527367/7396370731",
	AdStartUp  : "ca-app-pub-1777019132527367/8873103936",
	AdExit     : "ca-app-pub-1777019132527367/3451374331"
};

app.Config.android = {
	AppID : "com.veewo.supercat",
	packageName : "com.veewo.supercat",
	AppDefaultClass : "com/veewo/VeeCommon/VeeCommon",
	GameCenterPluginConfig : {"appid" : "com.veewo.supercat"},
	AnalyticsPluginADTrackConfig : {
		AdvertiserID : "164496",
		ConversionKey : "1b0e697a2fa9501dcafa6a08e2c1c017"
	},
	AdVideoPluginConfig : {
		AdsVungle : "com.veewo.supercat"
	},
	IAPConfig : {IAPID : "MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAhb+hA/lLAbVynW5AOQAurv4nsgDTRh4PsuHH3smCq01FGc4VqR4r/Uc1sOHZ3cR0ocHc2ISycIXd2A8/FW6ZQ9nRVHunYXqKwGSMZiImrPKH3qz4bChdxs42AtSTMutDBVIc3AVjbkOD5yaPh09xUxZ9lJDmJrXRoj0sKvn2FCyYpSYQyJZjTBOZs1+fGjaUK9ytiF5lZkhdIfsHkZA256kwq1uYGOi/KQk59qeCqfMg8ovA1Kgno+mitR2aG8A9PimG7WNPneqy3Ss7Lo68C5tT8RaWnXg2ZnLaWbZveyVfJFY2jGrI/K1CV8f+MJ7OqSu24nFXlPbgG22IuJaBhQIDAQAB"},
	AdBannerPluginName : "AdsAdapter",
	AdBannerPluginConfig : {
		AppGoogleBannerId: "ca-app-pub-4587184008612513/3196418381",


		//AppGoogleInterstialId: "ca-app-pub-4587184008612513/4673151588",

		AppGoogleInterstialId: "ca-app-pub-1777019132527367/2533549534",
		//change end

		//AppFaceBookBannerId : "324268734426400_478726335647305",
		AppFaceBookInterstialId : "150931201938556_150931438605199",

		AppGoogleRewardedVideoId : "ca-app-pub-1777019132527367/7083425138"
	},
	IAPs : [
		{ProductID: "com.veewo.unlocklevels", NonConsumable:"false"},
		{ProductID: "com.veewo.allcat", NonConsumable:"true"},
		{ProductID: "com.veewo.power", NonConsumable:"false"},
		{ProductID: "com.veewo.moon", NonConsumable:"true"},
		{ProductID: "com.veewo.unlockdiscolevels", NonConsumable:"true"}
	],

	// Custom...
	AdOdd      : "ca-app-pub-1777019132527367/1974641134",
	AdEven     : "ca-app-pub-1777019132527367/4442904336",
	AdPause    : "ca-app-pub-1777019132527367/2966171130",
	AdGameOver : "ca-app-pub-1777019132527367/8516174730",
	AdStartUp  : "ca-app-pub-1777019132527367/2609241934",
	AdExit     : "ca-app-pub-1777019132527367/3451374331",

	Achievements : [
		"CgkIu7e9p-oLEAIQAQ",   // star 1
		"CgkIu7e9p-oLEAIQAg",   // star 2
		"CgkIu7e9p-oLEAIQAw",   // star 3
		"CgkIu7e9p-oLEAIQBA",   // star 4
		"CgkIu7e9p-oLEAIQBQ",   // star 5
		"CgkIu7e9p-oLEAIQAA",   // flash
		"CgkIu7e9p-oLEAIQBg",   // jump
		"CgkIu7e9p-oLEAIQBw",   // heart
		"CgkIu7e9p-oLEAIQCg"    // coin
	],

	LeaderboardIDs : ["CgkIu7e9p-oLEAIQCQ"]
};
*/

app.init = function(isFirstPlay){

	// var config = vee.Utils.getObjByPlatform(app.Config.iOS, app.Config.android, {});
	// for (var i in config){
	// 	app.Config[i] = config[i];
	// }
	

	if (isFirstPlay) {
		vee.saveData();
	}

	if (!game.Data.isAndroid) vee.Common.getInstance().removeAllNotifications();
	// add your app launch code here
};

app.closeGame = function () {
	app.addCatNotification();
};

app.leave = function (argument) {
	//will resign focus , save data here
	cc.log("app leave");
	app.saveDataBeforeLeave();
	vee.saveData();
	game.LevelData.save();
	vee.VIPValues.save();

	app.addCatNotification();
};

app.resume = function (argument) {
	//activated from background
	cc.log("app resume");
	app.checkData();
	vee.data["leavets"] = 0;
	vee.saveData();

	if(game.Data.isVideoAding){
		cc.log("zq debug is video ading====");
		game.Data.isVideoAding = false;
	}
	else if(game.Data.isInLevelSceen && game.Data.oLyGame){
		cc.log("zq debug not video ading=====");
		game.Data.oLyGame.onPause();
	}

	if (!game.Data.isAndroid) vee.Common.getInstance().removeAllNotifications();
};

app.saveDataBeforeLeave = function () {
	var ts = new Date().getTime();
	vee.data["leavets"] = ts;
	vee.saveData();
};

app.checkData = function () {
	var ts = parseInt(vee.data["leavets"]);
	var nowTs = parseInt(new Date().getTime());
	if (nowTs < ts) {
		var e = parseInt(vee.dataManager.getEnergy());
		vee.dataManager.setEnergyTs(game.Data.nextEnergyTsFromNow());
		if (e > 1) {
			vee.dataManager.setEnergy(1);
		} else {
			vee.dataManager.setEnergy(0);
		}
		vee.data["ultE_ts"] = 0;
		if (game.Data.oEnergyCtl) game.Data.oEnergyCtl.showEnergy();
		vee.Utils.scheduleOnce(function () {
			vee.PopMgr.alert(
				vee.Utils.getLocalizedStringForKey("There`s a time leap!"),
				vee.Utils.getLocalizedStringForKey("ERROR")
			);
		}, 0.2);
	}
	vee.data["leavets"] = 0;
	vee.saveData();
};

app.addCatNotification = function () {
	if (!game.Data.isAndroid) return;
	var energy = game.Data.getEnergy();
	var notificationObj = {
		"tag"	      : "0",
		"closetime"   : ''+((new Date()).getTime())
	};

//	var oneHour = 3600000; // 3600 * 1000
//	var oneDay = 8640;  // 24 * 3600000
	var oneDay = 86400000;  // 24 * 3600000
	notificationObj.fireDate1 = '' + (oneDay * 3);
	notificationObj.ticker1 = vee.Utils.getLocalizedStringForKey("Have you forgotten me?");
	notificationObj.title1 = vee.Utils.getLocalizedStringForKey("Have you forgotten me?");
	notificationObj.content1 = vee.Utils.getLocalizedStringForKey("Meow~~~ I miss you. Still remember the days we advance in the game? Wanna go back to Phantom World for more surprise!");

	notificationObj.fireDate2 = '' + (oneDay * 7);
	notificationObj.ticker2 = vee.Utils.getLocalizedStringForKey("Have you forgotten me?");
	notificationObj.title2 = vee.Utils.getLocalizedStringForKey("Have you forgotten me?");
	notificationObj.content2 = vee.Utils.getLocalizedStringForKey("Meow~~~ I miss you. Still remember the days we advance in the game? Wanna go back to Phantom World for more surprise!");

	notificationObj.fireDate3 = '' + (oneDay * 14);
	notificationObj.ticker3 = vee.Utils.getLocalizedStringForKey("Have you forgotten me?");
	notificationObj.title3 = vee.Utils.getLocalizedStringForKey("Have you forgotten me?");
	notificationObj.content3 = vee.Utils.getLocalizedStringForKey("Meow~~~ I miss you. Still remember the days we advance in the game? Wanna go back to Phantom World for more surprise!");

	if (energy < 5) {
		var remainingCount = 5 - energy - 1;
		if (remainingCount < 0) remainingCount = 0;
		var ts = game.Data.getEnergyReviveTs();
		var nowTs = new Date().getTime();
		var timeLeft = parseInt(ts - nowTs) + remainingCount * game.Data.energyReviveDelay;
		cc.log("arg1 = "+energy);
		cc.log("arg2 = "+parseInt(ts - nowTs));
		cc.log("arg1 = "+remainingCount);
		cc.log("arg1 = "+game.Data.energyReviveDelay);
		cc.log("arg1 = "+ts);
		cc.log("arg1 = "+nowTs);
		cc.log("energy full revive time left : "+timeLeft);

		notificationObj.fireDate4 = ''+timeLeft;
		notificationObj.ticker4 = vee.Utils.getLocalizedStringForKey("Meow~~~ Energy is full!");
		notificationObj.title4 = vee.Utils.getLocalizedStringForKey("Meow~~~ Energy is full!");
		notificationObj.content4 = vee.Utils.getLocalizedStringForKey("Here we go, Mr. White!  It's time for journey! Meow~~~ Let's continue completing levels! Characters and locked levels are waiting for us!!!");
	}

	vee.Common.getInstance().addLocalNotification(notificationObj);
};

app.closeGame = function () {
	app.addCatNotification();
};