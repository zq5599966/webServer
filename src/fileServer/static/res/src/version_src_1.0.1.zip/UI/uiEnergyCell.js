/**
 * Created with AppCode.
 * User: WanThirty
 * Date: 15/9/13
 * Time: 上午11:28
 * To change this template use File | Settings | File Templates.
 */

var UIEnergyCell = vee.Class.extend({
	show : function () {
		this.playAnimate("on");
	},

	hide : function () {
		this.playAnimate("off");
	},

	use : function () {
		this.playAnimate("use");
	}
});

UIEnergyCell.create = function () {
	return cc.BuilderReader.load(res.uiEnergyCell_ccbi);
};