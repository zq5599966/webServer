/**
 * Created with AppCode.
 * User: WanThirty
 * Date: 15/7/3
 * Time: 下午2:56
 * To change this template use File | Settings | File Templates.
 */

var ItemGravityPlatform = ItemMovingPlatform.extend({
	_type : game.ObjectType.GravityPlatform,
	_isInit         : false,
	nodePlatform    : null,
	_w              : null,
	_h              : null,

	_posYLimit : null,
	_originPosY : null,
	bornWithPos : function (pos) {
		if (this._isInit) return;
		this._isInit = true;
		this._lastPos = pos;
		game.Data.registerUpdateObj(this);
//		vee.Utils.scheduleCallbackForTarget(this.rootNode, this.updatePos.bind(this));
		var mapConfig = game.Logic.configMap.getObject(this._grid);
		if (!mapConfig) {
			this._posYLimit = this._originPosY;
			this._checkPosWidth = this.boxSize.width/2;
			return;
		}
		var targetGridY = parseInt(mapConfig.name) + this._grid.y;
		this._posYLimit = game.Logic.getTilePosCenterByGrid(cc.p(0, targetGridY)).y;

		var w = mapConfig.width || 3;
		var h = mapConfig.height || 0.5;
		this.nodeBox.setContentSize(cc.size((w)*game.Data.tileSizeWidth ,(h+1)*game.Data.tileSizeWidth));
		var texSize = cc.size((w)*game.Data.tileSizeWidth ,(h)*game.Data.tileSizeWidth);
		this.resetBoxInfo();
		this._checkPosWidth = this.boxSize.width/2;
		this._checkPosHeight = this.boxSize.height/2;

		if (!(w == this._w && h == this._h)) {
			this.nodePlatform.removeAllChildren();
			this._w = w;
			this._w = h;
			var left   = -TILE_WIDTH*w/2 + TILE_WIDTH_HALF;
			var bottom = -TILE_WIDTH*h/2 + TILE_WIDTH_HALF;

			var fileName;
			if (game.LevelData.selectedCategory) {
				var idx = game.LevelData.selectedCategory.idx + 1;
				if (idx > 100) idx -= 100;
				fileName = "res/block_fall_"+idx+".png";
				if(null == res["block_fall_" + idx + "_png"]){
					fileName = "res/block_fall_1.png";
				}
			} else {
				fileName = "res/block_fall_1.png";
			}

			for (var i = 0; i < w; ++i) {
				for (var j = 0; j < h; ++j) {
					var spr = new cc.Sprite(fileName);
					spr.setPosition(cc.p(left + i*TILE_WIDTH, bottom + j*TILE_WIDTH));
					this.nodePlatform.addChild(spr);
				}
			}
		}

		this.resetBoxInfo();
		this._checkPosWidth = this.boxSize.width/2;

		var posOff = cc.p(texSize.width/2-game.Data.tileSizeWidth/2, texSize.height/2-game.Data.tileSizeWidth/2);
		var elePos = vee.Utils.pAdd(pos, posOff);
		this.setElePosition(elePos);
		this._originPosY = elePos.y;
		this._posYLimit += posOff.y;
		this._lastPos = pos;
	},

	_rectEnemy : null,
	updatePos : function(dt) {
		this._dt = dt;
		var oPlayer = game.Data.oPlayerCtl;
		var posPlayer = oPlayer._pos;
		var posPlatform = this.getElePosition();

		if (posPlayer.x < posPlatform.x - this._checkPosWidth || posPlayer.x > posPlatform.x + this._checkPosWidth || oPlayer._speedY > 0) {
			// check X red zone
			if (this._isGetPlayer) oPlayer.jumpSign = false;
			this._isGetPlayer = false;
			game.Data.removeGrabbedPlatform(this);
		} else if (this._isGetPlayer) {
			// let player move on platform
			this.pushTo(vee.Direction.Top, posPlayer, this.getEleRect(), oPlayer);
		} else {
			// check Y red zone
			// cast player position at next frame
			var castSpeedY = oPlayer._speedY;
			var castDt = 0.02;
			castSpeedY += (oPlayer._accY + (oPlayer._jumpSpeedProtect ? 0 : game.Data.G))*castDt;
			if (oPlayer.isLimitY) castSpeedY =  (castSpeedY < game.Data.playerYSpeedLimit ? game.Data.playerYSpeedLimit : castSpeedY);
			// calc safe postion...
			var posNextY = posPlayer.y + castSpeedY*castDt;
			var checkHeight = this.getCheckLine(posPlatform.y);
			var checkHeightPrev = this.getCheckLine(this._lastPos.y);
			if ( oPlayer._speedY <= 0
				&&
				((posNextY <= checkHeight && posPlayer.y >= checkHeight)
				|| (posNextY <= checkHeightPrev && posPlayer.y >= checkHeightPrev)) ) {
				this._isGetPlayer = true;
				game.Data.addGrabbedPlatform(this);
				oPlayer.downToBarrier();
				oPlayer.setJumping(false);
				oPlayer._speedY = 0;
				oPlayer.jumpSign = true;
				this.pushTo(vee.Direction.Top, posPlayer, this.getEleRect(), oPlayer);
			} else {
				this._isGetPlayer = false;
				oPlayer.jumpSign = false;
				game.Data.removeGrabbedPlatform(this);
			}
		}

		this._lastPos = posPlatform;
		this.afterUpdate(dt);
	},

	pushTo : function (dir, posPlayer, rectEnemy, nodeCtl) {
		if (nodeCtl._isSmashing) {
			nodeCtl._speedY = 0;
		}
		nodeCtl.isUpdateY = false;
		nodeCtl.needUpdateState = false;
		nodeCtl.updateState();
		var posOff = this.getPosOff();
		nodeCtl.setElePosition(cc.p(posPlayer.x + posOff.x, rectEnemy.y + rectEnemy.height));
		this.playerOnTop();
	},

	_castPosY : 0,
	_pushed : false,
	playerOnTop : function () {
		if (this._pushed) return;
		this._castPosY = this._container.getPositionY() - 200*this._dt;
		this._castPosY = this._castPosY < this._posYLimit ? this._posYLimit : this._castPosY;
		this._container.setPositionY(this._castPosY);
		this._pos.y = this._castPosY;
		this._pushed = true;
	},

	afterUpdate : function () {
		if (this._pushed) {
			this._pushed = false;
			return;
		}
		this._castPosY = this._container.getPositionY() + 300*this._dt;
		this._castPosY = this._castPosY > this._originPosY ? this._originPosY : this._castPosY;
		this._container.setPositionY(this._castPosY);
		this._pos.y = this._castPosY;
	},

	removeOnGridChange : function () {
		game.Data.removeUpdateObj(this);
	},

	die : function () {
		game.Data.removeUpdateObj(this);
		this.onDead();
		if (this._gridInMap) {
			if (!this._staticItem) {
				game.Logic.dynamicObjMap.setObject(null, this._gridInMap);
			} else {
				game.Logic.objMap.setObject(null, this._gridInMap);
			}
		}
		this._container.removeFromParent();
	}
});