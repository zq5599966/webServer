/**
 * Created with AppCode.
 * User: yop
 * Date: 15/10/30
 * Time: 下午7:02
 * To change this template use File | Settings | File Templates.
 */


LevelController.LevelEvent200 = LevelController.extend({
	eventStory1 : function(grid, dir) {
		this.showStory(1, grid, ""+
			"SelectNpc,Flash;"+
			"FaceTo,right;"+
			"MoveCamera,24,11,2;"+
			"FaceTo,left;"+
			"MoveRole,24,11;"+
			"ShowDialog,"+ vee.Utils.getLocalizedStringForKey("Hey! New face?", "嘿，新面孔？") +";"+
			"ShowDialog,"+ vee.Utils.getLocalizedStringForKey("I hope your brain can still perform its function, you know...", "希望你还是心智正常的，嘛……") +";"+
			"HideDialog;"+
			"FaceTo,right;"+
			"SelectNpc;"+
			"MoveRole,25,11;"+
			"ShowDialog,"+ vee.Utils.getLocalizedStringForKey("Watch out!", "小心！") +";"+
			"ShowDialog,"+ vee.Utils.getLocalizedStringForKey("(Snap)", "（响指）") +";"+
			"HideDialog;"+
			"Trigger,3,3;"+
			"ShowDialog,"+ vee.Utils.getLocalizedStringForKey("It's dangerous okay?", "拜托，这很危险的（省略三千字）") +";"+
			"HideDialog;"+
			"Delay,1;"+
			"UnlockRole;"+
			"SelectNpc,Flash;"+
			"FaceTo,left;"+
			"ShowDialog,"+ vee.Utils.getLocalizedStringForKey("Okay, we need a face-to-face conversation.", "好吧，也许我们需要面谈一下。") +";"+
			"ShowDialog,"+ vee.Utils.getLocalizedStringForKey("(Snap) Come on! Make your way over there!", "（响指）试着做点什么吧！") +";"+
			"HideDialog;"+
			"TimeLine,huxi_2;"+
			"Delay,1;"+
			"Trigger,4,3;"+
			"MoveCamera,21,16,1;"+
			"MoveCamera,24,11,1"+
		"");
	},

	eventStory2 : function(grid, dir) {
		this.showStory(2, grid, ""+
			"SelectNpc;"+
			"FaceTo,right;"+
			"MoveCamera,27,11,2;"+
			"ShowDialog,"+ vee.Utils.getLocalizedStringForKey("Flash just chatted with me. My apologies.", "闪电猫跟我亲切交谈了一下。我向你道歉。") +";"+
			"ShowDialog,"+ vee.Utils.getLocalizedStringForKey("Take these as a gift -- and please stay calm.", "作为礼物，收下这些。请保持神志清醒哦。") +";"+
			"HideDialog;"+
			"Trigger,32,12"+
		"");
	}
});