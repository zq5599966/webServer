/**
 * Created with AppCode.
 * User: WanThirty
 * Date: 15/10/29
 * Time: 下午5:09
 * To change this template use File | Settings | File Templates.
 */

var LyGameOverMini = vee.Class.extend({
	nodeTL : null,
	nodeTR : null,

	btnRetry : null,
	btnQuit : null,
	btnAd : null,
	ccbAvatarStore : null,

	lbTargetCoin    : null,
	lbCoinNum       : null,
	lbCoinPerfect   : null,
	spCoinProgress  : null,
	spAvatarHead    : null,
	spCoinIcon      : null,
	nodeProgressDesc : null,
	nodeProgress    : null,

	oCoinCtl        : null,
	oGettedCoinCtl  : null,
	lyNormalBG      : null,
	ly3starBG       : null,
	lyMiniBG        : null,
	ccbRecord       : null,
	unlockedIdx : -1,

	coinStartPos : null,
	coinPos : cc.p(507,297),

	// for progress animate
	_coin : 0,
	_gettedCoin : 0,
	_nextAvatar : null,
	_isUnlock : false,

	onCreate : function () {
		if (!VeeRecordButton.isPluginRecording) {
			this.ccbRecord.setVisible(false);
		}
		game.Data.oLyGameOver = this;
		vee.Audio.playEffect(res.inGame_function_lose_mp3);
		// check save point
		var idx = game.Data.getSavePointIdx();
		if (idx != game.Data.performingTMXIdx) {
		}
		// add coin
		game.LevelData.save();
		this.handleKey(true);
	},

	onKeyBack : function(){
		this.onQuit();
		return true;
	},

	onExit : function () {
		game.Data.oLyGameOver = null;
		cc.spriteFrameCache.removeSpriteFramesFromFile(res.item_coin_frames_plist);
		cc.spriteFrameCache.removeSpriteFramesFromFile(res.item_plist);
	},

	ccbInit : function () {

	},
	onLoaded : function () {

		if(game.Data.isAndroid && game.Data.version.isAutoSave){
			vee.GameCenter.autoSaveGame(jsb.fileUtils.getWritablePath(), "autoSave");
		}

		cc.log("MINI OVER onLoaded");
		vee.Controller.clearAll();
		if (game.Data.isFreeGame) {
			cc.log("zq debug lygameovermini onloaded");
			vee.Ad.showInterstitialByOnlineConfig("mini_over");
			vee.Analytics.UGameEvent.showAdEvent("mini_over", "interstial");
		}
		vee.Audio.stopMusic();
		// set start up timeline
		if (game.Data.version.isKTPlay) {
			this.playAnimate("LoseKTPlay");
		} else {
			this.playAnimate("LoseMini");
		}
		vee.PopMgr.setNodePos(this.nodeTL, vee.PopMgr.PositionType.TopLeft);
		vee.PopMgr.setNodePos(this.nodeTR, vee.PopMgr.PositionType.TopRight);

		this.spCoinProgress.getTexture().setAliasTexParameters();
		// preset for progress animate...
		this._coin = game.LevelData.getCoin();
		this._gettedCoin = game.Data.getTempCoin();
		// set default display
		var targetAvatar = game.AvatarData.getNextAvatar();
		var rate = 1;
		if (targetAvatar) {
			this._coinFrameName = targetAvatar.coinFrame;
			this.spAvatarHead.setTexture(targetAvatar.headName);
			this.setProgressEnable(true);
			LyGameOver.targetCoin = targetAvatar.price;
			rate = this._coin / targetAvatar.price;
			this.spCoinProgress.setScaleX(rate*this._maxPercent);
			// for progress animate
			this._nextAvatar = targetAvatar;
			// cast unlock
			game.LevelData.addCoin(this._gettedCoin);
			var coin = game.LevelData.getCoin();
			if (coin >= targetAvatar.price) {
				game.LevelData.costCoin(coin);

				// game.AvatarData.avatarPurchased(targetAvatar.idx);
				// this.unlockedIdx = targetAvatar.idx;

				//add by zq :历史遗留问题 fuck
				var tmpIdx = targetAvatar.idx;
				if(tmpIdx >= 11){
					tmpIdx = tmpIdx - 1;
				}
				game.AvatarData.avatarPurchased(tmpIdx);
				vee.Analytics.UGameEvent.unlockRoleEvent("coin", tmpIdx);
				this.unlockedIdx = tmpIdx;
				//end

				game.Data.setUnlocking(false);
				this._isUnlock = true;
			} else {
				this._isUnlock = false;
			}
			this.spCoinIcon.setSpriteFrame(targetAvatar.coinFrame);
		} else {
			this._isUnlock = false;
			this.setProgressEnable(false);
		}
		// default coin display
		this.oCoinCtl = vee.ScoreController.registerController(this.lbTargetCoin, this._coin, LyGameOver.formatFunc);
		this.oGettedCoinCtl = vee.ScoreController.registerController(this.lbCoinNum, this._gettedCoin);
		this.lbCoinPerfect.setVisible(false);
		game.Data.oLyGame.hideUI();
		game.LevelData.save();
		if (game.LevelData.selectedCategory) {
			vee.Analytics.logMissionFailed("LevelMini" + game.Data.performingTMXIdx);
		}

		if (this.btnKTPlay) {
			if (game.Data.isIOSCN || game.Data.isAndroid)
				this.btnKTPlay.setVisible(true);
			else
				this.btnKTPlay.setVisible(false);
		}

	},

	initController : function () {
		// selector...
		vee.Controller.initSelector(1,1,this.onQuit.bind(this),cc.p(0,0));
		vee.Controller.registerItemByButton(this.btnRetry, cc.p(0,0), this.onRetry.bind(this), "res/mfi_pause_btn_big.png");
		vee.Controller.activeSelector();

		// button action....
		if (vee.Utils.isRecordAvaliable()) {
			var btnRecordCtl = this.ccbRecord.controller;
			vee.Controller.registerButtonAction(
				[vee.KeyCode.AXIS_LEFT_TRIGGER,vee.KeyCode.BUTTON_LEFT_SHOULDER],
				btnRecordCtl.onTouch.bind(btnRecordCtl)
			);
		}
	},

	// ccb button bindings...
	onRetry : function () {
		vee.Audio.playEffect(res.inGame_menu_click_mp3);
//		if (game.Data.costEnergy()) {
			vee.Transition.out(res.MapTransition_ccbi, function () {
				this._openGame(false);
			}.bind(this));
//		} else {
//			AlertFillEnergy.show();
//		}
		vee.Controller.deactiveSelector();
	},

	onQuit : function () {
		vee.Transition.out(res.MapTransition_ccbi, function () {
			LyLevelSelect.show();
		});
		vee.Controller.deactiveSelector();
	},

	onKTPlay : function () {
		vee.KTPlay.show();
	},

	startProgress : function () {
		this._progressAnimate();
	},

	_openGame : function(isSavePoint) {
		vee.PopMgr.closeAll();
		cc.director.purgeCachedData();
		var node = vee.PopMgr.popCCB("res/veeGameLayer.ccbi");
		cc.log('opening level: ' + game.Data.performingTMXIdx);
		game.Data.oLyGame.onLoaded();
		game.Data.oLyGame.initStage(game.Data.performingTMXIdx, isSavePoint, game.StageType.Mini);
	},

	_progressEnable : true,
	setProgressEnable : function (isEnable) {
		this._progressEnable = isEnable;
		this.nodeProgress.setVisible(isEnable);
		this.nodeProgressDesc.setVisible(isEnable);
	},

	_maxPercent : 42,
	_progressAnimate : function () {
		if (!this._progressEnable) return;
		// preset arguments...
		if (this._nextAvatar) {
			this.spAvatarHead.setTexture(this._nextAvatar.headName);
			var targetCoin = this._nextAvatar.price;
			LyGameOver.targetCoin = targetCoin;
			if (this._isUnlock) {
				// refresh coin
				var coinOff = targetCoin - this._coin;
				this._showCoinParticle(coinOff);
			} else {
				// refresh coin
				this._showCoinParticle(this._gettedCoin);
			}
		}
	},

	_coinOff : 0,
	_coinCount : 0,
	_coinItr : 0,
	_coinFrameName : null,
	_showCoinParticle : function (coinOff) {
		this._coinOff = coinOff;
		if (coinOff > 40) {
			this._coinItr = Math.ceil(coinOff / 40);
		} else {
			this._coinItr = 1;
		}
		this._coinCount = 0;
		this.coinStartPos = vee.Utils.pAdd(this.lbCoinNum.getPosition(), this.nodeTR.getPosition());
		vee.Utils.scheduleCallbackForTarget(this.nodeTR, this.updateShowCoin.bind(this), 0.05);
	},

	updateShowCoin : function (dt) {
		if (this._coinOff > 0) {
			if (this._coinItr > this._coinOff) {
				this._coinItr = this._coinOff;
			}
			this._coinOff -= this._coinItr;
			this._gettedCoin -= this._coinItr;
			this.oGettedCoinCtl.setNumber(this._gettedCoin);
			this._coinCount += this._coinItr;
			//TODO:: change head by avatar and use pool to recycle
			var sp = new cc.Sprite("#"+this._coinFrameName);
			sp.setPosition(this.coinStartPos);
			sp.itr = this._coinItr;
			if (this._coinOff <= 0) sp.isOver = true;
			sp.runAction(cc.sequence(
				cc.jumpTo(0.5, this.coinPos.x, this.coinPos.y, 100, 1),
				cc.callFunc(function () {
					this._coin += sp.itr;
					this.oCoinCtl.setNumber(this._coin);
					this.spCoinProgress.stopAllActions();
					this.spCoinProgress.runAction(cc.scaleTo(0.04, this._coin/LyGameOver.targetCoin*this._maxPercent, 1));
					if (sp.isOver && this.unlockedIdx >= 0) {
						LyUnlock.show(this.unlockedIdx);
						this.oCoinCtl.setNumber(LyGameOverMini.targetCoin);
					}
					sp.removeFromParent();
					vee.Audio.playEffect(res.inGame_function_countCoins_mp3);
				}.bind(this))
			));
			this.rootNode.addChild(sp, 10);
		} else {
			vee.Utils.unscheduleAllCallbacksForTarget(this.nodeTR);
		}
	},

	changeAvatar : function (idx) {

	}
});

LyGameOverMini.targetCoin = null;

LyGameOverMini.formatFunc = function (label, displayValue, str) {
	label.setString(displayValue+" / "+LyGameOverMini.targetCoin);
};

LyGameOverMini.show = function () {
	var node = vee.PopMgr.popCCB(res.GameOverMini_ccbi, {alpha:0});
	node.controller.ccbInit();
};