/**
 * Created with AppCode.
 * User: WanThirty
 * Date: 15/6/24
 * Time: 下午6:54
 * To change this template use File | Settings | File Templates.
 */

var LyDynamicBG = vee.Class.extend({
	dynamicObj1 : null,

	bgName : null,

	_posPrev : null,
	_posNext : null,
	setOffset : function(offset) {
		if (this.dynamicObj1) {
			this._posPrev = this.dynamicObj1.getPosition();
			this._posNext = vee.Utils.pAdd(this._posPrev, cc.p(offset.x * 0.2, offset.y * 0.1));
			this.dynamicObj1.setPosition(this.safePos(this._posNext));
		}

//		var objs = this.bg1.getChildren();
//		for (var i in objs) {
//			var obj = objs[i];
//			obj.setPosition(vee.Utils.pAdd(obj.getPosition(), cc.p(offset.x * 0.6, offset.y * 0.6)));
////			obj.setPositionX(obj.getPositionX() + offset.x * 0.8);
//			this.safePos(obj);
//		}
//		objs = this.bg2.getChildren();
//		for (var i in objs) {
//			var obj = objs[i];
//			obj.setPosition(vee.Utils.pAdd(obj.getPosition(), cc.p(offset.x * 0.02, offset.y * 0.1)));
//			this.safePos(obj);
//		}
//		objs = this.bg3.getChildren();
//		for (var i in objs) {
//			var obj = objs[i];
//			obj.setPosition(vee.Utils.pAdd(obj.getPosition(), cc.p(offset.x * 0.01, offset.y * 0.1)));
//			this.safePos(obj);
//		}
	},

	_objSize : null,
	safePos : function (pos) {
		pos.x = pos.x > 0 ? 0 : pos.x;
		pos.y = pos.y > 0 ? 0 : pos.y;
		return pos;
	},

	disappear : function () {
		game.Data.isChangingBG = true;
		this.rootNode.removeFromParent();
		game.Data.isChangingBG = false;
	}
});

LyDynamicBG.create = function (bgName) {
    var node = cc.BuilderReader.load("res/"+bgName+".ccbi");
	node.controller.name = bgName;
	return node;
}