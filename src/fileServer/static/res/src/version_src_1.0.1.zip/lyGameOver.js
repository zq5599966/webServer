/**
 * Created with AppCode.
 * User: WanThirty
 * Date: 15/9/10
 * Time: 下午5:22
 * To change this template use File | Settings | File Templates.
 */

var LyGameOver = vee.Class.extend({
	nodeTL : null,
	nodeTR : null,
	nodeL : null,

	btnRetry : null,
	btnRevive : null,
	btnQuit : null,
	btnAd : null,
	btnKTPlay : null,
	lbReviveCost : null,
	spBtnReviveLight : null,
	spProgressCoin : null,

	lbTargetCoin    : null,
	lbCoinNum       : null,
	lbCoinPerfect   : null,
	spCoinProgress  : null,
	spAvatarHead    : null,
	spCoinIcon      : null,
	nodeProgressDesc : null,
	nodeProgress    : null,

	oCoinCtl        : null,
	oGettedCoinCtl  : null,
	lyNormalBG      : null,
	ly3starBG       : null,
	lyMiniBG        : null,
	spHero          : null,
	ccbRecord       : null,

	coinStartPos : null,
	coinPos : cc.p(507,297),
	unlockedIdx : -1,

	_canRevive : null,

	// for progress animate
	_coin : 0,
	_gettedCoin : 0,
	_nextAvatar : null,
	_isUnlock : false,
	_showReward : true,

	onCreate : function () {
		if (!VeeRecordButton.isPluginRecording) {
			this.ccbRecord.setVisible(false);
		}
		game.Data.addMiniCount();
		game.Data.oLyGameOver = this;
		vee.Audio.playEffect(res.inGame_function_lose_mp3);
		// check save point
		var idx = game.Data.getSavePointIdx();
		if (idx == game.Data.performingTMXIdx) {
			this._canRevive = true;
		}
		// add coin
		game.LevelData.save();
		this.handleKey(true);
	},

	onKeyBack : function(){
		this.onQuit();
		return true;
	},

	onExit : function () {
		game.Data.oLyGameOver = null;
		cc.spriteFrameCache.removeSpriteFramesFromFile(res.item_coin_frames_plist);
		cc.spriteFrameCache.removeSpriteFramesFromFile(res.item_plist);
	},

	onloadEvent : function () {
		var node = LyAvatarStore.load();
		this.rootNode.addChild(node);
		node.controller.onLoaded();

		// set start up timeline
		if (game.Data.version.isKTPlay && this.btnKTPlay) {
			this.playAnimate("LoseKTPlay");
		} else {
			this.playAnimate("LoseNoAd");
		}
		vee.PopMgr.setNodePos(this.nodeTL, vee.PopMgr.PositionType.TopLeft);
		vee.PopMgr.setNodePos(this.nodeTR, vee.PopMgr.PositionType.TopRight);
		vee.PopMgr.setNodePos(this.nodeL, vee.PopMgr.PositionType.Left);

		this.spCoinProgress.getTexture().setAliasTexParameters();
		// preset for progress animate...
		this._coin = game.LevelData.getCoin();
		this._gettedCoin = game.Data.getTempCoin();
		// set default display
		var targetAvatar = game.AvatarData.getNextAvatar();
		var rate = 1;
		if (targetAvatar) {
			this._coinFrameName = targetAvatar.coinFrame;
			this.spAvatarHead.setTexture(targetAvatar.headName);
			this.setProgressEnable(true);
			LyGameOver.targetCoin = targetAvatar.price;
			rate = this._coin / targetAvatar.price;
			this.spCoinProgress.setScaleX(rate*this._maxPercent);
			// for progress animate
			this._nextAvatar = targetAvatar;
			// cast unlock
			game.LevelData.addCoin(this._gettedCoin);
			if (this._gettedCoin == 0) this._progressEnable = false;
			var coin = game.LevelData.getCoin();
			if (coin >= targetAvatar.price) {
				game.LevelData.resetCoin(coin);

				// game.AvatarData.avatarPurchased(targetAvatar.idx);
				// this.unlockedIdx = targetAvatar.idx;

				//add by zq :历史遗留问题 fuck
				var tmpIdx = targetAvatar.idx;
				if(tmpIdx >= 11){
					tmpIdx = tmpIdx - 1;
				}
				game.AvatarData.avatarPurchased(tmpIdx);

				vee.Analytics.UGameEvent.unlockRoleEventParam("coin", tmpIdx);

				this.unlockedIdx = tmpIdx;
				//end

				game.Data.setUnlocking(false);
				this._isUnlock = true;
			} else {
				this._isUnlock = false;
			}
			this.spCoinIcon.setSpriteFrame(targetAvatar.coinFrame);
		} else {
			this._isUnlock = false;
			this.setProgressEnable(false);
		}

		if (game.Data.checkIs61()) {
			if (game.Data.oPlayerCtl.ccbName == game.RoleNameStrData.Fox) {
				this.spHero.setTexture(res.hero_dead_Fox2_png);
			} else if (game.Data.oPlayerCtl.ccbName == game.RoleNameStrData.SmallFox) {
				this.spHero.setTexture(res.hero_dead_Fox1_png);
			}
		}
		else if(game.Data.checkIsMidAutumn()){
			this.spHero.setTexture(res.hero_dead_14_rabbit_png);
		}
		else if(game.Data.checkIsHolloween()){
			var dieName = game.AvatarData.getAvatarData(13).dieName;
			this.spHero.setTexture(dieName);
		}
		else if(game.Data.checkIsThanksgiving()){
			var dieName = game.AvatarData.getAvatarData(14).dieName;
			this.spHero.setTexture(dieName);
		}
		else {
			var data = game.AvatarData.getCurrentAvatar();
			if (data) {
				this.spHero.setTexture(data.dieName);
			}
		}

		// default coin display
		this.oCoinCtl = vee.ScoreController.registerController(this.lbTargetCoin, this._coin, LyGameOver.formatFunc);
		this.oGettedCoinCtl = vee.ScoreController.registerController(this.lbCoinNum, this._gettedCoin);
		// calc is stage coin all collected
		this.lbCoinPerfect.setVisible(false);
		game.LevelData.save();
		if (game.LevelData.selectedCategory) {
			var category = game.LevelData.selectedCategory.idx + 1;
			var level = game.LevelData.selectedLevel.idx + 1;
			vee.Analytics.logMissionFailed("Level" + (category-100) + "-" + level + "R");
		}

		if (this.btnKTPlay) {
			this.btnKTPlay.setVisible(game.Data.version.isKTPlay);
		}
	},

	onLoaded : function () {
		if(game.Data.isAndroid && game.Data.version.isAutoSave){
			vee.GameCenter.autoSaveGame(jsb.fileUtils.getWritablePath(), "autoSave");
		}

		vee.Controller.clearAll();

		/*
		if(game.Data.willShowVideoAd){
			vee.Ad.showRevivalVideoAd(this.onloadEvent.bind(this));
			return;
		}
		else if (game.Data.isFreeGame) {
			cc.log("zq debug lygameover onloaded");
			vee.Ad.showInterstitialByOnlineConfig("game_over");
		}
		*/
		if (game.Data.isFreeGame && !game.Data.shownVideoAd) {
			cc.log("zq debug lygameover onloaded");
			vee.Ad.showInterstitialByOnlineConfig("game_over");
			vee.Analytics.UGameEvent.showAdEvent("game_over", "interstial");

			// vee.Ad.showNative();

		}



		game.Data.shownVideoAd = false;

		this.onloadEvent();

	},

	showBanner : function () {
		vee.Ad.showBannerAd();
		cc.log("zq debug show native ad");
	},

	initController : function () {
		// selector...
		vee.Controller.initSelector(1,2,this.onQuit.bind(this),cc.p(0,1));
		vee.Controller.registerItemByButton(BtnShop.instance.btnOpenStore, cc.p(0,0), this.ccbAvatarStore.controller.onOpenStore.bind(this), res.mfi_home_avatar_on_png);
		vee.Controller.registerItemByButton(this.btnRetry, cc.p(0,1), this.onRetry.bind(this), "res/mfi_pause_btn_big.png");
		vee.Controller.activeSelector();

		// button action...
		if (vee.Utils.isRecordAvaliable()) {
			var btnRecordCtl = this.ccbRecord.controller;
			vee.Controller.registerButtonAction(
				[vee.KeyCode.AXIS_LEFT_TRIGGER,vee.KeyCode.BUTTON_LEFT_SHOULDER],
				btnRecordCtl.onTouch.bind(btnRecordCtl)
			);
		}
		var btnStoreCtl = this.ccbAvatarStore.controller;
		vee.Controller.registerButtonAction(
			[vee.KeyCode.AXIS_RIGHT_TRIGGER,vee.KeyCode.BUTTON_RIGHT_SHOULDER],
			btnStoreCtl.onOpenStore.bind(btnStoreCtl)
		);
		vee.Controller.activeButton();
	},

	onRetry : function () {
		vee.Audio.playEffect(res.inGame_menu_click_mp3);
		if (game.Data.costEnergy()) {
			this.loseRetry();
		} else {
			game.Data.onEnergyEmpty(game.LifeEmptyType.Lose);
		}

		vee.Ad.hideBannerAd();

		vee.Controller.clearAll();
		vee.Controller.deactiveSelector();
	},

	//jin
	loseRetry : function() {
		game.Data.isResetSkip = false;
		EfxCostEnergy.show(this.btnRetry.getPosition(), this.rootNode);
		vee.Transition.out(res.MapTransition_ccbi, function () {
			this._openGame(this._canRevive);
		}.bind(this));
		++game.Data.retryCount;
	},

	onQuit : function () {
		vee.Transition.out(res.MapTransition_ccbi, function () {
			LyLevelSelect.show();
		});

		vee.Ad.hideBannerAd();

		vee.Controller.deactiveSelector();
	},

	onAd : function () {
		//TODO:: show ad!
	},

	onKTPlay : function () {
		vee.KTPlay.show();
	},

	startProgress : function () {
		this._progressAnimate();
	},

	_openGame : function(isSavePoint) {
		vee.PopMgr.closeAll();
		cc.director.purgeCachedData();
		var node = vee.PopMgr.popCCB("res/veeGameLayer.ccbi");
		cc.log('opening level: ' + game.Data.performingTMXIdx);
		game.Data.oLyGame.onLoaded();
		game.Data.oLyGame.initStage(game.Data.performingTMXIdx, isSavePoint);
	},

	_progressEnable : true,
	setProgressEnable : function (isEnable) {
		this._progressEnable = isEnable;
		this.nodeProgress.setVisible(isEnable);
		this.nodeProgressDesc.setVisible(isEnable);
	},

	_maxPercent : 42,
	_progressAnimate : function () {
		if (!this._progressEnable) {
			if (this._nextAvatar) {
				if (this._showReward) {
					//LyReward.showLogic(false, this._nextAvatar.price - this._coin);
					this._showReward = false;
				}
			}
			return;
		}
		// preset arguments...
		if (this._nextAvatar) {
			this.spAvatarHead.setTexture(this._nextAvatar.headName);
			var targetCoin = this._nextAvatar.price;
			LyGameOver.targetCoin = targetCoin;
			if (this._isUnlock) {
				// refresh coin
				var coinOff = targetCoin - this._coin;
				this._showCoinParticle(coinOff);
			} else {
				// refresh coin
				this._showCoinParticle(this._gettedCoin);
			}
		}
	},

	_coinOff : 0,
	_coinCount : 0,
	_coinItr : 0,
	_coinFrameName : null,
	_showCoinParticle : function (coinOff) {
		this._coinOff = coinOff;
		if (coinOff > 40) {
			this._coinItr = Math.ceil(coinOff / 40);
		} else {
			this._coinItr = 1;
		}
		this._coinCount = 0;
		this.coinStartPos = vee.Utils.pAdd(this.lbCoinNum.getPosition(), this.nodeTR.getPosition());
		vee.Utils.scheduleCallbackForTarget(this.nodeTR, this.updateShowCoin.bind(this), 0.05);
	},

	updateShowCoin : function (dt) {
		if (this._coinOff > 0) {
			if (this._coinItr > this._coinOff) {
				this._coinItr = this._coinOff;
			}
			this._coinOff -= this._coinItr;
			this._gettedCoin -= this._coinItr;
			this.oGettedCoinCtl.setNumber(this._gettedCoin);
			this._coinCount += this._coinItr;
			var sp = new cc.Sprite("#"+this._coinFrameName);
			sp.setPosition(this.coinStartPos);
			sp.itr = this._coinItr;
			if (this._coinOff <= 0) sp.isOver = true;
			sp.runAction(cc.sequence(
				cc.jumpTo(0.5, this.coinPos.x, this.coinPos.y, 100, 1),
				cc.callFunc(function () {
					this._coin += sp.itr;
					this.oCoinCtl.setNumber(this._coin);
					this.spCoinProgress.stopAllActions();
					this.spCoinProgress.runAction(cc.scaleTo(0.04, this._coin/LyGameOver.targetCoin*this._maxPercent, 1));
					if (sp.isOver) {
						if (this.unlockedIdx >= 0) {
							LyUnlock.show(this.unlockedIdx);
							this.oCoinCtl.setNumber(LyGameOver.targetCoin);
						}
						//} else {
						//	// show reward
						//	if (this._showReward) {
						//		cc.log("显示1");
						//		LyReward.showLogic(false, this._nextAvatar.price - this._coin);
						//		this._showReward = false;
						//	}
						//}
					}
					sp.removeFromParent();
					vee.Audio.playEffect(res.inGame_function_countCoins_mp3);
				}.bind(this))
			));
			this.rootNode.addChild(sp, 10);
		} else {
			vee.Utils.unscheduleAllCallbacksForTarget(this.nodeTR);
		}
	},

	changeAvatar : function (idx) {
		var data = game.AvatarData.getAvatarData(idx);
		if (data) {
			this.spHero.setTexture(data.dieName);
		}
	}
});

LyGameOver.targetCoin = null;

LyGameOver.formatFunc = function (label, displayValue, str) {
	label.setString(displayValue+" / "+LyGameOver.targetCoin);
};