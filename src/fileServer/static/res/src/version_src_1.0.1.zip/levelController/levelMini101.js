/**
 * Created with AppCode.
 * User: yop
 * Date: 15/10/30
 * Time: 下午7:02
 * To change this template use File | Settings | File Templates.
 */


LevelController.LevelMini101 = LevelController.extend({
	eventStory1 : function(grid, dir) {
		this.showStory(1, grid, ""+
			"RemoveEnemy;"+
			"SelectNpc;"+
			"FaceTo,left;"+
			"MoveCamera,33,16,2;"+
			"ShowDialog,"+ vee.Utils.getLocalizedStringForKey("Nice! You found me!", "不错，你找到我了！") +";"+
			"ShowDialog,"+ vee.Utils.getLocalizedStringForKey("Get your bonus here!", "来拿你的奖励吧！") +";"+
			"HideDialog;"+
			"TimeLine,huxi_2;"+
			"Delay,1;"+
			"AddCoin," + vee.Utils.getObjByPlatform('100','100','100') + ";"+
			"Delay,2;"+
			"GameOver"+
		"");
	}
});