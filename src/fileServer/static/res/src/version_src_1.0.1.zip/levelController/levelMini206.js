/**
 * Created with AppCode.
 * User: yop
 * Date: 15/10/27
 * Time: 下午3:33
 * To change this template use File | Settings | File Templates.
 */

LevelController.LevelMini206 = LevelController.extend({
	eventStory1 : function(grid, dir) {
		this.showStory(1, grid, ""+
		"RemoveEnemy;"+
		"MoveCamera,20,19,1;"+
		"SelectNpc;"+
		"ShowDialog,"+ vee.Utils.getLocalizedStringForKey("There's no time for talking. Take this -- and go!","没时间废话了！跟！我！走！") +";"+
		"HideDialog;"+
		"TimeLine,huxi_2;"+
		"Delay,1;"+
		"AddCoin," + vee.Utils.getObjByPlatform('250','500','250') + ";"+
		"Delay,1;"+
		"GameOver"+
		"");
	}
});
