/**
 * Created with AppCode.
 * User: WanThirty
 * Date: 15/10/28
 * Time: 上午11:11
 * To change this template use File | Settings | File Templates.
 */

var EfxHideBlockIn = vee.Class.extend({
	ccbInit : function () {
		this.playAnimate("show", function () {
			this.rootNode.removeFromParent();
		}.bind(this));
	}
});

EfxHideBlockIn.show = function (pos) {
	var node = cc.BuilderReader.load(res.efx_HideBlockIn_ccbi);
	node.controller.ccbInit();
	node.setPosition(pos);
	game.Data.oLyGame.lyMap.addChild(node, 8);
};