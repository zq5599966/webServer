/**
 * Created with AppCode.
 * User: WanThirty
 * Date: 15/7/7
 * Time: 上午11:48
 * To change this template use File | Settings | File Templates.
 */

var LyPosSetting = vee.Class.extend({
	spLeft : null,
	btnReset : null,
	btnDone : null,
	btnScale : null,
	btnChangeType : null,
	ccbDisplay : null,

	nodeTL : null,
	nodeTR : null,
	nodeContainer : null,
	lyTouch : null,

	lbControlType : null,
	lbDesc : null,

	_scaleRate : 1,

	onCreate : function () {
		this.handleKey(true);
	},

	onKeyBack : function(){
		this.onDone();
		return true;
	},

	ccbInit : function () {
		vee.GestureController.registerController(this.lyTouch, this, true);
		vee.PopMgr.setNodePos(this.nodeTL, vee.PopMgr.PositionType.TopLeft);
		vee.PopMgr.setNodePos(this.nodeTR, vee.PopMgr.PositionType.TopRight);
		if (game.Data.btnMovePos) {
			var btn = this.nodeContainer.getChildByTag(1);
			btn.setPosition(game.Data.btnMovePos);
			btn = this.nodeContainer.getChildByTag(2);
			btn.setPosition(game.Data.btnDropPos);
			btn = this.nodeContainer.getChildByTag(3);
			btn.setPosition(game.Data.btnJumpPos);
		} else {
			this.onReset();
		}
		var isGesture = game.Data.isGestureControl();
		this._setType(isGesture);
		var isSmall = game.Data.isSmallButton();
		this._setSize(isSmall);
	},

	_setType : function (isGesture) {
		if (isGesture) {
			this.lbControlType.setString(vee.Utils.getLocalizedStringForKey("GESTURE"));
			this.lbDesc.setString(vee.Utils.getLocalizedStringForKey("Hold your finger to the screen to jump higher."));
			this.playAnimate("B");
			this.ccbDisplay.controller.showAnimate();
		} else {
			this.lbControlType.setString(vee.Utils.getLocalizedStringForKey("BUTTON"));
			this.lbDesc.setString(vee.Utils.getLocalizedStringForKey("Move these buttons as you like."));
			this.playAnimate("A");
		}
	},

	_setSize : function (isSmall) {
		if (isSmall) {
			this.btnScale.setBackgroundSpriteForState(cc.Scale9Sprite.create(res.btn_custom_1x_png), cc.CONTROL_STATE_NORMAL);
			this._resetBtnScale(game.Data.smallButtonRate);
		} else {
			this.btnScale.setBackgroundSpriteForState(cc.Scale9Sprite.create(res.btn_custom_2x_png), cc.CONTROL_STATE_NORMAL);
			this._resetBtnScale(1);
		}
	},

	_resetBtnScale : function (scale) {
		this._scaleRate = scale;
		for (var i = 1; i < 4; ++i) {
			var btn = this.nodeContainer.getChildByTag(i);
			if (btn) {
//				btn.setScale(scale);
				btn.stopAllActions();
				btn.runAction(cc.EaseElasticOut.create(cc.scaleTo(0.3, scale), 1));
			}
		}
	},

	onDone : function () {
		for (var i = 1; i < 4; ++i) {
			var btn = this.nodeContainer.getChildByTag(i);
			vee.data["btnpos"+i] = ""+btn.getPositionX()+","+btn.getPositionY();
		}
		vee.saveData();
		vee.PopMgr.closeLayer();
		if (game.Data.oLyGame) {
			game.Data.oLyGame.resetGestureControl();
			game.Data.oLyGame.resetButtonSize();
			game.Data.oLyGame.resetButtonState();
		}
	},

	onReset : function () {
		var isSmall = game.Data.isSmallButton();
		var btn = this.nodeContainer.getChildByTag(1);
		vee.PopMgr.setNodePos(btn, vee.PopMgr.PositionType.BottomLeft);
//		if (isSmall) {
//			var size = btn.getContentSize();
//			var newpos = btn.getPosition();
//			btn.setPosition(cc.p(newpos.x - size.width/4, newpos.y - size.height/4));
//		}
		btn = this.nodeContainer.getChildByTag(3);
		vee.PopMgr.setNodePos(btn, vee.PopMgr.PositionType.BottomRight);
		var pos = cc.p(btn.getPosition().x, btn.getPosition().y);
//		if (isSmall) {
//			var size = btn.getContentSize();
//			var newpos = btn.getPosition();
//			btn.setPosition(cc.p(newpos.x + size.width/4, newpos.y - size.height/4));
//		}
		btn = this.nodeContainer.getChildByTag(2);
		btn.setPosition(vee.Utils.pAdd(pos, cc.p(-btn.getContentSize().width, 0)));
//		if (isSmall) {
//			var size = btn.getContentSize();
//			var newpos = btn.getPosition();
//			btn.setPosition(cc.p(newpos.x + size.width/2, newpos.y - size.height/4));
//		}
	},

	onChangeType : function () {
		var isGesture = !game.Data.isGestureControl();
		game.Data.setGestureControl(isGesture);
		this._setType(isGesture);
	},

	onScale : function () {
		var isSmall = !game.Data.isSmallButton();
		game.Data.setSmallButton(isSmall);
		this._setSize(isSmall);
	},

	_arrTouchedBtn : null,
	onGestureBegin : function (ctx) {
		if (game.Data.isGestureControl()) {
			return false;
		}
		this._arrTouchedBtn = [];
		var touchPos = ctx.getBeginPoint();
		for (var i = 1; i < 4; ++i) {
			var btn = this.nodeContainer.getChildByTag(i);
			if (btn) {
				var btnPos = btn.getPosition();
				var btnSize = btn.getContentSize();
				btnSize.width = btnSize.width*this._scaleRate;
				btnSize.height = btnSize.height*this._scaleRate;
				var btnRect = cc.rect(btnPos.x - btnSize.width/2, btnPos.y - btnSize.height/2, btnSize.width, btnSize.height);
				if (cc.rectContainsPoint(btnRect, touchPos)) {
					this._arrTouchedBtn.push(btn);
					break;
				}
			}
		}
		return true;
	},

	onGestureMove : function (ctx, off) {
		for (i in this._arrTouchedBtn) {
			var btn = this._arrTouchedBtn[i];
			btn.setPosition(vee.Utils.pAdd(btn.getPosition(), off));
		}
	},

	onGestureLeave : function (ctx) {
		this._arrTouchedBtn = null;
	}
});

LyPosSetting.show = function () {
	var node = vee.PopMgr.popCCB(res.lyPosSetting_ccbi, true);
	node.controller.ccbInit();
};

var LyGestureDisplay = vee.Class.extend({
	showAnimate : function () {
		this.playAnimate("show");
	}
});