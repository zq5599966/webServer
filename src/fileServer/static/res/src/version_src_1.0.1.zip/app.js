
if (vee.GameModule) {
	vee.GameModule.MainLayer.extend({
		ccbSelectLayer : null,

		onLoaded : function() {
			this.ccbSelectLayer.controller.onLoaded();
		},
		onKeyBack : function(){
			if (!LyAvatarStore.isShow) {
				vee.onKeyBack();
			}
		},

		onSetting : function () {
			LyPosSetting.show();
		}
	});

	vee.GameModule.OverLayer.extend({
		getShareContent : function() {
			return "这才是真正的 分享字符串";
		}
	});

	vee.GameModule.SceneMgr.openOver = function(){
		cc.log("game.Data.stageType = "+game.Data.stageType);
		if (game.Data.stageType == game.StageType.Mini) {
			LyGameOverMini.show();
		} else {
			// vee.PopMgr.closeAll();
			// var ctlOver = vee.PopMgr.popCCB(this.overFile, true);
			// ctlOver.setVisible(false);
			// if (game.Data.oLyGameOver) {
				var failStr = this.overFile;
				if(game.Data.willShowVideoAd && vee.Ad.checkCacheVideoAd()){
					cc.log("zq debug open over ============ 1111111111");
					vee.Ad.showRevivalVideoAd(function () {
						vee.Utils.scheduleOnce(function () {
							vee.PopMgr.closeAll();
							var ctlOver = vee.PopMgr.popCCB(failStr, true);
							// ctlOver.setVisible(true);
							game.Data.oLyGameOver.onLoaded();
						}, 0.2);
					});
					return;
				}
				cc.log("zq debug open over ============ 2222222222");
				// ctlOver.setVisible(true);
				vee.PopMgr.closeAll();
				var ctlOver = vee.PopMgr.popCCB(failStr, true);
				game.Data.oLyGameOver.onLoaded();
			// }
		}
	};
}

game.AnalyticsUmeng = null;

game.initPhantomCatData = function () {
	var data = vee.Utils.loadObj("VeeData");
	if (!data) {
		vee.isNewPlayer = true;
		vee.isFirstPlay = true;
		vee.data["veewocheck"] = "ok";
		vee.saveData();
	} else {
		vee.isFirstPlay = false;
		vee.data = data;
	}
	app.init(vee.isFirstPlay);
	game.Data.init();
	game.LevelData.categories = [];
	game.LevelData.load();
	game.AvatarData.init();
	vee.saveData();
	vee.VIPValues.save();
};
game.loginPlatform = "";

function requestNewUserAnAlytics(){

	vee.isNewPlayer = vee.data["isRequestNewPlayer"];

	if(game.Data.isClearVersion && (undefined == vee.isNewPlayer || vee.isNewPlayer)){
		//发送新用户统计请求
		var callback = function(isSuccess){
			cc.log("http request-------callback js" + isSuccess);
			var ret = JSON.parse(isSuccess);
			vee.Utils.logObj(ret, "request return");
			if("success" == ret.data.result){
				vee.isNewPlayer = false;
				vee.data["isRequestNewPlayer"] = false;
				vee.saveData();
				cc.log("http request-------success");
			}
			else{
				vee.isNewPlayer = true;
				vee.data["isRequestNewPlayer"] = true;
				vee.saveData();
				cc.log("http request-------fail");
			}
		}
		var ct = (new Date()).getTime();

		var platform = "";
		if(cc.sys.os == cc.sys.OS_ANDROID){
			platform = "android";
		}
		else if(cc.sys.os == cc.sys.OS_IOS){
			platform = "ios";
		}

		var url = "http://www.veewogames.cn/php/newuser.php?clientTime=" + ct + "&platform=" + platform;
		cc.log("zq debug  url====" + url);
		vee.Utils.getObjWithURL(
			url,
//			"http://localhost/adapter.html?phoneAction=newplayer&uid=123",
			function (data) {
				callback(data);
			},
			null,
			null,
			true
		);
	}
}

//function webTest(){
//	vee.net.init();
//
//	function onclick(){
//		vee.net.sendMsg();
//	}
//
//	var scene = cc.Director.getRunningScene();
//	var menuRequest = new cc.Menu();
//	scene.addChild(menuRequest);
//
//	var labelSendText = new cc.LabelTTF("Send Text", "Arial", 22);
//	var itemSendText = new cc.MenuItemLabel(labelSendText, onclick, this);
//	itemSendText.x = game.Data.winSize.width / 2;
//	itemSendText.y = game.Data.winSize.height/2;
//	menuRequest.addChild(itemSendText);
//}


function main(){

	game.Data.version.init();

	vee.init();

	game.Data.init();

	vee.Controller.active();
	//vee.PopMgr.autoGarbageCollect(1);
//	if(true){
//		webTest();
//		return;
//	}
	if (game.Data.version.isKTPlay) {
		vee.KTPlay.activate();
	}

	game.LevelData.load();
	game.AvatarData.init();
	app.checkData();

//	requestNewUserAnAlytics();

//	//debug
//	vee.Ad.activateVideoAd();
//	//end

	/*
	if (game.Data.isWeiXin) {
		vee.data.adEnabled = false;
		app.Config.IAPPluginName = "IAPMidas";
	}

	if (game.Data.isFreeGame) {
		app.Config.AnalysticsPluginConfig = vee.Utils.getObjByPlatform("56691d48e0f55ab3de000010", "55ffa3bde0f55ae39f003687", "");
		if (!game.Data.isIOSCN) {
			app.Config.AnalysticsPluginConfig = "584fd4e4b27b0a25140000f5";
		}
	} else {
		// app.Config.AnalysticsPluginConfig = vee.Utils.getObjByPlatform("55ffa36167e58eb467002958", "56691d0767e58ebf2d001d32", "");
		app.Config.AnalysticsPluginConfig = vee.Utils.getObjByPlatform("584a53fb8f4a9d74180016f9", "56691d0767e58ebf2d001d32", "");
	}
	*/

	vee.Ad.activate();

	vee.Analytics.activate();

	vee.OnlineConfig.activate(vee.Analytics.pAnalytics);

	if (game.Data.isFreeGame) {

		//连续登录
		cc.log("zq debug checkHasContinuousLogin 11111111111");
		if(vee.dataManager.checkHasContinuousLogin()){
			cc.log("zq debug checkHasContinuousLogin 2222222222222");
			game.Data.willShowLoginPop = true;
			var contiunsDays = vee.dataManager.getContinuousLoginDays();
			if(contiunsDays > 3){
				vee.Ad.isNoAd = true;
			}
		}
		vee.dataManager.setLoginTime();

		cc.log("zq debug checkHasContinuousLogin 333333333");
		//end

		vee.Ad.activate();

		//vee.Ad.initAdOnlineConfig();
		//vee.Ad.activateWithSettedEntityPos();
		//vee.Ad.changeEntityAdIDTo("open_screen");
		//vee.Ad.changeEntityAdIDTo("start_btn");
		//vee.Ad.changeEntityAdIDTo("level_btn");
		//vee.Ad.activateVideoAd();
	} else if (!game.Data.isAndroid) {
		// for demo
//		vee.Ad.activate();
	}

	if (!(game.Data.isAndroid && !game.Data.isFreeGame)) {
//		vee.Analytics.activate();
		vee.IAPMgr.activate();
		// for demo
		vee.GameCenter.activate();
		if (!game.Data.isAndroid) {
			vee.GameCenter.login();
		}
		vee.Utils.checkPackage();
	}

	var startFunc = function () {
		// for demo
//		vee.isFirstPlay = false;
		vee.PopMgr.closeAll();

		if (vee.dataManager.getPower() == undefined) {
			vee.dataManager.setPower(1);
		}

		vee.saveData();


		var showVersionSceen = function (overCall) {
			var sceen1 = cc.Sprite("res/version_cn.png");
			sceen1.setAnchorPoint(cc.p(0, 0));
			vee.PopMgr.popLayer(sceen1);
			sceen1.runAction(cc.sequence(cc.delayTime(1), cc.fadeOut(1), cc.callFunc(function(){
				var sceen2 = cc.Sprite("res/open_sceen_cn.png");
				sceen2.setAnchorPoint(cc.p(0, 0));
				vee.PopMgr.popLayer(sceen2);
				sceen2.runAction(cc.sequence(cc.delayTime(1), cc.callFunc(function () {
					if(overCall) overCall();
				})));
			})))
		}

		if (vee.isFirstPlay) {
//			requestNewUserAnAlytics();
			var gameStartFunc = function () {
				vee.PopMgr.closeAll();
				cc.director.purgeCachedData();
				vee.PopMgr.popCCB("res/veeGameLayer.ccbi");
				game.Data.oLyGame.onLoaded();
				vee.Analytics.logEvent("story_start");
				vee.Analytics.UGameEvent.startGuideLevel();
				game.Data.oLyGame.initStage('Story1');
				game.Data.oLyGame.setFirstPlay(true);
			};
			if (game.Data.isAndroid) {
				//jin
				if (game.Data.isWeiXin) {
					LyWeiXinOpen.show();
				} else {
					if (game.Data.isFreeGame) {
						vee.PopMgr.alert(
							vee.Utils.getLocalizedStringForKey("Do you want to login Google Play Game Services?"),
							vee.Utils.getLocalizedStringForKey("GooglePlay"),
							function () {
								game.Data.isAutoLoginGoogle = true;
								vee.GameCenter.login();
								vee.Transition.out(res.MapTransition_ccbi, gameStartFunc);
							},
							function () {
								game.Data.isAutoLoginGoogle = false;
								vee.Transition.out(res.MapTransition_ccbi, gameStartFunc);
							}
						);
					} else {
						vee.Transition.out(res.MapTransition_ccbi, gameStartFunc);
					}
				}
			} else {
				if(game.Data.version.curVersion == VERSION.IOS_FREE_CN){
					showVersionSceen(function () {
						vee.Transition.out(res.MapTransition_ccbi, gameStartFunc);
					});
				}
				else{
					vee.Transition.out(res.MapTransition_ccbi, gameStartFunc);
				}

			}
		} else {
			if (game.Data.isWeiXin) {
				LyWeiXinOpen.show();
			} else {

				if(game.Data.version.curVersion == VERSION.IOS_FREE_CN){
					showVersionSceen(function () {
						LyIndex.show();
					});
				}
				else{
					LyIndex.show();
					if (game.Data.isAutoLoginGoogle && game.Data.isAndroid) {
						vee.GameCenter.login();
					}
				}
			}
		}

		if (game.Data.isFreeGame && game.Data.isAndroid) {
			vee.Utils.scheduleOnce(function () {
				cc.log("show open screen ad!");
				vee.Ad.showInterstitialByOnlineConfig("open_screen");
				vee.Analytics.UGameEvent.showAdEvent("openScreen", "interstial");
			}, 1.4);
		}
	};

	if (game.Data.isAndroid) {
		LySplash.show();
		vee.Utils.scheduleOnce(function () {
			vee.PopMgr.closeAll();
			startFunc();
		}, 1);
	} else {

		var startGameFunc = function () {
			startFunc();

			vee.Utils.scheduleOnce(function () {
				cc.log("show open screen ad!");
				vee.Ad.showInterstitialByOnlineConfig("open_screen");
				vee.Analytics.UGameEvent.showAdEvent("openScreen", "interstial");
			}, 2);
		}

		// if(game.Data.version.curVersion == VERSION.IOS_FREE_CN){
        //
		// }
		// else{
			startGameFunc();
		// }

	}

	// keyboard listener for web
	if (vee.Utils.getObjByPlatform(false,false,true)) {
		gameCanvas.addEventListener('keydown', doKeyDown, true);
		gameCanvas.addEventListener('keyup', doKeyUp, true);
		gameCanvas.focus();

		function doKeyDown(e) {
			if (!game.Data.oLyGame) return;
			var keyID = e.keyCode ? e.keyCode :e.which;
			if(keyID === 38 || keyID === 87)  { // up arrow and W
				game.Data.oLyGame.onJump(null, cc.CONTROL_EVENT_TOUCH_DOWN);
			}
			if(keyID === 39 || keyID === 68)  { // right arrow and D
				game.Data.oLyGame.onRight(null, cc.CONTROL_EVENT_TOUCH_DOWN);
			}
			if(keyID === 40 || keyID === 83)  { // down arrow and S
			}
			if(keyID === 37 || keyID === 65)  { // left arrow and A
				game.Data.oLyGame.onLeft(null, cc.CONTROL_EVENT_TOUCH_DOWN);
			}
			if (keyID == 32) { // space bar
				game.Data.oPlayerCtl.BButton();
				game.Data.oPlayerCtl.BButton(true);
			}
		}

		function doKeyUp(e) {
			if (!game.Data.oLyGame) return;
			var keyID = e.keyCode ? e.keyCode :e.which;
			if(keyID === 38 || keyID === 87)  { // up arrow and W
			}
			if(keyID === 39 || keyID === 68)  { // right arrow and D
				game.Data.oLyGame.onRight(null, 32);
			}
			if(keyID === 40 || keyID === 83)  { // down arrow and S

			}
			if(keyID === 37 || keyID === 65)  { // left arrow and A
				game.Data.oLyGame.onLeft(null, 32);
			}
		}
	}

	if (vee.Utils.getObjByPlatform(true,true,false)) {
		cc.log("测111111试：" + vee.data["tag_61"]);
		if (vee.data["tag_61"] == undefined) {
			vee.data["tag_61"] = 1;
			var state_61 = game.LevelData.getCategory(6).getLevelDataController(0).getLevelState();
			if (state_61 != 2) {
				vee.data["level61_ts"] = vee.Utils.getTimeNow();
			}
		}
	}

}

VeeRestorePurchaseButton.registerCallback(function(productid) {

});

vee.Transition.pop = function(ccb, pos){
	var node = cc.BuilderReader.load(ccb, null, null, true);
	var lyTouch = cc.LayerGradient.create(cc.color(0,0,0,150),cc.color(0,0,0,150));
	lyTouch.setOpacity(0);
	cc.eventManager.addListener({
		event: cc.EventListener.TOUCH_ONE_BY_ONE,
		swallowTouches: true,
		onTouchBegan: function(touches, event){
			return true;
		}
	}, lyTouch);
	node.addChild(lyTouch);
	vee.PopMgr.rootNode.addChild(node);
	if (pos) node.setPosition(pos);
	else vee.PopMgr.setNodePos(node, vee.PopMgr.PositionType.Center, cc.p(0,0), true);
	return node;
};