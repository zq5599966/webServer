/**
 * Created with AppCode.
 * User: WanThirty
 * Date: 15/7/13
 * Time: 下午5:17
 * To change this template use File | Settings | File Templates.
 */

var EnemyMoth = EnemyMushroom.extend({
	objType : game.ObjectType.Moth,

    _accYForSet : 500,
    _accXForSet : 500,
	_speedXLimitForSet : 200,
	_speedYLimitForSet : 200,
	_hasDecay : false,
	_needSafePos : false,

	_loopEfx : null,
	bornWithPos : function () {
		this._hasDecay = false;
		this._needSafePos = false;
		this._hasG = false;
//		this._loopEfx = vee.Audio.playEffect(res.inGame_monster_butterfly_mp3);
	},

	onDead : function () {
//		vee.Audio.stopEffect(this._loopEfx);
	},

	collide : function (dir) {
		if (game.Data.oPlayerCtl._isBounce || !this._hasCollide) return;
		if (dir == vee.Direction.Top && !game.Data.oPlayerCtl.extendController) {
			if (!game.Data.playerHawk) {
				this.popPlayerUp();
				this.dieAnimate(dir);
			}
		} else if (game.Data.playerHawk) {
			game.Data.oLyGame.shake();
			this.dieAnimate(dir);
		} else {
			if (game.Data.playerInvisible || game.Data.oPlayerCtl._isBounce) return;
			var dir = this.getElePosition().x > game.Data.oPlayerCtl.getElePosition().x ? vee.Direction.Left : vee.Direction.Right;
			game.Data.oPlayerCtl.getShock(dir, true);
		}
	},
	defaultMoveLogic : function () {
		
	},
	safeEnemyPos : function (pos) {
		var grid = game.Logic.getTileGridByPos(pos);
		var td = game.Logic.map.getObject(grid);
		this._isSloping = false;
		var ret = game.Logic.checkTileRough(td, pos, this, vee.Direction.Origin);
		if (!ret) {
			td = game.Logic.map.getObject(cc.p(grid.x, grid.y+1));
			ret = game.Logic.checkTileRough(td, pos, this, vee.Direction.Bottom);
		}
		return ret ? ret : pos;
	},

	setFaceTo : function(dir,force) {
		if (this._faceTo == dir && !force) return;
		dir = dir ? dir : vee.Direction.Left;
		this._faceTo = dir;
		if (dir == vee.Direction.Left) {
			this.rootNode.setScaleX(1);
		} else {
			this.rootNode.setScaleX(-1);
		}
	},

	setMoveState : function (state) {}
});

var EnemyBee = EnemyMoth.extend({
	objType : game.ObjectType.Bee,

	_accYForSet : 1200,
	_accXForSet : 5000,
	_speedXLimitForSet : 250,
	_speedYLimitForSet : 250,
	_loopEfx : null,
	bornWithPos : function () {
		this._hasDecay = false;
		this._needSafePos = false;
		this._hasG = false;
//		this._loopEfx = vee.Audio.playEffect(res.inGame_monster_bee_mp3);
	},

	onDead : function () {
//		vee.Audio.stopEffect(this._loopEfx);
	},

	_lockY : true,
	AILogic : function() {
		this._hasCollide = true;
		var mapConfig = game.Logic.configMap.getObject(this._grid);
		if (mapConfig) {
			if (mapConfig.first && mapConfig.last) {
				this._hasG = false;
				this._checkPosFirst = game.Logic.getTilePosCenterByGrid(vee.Utils.pAdd(this._grid, mapConfig.first));
				this._checkPosLast = game.Logic.getTilePosCenterByGrid(vee.Utils.pAdd(this._grid, mapConfig.last));
				if (mapConfig.first.y - mapConfig.last.y == 0 || this._lockY) {
					this._onlyHor = true;
					this._accY = 0;
				} else {
					this._hasG = false;
					this._accY = this._accYForSet*(vee.Utils.isLucky(0.5) ? -1 : 1);
					this._speedYLimit = this._speedYLimitForSet;
				}

				if (this._checkPosFirst.y < this._checkPosLast.y) this._checkPosFirst.y = [this._checkPosLast.y, this._checkPosLast.y = this._checkPosFirst.y][0];
			}
			this._speedXLimit = this._speedXLimitForSet;
			if (mapConfig.dir == "right") {
				this.moveRight();
			} else {
				this.moveLeft();
			}
		} else {
			if (this._faceTo == vee.Direction.Right) {
				this.moveRight();
			} else {
				this.moveLeft();
			}
		}

		this.playAnimate("run");;
	},

	count : 0,
	AILogicPerFrame : function(dt) {
		if (this.count > 1) {
			this.count = 0;
			return;
		}
		++this.count;
		var pos = this.getElePosition();
		if (this._checkPosFirst) {
			if (!this._onlyHor) {
				if (pos.y > this._checkPosFirst.y)
					this._accY = -this._accYForSet;
				if (pos.y < this._checkPosLast.y)
					this._accY = this._accYForSet;
			}
		} else {
			this.defaultMoveLogic();
		}
		pos = null;
	},

	afterCreate : function () {
		if (this._faceTo == vee.Direction.Right) {
			if (this._grid.x - game.Data.oPlayerCtl._grid.x > 0) {
				this.die();
			}
		} else {
			if (this._grid.x - game.Data.oPlayerCtl._grid.x < 0) {
				this.die();
			}
		}
	}
});

var EnemyFastBee = EnemyBee.extend({
	objType: game.ObjectType.FastBee,

	_lockY : false,
	_accYForSet: 1200,
	_accXForSet: 5000,
	_speedXLimitForSet: 320,
	_speedYLimitForSet: 250,
	_loopEfx : null,
	bornWithPos : function () {
		this._hasDecay = false;
		this._needSafePos = false;
		this._hasG = false;
//		this._loopEfx = vee.Audio.playEffect(res.inGame_monster_bee_mp3);
	},

	onDead : function () {
//		vee.Audio.stopEffect(this._loopEfx);
	},

	AILogic : function() {
		this._speedXLimit = this._speedXLimitForSet + vee.Utils.randomInt(-30, 30);
		this._hasCollide = true;
		var mapConfig = game.Logic.configMap.getObject(this._grid);
		if (mapConfig) {
			if (mapConfig.first && mapConfig.last) {
				this._hasG = false;
				this._checkPosFirst = game.Logic.getTilePosCenterByGrid(vee.Utils.pAdd(this._grid, mapConfig.first));
				this._checkPosLast = game.Logic.getTilePosCenterByGrid(vee.Utils.pAdd(this._grid, mapConfig.last));
				if (mapConfig.first.y - mapConfig.last.y == 0 || this._lockY) {
					this._onlyHor = true;
					this._accY = 0;
				} else {
					this._hasG = false;
					this._accY = this._accYForSet*(vee.Utils.isLucky(0.5) ? -1 : 1);
					this._speedYLimit = this._speedYLimitForSet;
				}

				if (this._checkPosFirst.y < this._checkPosLast.y) this._checkPosFirst.y = [this._checkPosLast.y, this._checkPosLast.y = this._checkPosFirst.y][0];
			}
			this._speedXLimit = this._speedXLimitForSet;
			if (mapConfig.dir == "right") {
				this.moveRight();
			} else {
				this.moveLeft();
			}
		} else {
			if (this._faceTo == vee.Direction.Right) {
				this.moveRight();
			} else {
				this.moveLeft();
			}
		}

		this.playAnimate("run");;
	}
});

var EnemyMadBee = EnemyBee.extend({

	objType: game.ObjectType.MadBee,

	_accYForSet : 1200,
	_accXForSet : 5000,
	_speedXLimitForSet : 150,
	_speedYLimitForSet : 150,
	_playerPos : null,

	resetStatus : function () {
		this._container.setRotation(0);
		this._isOver = false;
		this._isFindPlayer = false;
	},

	AILogicPerFrame : function() {


		if (this.count > 1) {
			this.count = 0;
			return;
		}

		if (this._isOver) return;

		this._pos = this.getElePosition();
		this._playerGrid = game.Data.oPlayerCtl._grid;
		var offX = this._grid.x - this._playerGrid.x;
		var offY = this._grid.y - this._playerGrid.y;
		if ( ((offX > 0 && this._faceTo == vee.Direction.Left)
			|| (offX < 0 && this._faceTo == vee.Direction.Right))
			&& (Math.abs(offX) < 6 && Math.abs(offY) < 3)
			&& !game.Data.oPlayerCtl._isBounce)
		{
			// find player
			if (!this._isFindPlayer) {
				vee.Audio.playEffect(res.inGame_monster_crazyFound_mp3);
				this._isFindPlayer = true;
				this._checkPosFirst = null;
				this._accX = 0;
				this._accY = 0;
				this._speedX = 0;
				this._speedY = 0;
				this.playAnimate("get", function() {
					this._speedXLimit = 9999;
					this._speedYLimit = 9999;
					this.playAnimate("eat");
					this._playerPos = game.Data.oPlayerCtl.getElePosition();
					if (this._playerPos.x > this._pos.x) {
                        this.setFaceTo(vee.Direction.Right);
					} else {
						this.setFaceTo(vee.Direction.Left);
					}
					this._dashing = true;

					var agl = vee.Utils.angleOfLine(this._pos, vee.Utils.pAdd(this._playerPos, cc.p(0,32)));
					var targetPoint = vee.Utils.getPointWithAngle(this._pos, 800, agl);

					var dirNum = this._faceTo == vee.Direction.Left ? 1 : -1;
					this._container.setRotation(agl+(90*dirNum));
					this._speedX = targetPoint.x - this._pos.x;
					this._speedY = targetPoint.y - this._pos.y;
				}.bind(this));
			}
		}
		else if (!this._isFindPlayer)
		{
			this._dashing = false;
			this._speedXLimit = 150;
		}

		++this.count;
		var pos = this.getElePosition();
		if (this._checkPosFirst && !this._isFindPlayer) {
			if (!this._onlyHor) {
				if (pos.y > this._checkPosFirst.y)
					this._accY = -this._accYForSet;
				if (pos.y < this._checkPosLast.y)
					this._accY = this._accYForSet;
			}
		} else {
			this.defaultMoveLogic();
		}
		pos = null;
	}
});

var EnemyFish = EnemyMoth.extend({
	objType: game.ObjectType.Fish,
	_loopEfx : null,
	bornWithPos : function () {
		this._hasDecay = false;
		this._needSafePos = false;
		this._hasG = false;
//		this._loopEfx = vee.Audio.playEffect(res.inGame_monster_bombFish_mp3);
	},

	onDead : function () {
//		vee.Audio.stopEffect(this._loopEfx);
	}
});