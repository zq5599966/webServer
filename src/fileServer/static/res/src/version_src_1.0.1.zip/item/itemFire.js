/**
 * Created with AppCode.
 * User: WanThirty
 * Date: 15/7/14
 * Time: 上午10:52
 * To change this template use File | Settings | File Templates.
 */

var ItemFire = Item.extend({
	_type : game.ObjectType.Fire,
	spFire : null,

	_loopEfx : null,
	_startPos : null,
	_tarPos : null,
	_height : null,
	_dur : 0,
	bornWithPos : function (pos) {
		vee.Utils.scheduleCallbackForTarget(this.rootNode, this.updatePos.bind(this), 0.1);
		this._startPos = pos;
		var mapConfig = game.Logic.configMap.getObject(this._grid);
		if (mapConfig) {
			var arrArg = mapConfig.name.split(",");
			if (arrArg.length == 3) {
				var tarGrid = cc.p(parseInt(arrArg[0]), parseInt(arrArg[1]));
				tarGrid = vee.Utils.pAdd(tarGrid, this._gridInMap);
				this._tarPos = cc.p(game.Logic.getTilePosCenterByGrid(tarGrid));
				var tarHeightGridY = parseInt(arrArg[2]);
				tarHeightGridY = this._gridInMap.y + tarHeightGridY
				var tarHeight = game.Logic.getTilePosCenterByGrid(cc.p(0, tarHeightGridY));
				this._height = tarHeight.y-this._tarPos.y;
				if (this._tarPos.x < this._grid.x) {
					this.nodeBox.setScaleX(-1);
				}

				this._dur = 1.6;
				this.runJump();
			} else {
				this.errorInInit();
			}
		} else {
			this.errorInInit();
		}
		this.playAnimate("run");
	},

	runJump : function () {
		this._hasCollide = true;
		this.spFire.setVisible(true);
		this.setElePosition(this._startPos);

		vee.Audio.playEffect(res.inGame_efx_fire_mp3);
		this._container.runAction(cc.sequence(
			cc.jumpTo(this._dur, this._tarPos.x, this._tarPos.y, this._height, 1),
			cc.callFunc(function () {
				this._hasCollide = false;
				this.spFire.setVisible(false);
			}.bind(this)),
			cc.delayTime(0.5),
			cc.callFunc(function () {
				this.runJump();
			}.bind(this))
		));
	},

	errorInInit : function () {
		cc.log("error in init item fire!");
		this._container.removeFromParent();
	},

	updatePos : function (dt) {
		var rectEnemy = this.getEleRect();
		var rectPlayer = game.Data.oPlayerCtl.getEleRect();
		if (cc.rectIntersectsRect(rectEnemy, rectPlayer)) {
			this.collidePlayer();
		}
	},

	getInhaleController : function () {
		return null;
	},

	collidePlayer : function () {
		if (game.Data.oPlayerCtl._isBounce || !this._hasCollide || game.Data.playerInvisible || game.Data.playerHawk) return;
		var dir = this.getElePosition().x > game.Data.oPlayerCtl.getElePosition().x ? vee.Direction.Left : vee.Direction.Right;
		game.Data.oPlayerCtl.getShock(dir, true);
	},

	onDead : function () {
	}
});