/**
 * Created by john on 2016/11/25.
 */
var appConfig_Android_free = {
    AppID : "com.veewo.supercat",

    AppName : app.configManager.AppName,

    AppAlias : app.configManager.AppAlias,

    AppDefaultClass : "com/veewo/VeeCommon/VeeCommon",

    AppURL : app.configManager.AppURL,

    RateURL : app.configManager.RateURL,

    PromoURL : app.configManager.PromoURL,
    PromoChannel : app.configManager.PromoChannel,
    PromoBannerEnable : app.configManager.PromoBannerEnable,
    PromoFullScreenEnable : app.configManager.PromoFullScreenEnable,

    //plugins
    GameCenterPluginName : app.configManager.GameCenterPluginName,
    AnalyticsPluginName : app.configManager.AnalyticsPluginName,
    AnalyticsPluginADTrackName : app.configManager.AnalyticsPluginADTrackName,
    IAPPluginName : app.configManager.IAPPluginName,

    //Deprecated
    AdVideoPluginName : app.configManager.AdVideoPluginName,
    AdBannerPluginName : app.configManager.AdBannerPluginName,
    AdInterstialPluginName : app.configManager.AdInterstialPluginName,

    AdInterstialPluginCoinfig : null,
    IsBannerEnabled : app.configManager.IsBannerEnabled,
    IsInterestialEnabled : app.configManager.IsInterestialEnabled,

    IAPs : [
        {ProductID: "com.veewo.unlocklevels", NonConsumable:"false"},
        {ProductID: "com.veewo.allcat", NonConsumable:"true"},
        {ProductID: "com.veewo.power", NonConsumable:"false"},
        {ProductID: "com.veewo.moon", NonConsumable:"true"},
        {ProductID: "com.veewo.unlockdiscolevels", NonConsumable:"true"}
    ],

    LeaderboardIDs : ["CgkIu7e9p-oLEAIQCQ"],

    AnalyticsPluginADTrackConfig : {
        AdvertiserID : "164496",
        ConversionKey : "1b0e697a2fa9501dcafa6a08e2c1c017"
    },

    GameCenterPluginConfig : {"appid" : "com.veewo.supercat"},

    AnalysticsPluginConfig : "58477fedc62dca2bf3001741",

    //Deprecated
    AdBannerPluginConfig : {
        AppGoogleBannerId: "ca-app-pub-4587184008612513/3196418381",            //未启用
        AppGoogleInterstialId: "ca-app-pub-1777019132527367/2533549534",        //多处修改
        AppFaceBookInterstialId : "150931201938556_150931438605199",            //多处修改
        AppGoogleRewardedVideoId : "ca-app-pub-1777019132527367/7083425138",     //多处修改
        QixunAppkey : "bf8e5fta82shhuddk1spd9rb",
    },

    AdVideoPluginConfig : {
        AdsVungle : "com.veewo.supercat"
    },

    Achievements : [
        "CgkIu7e9p-oLEAIQAQ",   // star 1
        "CgkIu7e9p-oLEAIQAg",   // star 2
        "CgkIu7e9p-oLEAIQAw",   // star 3
        "CgkIu7e9p-oLEAIQBA",   // star 4
        "CgkIu7e9p-oLEAIQBQ",   // star 5
        "CgkIu7e9p-oLEAIQAA",   // flash
        "CgkIu7e9p-oLEAIQBg",   // jump
        "CgkIu7e9p-oLEAIQBw",   // heart
        "CgkIu7e9p-oLEAIQCg"    // coin
    ],

    // Custom...
    AdOdd      : "ca-app-pub-1777019132527367/1974641134",
    AdEven     : "ca-app-pub-1777019132527367/4442904336",
    AdPause    : "ca-app-pub-1777019132527367/2966171130",
    AdGameOver : "ca-app-pub-1777019132527367/8516174730",
    AdStartUp  : "ca-app-pub-1777019132527367/2609241934",
    AdExit     : "ca-app-pub-1777019132527367/3451374331",

    IAPConfig : {IAPID : "MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAhb+hA/lLAbVynW5AOQAurv4nsgDTRh4PsuHH3smCq01FGc4VqR4r/Uc1sOHZ3cR0ocHc2ISycIXd2A8/FW6ZQ9nRVHunYXqKwGSMZiImrPKH3qz4bChdxs42AtSTMutDBVIc3AVjbkOD5yaPh09xUxZ9lJDmJrXRoj0sKvn2FCyYpSYQyJZjTBOZs1+fGjaUK9ytiF5lZkhdIfsHkZA256kwq1uYGOi/KQk59qeCqfMg8ovA1Kgno+mitR2aG8A9PimG7WNPneqy3Ss7Lo68C5tT8RaWnXg2ZnLaWbZveyVfJFY2jGrI/K1CV8f+MJ7OqSu24nFXlPbgG22IuJaBhQIDAQAB"},
    packageName : "com.veewo.supercat",

    ShareKTPlay_android : {
        key : "19ypSjYv6D",
        secret : "96f8fb00696a9f83add4c0b8afdd19af801e54fb"
    }
}