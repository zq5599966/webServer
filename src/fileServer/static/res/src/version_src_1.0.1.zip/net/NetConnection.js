/**
 * Created with AppCode.
 * User: ZQ
 * Date: 16/6/30
 * Time: 上午10:07
 * To change this template use File | Settings | File Templates.
 */
var vee = vee || {};

//vee.Utils = {
//
//	_stepTime : 0,
//
//	beginTiming : function(){
//		_stepTime = new Date();
//	},
//
//	endTiming : function(msg){
//		var end = new Date();
//		cc.log("%s  cost time===%d", msg, end - _stepTime);
//		_stepTime = end;
//	}
//};



vee.net = {

	WebSocket : WebSocket || window.WebSocket || window.MozWebSocket,

	wsSendText : null,
	wsSendBinary : null,


	init : function(){

		// this.wsSendText = new WebSocket("ws://192.168.199.226:1234/websocket");
		this.wsSendText = new WebSocket("ws://45.56.74.89:1234/websocket");
		this.wsSendText.binaryType = "arraybuffer";

		this.wsSendText.onopen = function(evt){
			vee.Utils.beginTiming();
			cc.log("web socket send text was connection ");
			vee.msgControl.loginServer();

			// var protoBuf = dcodeIO.ProtoBuf;
			// var builder = protoBuf.loadProtoFile("res/protobuf/message.proto");
			// var Message = builder.build("gameProto.Message");
			// var message = new Message();
			// message.id = 10;
			// message.text = "fuckjs";
			// var buffer = message.encodeAB();
			// // var buffer = Message.encode(message);
			// vee.net.sendMsg(buffer);
		};

		this.wsSendText.onmessage = function(evt){
			vee.Utils.endTiming("send msg ");
			// var textStr = "response text msg: "+evt.data;

			cc.log(evt.data);
			// var tmp = evt.data.split(",");
			// var pos = cc.p(parseInt(tmp[0]), parseInt(tmp[1]));
            //
			// cc.eventManager.dispatchCustomEvent("userPos", pos);
			var protoBuf = dcodeIO.ProtoBuf;
			var Builder = protoBuf.loadProtoFile("res/protobuf/baseProto.proto");
			var UserInfo = Builder.build("gameProto.GameUserInfo");

			var user = UserInfo.decode(evt.data);
			cc.log("user uid======%s", user.uid);
			cc.log("user uname======%s", user.uname);
		};

		this.wsSendText.onerror = function(evt){
			cc.log("send text error");
		};

		this.wsSendText.onclose = function(evt){
			cc.log("ws on close");
		};

	},

	sendMsg : function(msg){
		if(this.wsSendText.readyState == WebSocket.OPEN){
//			vee.Utils.beginTiming();
// 			var binary = this._stringConvertToArray(msg);
// 			this.wsSendText.send(binary.buffer);
			this.wsSendText.send(msg);
			cc.log("send msg =======" + msg);
		}
	},

	sendPos : function(pos){
		if(this.wsSendText.readyState == WebSocket.OPEN){
			this.wsSendText.send(pos.x + "," + pos.y);
		}
	},

	_stringConvertToArray:function (strData) {
		if (!strData)
			return null;

		var arrData = new Uint16Array(strData.length);
		for (var i = 0; i < strData.length; i++) {
			arrData[i] = strData.charCodeAt(i);
		}
		return arrData;
	},
};


