/**
 * Created with AppCode.
 * User: WanThirty
 * Date: 15/5/9
 * Time: 下午3:47
 * To change this template use File | Settings | File Templates.
 */

var Enemy = InhaleObj.extend({
	nodeBox : null,
	boxOffset : null,
	boxSize : null,
	_checkPosFirst : null,
	_checkPosLast : null,

	_eleType : game.EleType.Enemy,
	_container : null,
	_grid : null,
	_gridInMap : null,
	_lastPosition : null,
	pushedDir : null,

	_speedX : 0,
	_speedY : 0,
	_accX : 0,
	_accY : 0,
	_accXForSet : game.Data.playerXacc,
	_accYForSet : game.Data.playerXacc,
	_speedXLimit : 100,
	_speedYLimit : 1300,
	_speedXLimitForSet : 100,
	_speedYLimitForSet : 1300,
	_faceTo : vee.Direction.Right,
	_moveDir : vee.Direction.Origin,
	_decayX : 2200,
	_eleSize : null,
	_moveState : MoveState.Moving,
	_speedScaleRate : 1,

	uncheck : false,

	onCreate : function() {
		this.pushedDir = [];
		this.boxOffset = this.nodeBox.getPosition();
		this.boxSize = this.nodeBox.getContentSize();
	},

	cutInAnimate : function (callback) {
		this.uncheck = true;
		this._isOver = true;
		this.playAnimate("in", function () {
			this.uncheck = false;
			this._isOver = false;
			if (callback) callback();
		}.bind(this));
	},

	onExit : function () {
	},

	initPosition : function(pos) {
		this.needRefreshPos = true;
		this._stopX = false;
		this._hasG = true;
		this._needSafePos = true;
		this._hasCollide = true;
		this._isOver = false;
		this.setElePosition(pos);
		this.bornWithPos(pos);
		this._grid = game.Logic.getTileGridByPos(pos);
		this._lastGrid = game.Logic.getTileGridByPos(pos);
		this.resetStatus();
		// reset status...
		this._onlyHor = false;
		this._onlyVer = false;
		this._speedXLimit = this._speedXLimitForSet;
		this._speedYLimit = this._speedYLimitForSet;

		this.AILogic();
		this.onGridChanged();
	},

	afterCreate : function () {

	},

	resetStatus : function () {

	},

	updateState : function () {

	},

	isDashing : function() {

	},

	setMoveState : function (state) {
		if (this._moveState == state) return;
		switch (state) {
			case MoveState.JumpUp:
				break;
			case MoveState.Moving:
				EfxDust.show(this.getElePosition(), DustType.ForceJumpDust);
				break;
			default :
				break;
		}
		this._moveState = state;
	},

	setGridInMap : function (grid) {
		this._gridInMap = grid;
	},

	getElePosition : function() {
		return this._container.getPosition();
	},

	_pos : null,
	_checkForDieW : 17,
	setElePosition : function(pos, grid) {
		this._lastPosition = this._container.getPosition();
		this._container.setPosition(pos);
		this._grid = game.Logic.getTileGridByPos(pos);
		this._pos = cc.p(pos.x, pos.y);
	},

	setContainerNode : function(node) {
		this._container = node;
	},

	jump : function() {
		if (!this._isJumping) {
			this.setJumping(true);
		}
	},

	setJumping : function(isJumping) {
		this._isJumping = isJumping;
	},

	isJumping : function () {
		return this._isJumping;
	},

	getEleRect : function() {
		var pos = this.getElePosition();
		var rect = cc.rect(
			pos.x + this.boxOffset.x - this.boxSize.width/2,
			pos.y + this.boxOffset.y - this.boxSize.height/2,
			this.boxSize.width,
			this.boxSize.height
		);
		return rect;
	},

	setFaceTo : function(dir,force) {
		if (this._faceTo == dir && !force) return;
		dir = dir ? dir : vee.Direction.Left;
		this._faceTo = dir;
		if (dir == vee.Direction.Left) {
			this.rootNode.setScaleX(1);
		} else {
			this.rootNode.setScaleX(-1);
		}
	},

	getFaceToNumber : function() {
		return this._faceTo == vee.Direction.Left ? -1 : 1;
	},

	moveLeft : function() {
		this.setFaceTo(vee.Direction.Left, true);
		this._accX = -this._accXForSet;
	},

	moveRight: function() {
		this.setFaceTo(vee.Direction.Right, true);
		this._accX = this._accXForSet;
	},

	die : function() {
		this.onDead();
		//vee.Audio.playEffect("res/inGame_event_deathMonster_"+vee.Utils.randomInt(1,6)+".mp3");
		this._hasCollide = false;
		this._isOver = true;
		game.Data.removeUsingEnemy(this);
		this.inhaleController = null;
		if (this._gridInMap) {
			game.Logic.dynamicObjMap.removeObject(this._gridInMap);
		}
		this.rootNode.setVisible(false);
		this._speedX = 0;
		this._speedY = 0;
		this._accX = 0;
		this._accY = 0;
		this._checkPosFirst = null;
		this._checkPosLast = null;
		game.Data.enemyPool.push(this);
	},

	stopMove : function() {
		this._accX = 0;
	},

	leftToBarrier : function(td) {
		this.pushedDir[vee.Direction.Left] = 1;
		game.Logic.triggerTileCallback(td, this, vee.Direction.Left);
	},

	rightToBarrier : function(td) {
		this.pushedDir[vee.Direction.Right] = 1;
		game.Logic.triggerTileCallback(td, this, vee.Direction.Right);
	},

	upToBarrier : function(td) {
		this.pushedDir[vee.Direction.Top] = 1;
		this._speedY = 0;
		this._accY = 0;
		game.Logic.triggerTileCallback(td, this, vee.Direction.Top);
	},

	jumping : false,
	downToBarrier : function(td) {
		this.pushedDir[vee.Direction.Bottom] = 1;
		this._speedY = 0;
		this._accY = 0;
		this.jumping = false;
		game.Logic.triggerTileCallback(td, this, vee.Direction.Bottom);
	},

	dieEffect : function () {
		var pos = this.getElePosition();
		EfxEnemyDie.show(pos);
		this._accX = 0;
		this._speedX = 0;
		this._isOver = true;
		this.playAnimate("die", function () {
			this.die();
		}.bind(this));
	},

	squeeze : function (dir) {
		if (this._isOver) return true;
		if (this.pushedDir[vee.Direction.revert(dir)]) {
			this.dieEffect();
			return true;
		}
	},

	_xLimit : null,
	onGridChanged : function() {
		if (!this._grid || !this._lastGrid) return;

		if (game.Data.oPlayerCtl &&
			(this._grid.x > game.Data.oPlayerCtl._grid.x + this._checkForDieW ||
			this._grid.x < game.Data.oPlayerCtl._grid.x - this._checkForDieW ||
			this._grid.y > game.Data.oPlayerCtl._grid.y + this._checkForDieW ||
			this._grid.y < game.Data.oPlayerCtl._grid.y - this._checkForDieW))
		{
			this._isOver = true;
			this.die();
		}

		var grid = cc.p(
			(this._faceTo == vee.Direction.Right ? this._grid.x + 1 : this._grid.x - 1),
			(this._isSloping ? this._grid.y-1 : this._grid.y)
		);

		this.updateXLimit(grid);
	},

	updateXLimit : function (grid) {
		if (this._speedScaleRate < 1) {
			grid.y -= 1;
			if (this._speedScaleRate < 0.6 || this._speedScaleRate > 0.8) {
				var tdOrigin = game.Logic.map.getObject(this._grid);
				if (tdOrigin && tdOrigin.tileInfo && tdOrigin.tileInfo.speedScale < 1) {
					grid.y -= 1;
				} else {
					grid.y += 1;
				}
			}
		}

		var td = game.Logic.map.getObject(grid);
		if (td) {
			var tileInfo = game.TileIDInfo["Tile"+td.gid];
			if (tileInfo && (tileInfo.type == game.ObjectType.Block || tileInfo.type == game.ObjectType.BlockHurt || tileInfo.type == game.ObjectType.BlockBomb || tileInfo.type == game.ObjectType.BlockBreakable || tileInfo.type == game.ObjectType.BlockScale)) {
				this._xLimit = game.Logic.getTilePosCenterByGrid(grid).x + (this._faceTo == vee.Direction.Right ? -TILE_WIDTH-10 : TILE_WIDTH+10);
				return;
			}
		} else {
			this._xLimit = null;
		}
	},

	needRefreshPos : true,
	_freezeY : false,
	updatePos : function(timeDelta) {
		if (this._isOver || this.AILogicPerFrame(timeDelta)) return;
		// calc speed X...
		if (this.needRefreshPos) {
			this.calcX(timeDelta);
			var dirX = game.Logic.getMoveDirectionBySpeedX(this._speedX);
			this._moveDir = dirX;

			// calc speed Y...
			if (!this._freezeY) this.calcY(timeDelta);

			// calc safe postion...
			this.refreshPosition(timeDelta);
		}

		this.checkCollide();

		if (this.needRefreshPos) {
			if (this._speedY != 0) {
				this.setJumping(true);
			}

			// Calc decay...
			this.checkDecay(timeDelta);
		}
		this.afterUpdatePos();
	},

	_stopX : false,
	calcX : function(timeDelta) {
		if (this._stopX) return;
		this._speedX += this._accX*timeDelta;
		if (Math.abs(this._speedX) > this._speedXLimit) {
			var dir = this._speedX > 0 ? 1 : -1;
			this._speedX = this._speedXLimit*dir;
		}
		this._speedX = Math.round(this._speedX);
	},

	_hasG : true,
	_stopY : false,
	calcY : function(timeDelta) {
		if (this._stopY) return;
		this.setMoveState(this._speedY != 0 ? MoveState.JumpUp : MoveState.Moving);
		this._speedY += this._accY*timeDelta;
		if (this._hasG) this._speedY += game.Data.G*timeDelta;
		if (Math.abs(this._speedY) > this._speedYLimit) {
			var dir = this._speedY > 0 ? 1 : -1;
			this._speedY = this._speedYLimit*dir;
		}
		this._speedY = Math.round(this._speedY);
	},

	_needSafePos : true,
	_safePos : null,
	refreshPosition : function(timeDelta) {
		var castPos = cc.p(this.getElePosition().x + this._speedX*timeDelta*this._speedScaleRate, this.getElePosition().y + this._speedY*timeDelta);
		var lastGrid = game.Logic.getTileGridByPos(this.getElePosition());
		if (!this._lastGrid || lastGrid.x != this._lastGrid.x || lastGrid.y != this._lastGrid.y) {
			this.onGridChanged();
			this._lastGrid = lastGrid;
		}
		this.pushedDir = [];
		if (this._needSafePos) {
			this.setElePosition(this.safeEnemyPos(castPos));
		}
		else this.setElePosition(castPos);
	},

	_isSloping : false,
	safeEnemyPos : function (pos) {
		var grid = game.Logic.getTileGridByPos(pos);
		var td = game.Logic.map.getObject(grid);
		this._isSloping = false;
		var ret = game.Logic.checkTileRough(td, pos, this, vee.Direction.Origin);
		if (!ret) {
			td = game.Logic.map.getObject(cc.p(grid.x, grid.y+1));
			ret = game.Logic.checkTileRough(td, pos, this, vee.Direction.Bottom);
		}
		this._hasG = ret ? false : true;
		return ret ? ret : pos;
	},

	_hasCollide : true,
	_checkWidthOff : 30,
	checkCollide : function () {
		if (!this._hasCollide) return;
		var rectEnemy = this.getEleRect();
		var rectForCheck = game.Data.oPlayerCtl.getEleRect();
		rectForCheck.x -= this._checkWidthOff;
		rectForCheck.width += this._checkWidthOff*2;
//		game.Data.oLyGame.drawNode.clear();
//		game.Logic.drawRect(rectEnemy);
//		game.Logic.drawRect(rectForCheck);
		if (cc.rectIntersectsRect(rectEnemy, rectForCheck)) {
			var playerY = game.Data.oPlayerCtl.getElePosition().y;
			var rectPlayer = game.Data.oPlayerCtl.getEleRect();
			var enemyPos = this.getElePosition();
			var enemyY = enemyPos.y;
			if (enemyY <= playerY) {
				var offsetY = playerY - enemyY;
				if (offsetY > this.boxSize.height/2 + this.boxOffset.y) {
					if (game.Data.oPlayerCtl._speedY <= 0) {
						this.collide(vee.Direction.Top);
					}
				} else if (enemyPos.x > rectPlayer.x && enemyPos.x < rectPlayer.x + rectPlayer.width) {
					if (rectPlayer.x + rectPlayer.width/2 > enemyPos.x) {
						this.collide(vee.Direction.Right);
					} else {
						this.collide(vee.Direction.Left);
					}
				}
			} else if (enemyPos.x > rectPlayer.x && enemyPos.x < rectPlayer.x + rectPlayer.width) {
				this.collide(vee.Direction.Bottom);
			}
		}
	},

	_hasDecay : true,
	checkDecay : function (timeDelta) {
		if (!this._hasDecay) return;
		if (this._accX > 0 && this._speedX < 0) {
			this._speedX += this._decayX*timeDelta;
		} else if (this._accX < 0 && this._speedX > 0) {
			this._speedX -= this._decayX*timeDelta;
		} else if (this._accX == 0 && this._speedX != 0) {
			if (this._speedX > 0) {
				this._speedX -= this._decayX*timeDelta;
				if (this._speedX <= 0) this._speedX = 0;
			} else if (this._speedX <= 0) {
				this._speedX += this._decayX*timeDelta;
				if (this._speedX >= 0) this._speedX = 0;
			}
		}
	},

	inhaleController : null,
	getInhaleController : function () {
		if (this.inhaleController) {
			return null;
		}
		this.inhaleController = new InhaleObj();
		this.inhaleController.obj = this;
		return this.inhaleController;
	},
	getAte : function () {
		game.Data.oPlayerCtl.feed();
		this.die();
	},

	hitByStar : function (dir) {
		if (this._isOver) return;
		this.dieAnimate(dir);
	},

	_popPlayerHeightMax : 1500,
	_popPlayerHeight : 950,
	popPlayerUp : function () {
		var oPlayer = game.Data.oPlayerCtl;
		if (oPlayer._isSmashing) return;
		oPlayer._isFlying = false;
		if (!oPlayer._isSmashing) {
			oPlayer._isJumpLimitY = false;
			if (game.Data.isHoldJumpButtom) {
				oPlayer._speedY = this._popPlayerHeightMax;
			} else {
				oPlayer._speedY = this._popPlayerHeight;
			}
		}
		oPlayer._speedX = 0;
	},

	defaultMoveLogic : function () {
		if (this._xLimit === null || this._speedX == 0) return;
		if (this._speedX > 0) {
			if (this.getElePosition().x > this._xLimit) {
				this.moveLeft();
				this._xLimit = null;
				this.onGridChanged();
				this.rightToBarrier();
			}
		} else {
			if (this.getElePosition().x < this._xLimit) {
				this.moveRight();
				this._xLimit = null;
				this.onGridChanged();
				this.leftToBarrier();
			}
		}
	},
	getShock : function () {
		this.needRefreshPos = false;
	},
	resumeShock : function () {
		this.needRefreshPos = true;
	},

	isDashing : function () {
		return false;
	},
	onKill : function () {
		var avatar = game.AvatarData.getCurrentAvatar();
		if (avatar && avatar.type == game.Roles.Vampire) {
			if (vee.Utils.isLucky(0.33)) {
				game.Data.addLife();
			}
		}
	},

	// For overwrite
	bornWithPos : function(pos) {},
	AILogic : function() {},
	AILogicPerFrame : function(dt) {},
	onDead : function () {},
	collide : function(dir) {},
	afterUpdatePos : function () {}
});



/*--  Enemy create function  --*/
Enemy.createWithInfo = function (info, forceCreate) {
	var node = game.Data.getEnemyFromPool(info.type);
	if (node && !forceCreate) {
		node.controller.setFaceTo(info.dir, true);
		return {container : node.controller._container, controller : node.controller};
	} else {
		var ccbName = null;
		switch (info.type) {
			case game.ObjectType.Slime:
				ccbName = res.eleSLM_ccbi;
				break;
			case game.ObjectType.DogSlime:
				ccbName = res.eleSLM_Dog_ccbi;
				break;
			case game.ObjectType.Cannon:
				ccbName = res.eleLuoBo_ccbi;
				break;
			case game.ObjectType.Spider:
				ccbName = res.eleSpider_ccbi;
				break;
			case game.ObjectType.ArmorSlime:
				ccbName = res.eleSLM_Armor_ccbi;
				break;
			case game.ObjectType.ArmorSlimeHawk:
				ccbName = res.eleSLM_Invisible_ccbi;
				break;
			case game.ObjectType.SusliksHawk:
				ccbName = res.eleDiShu2_ccbi;
				break;
			case game.ObjectType.JumpSlime:
				ccbName = res.enemyJumpSlime_ccbi;
				break;
			case game.ObjectType.JumpSlimeLink:
				ccbName = res.enemyJumpSlime2_ccbi;
				break;
			case game.ObjectType.Moth:
				ccbName = res.eleBat4_ccbi;
				break;
			case game.ObjectType.Bee:
				ccbName = res.eleBat_ccbi;
				break;
			case game.ObjectType.FastBee:
				ccbName = res.eleBat2_ccbi;
				break;
			case game.ObjectType.Fish:
				ccbName = res.eleBat3_ccbi;
				break;
			case game.ObjectType.Flight:
				ccbName = res.eleUFO_ccbi;
				break;
			case game.ObjectType.MadBee:
				ccbName = res.eleBat_C_ccbi;
				break;
			case game.ObjectType.DrillDog:
				ccbName = res.eleDrillDog_ccbi;
				break;
			case game.ObjectType.MapEater:
				ccbName = res.eleMapEater_ccbi;
				break;
			case game.ObjectType.JumpFrog:
				ccbName = res.enemyJumpSlime3_ccbi;
				break;
			default :
				break;
		}
		if (ccbName) {
			node = cc.BuilderReader.load(ccbName);
			var container = cc.Node.create();
			container.addChild(node);
			node.controller.setContainerNode(container);
			node.controller.setFaceTo(info.dir, true);
			if (node.controller.inMapBack) {
				game.Data.oLyGame.lyMapBack.addChild(container);
			} else {
				game.Data.oLyGame.lyMap.addChild(container);
			}
			return {container : container, controller : node.controller};
		} else {
			return null;
		}
	}
};
/*--  Enemy create function  --*/



// Enemies...
var EnemyMushroom = Enemy.extend({
	objType : game.ObjectType.Slime,
	_runAI : true,

	_onlyHor : false,
	_onlyVer : false,
	resetStatus : function () {
		this._hasCollide = true;
	},

	AILogic : function() {
		this._hasCollide = true;
		var mapConfig = game.Logic.configMap.getObject(this._grid);
		if (mapConfig) {
			if (mapConfig.first && mapConfig.last) {
				this._hasG = false;
				this._checkPosFirst = game.Logic.getTilePosCenterByGrid(vee.Utils.pAdd(this._grid, mapConfig.first));
				this._checkPosLast = game.Logic.getTilePosCenterByGrid(vee.Utils.pAdd(this._grid, mapConfig.last));
				if (mapConfig.first.y - mapConfig.last.y == 0) {
					this._onlyHor = true;
					this._accY = 0;
				} else {
					this._hasG = false;
					this._accY = this._accYForSet;
					this._speedYLimit = this._speedYLimitForSet;
				}
				if (mapConfig.first.x - mapConfig.last.x == 0) {
					this._onlyVer = true;
					this._accX = 0;
					this._speedXLimit = 0;
				} else {
					this._accX = this._accXForSet;
					this._speedXLimit = this._speedXLimitForSet;
				}
				if (this._checkPosFirst.y < this._checkPosLast.y) this._checkPosFirst.y = [this._checkPosLast.y, this._checkPosLast.y = this._checkPosFirst.y][0];
			}
			if (mapConfig.dir == "right") {
				this.setFaceTo(vee.Direction.Right);
			} else {
				this.setFaceTo(vee.Direction.Left);
			}
		}
		if (this._faceTo == vee.Direction.Right) {
			this.moveRight();
		} else {
			this.moveLeft();
		}

		this.playAnimate("run");
	},

	count : 0,
	AILogicPerFrame : function(dt) {
		if (this.count > 1) {
			this.count = 0;
			return;
		}
		++this.count;
		var pos = this.getElePosition();
		if (this._checkPosFirst) {
			if (!this._onlyVer) {
				if (pos.x < this._checkPosFirst.x){
					this._accX = this._accXForSet;
					this.setFaceTo(vee.Direction.Right);
				}
				if (pos.x > this._checkPosLast.x) {
					this._accX = -this._accXForSet;
					this.setFaceTo(vee.Direction.Left);
				}
			}
			if (!this._onlyHor) {
				if (pos.y > this._checkPosFirst.y)
					this._accY = -this._accYForSet;
				if (pos.y < this._checkPosLast.y)
					this._accY = this._accYForSet;
			}
		} else {
			this.defaultMoveLogic();
		}
		pos = null;
	},

	leftToBarrier : function() {
		this.moveRight();
	},

	rightToBarrier : function() {
		this.moveLeft();
	},

	collide : function(dir) {
		var oPlayer = game.Data.oPlayerCtl;
		if (oPlayer._isBounce || !this._hasCollide) return;
		if (dir == vee.Direction.Top && !oPlayer.extendController) {
			if (!game.Data.playerHawk) {
				this.popPlayerUp();
				this.dieAnimate(dir);
			}
		} else if (game.Data.playerHawk) {
			game.Data.oLyGame.shake();
			this.dieAnimate(dir);
		} else {
			if (game.Data.playerInvisible || oPlayer._isBounce) return;
			var dir = this.getElePosition().x > oPlayer.getElePosition().x ? vee.Direction.Left : vee.Direction.Right;
			oPlayer.getShock(dir, true);
			this.setFaceTo(vee.Direction.revert(dir));
			this.onGridChanged();
			if (this._faceTo == vee.Direction.Left) {
				this.moveLeft();
			} else {
				this.moveRight();
			}
		}
	},

	dieAnimate : function (dir) {
		this.onKill();
		var pos = this.getElePosition();
		EfxEnemyDie.show(pos);
		this._hasCollide = false;
		this._isOver = true;
		this.die();
	}
});

var EnemyDogSlime = EnemyMushroom.extend({
	objType : game.ObjectType.DogSlime,
	_triggerObj : true,
	_runAI : true,
	_loopEfx : null,
	resetStatus : function () {
		this._dashing = false;
		this._isFindPlayer = false;
	},

	_dashing : false,
	isDashing : function () {
		return this._dashing;
	},

	findTarget : function (callback) {
		vee.Audio.playEffect(res.inGame_monster_crazyFound_mp3);
		this._isFindPlayer = true;
		this._checkPosFirst = null;
		this._accX = 0;
		if (callback) {
			this.playAnimate("get", callback);
		} else {
			this.playAnimate("get");
		}
	},
	_findTargetCallback : null,
	findTargetWithDelay : function (delay, callback) {
		if (callback) this._findTargetCallback = callback;
		this._container.runAction(cc.sequence(
			cc.delayTime(delay),
			cc.callFunc(function () {
				this.findTarget(this._findTargetCallback);
			}.bind(this))
		));
	},

	dogDash : function () {
		this.playAnimate("eat");
		this._playerPos = game.Data.oPlayerCtl.getElePosition();
		this._speedXLimit = 600;
		this._dashing = true;
		if (this._faceTo == vee.Direction.Right) {// this._playerPos.x > this._pos.x
			this.moveRight();
		} else {
			this.moveLeft();
		}
	},

	_pos : null,
	_playerGrid : null,
	_playerPos : null,
	_isFindPlayer : false,
	AILogicPerFrame : function() {
		if (this._isOver) return;
		this._pos = this.getElePosition();
		this._playerGrid = game.Data.oPlayerCtl._grid;
		if (this._playerGrid.y == this._grid.y &&
			((this._faceTo == vee.Direction.Left && this._grid.x - this._playerGrid.x <= 6 && this._grid.x - this._playerGrid.x >= 0) ||
			(this._faceTo == vee.Direction.Right && this._playerGrid.x - this._grid.x <= 6 && this._playerGrid.x - this._grid.x >= 0)) &&
			!game.Data.oPlayerCtl._isBounce)
		{
			// find player
			if (!this._isFindPlayer) {
				this.findTarget(function () {
					this.dogDash();
				}.bind(this));
			}
		}
		else if (!this._isFindPlayer)
		{
			this._dashing = false;
//			this._speedXLimit = 100;
		}
		var pos = this.getElePosition();
		if (this._checkPosFirst && !this._isFindPlayer) {
			if (!this._onlyVer) {
				if (pos.x < this._checkPosFirst.x){
					this._accX = this._accXForSet;
					this.setFaceTo(vee.Direction.Right);
				}
				if (pos.x > this._checkPosLast.x) {
					this._accX = -this._accXForSet;
					this.setFaceTo(vee.Direction.Left);
				}
			}
			if (!this._onlyHor) {
				if (pos.y > this._checkPosFirst.y)
					this._accY = -this._accYForSet;
				if (pos.y < this._checkPosLast.y)
					this._accY = this._accYForSet;
			}
		} else {
			this.defaultMoveLogic();
		}
		pos = null;
	},

	leftToBarrier : function() {
		this._hasG = true;
		var tgGrid = cc.p(this._grid.x-1, this._grid.y);
		var tdToBarrier = game.Logic.map.getObject(tgGrid);
		game.Logic.checkTileTrigger(tgGrid, vee.Direction.Left, tdToBarrier, this);
		game.Logic.triggerTileCallback(tdToBarrier, this, vee.Direction.Left);
		if (!this._isOver) {
			if (this._dashing) {
				this._accX = 0;
				this._speedX = 200;
				this._speedY = 500;
			}
			this._dashing = false;
			this._isFindPlayer = false;
			this._speedXLimit = 100;
			this.playAnimate("run");
//		vee.Audio.stopEffect(this._loopEfx);
			this.moveRight();
		}
	},

	rightToBarrier : function() {
		this._hasG = true;
		var tgGrid = cc.p(this._grid.x+1, this._grid.y);
		var tdToBarrier = game.Logic.map.getObject(tgGrid);
		game.Logic.checkTileTrigger(tgGrid, vee.Direction.Right, tdToBarrier, this);
		game.Logic.triggerTileCallback(tdToBarrier, this, vee.Direction.Right);
		if (!this._isOver) {
			if (this._dashing) {
				this._accX = 0;
				this._speedX = -200;
				this._speedY = 500;
			}
			this._dashing = false;
			this._isFindPlayer = false;
			this._speedXLimit = 100;
			this.playAnimate("run");
//		vee.Audio.stopEffect(this._loopEfx);
			this.moveLeft();
		}
	},

	downToBarrier : function(td) {
		if (!this._dashing) {
			this._speedXLimit = this._speedXLimitForSet;
		}
		this.pushedDir[vee.Direction.Bottom] = 1;
		this._speedY = 0;
		this._accY = 0;
		this.jumping = false;
		game.Logic.triggerTileCallback(td, this, vee.Direction.Bottom);
	},

	collide : function(dir) {
		if (game.Data.oPlayerCtl._isBounce || this._isOver) return;
		if (dir == vee.Direction.Top && !game.Data.oPlayerCtl.extendController) {
			if (!game.Data.playerHawk) {
				this.popPlayerUp();
				this.dieAnimate(dir);
			}
		} else if (game.Data.playerHawk) {
			game.Data.oLyGame.shake();
			this.dieAnimate(dir);
		} else {
			if (game.Data.playerInvisible) return;
			var dir = this.getElePosition().x > game.Data.oPlayerCtl.getElePosition().x ? vee.Direction.Left : vee.Direction.Right;
			game.Data.oPlayerCtl.getShock(dir, true);
			this.onGridChanged();
		}
	},

	onDead : function () {
//		vee.Audio.stopEffect(this._loopEfx);
	},

	moveToGrid : function(grid, callback) {
		Cinema.moveToGrid(this, grid, callback);
	}
});