/**
 * Created with AppCode.
 * User: yop
 * Date: 15/10/30
 * Time: 下午7:02
 * To change this template use File | Settings | File Templates.
 */


LevelController.LevelEvent104 = LevelController.extend({
	eventStory1 : function(grid, dir) {
		this.showStory(1, grid, ""+
			"MoveCamera,24,13,2;"+
			"SelectNpc,Flash;"+
			"ShowDialog,"+ vee.Utils.getLocalizedStringForKey("We are talking about you!", "我们正在谈起你呢！") +";"+
			"ShowDialog,"+ vee.Utils.getLocalizedStringForKey("Oh here's your new friend!", "哦对了，这位是新的小伙伴！") +";"+
			"ShowDialog,"+ vee.Utils.getLocalizedStringForKey("Our new friend is very interested in you, he is mini...!", "他是小...") +";"+
			"HideDialog;"+
			"SelectNpc;"+
			"ShowDialog,"+ vee.Utils.getLocalizedStringForKey("Nah, you are the mini minion one!", "叽！你才小！") +";"+
			"ShowDialog,"+ vee.Utils.getLocalizedStringForKey("Get out, big guy!", "滚开，大高个！") +";"+
			"HideDialog;"+
			"MoveRole,25,13;"+
			"ShowDialog,"+ vee.Utils.getLocalizedStringForKey("Here you are!", "给，") +";"+
			"ShowDialog,"+ vee.Utils.getLocalizedStringForKey("Oh -- and here's my data!", "这是我的数据！") +";"+
			"HideDialog;"+
			"UnlockRole;"+
			"TimeLine,huxi_2;"+
			"Delay,1;"+
			"MoveCamera,12,13,1;"+
			"Trigger,24,14;"+
			"Delay,2;"+
			"MoveCamera,24,13,1;"+
			"ShowDialog,"+ vee.Utils.getLocalizedStringForKey("I will dance on your grave!", "你挂的时候我会鼓掌的，") +";"+
			"ShowDialog,"+ vee.Utils.getLocalizedStringForKey("I just rolling my eyes. Bye!", "再见！叽！") +";"+
			"HideDialog"+
		"");
	}
});