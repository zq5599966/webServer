/**
 * Created with AppCode.
 * User: WanThirty
 * Date: 15/11/10
 * Time: 下午1:32
 * To change this template use File | Settings | File Templates.
 */

var LyDemoText = vee.Class.extend({
	ccbInit : function (callback) {
		this.playAnimate("open", callback);
	}
});

LyDemoText.show = function (callback) {
	var node = vee.PopMgr.popCCB("res/lyDemoText.ccbi", {alpha:0});
	node.controller.ccbInit(callback);
};