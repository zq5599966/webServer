/**
 * Created with AppCode.
 * User: yop
 * Date: 15/9/3
 * Time: 下午8:03
 * To change this template use File | Settings | File Templates.
 */

var BtnShop = vee.Class.extend({
	spHead : null,
	spBtnR : null,
	btnOpenStore : null,
	onCreate : function () {
		BtnShop.instance = this;
		this.refreshBtnHead();
		vee.Controller.registerControllerSprite(this.spBtnR);
	},

	onExit : function () {
		BtnShop.instance = null;
		vee.Controller.removeControllerSprite(this.spBtnR);
	},

	refreshBtnHead : function () {
		var avatar = game.AvatarData.getCurrentAvatar();
		this.spHead.setTexture(avatar.headName);
	},


	tmpIndex : 0,
	onOpenStore : function() {
		if(game.Data.zqdebug){
			/*
			ccbContinuousLoginAlert.show(this.tmpIndex);
			this.tmpIndex++;
			if(this.tmpIndex > 4) this.tmpIndex = 0;
			*/

			// LyRate.show();

			// ccbRevivalVideoAlert.show();

			vee.Ad.showInterstitialByOnlineConfig("game_over");


			return;
		}
                               
		if (LyLevelSelect.isUnlocking) return;
		if (LyAvatarStore.getInstance()) {
			LyAvatarStore.getInstance().show();
		}
	}
});

BtnShop.instance = null;
BtnShop.refreshHead = function () {
	if (BtnShop.instance) {
		BtnShop.instance.refreshBtnHead();
	}
};

var LyAvatarStore = vee.Class.extend({
	/** @type {vee.PagingController} */
	pagingCtl : null,

//	lbCoinNum : null,

	btnClose      : null,
	btnBuyAll     : null,
	btnRestore    : null,
	containerNode : null,
	lbPrice       : null,
	lbRestore     : null,
	ccbBuyAvatar  : null,

	onLoaded : function() {
		LyAvatarStore.instance = this;

		this.initContent();



		if(game.Data.isFreeGame){
			var num = Math.ceil((this.lyContent.getChildrenCount()-1) / 2) + 1;
		}
		else{
			var num = Math.ceil(this.lyContent.getChildrenCount() / 2);
		}

		cc.log("lyContent count=====%d   num====%d", this.lyContent.getChildrenCount(), num);

		var ctl = vee.PowerPagingController.registerController(this.lyContent, num);
		ctl.setSensitivity(0.75);
		ctl.setBounceEnabled(true);
		ctl.setPageChanged(this.onPageChanged.bind(this));
		ctl.setDragingBuffer(30);
		ctl.setEnabled(false);


		this.pagingCtl = ctl;

		vee.PopMgr.setNodePos(this.btnClose, vee.PopMgr.PositionType.TopRight, cc.p(0,0));
		this.rootNode.setVisible(false);
		this.rootNode.setLocalZOrder(-1);

		this.refreshCoin();
		this.refreshBuyState();
		this.handleKey(true);
		LyAvatarStore.isShow = false;
	},

	initContent : function(){
		cc.log("content size===w==%d  h==%d", this.lyContent.getContentSize().width, this.lyContent.getContentSize().height);

		var num = game.AvatarData.getProductData().length;
		var modelItem = this.lyContent.getChildByTag(1);
		var beginPosX = modelItem.getPositionX();


		//y=== 360 114  x=== 552
		for(var i = 1; i < num; i++){
			var item = cc.BuilderReader.load(res.avatarCell_ccbi);

			var index = i + 1;
			item.setTag(index);

			var col = Math.floor(i / 2);
			var row = (index + 1) % 2;
			var posX, posY;
			posY = row == 0 ? 360 : 114;
			posX = beginPosX + col * 552;

			item.setPosition(cc.p(posX, posY));
			this.lyContent.addChild(item);

			this["avatarCell"+(i+1)] = item;

			item.controller.init(index);
		}

	},

	_tempControllerState : null,
	_defaultCursorGrid : null,
	initController : function () {
		vee.Controller.activeButton();
		vee.Controller.registerButtonAction(
			vee.KeyCode.BUTTON_DPAD_LEFT,
			this.pageToLeft.bind(this)
		);
		vee.Controller.registerButtonAction(
			vee.KeyCode.BUTTON_DPAD_RIGHT,
			this.pageToRight.bind(this)
		);
		vee.Controller.registerButtonAction(
			[vee.KeyCode.BUTTON_B,vee.KeyCode.BUTTON_RIGHT_SHOULDER,vee.KeyCode.AXIS_RIGHT_TRIGGER],
			this.hide.bind(this)
		);
		var initGrid = this._defaultCursorGrid ? this._defaultCursorGrid : cc.p(1,0);
		vee.Controller.initSelector(9, 2, null, initGrid);
		if (game.Data.isFreeGame) {
			if (this.btnBuyAll.isVisible()) {
				vee.Controller.registerItemByButton(this.btnBuyAll, cc.p(0,0), this.onBuyAll.bind(this), "res/mfi_btn_on_210.png");
				vee.Controller.registerItemByButton(this.btnRestore, cc.p(0,1), this.onRestore.bind(this), "res/mfi_btn_on_170.png");
			}
		}
		this.createItem();
		vee.Controller.activeSelector();
	},

	pageToLeft : function () {
		var pageGrid = vee.Controller.getSelectorGrid();
		cc.log("page To left ===x=%d  y=%d", pageGrid.x, pageGrid.y);
		this.pagingCtl.setPage(pageGrid.x + 1, true);
	},

	pageToRight : function () {

		var pageGrid = vee.Controller.getSelectorGrid();

		cc.log("page To Right ===x=%d  y=%d", pageGrid.x, pageGrid.y);

		this.pagingCtl.setPage(pageGrid.x + 1, true);
	},

	createItem : function () {
		for (var i = 1; i < 9; ++i) {
			var ctl = this._getAvatarCellCtl(i*2-1);
			if (ctl) vee.Controller.registerItemByButton(ctl.spBG, cc.p(i,0), ctl.onBuy.bind(ctl), "res/mfi_avatar_on.png", cc.p(-4,0));
			var ctl = this._getAvatarCellCtl(i*2);
			if (ctl) vee.Controller.registerItemByButton(ctl.spBG, cc.p(i,1), ctl.onBuy.bind(ctl), "res/mfi_avatar_on.png", cc.p(-4,0));
		}
	},

	_getAvatarCellCtl : function (idx) {
		var cell = this["avatarCell" + idx];
		if (cell)
			return cell.controller;
		else
			return null;
	},

	onExit : function () {
		LyAvatarStore.instance = null;
		LyAvatarStore.arrCell = [];
	},

	refreshBuyState : function () {
		if (game.Data.isWeiXin) {
			this.btnRestore.setVisible(false);
			this.lbRestore.setVisible(false);
		}
		if (game.Data.isFreeGame && vee.data["allcat"]) {
			this.btnBuyAll.setVisible(false);
			this.btnRestore.setVisible(false);
			this.lbPrice.setVisible(false);
			this.lbRestore.setVisible(false);
			this.ccbBuyAvatar.controller.refreshState();
		}
	},

	onKeyBack : function() {
		this.hide();
		return true;
	},

	refreshCoin : function () {

	},

	onClose : function() {
		this.hide();
	},

	show : function() {

		/*
		if(game.Data.zqdebug){
			vee.Ad.showInterstitialByOnlineConfig("avarar store click");
			return;
		}
		*/
		game.Data.curSceen = "lyAvatarStore";

		LyAvatarStore.isShow = true;
		cc.log("avatar show");
		this.pagingCtl.setEnabled(true);
		this.rootNode.setVisible(true);
		this.rootNode.setLocalZOrder(99999); //update Touch
		this.playAnimate('show');
		vee.Audio.playEffect(res.outGame_menu_intoStore_mp3);

		this._tempControllerState = vee.Controller.cacheControllerState();
	},

	hide : function() {
		if (!LyAvatarStore.isShow) return;
		vee.Controller.deactiveSelector();
		vee.Controller.deactiveButton();
		if (vee.Controller._cursorGrid) {
			this._defaultCursorGrid = cc.p(vee.Controller._cursorGrid.x, vee.Controller._cursorGrid.y);
		}

		this.pagingCtl.setEnabled(false);
		this.playAnimate('hide', function() {
			LyAvatarStore.isShow = false;
			this.rootNode.setVisible(false);
			this.rootNode.setLocalZOrder(-1); //update Touch

			vee.Controller.reviveControllerState(this._tempControllerState);
		}.bind(this));
		vee.Audio.playEffect(res.outGame_menu_closeStore_mp3);
	},

	onPageChanged : function(pageNum) {

	},

	onBuyAll : function () {
		if (!this.btnBuyAll.isVisible()) return;
		vee.IAPMgr.buyProduct(1, function () {
			game.AvatarData.allPurchase();
			this.refreshBuyState();
			cc.log("state : "+vee.Controller._isActiveSelector+" "+vee.Controller._isActiveButton);
			vee.Controller.activeButton();
			vee.Controller.activeSelector();
			vee.Utils.scheduleOnce(function () {
				vee.PopMgr.alert(
					vee.Utils.getLocalizedStringForKey("All avatar has been unlocked"),
					vee.Utils.getLocalizedStringForKey("SUCCESS")
				);
			}, 0.2);
			vee.Analytics.logChargeSuccess(game.Data.orderId);
		}.bind(this), function () {

		});
		game.Data.orderId = new Date().getTime();
		vee.Analytics.logChargeRequest(game.Data.orderId, 1, 1.99);
	},

	onRestore : function () {
		if (!this.btnRestore.isVisible()) return;
		vee.IAPMgr.restoreProduct(function (productID) {
			cc.log("pd id = "+productID);
			var ids = productID.split(",");
			for (id in ids) {
				var pdid = ids[id];
				if (pdid == "com.veewo.allcat" || pdid == "com.veewo.allcat.cn") {
					game.AvatarData.allPurchase();
					this.refreshBuyState();
					vee.Controller.activeButton();
					vee.Controller.activeSelector();
					vee.Utils.scheduleOnce(function () {
						vee.PopMgr.alert(
							vee.Utils.getLocalizedStringForKey("All avatar has been unlocked"),
							vee.Utils.getLocalizedStringForKey("SUCCESS")
						);
					}, 0.2);
				}
			}
		}.bind(this));
	}
});

LyAvatarStore.instance = null;
LyAvatarStore.getInstance = function () {
	return LyAvatarStore.instance;
};
LyAvatarStore.arrCell = [];
LyAvatarStore.refreshState = function () {
	if (LyAvatarStore.instance) {
		for (var i in LyAvatarStore.arrCell) {
			var cell = LyAvatarStore.arrCell[i];
			cell.refreshCellState();
		}
	}
};

LyAvatarStore.isShow = false;

LyAvatarStore.load = function () {
	var node = null;

//	if(true){
//		node = cc.BuilderReader.load(res.lyAvatarStore_new_ccbi);
//		return node;
//	}

	if (game.Data.isFreeGame) {
		node = cc.BuilderReader.load(res.lyAvatarStore_android_ccbi);
	} else {
		node = cc.BuilderReader.load(res.lyAvatarStore_ccbi);
	}
	return node;
};

var BuyAvatar = vee.Class.extend({
	spText : null,

	onCreate : function () {
		this.refreshState();
	},

	refreshState : function () {
		if (vee.data["allcat"]) {
			this.spText.setVisible(false);
		}
	}
});



