/**
 * Created with AppCode.
 * User: yop
 * Date: 15/9/2
 * Time: 上午11:53
 * To change this template use File | Settings | File Templates.
 */

var CategoryData = cc.Class.extend({
	idx : null,
	bg : null,
	title : null,
	percent : null,
	levels : null,
	beginLevel : null,
	endLevel : null,
	levelCount : null,
	unlockStar : null,
	lockStatus : null,
	bgUnlock : null,
	categoryReady : null,

	ctor : function(bg, title, idx, beginLevel, levelCount, percent, unlockStar, lockStatus, bgUnlock, categoryReady) {
		this.bg = bg;
		this.title = title;
		this.idx = idx;
		this.percent = percent;
		this.beginLevel = beginLevel;
		this.levelCount = levelCount;
		this.unlockStar = unlockStar;
		this.lockStatus = lockStatus;
		this.bgUnlock = bgUnlock;
		this.categoryReady = categoryReady;
		this.endLevel = this.beginLevel + this.levelCount - 1;
	},

	getStarCount : function(star) {
		return (star & 0x0001 ? 1 : 0) + (star & 0x0010 ? 1 : 0) + (star & 0x0100 ? 1 : 0);
	},

	isAllLevelUnlock : function () {
		for (var i in this.levels) {
			var level = this.levels[i];
			if (level.lock) return false;
		}
		return true;
	},

	isAllLevelPass : function(){
		var level = this.levels[this.levelCount - 1];
		vee.Utils.logObj(level, "level data---------");
		return level.isLevelPassed;
//		return false;
	},

	checkHasUnlockMoon : function(){
		var levelIndex = game.LevelData.selectedCategory.idx;

		if(game.Data.version.newVersion){
			var isFirstPass = game.LevelData.getCategory(0).isAllLevelPass();
			var firstLevelPass = this.getLevelData(0).isLevelPassed;
			cc.log("level index========%d", levelIndex);
			return isFirstPass && firstLevelPass && levelIndex < 5;
		}
		else{
			return (this.isAllLevelPass() && levelIndex < 5);
		}
	},

	updatePercent : function() {
		var starCount = 0;
		if (!this.levels) this.load();
		for(var i = 0; i < this.levelCount; i++) {
			starCount += this.getStarCount(this.levels[i].star);
		}
		var percent = Math.floor(starCount * 100 / (this.levelCount*3));
		if (percent == 100) {
			vee.GameCenter.unlockAchievement(this.idx);
		}
		if (this.percent != percent) {
			game.LevelData.setPercent(this.idx, this.percent);
			this.percent = percent;
		}
	},

	isAllStarArchive : function () {
		var starCount = this.getCategoryStarCount();
		return starCount == (this.levelCount*3);
	},

	getCategoryStarCount : function () {
		var starCount = 0;
		if (!this.levels) this.load();
		for(var i = 0; i < this.levelCount; i++) {
			starCount += this.getStarCount(this.levels[i].star);
		}
		return starCount;
	},

	save : function() {
		vee.Utils.saveObj(this.levels,'yrogetac_'+this.idx);
		this.updatePercent();
	},

	load : function() {
		cc.log("this.idx = "+this.idx);
		if (this.idx == undefined) return null;
		this.levels = vee.Utils.loadObj('yrogetac_'+this.idx);
		if (!this.levels) {
			this.levels = [];
		}
		// initialize LevelData
		for(var i = 0; i < this.levelCount; i++) {
			if (!this.levels[i]) {
				this.levels[i] = {
					levelNo: (this.beginLevel + i),

					/* */
					lock: true,
					isCollectAllCoin: false,
					star: 0,
					playedCount: 0,
					/*
					 lock : false,
					 isCollectAllCoin : vee.Utils.isLucky(0.3),
					 star : vee.Utils.randomInt(0,7),
					 playedCount : vee.Utils.randomInt(0,3),
					 */
					lastKilledPos: false
				}
			}
		}
		if (this.levels[0].levelNo < 99) {
			this.levels[0].lock = false;
		}
		this.save();
	},

	/**
	 * @param idx
	 * @returns {CategoryData.LevelDataController}
	 */
	getLevelDataController : function(idx) {
		if (!this.levels) this.load();
		if (!this.levels || !this.levels[idx]) return null;
		return CategoryData.LevelDataController.getController(idx, this.levels[idx]);
	},

	/**@return {CategoryData.LevelData}*/
	getLevelData : function(idx) {
		if (!this.levels) this.load();

        if(this.levels){
            return this.levels[idx];
        }
		return null;
	}
});

CategoryData.LevelData = {
	levelNo             : 0,
	lock                : true,
	star                : 0x0000,
	playedCount         : 0,
	continueKilledCount : 0,
	lastKilledPos       : null,
	isCollectAllCoin    : false,
	isReverseKeyCollected : false,
	isLevelPassed		: false
};

CategoryData.LevelDataController = {
	/** @type {CategoryData.LevelData} */
	levelData : null,
	idx : null,

	tempStarAchieved : 0x0000,
	tempKeyCollected : false,

	getController : function(idx, data) {
		this.idx = idx;
		this.levelData = data;
		this.tempStarAchieved = 0x0000;
		return this;
	},

	getLevelState : function(data) {
		var data = data ? data : this.levelData;
		if (data.lock) return 0;
		return (data.playedCount > 0 ? 2 : 1);
	},

	levelComplete : function(allCoinCollect) {
		var category = game.LevelData.selectedCategory;
		this.levelData.playedCount += 1;
		this.levelData.isLevelPassed = true;

		if (allCoinCollect) {
			// all Coin Collect
			this.levelData.isCollectAllCoin = true;
		}

		this.levelData.lastKilledPos = false;
		this.levelData.continueKilledCount = 0;

		var newStar = this.levelData.star | this.tempStarAchieved;
		if (newStar != this.levelData.star) {
			if (category.idx < 100) {
				game.LevelData.addStar(category.getStarCount(newStar) - category.getStarCount(this.levelData.star));
			}
			this.levelData.star = newStar;
		}

		if (this.tempKeyCollected && category.idx < 100) {
			this.levelData.isReverseKeyCollected = true;
			if (game.Data.isReverseWorldOpen) this._checkReverseLevel(category);
			this.tempKeyCollected = false;
		}

		if (newStar == 0x0111) {
			// all star got
		}

		//unlock new level
		if (category.idx < 100) {
			var lData = category.getLevelData(this.idx + 1);
			if (lData) lData.lock = false;
		}

		game.LevelData.selectedCategory.save();
	},

	_checkReverseLevel : function (category) {
		var reverseCategoryIdx = category.idx + 100;
		var reverseCategory = game.LevelData.getCategory(reverseCategoryIdx);
		var reverseLevel = reverseCategory.getLevelData(this.idx);
		if (reverseLevel) {
			reverseLevel.lock = false;
			game.Data.newMoonLevelIdx = reverseLevel.levelNo;
			cc.log('game.Data.newMoonLevelIdx + '+game.Data.newMoonLevelIdx);
		}
		reverseCategory.save();
	},

	levelFail : function(grid) {
		this.levelData.continueKilledCount += 1;
		this.lastKilledPos = grid;

		game.LevelData.selectedCategory.save();
	},

	gameBegin : function(isSavePoint) {
		if (!isSavePoint) {
			cc.log(" !!!!!!!!!! ======= reset level data!!");
			this.tempStarAchieved = 0x0000;
		}
	},

	starAchieved : function (idx) {
		switch (idx) {
			case 1 :
				this.tempStarAchieved = this.tempStarAchieved | 0x0001;
				break;
			case 2 :
				this.tempStarAchieved = this.tempStarAchieved | 0x0010;
				break;
			case 3 :
				this.tempStarAchieved = this.tempStarAchieved | 0x0100;
				break;
		}

		// if(!game.LevelData.selectedLevel.isStarAchieved(idx)){
		// 	vee.Analytics.UGameEvent.registerSuperProperty("", 1);
		// }
	},

	isTempStarAchieved : function (idx) {
		switch (idx) {
			case 1 :
				return (this.tempStarAchieved & 0x0001) > 0;
			case 2 :
				return (this.tempStarAchieved & 0x0010) > 0;
			case 3 :
				return (this.tempStarAchieved & 0x0100) > 0;
			default :
				return false;
		}
	},

	isStarAchieved : function (idx) {
		switch (idx) {
			case 1 :
				return (this.levelData.star & 0x0001) > 0;
			case 2 :
				return (this.levelData.star & 0x0010) > 0;
			case 3 :
				return (this.levelData.star & 0x0100) > 0;
			default :
				return false;
		}
	},

	getCurrentStarAchieved : function() {
		return this.tempStarAchieved;
	},

	getAchievedStarCount : function () {
		var count = 0;
		for (i = 1; i < 4; ++i) {
			if (this.isStarAchieved(i)) {
				++count;
			}
		}
		return count;
	},

	tempReverseKeyCollected : function () {
		this.tempKeyCollected = true;
	},

	isLevelReverseKeyCollected : function () {
		return this.levelData.isReverseKeyCollected;
	},

	getLevelNo : function() {
		return this.levelData.levelNo;
	},

	isAllCoinCollect : function() {
		return this.levelData.isCollectAllCoin;
	},

	isNextLevelAvailable : function() {
		var levelData = game.LevelData.selectedCategory.getLevelData(this.idx + 1);
		if (levelData && !levelData.lock) return true;
		return false;
	},


	
	isHaveNextLevel : function () {
        cc.log("is have next level");
		var levelData = game.LevelData.selectedCategory.getLevelData(this.idx + 1);
		if (levelData && !levelData.lock) {
            cc.log("is have next level 11111111");
			return true;
		}
        cc.log("is have next level 22222222");
		return false;
	},

	isGoNextCategory : function () {
		if (game.Data.isClearVersion || game.Data.isFreeGame) {
			var level = game.LevelData.selectedLevel;
			var isKeyCollected = level && level.isLevelReverseKeyCollected();
			if (game.Data.isSelectingReverseWorld && !isKeyCollected) {
				return false;
			}
			if (game.LevelData.selectedCategory.idx == 5 &&
				(game.LevelData.selectedLevel.idx == game.LevelData.selectedCategory.levelCount - 1)){
				return false;
			}

			var nextCategory = game.LevelData.getNextCategory();
			if (!nextCategory || !nextCategory.categoryReady) {
				return false;
			}

			game.LevelData.selectedCategory = nextCategory;
			var levelData = nextCategory.getLevelData(0);
			game.LevelData.selectedLevel = this.getController(0, levelData);
			return true;
		}
		return false;
	},

	setNextSelectLevel : function () {
		var levelData = game.LevelData.selectedCategory.getLevelData(this.idx + 1);
		game.LevelData.selectedLevel = this.getController(this.idx + 1, levelData);
	},


	goNextLevel : function() {
		var levelData = game.LevelData.selectedCategory.getLevelData(this.idx + 1);
		if (levelData && !levelData.lock) {
			game.LevelData.selectedLevel = this.getController(this.idx + 1, levelData);
			return true;
		}

//		if (game.Data.isClearVersion || game.Data.isAndroid && game.Data.isFreeGame) {
		if (game.Data.isClearVersion || game.Data.isFreeGame) {
			var level = game.LevelData.selectedLevel;
			var isKeyCollected = level && level.isLevelReverseKeyCollected();
			if (game.Data.isSelectingReverseWorld && !isKeyCollected) {
				return false;
			}
			if (game.LevelData.selectedCategory.idx == 5 &&
				(game.LevelData.selectedLevel.idx == game.LevelData.selectedCategory.levelCount - 1)){
				return false;
			}

			var nextCategory = game.LevelData.getNextCategory();
			if (!nextCategory) {
				return false;
			}
			game.LevelData.selectedCategory = nextCategory;
			var levelData = nextCategory.getLevelData(0);
			game.LevelData.selectedLevel = this.getController(0, levelData);
			return true;
		}


		return false;
	}
}