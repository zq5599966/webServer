/**
 * Created with AppCode.
 * User: WanThirty
 * Date: 15/9/11
 * Time: 下午2:46
 * To change this template use File | Settings | File Templates.
 */

var EfxWinStar = vee.Class.extend({
	spBack : null,

	setGettedStar : function () {
		if (game.Data.checkIs61()) {
			this.spBack.setSpriteFrame("win_statChild_off2.png");
		} else {
			this.spBack.setSpriteFrame("win_stat_off_2.png");
		}
	},

	show : function () {
		this.playAnimate("light");
	},

	unlock : function () {
		this.playAnimate("unlock");
	},

	ScrShake : function () {
		if (!game.Data.oLyGameOver) return;
		var sc = game.Data.oLyGameOver.rootNode;
		sc.stopAllActions();
		var dur = 0.03;
		var amplitudeY = 18;
		sc.runAction(cc.sequence(
			cc.MoveBy.create(dur,   0, -amplitudeY),
			cc.MoveBy.create(dur,   0, amplitudeY*2),
			cc.MoveBy.create(dur,   0, -amplitudeY),
			cc.MoveBy.create(dur/2, 0, amplitudeY),
			cc.MoveBy.create(dur/2, 0, -amplitudeY*2),
			cc.MoveBy.create(dur/2, 0, amplitudeY)
		));
	}
});