/**
 * Created with AppCode.
 * User: WanThirty
 * Date: 15/11/27
 * Time: 上午11:14
 * To change this template use File | Settings | File Templates.
 */

var EnemyTrap = vee.Class.extend({
	trapBlockData : null,
	grid : null,

	ccbInit : function () {
		this.playAnimate("huxi");
	},

	attack : function () {
		this.playAnimate("attack", function () {
			this.playAnimate("reset", function () {
				this.trapBlockData.trapped = false;
			}.bind(this));
			game.Logic.map.removeObject(this.grid);
		}.bind(this));
	},

	makeDamage : function () {
		var playerGrid = game.Data.oPlayerCtl._grid;
		if (game.Logic.isGridSame(this.grid, playerGrid)) {
			// damage!
			game.Data.oPlayerCtl.getShock(game.Data.oPlayerCtl._faceTo, true);
		}
		// might be bomb
		var tileDataForCheck = game.Logic.map.getObject(this.grid);
		if (tileDataForCheck && tileDataForCheck.tileInfo.type == game.ObjectType.BlockBomb) {
			var tileData = game.Logic.getBlockTileData(this.grid, this.trapBlockData.layer);
			tileDataForCheck.tempData = tileData;
		} else {
			var tileData = game.Logic.getBlockTileData(this.grid, this.trapBlockData.layer);
			game.Logic.map.setObject(tileData, this.grid);
		}
	}
});