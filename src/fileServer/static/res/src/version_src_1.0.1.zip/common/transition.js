/**
 * Created with AppCode.
 * User: Yop Chan
 * Date: 14-7-7
 * Time: 下午3:18
 * To change this template use File | Settings | File Templates.
 */

var VeeTransition = vee.Class.extend({

	_in : function(callback){
		this.playAnimate("out", function(){
			this.rootNode.removeFromParent();
			if (callback) callback();
		}.bind(this));
	},

	_out : function(callback){
		this.playAnimate("in", function(){
			this.rootNode.removeFromParent();
			if (callback) callback();
		}.bind(this));
	},

	_performInOut : function (callback, delay, finishCallback) {
		this.playAnimate("in", function () {
			this.rootNode.runAction(cc.sequence(
				cc.delayTime(delay),
				cc.callFunc(function () {
					if (callback) callback();
					this._in(finishCallback);
				}.bind(this))
			));
		}.bind(this));
	}
});

var vee = vee = vee || {};

vee.Transition = {};

vee.Transition.pop = function(ccb, pos){
	var node = cc.BuilderReader.load(ccb);
	var lyTouch = cc.LayerGradient.create(cc.color(0,0,0,150),cc.color(0,0,0,150));
	lyTouch.setOpacity(0);
	cc.eventManager.addListener({
		event: cc.EventListener.TOUCH_ONE_BY_ONE,
		swallowTouches: true,
		onTouchBegan: function(touches, event){
			return true;
		}
	}, lyTouch);
	node.addChild(lyTouch);
	vee.PopMgr.rootNode.addChild(node);
	if (pos) node.setPosition(pos);
	else vee.PopMgr.setNodePos(node, vee.PopMgr.PositionType.Center, cc.p(0,0), true);
	return node;
};

vee.Transition.in = function(ccb, callback, pos){
	var node = this.pop(ccb, pos);
	node.controller._in(callback);
};

vee.Transition.out = function(ccb, callback, pos){
	var node = this.pop(ccb, pos);
	node.controller._out(callback);
};

vee.Transition.perform = function (ccb, callback, delay, finishCallback) {
	if (!delay) delay = 0;
	var node = this.pop(ccb);
	node.controller._performInOut(callback, delay, finishCallback);
};