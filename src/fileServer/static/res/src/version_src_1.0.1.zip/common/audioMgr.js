var vee = vee = vee || {};

vee.Audio = {
    event : {
        popLayer : "res/sfx_menu_openwindow.mp3",
        closeLayer : "res/sfx_menu_closewindow.mp3",
        button : "res/sfx_menu_buttonclick.mp3"
    },
    
    lastBGM : null,
    
    currentBGID : -1,
    
    _isMusicPause : false,
    _isMusicStopped : false,	//用于处理停止音效会停止音乐的问题
    
    addEventEffect : function(eventName, effectName) {
        this.event[eventName] = effectName;
    },
    
    addEvents : function(obj) {
        for(var key in obj){
            this.event[key] = obj[key];
        }
    },
    
    preload : function (str, callback) {
        if(!callback){
            callback = function (isSuccess) {
                // cc.log("preload audio str===%s" + isSuccess, str);
                if(!isSuccess){
                    preload(str, callback);
                }
            }
        }
        // jsb.AudioEngine.preload(str, callback);
    },
    
    /**
     *
     * @param 目前可以传 popLayer, closeLayer, button 三种
     */
    onEvent : function(e, loop){
        var efx = this.event[e];
        if(efx) {
            if (_.isArray(efx)) {
                var idx = vee.Utils.randomInt(0,efx.length-1);
                return this.playEffect(efx[idx], loop);
            } else return this.playEffect(efx, loop);
        }
    },
    
    /**
     *
     * @param efx
     */
    playEffect : function(efx, loop){
        if (!this.soundEnabled) return null;
        var a = arguments[1] ? arguments[1] : false;
        return jsb.AudioEngine.play2d(efx, loop);
    },
    
    /**
     *
     * @param efx
     */
    stopEffect : function(efx){
        //if (efx)
        //	cc.audioEngine.stopEffect(efx);
    },
    
    stopAllEffcts : function() {
        //cc.audioEngine.stopAllEffects();
        jsb.AudioEngine.stopAll();
        this._isMusicStopped = true;
    },
    
    pauseAllEffects : function() {
        //cc.audioEngine.pauseAllEffects();
        jsb.AudioEngine.pauseAll();
        if (this.musicEnabled && !this._isMusicPause) {
            jsb.AudioEngine.resume(this.currentBGID);
        }
    },
    
    resumeAllEffects : function(){
        jsb.AudioEngine.resumeAll();
        if (this.musicEnabled && this._isMusicPause) {
            jsb.AudioEngine.pause(this.currentBGID);
        }
    },
    
    /**
     *
     * @param m
     */
    playMusic : function(m) {
        if (this.currentBGID != -1) {
            vee.Audio.stopMusic();
        }
        this.lastBGM = m;
        if (!this.musicEnabled) return;
        this.currentBGID = jsb.AudioEngine.play2d(m, true);
    },
    
getLastMusic: function(){
    return this.lastBGM;
},
    
    playLastMusic : function() {
        if (!this.musicEnabled) return;
        if (this.lastBGM){
	        if (this.currentBGID != -1) {
	            jsb.AudioEngine.stop(this.currentBGID);
	        }
	        cc.log("zq debug play last music====" + this.lastBGM);
            this.currentBGID = jsb.AudioEngine.play2d(this.lastBGM, true);
        }
    },
    
    stopMusic : function() {
        this.lastBGM = undefined;
        jsb.AudioEngine.stop(this.currentBGID);
	    this.currentBGID = -1;
    },
    
    stopMusicWithSave : function() {
        jsb.AudioEngine.stop(this.currentBGID);
    },
    
    pauseMusic : function() {
        jsb.AudioEngine.pause(this.currentBGID);
    },
    
    resumeMusic : function() {
        if (this._isMusicStopped) {
            this.playLastMusic();
            this._isMusicStopped = false;
        } else {
            jsb.AudioEngine.resume(this.currentBGID);
        }
    },
    
    pause : function(){
        this._isMusicPause = true;
        jsb.AudioEngine.pauseAll();
    },
    
    resume : function(){
        this._isMusicPause = false;
        jsb.AudioEngine.resumeAll();
    },
    
    musicEnabled : true,
    soundEnabled : true,
    setMusicEnabled : function(v) {
        this.musicEnabled = v;
        vee.data.musicEnabled = v;
        if (!v) this.stopMusicWithSave();
        else if (!this._isMusicPause) {
            this.playLastMusic();
        }
    },
    
    setSoundEnabled : function(v) {
        this.soundEnabled = v;
        vee.data.soundEnabled = v;
        if (!v) this.stopAllEffcts();
        var com = vee.Common.getInstance();
        cc.log("enable : "+v);
        com.setSoundEnabled(v);
    },
    
    init : function() {
        this.musicEnabled = vee.data.musicEnabled;
        this.soundEnabled = vee.data.soundEnabled;
        var com = vee.Common.getInstance();
        com.setSoundEnabled(this.soundEnabled);

        // this.preload(res.outGame_efx_showLogo_mp3);
        // this.preloadAllSound();
        if(VERSION.IOS_FREE_CN != game.Data.version.curVersion){
            this.preloadAudio();
        }
    },


    /**
     * add by zq preload audio
     */
    _audioCachePool : null,
    _audioAllCacheNum : 0,
    _maxPreloadNum : 5, //同时加载总数
    _curPreloadNum : 0, //加载前
    _curEndloadNum : 0, //加载完成
    pushAudioCache : function (str) {
        this._audioCachePool.push(str);
    },

    startPreloadAudio :function (overCallback) {
        var audioStr = this._audioCachePool.shift();

        var len = this._audioCachePool.length;
        // if (len > 0) {
            var percentNum = (this._audioAllCacheNum-len) / (this._audioAllCacheNum + 1) * 100;
            if(game.Data.oLvLoadingCtl){
                game.Data.oLvLoadingCtl.setPercent(parseInt(percentNum));
            }

            vee.Utils.scheduleOnce(function () {
                /*
                cc.log("zq debug audio str====%s", audioStr);
                vee.Utils.beginTiming();
                this.preload(audioStr, function () {
                    vee.Utils.endTiming("load audio str==" + audioStr + " cost===");
                    // this.startPreloadAudio(overCallback);
                }.bind(this));
                this.startPreloadAudio(overCallback);
                */
                // this.preload(audioStr, function () {
                //     this._curPreloadNum = this._curPreloadNum + 1;
                //     if(this._curPreloadNum == this._maxPreloadNum){
                //
                //     }
                // }.bind(this));
                this.preload(audioStr, function () {
                    this._curPreloadNum = this._curPreloadNum + 1;
                    if(this._curPreloadNum >= this._audioAllCacheNum && overCallback){
                        overCallback();
                    }
                }.bind(this));
                this.startPreloadAudio(overCallback);
            }.bind(this));
        // } else {
        //     if (overCallback) overCallback();
        // }
    },

    preloadAllSound : function () {
        this._audioCachePool = [];
        this.pushAudioCache(res._inGame_function_win_mp3);
        this.pushAudioCache(res.efx_dog_bark_mp3);
        this.pushAudioCache(res.inGame_action_bomb_mp3);
        this.pushAudioCache(res.inGame_action_bullet_mp3);
        this.pushAudioCache(res.inGame_action_jump_mp3);
        this.pushAudioCache(res.inGame_action_smash_mp3);
        this.pushAudioCache(res.inGame_action_smashOver_mp3);
        this.pushAudioCache(res.inGame_action_smashStart__mp3);
        this.pushAudioCache(res.inGame_action_teleport_mp3);
        this.pushAudioCache(res.inGame_character_bearFear_1_mp3);
        this.pushAudioCache(res.inGame_character_bearFear_2_mp3);
        this.pushAudioCache(res.inGame_character_cop_1_mp3);
        this.pushAudioCache(res.inGame_character_cop_2_mp3);
        this.pushAudioCache(res.inGame_character_flashEyes_1_mp3);
        this.pushAudioCache(res.inGame_character_flashEyes_2_mp3);
        this.pushAudioCache(res.inGame_character_flashEyes_3_mp3);
        this.pushAudioCache(res.inGame_character_hermione_1_mp3);
        this.pushAudioCache(res.inGame_character_hermione_2_mp3);
        this.pushAudioCache(res.inGame_character_kevo_1_mp3);
        this.pushAudioCache(res.inGame_character_kevo_2_mp3);
        this.pushAudioCache(res.inGame_character_littleDown_mp3);
        this.pushAudioCache(res.inGame_character_littleDrop_mp3);
        this.pushAudioCache(res.inGame_character_littleEscape_mp3);
        this.pushAudioCache(res.inGame_character_littleShock_mp3);
        this.pushAudioCache(res.inGame_character_littleWalk_mp3);
        this.pushAudioCache(res.inGame_character_m_42_1_mp3);
        this.pushAudioCache(res.inGame_character_m_42_2_mp3);
        this.pushAudioCache(res.inGame_character_phantom_1_mp3);
        this.pushAudioCache(res.inGame_character_phantom_2_mp3);
        this.pushAudioCache(res.inGame_character_spaceman_1_mp3);
        this.pushAudioCache(res.inGame_character_spaceman_2_mp3);
        this.pushAudioCache(res.inGame_character_tiny_1_mp3);
        this.pushAudioCache(res.inGame_character_tiny_2_mp3);
        this.pushAudioCache(res.inGame_character_vampire_1_mp3);
        this.pushAudioCache(res.inGame_character_vampire_2_mp3);
        this.pushAudioCache(res.inGame_efx_blockBomb_multi_mp3);
        this.pushAudioCache(res.inGame_efx_blockBomb_single_mp3);
        this.pushAudioCache(res.inGame_efx_blockBreak_mp3);
        this.pushAudioCache(res.inGame_efx_blockBreak_1_mp3);
        this.pushAudioCache(res.inGame_efx_blockBreak_2_mp3);
        this.pushAudioCache(res.inGame_efx_blockBreak_3_mp3);
        this.pushAudioCache(res.inGame_efx_blockBreak_4_mp3);
        this.pushAudioCache(res.inGame_efx_blockUnmove_mp3);
        this.pushAudioCache(res.inGame_efx_bombCount_mp3);
        this.pushAudioCache(res.inGame_efx_bombExplode_mp3);
        this.pushAudioCache(res.inGame_efx_bubbleVanish_mp3);
        this.pushAudioCache(res.inGame_efx_coinGenerate_mp3);
        this.pushAudioCache(res.inGame_efx_coinListGenerate_mp3);
        this.pushAudioCache(res.inGame_efx_entrance_mp3);
        this.pushAudioCache(res.inGame_efx_exit_mp3);
        this.pushAudioCache(res.inGame_efx_fire_mp3);
        this.pushAudioCache(res.inGame_efx_hideLight_mp3);
        this.pushAudioCache(res.inGame_efx_invisibleStart_mp3);
        this.pushAudioCache(res.inGame_efx_showCourseText_mp3);
        this.pushAudioCache(res.inGame_efx_showLight_mp3);
        this.pushAudioCache(res.inGame_efx_showText_mp3);
        this.pushAudioCache(res.inGame_efx_spring_mp3);
        this.pushAudioCache(res.inGame_event_applause_mp3);
        this.pushAudioCache(res.inGame_event_blockMove_mp3);
        this.pushAudioCache(res.inGame_event_contact_mp3);
        this.pushAudioCache(res.inGame_event_countDown_mp3);
        this.pushAudioCache(res.inGame_event_deathInstant_mp3);
        this.pushAudioCache(res.inGame_event_deathMonster_mp3);
        this.pushAudioCache(res.inGame_event_deathMonster_1_mp3);
        this.pushAudioCache(res.inGame_event_deathMonster_2_mp3);
        this.pushAudioCache(res.inGame_event_deathMonster_3_mp3);
        this.pushAudioCache(res.inGame_event_deathMonster_4_mp3);
        this.pushAudioCache(res.inGame_event_deathMonster_5_mp3);
        this.pushAudioCache(res.inGame_event_deathMonster_6_mp3);
        this.pushAudioCache(res.inGame_event_deathNoLife_mp3);
        this.pushAudioCache(res.inGame_event_fulfillLife_mp3);
        this.pushAudioCache(res.inGame_event_hitBlock_mp3);
        this.pushAudioCache(res.inGame_event_hitEnemy_mp3);
        this.pushAudioCache(res.inGame_event_hurted_mp3);
        this.pushAudioCache(res.inGame_event_machineAppear_mp3);
        this.pushAudioCache(res.inGame_event_maskOff_mp3);
        this.pushAudioCache(res.inGame_event_relayReach_mp3);
        this.pushAudioCache(res.inGame_event_switchOff_mp3);
        this.pushAudioCache(res.inGame_event_switchOn_mp3);
        this.pushAudioCache(res.inGame_event_toGround_mp3);
        this.pushAudioCache(res.inGame_function_allCoinsGotten_mp3);
        this.pushAudioCache(res.inGame_function_bonusEntrance_mp3);
        this.pushAudioCache(res.inGame_function_countCoins_mp3);
        this.pushAudioCache(res.inGame_function_lose_mp3);
        this.pushAudioCache(res.inGame_function_star_mp3);
        this.pushAudioCache(res.inGame_function_unlockAvator_mp3);
        this.pushAudioCache(res.inGame_function_win_mp3);
        this.pushAudioCache(res.inGame_function_winStar1_mp3);
        this.pushAudioCache(res.inGame_function_winStar2_mp3);
        this.pushAudioCache(res.inGame_function_winStar3_mp3);
        this.pushAudioCache(res.inGame_menu_click_mp3);
        this.pushAudioCache(res.inGame_menu_hidePausePage_mp3);
        this.pushAudioCache(res.inGame_menu_showMessage_mp3);
        this.pushAudioCache(res.inGame_menu_showPausePage_mp3);
        this.pushAudioCache(res.inGame_monster_crazyFound_mp3);
        this.pushAudioCache(res.inGame_monster_crazyRush_mp3);
        this.pushAudioCache(res.inGame_monster_enterCannon_mp3);
        this.pushAudioCache(res.inGame_monster_jumpSlimeDown_mp3);
        this.pushAudioCache(res.inGame_monster_launchCannon_mp3);
        this.pushAudioCache(res.inGame_monster_rotateCannon_mp3);
        this.pushAudioCache(res.inGame_monster_spikeExtend_mp3);
        this.pushAudioCache(res.inGame_monster_spikeRevoke_mp3);
        this.pushAudioCache(res.inGame_pick_bigCoin_mp3);
        this.pushAudioCache(res.inGame_pick_coin_1_mp3);
        this.pushAudioCache(res.inGame_pick_coin_2_mp3);
        this.pushAudioCache(res.inGame_pick_coin_3_mp3);
        this.pushAudioCache(res.inGame_pick_coin_4_mp3);
        this.pushAudioCache(res.inGame_pick_coin_5_mp3);
        this.pushAudioCache(res.inGame_pick_coin_6_mp3);
        this.pushAudioCache(res.inGame_pick_coin_7_mp3);
        this.pushAudioCache(res.inGame_pick_coin_8_mp3);
        this.pushAudioCache(res.inGame_pick_heart_mp3);
        this.pushAudioCache(res.inGame_pick_pixie_mp3);
        this.pushAudioCache(res.outGame_efx_healthCharge_mp3);
        this.pushAudioCache(res.outGame_efx_senceChange_mp3);
        // this.pushAudioCache(res.outGame_efx_showLogo_mp3);
        this.pushAudioCache(res.outGame_efx_showLogo_tutorial_mp3);
        this.pushAudioCache(res.outGame_menu_buyAvator_mp3);
        this.pushAudioCache(res.outGame_menu_changeAvator_mp3);
        this.pushAudioCache(res.outGame_menu_chooseLevel_mp3);
        this.pushAudioCache(res.outGame_menu_chooseSection_mp3);
        this.pushAudioCache(res.outGame_menu_closeStore_mp3);
        this.pushAudioCache(res.outGame_menu_intoStore_mp3);
        this.pushAudioCache(res.outGame_menu_leaveLocked_mp3);
        this.pushAudioCache(res.outGame_menu_leaveSection_mp3);
        this.pushAudioCache(res.outGame_menu_sectionLocked_mp3);
        this.pushAudioCache(res.outGame_menu_unlockSection_mp3);
        this.pushAudioCache(res.outGame_menu_viewSection_mp3);
        this.pushAudioCache(res.sfx_menu_buttonclick_mp3);
        this.pushAudioCache(res.sfx_menu_closewindow_mp3);
        this.pushAudioCache(res.sfx_menu_openwindow_mp3);

        this._audioAllCacheNum = this._audioCachePool.length;
        // LyLevelLoading.show();
        // this.startPreloadAudio();
    },

    preloadAudio : function () {
        this.preload(res._inGame_function_win_mp3);
        this.preload(res.efx_dog_bark_mp3);
        this.preload(res.inGame_action_bomb_mp3);
        this.preload(res.inGame_action_bullet_mp3);
        this.preload(res.inGame_action_jump_mp3);
        this.preload(res.inGame_action_smash_mp3);
        this.preload(res.inGame_action_smashOver_mp3);
        this.preload(res.inGame_action_smashStart__mp3);
        this.preload(res.inGame_action_teleport_mp3);
        this.preload(res.inGame_character_bearFear_1_mp3);
        this.preload(res.inGame_character_bearFear_2_mp3);
        this.preload(res.inGame_character_cop_1_mp3);
        this.preload(res.inGame_character_cop_2_mp3);
        this.preload(res.inGame_character_flashEyes_1_mp3);
        this.preload(res.inGame_character_flashEyes_2_mp3);
        this.preload(res.inGame_character_flashEyes_3_mp3);
        this.preload(res.inGame_character_hermione_1_mp3);
        this.preload(res.inGame_character_hermione_2_mp3);
        this.preload(res.inGame_character_kevo_1_mp3);
        this.preload(res.inGame_character_kevo_2_mp3);
        this.preload(res.inGame_character_littleDown_mp3);
        this.preload(res.inGame_character_littleDrop_mp3);
        this.preload(res.inGame_character_littleEscape_mp3);
        this.preload(res.inGame_character_littleShock_mp3);
        this.preload(res.inGame_character_littleWalk_mp3);
        this.preload(res.inGame_character_m_42_1_mp3);
        this.preload(res.inGame_character_m_42_2_mp3);
        this.preload(res.inGame_character_phantom_1_mp3);
        this.preload(res.inGame_character_phantom_2_mp3);
        this.preload(res.inGame_character_spaceman_1_mp3);
        this.preload(res.inGame_character_spaceman_2_mp3);
        this.preload(res.inGame_character_tiny_1_mp3);
        this.preload(res.inGame_character_tiny_2_mp3);
        this.preload(res.inGame_character_vampire_1_mp3);
        this.preload(res.inGame_character_vampire_2_mp3);
        this.preload(res.inGame_efx_blockBomb_multi_mp3);
        this.preload(res.inGame_efx_blockBomb_single_mp3);
        this.preload(res.inGame_efx_blockBreak_mp3);
        this.preload(res.inGame_efx_blockBreak_1_mp3);
        this.preload(res.inGame_efx_blockBreak_2_mp3);
        this.preload(res.inGame_efx_blockBreak_3_mp3);
        this.preload(res.inGame_efx_blockBreak_4_mp3);
        this.preload(res.inGame_efx_blockUnmove_mp3);
        this.preload(res.inGame_efx_bombCount_mp3);
        this.preload(res.inGame_efx_bombExplode_mp3);
        this.preload(res.inGame_efx_bubbleVanish_mp3);
        this.preload(res.inGame_efx_coinGenerate_mp3);
        this.preload(res.inGame_efx_coinListGenerate_mp3);
        this.preload(res.inGame_efx_entrance_mp3);
        this.preload(res.inGame_efx_exit_mp3);
        this.preload(res.inGame_efx_fire_mp3);
        this.preload(res.inGame_efx_hideLight_mp3);
        this.preload(res.inGame_efx_invisibleStart_mp3);
        this.preload(res.inGame_efx_showCourseText_mp3);
        this.preload(res.inGame_efx_showLight_mp3);
        this.preload(res.inGame_efx_showText_mp3);
        this.preload(res.inGame_efx_spring_mp3);
        this.preload(res.inGame_event_applause_mp3);
        this.preload(res.inGame_event_blockMove_mp3);
        this.preload(res.inGame_event_contact_mp3);
        this.preload(res.inGame_event_countDown_mp3);
        this.preload(res.inGame_event_deathInstant_mp3);
        this.preload(res.inGame_event_deathMonster_mp3);
        this.preload(res.inGame_event_deathMonster_1_mp3);
        this.preload(res.inGame_event_deathMonster_2_mp3);
        this.preload(res.inGame_event_deathMonster_3_mp3);
        this.preload(res.inGame_event_deathMonster_4_mp3);
        this.preload(res.inGame_event_deathMonster_5_mp3);
        this.preload(res.inGame_event_deathMonster_6_mp3);
        this.preload(res.inGame_event_deathNoLife_mp3);
        this.preload(res.inGame_event_fulfillLife_mp3);
        this.preload(res.inGame_event_hitBlock_mp3);
        this.preload(res.inGame_event_hitEnemy_mp3);
        this.preload(res.inGame_event_hurted_mp3);
        this.preload(res.inGame_event_machineAppear_mp3);
        this.preload(res.inGame_event_maskOff_mp3);
        this.preload(res.inGame_event_relayReach_mp3);
        this.preload(res.inGame_event_switchOff_mp3);
        this.preload(res.inGame_event_switchOn_mp3);
        this.preload(res.inGame_event_toGround_mp3);
        this.preload(res.inGame_function_allCoinsGotten_mp3);
        this.preload(res.inGame_function_bonusEntrance_mp3);
        this.preload(res.inGame_function_countCoins_mp3);
        this.preload(res.inGame_function_lose_mp3);
        this.preload(res.inGame_function_star_mp3);
        this.preload(res.inGame_function_unlockAvator_mp3);
        this.preload(res.inGame_function_win_mp3);
        this.preload(res.inGame_function_winStar1_mp3);
        this.preload(res.inGame_function_winStar2_mp3);
        this.preload(res.inGame_function_winStar3_mp3);
        this.preload(res.inGame_menu_click_mp3);
        this.preload(res.inGame_menu_hidePausePage_mp3);
        this.preload(res.inGame_menu_showMessage_mp3);
        this.preload(res.inGame_menu_showPausePage_mp3);
        this.preload(res.inGame_monster_crazyFound_mp3);
        this.preload(res.inGame_monster_crazyRush_mp3);
        this.preload(res.inGame_monster_enterCannon_mp3);
        this.preload(res.inGame_monster_jumpSlimeDown_mp3);
        this.preload(res.inGame_monster_launchCannon_mp3);
        this.preload(res.inGame_monster_rotateCannon_mp3);
        this.preload(res.inGame_monster_spikeExtend_mp3);
        this.preload(res.inGame_monster_spikeRevoke_mp3);
        this.preload(res.inGame_pick_bigCoin_mp3);
        this.preload(res.inGame_pick_coin_1_mp3);
        this.preload(res.inGame_pick_coin_2_mp3);
        this.preload(res.inGame_pick_coin_3_mp3);
        this.preload(res.inGame_pick_coin_4_mp3);
        this.preload(res.inGame_pick_coin_5_mp3);
        this.preload(res.inGame_pick_coin_6_mp3);
        this.preload(res.inGame_pick_coin_7_mp3);
        this.preload(res.inGame_pick_coin_8_mp3);
        this.preload(res.inGame_pick_heart_mp3);
        this.preload(res.inGame_pick_pixie_mp3);
        this.preload(res.outGame_efx_healthCharge_mp3);
        this.preload(res.outGame_efx_senceChange_mp3);
        this.preload(res.outGame_efx_showLogo_mp3);
        this.preload(res.outGame_efx_showLogo_tutorial_mp3);
        this.preload(res.outGame_menu_buyAvator_mp3);
        this.preload(res.outGame_menu_changeAvator_mp3);
        this.preload(res.outGame_menu_chooseLevel_mp3);
        this.preload(res.outGame_menu_chooseSection_mp3);
        this.preload(res.outGame_menu_closeStore_mp3);
        this.preload(res.outGame_menu_intoStore_mp3);
        this.preload(res.outGame_menu_leaveLocked_mp3);
        this.preload(res.outGame_menu_leaveSection_mp3);
        this.preload(res.outGame_menu_sectionLocked_mp3);
        this.preload(res.outGame_menu_unlockSection_mp3);
        this.preload(res.outGame_menu_viewSection_mp3);
        this.preload(res.sfx_menu_buttonclick_mp3);
        this.preload(res.sfx_menu_closewindow_mp3);
        this.preload(res.sfx_menu_openwindow_mp3);
    }


    //preload audio end
};

vee.soundPopup = function() {
    vee.Audio.onEvent("popLayer");
}

vee.soundCloseLayer = function() {
    vee.Audio.onEvent("closeLayer");
}

vee.soundButton = function() {
    vee.Audio.onEvent("button");
}