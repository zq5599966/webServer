/**
 * Created with AppCode.
 * User: WanThirty
 * Date: 15/6/23
 * Time: 下午2:39
 * To change this template use File | Settings | File Templates.
 */

var EfxHit = vee.Class.extend({
	psStar1 : null,
	psStar2 : null,
		onCreate : function () {
			this.playAnimate("Show", function () {
				this.rootNode.removeFromParent();
			}.bind(this));
		}
	});

EfxHit.create = function (pos, dir) {
	var node = cc.BuilderReader.load(res.efx_hit_enemy_ccbi);
        //testcode
	if (node.controller.psStar1) node.controller.psStar1.setPositionType(1);
	if (node.controller.psStar2) node.controller.psStar2.setPositionType(1);
	var dirOff = vee.Direction.direction2Point(dir);
	dirOff.x *= (game.Data.tileSizeWidth/2);
	dirOff.y *= -(game.Data.tileSizeWidth/2);
	if (dirOff.x) dirOff.x += (dirOff.x > 0 ? -20 : 20);
	if (dirOff.y) dirOff.y += (dirOff.y > 0 ? -20 : 20);
	node.setPosition(vee.Utils.pAdd(pos, dirOff));
	game.Data.oLyGame.lyMap.addChild(node, 8);
	return node;
};

var EfxHitBlock = {};
EfxHitBlock.create = function (pos, dir) {
	var node = cc.BuilderReader.load(res.efx_hit_block_ccbi);
        //testcode
	if (node.controller.psStar1) node.controller.psStar1.setPositionType(1);
	if (node.controller.psStar2) node.controller.psStar2.setPositionType(1);
	var dirOff = vee.Direction.direction2Point(dir);
	dirOff.x *= TILE_WIDTH_HALF+6;
	dirOff.y *= -TILE_WIDTH_HALF-6;
//	if (dirOff.x) dirOff.x += (dirOff.x > 0 ? -32 : 32);
//	if (dirOff.y) dirOff.y += (dirOff.y > 0 ? -32 : 32);
	node.setPosition(vee.Utils.pAdd(pos, dirOff));
	game.Data.oLyGame.lyMap.addChild(node, 8);
	return node;
};

var EfxBulletShoot = {};
EfxBulletShoot.create = function (pos, dir, container) {
	var node = cc.BuilderReader.load(res.efx_PlayerAttack_ccbi);
	var dirOff = vee.Direction.direction2Point(dir);
	node.setScaleX(dirOff.x);
	dirOff.x *= (game.Data.tileSizeWidth/2);
	dirOff.y *= -(game.Data.tileSizeWidth/2);
	if (dirOff.x) dirOff.x += (dirOff.x > 0 ? 5 : -5);
	if (dirOff.y) dirOff.y += (dirOff.y > 0 ? 5 : -5);
	node.setPosition(dirOff);
	container.addChild(node, 8);
	return node;
};

var EfxTeleportDust = {};
EfxTeleportDust.create = function (pos, dir) {
	var node = cc.BuilderReader.load(res.efx_PlayerShunYi_LiZi_ccbi);
	node.controller.ps1.setPositionType(1);
	var dirOff = vee.Direction.direction2Point(dir);
	node.setScaleX(dirOff.x);
	dirOff.x *= (game.Data.tileSizeWidth/2);
	dirOff.y *= -(game.Data.tileSizeWidth/2);
	if (dirOff.x) dirOff.x += (dirOff.x > 0 ? 5 : -5);
	if (dirOff.y) dirOff.y += (dirOff.y > 0 ? 5 : -5);
	node.setPosition(vee.Utils.pAdd(pos, dirOff));
	game.Data.oLyGame.lyMap.addChild(node, 8);
	return node;
};


var EfxGetBigCoin = EfxHit.extend({
	ps1 : null,
	ccbInit : function () {
		this.ps1.setPositionType(1);
	},
	slow1 : function() {
		vee.PopMgr.rootNode.getScheduler().setTimeScale(0.7);
	},

	slow2  : function() {
		vee.PopMgr.rootNode.getScheduler().setTimeScale(0.12);
	},

	resume2 : function() {
		vee.PopMgr.rootNode.getScheduler().setTimeScale(0.6);
	},

	resume1 : function() {
		vee.PopMgr.rootNode.getScheduler().setTimeScale(1);
//		game.Data.cameraScaleLimitMIN = 1;
//		game.Data.cameraScaleSpeed = 0.001;
	}
});

EfxGetBigCoin.create = function(pos) {
	var node = cc.BuilderReader.load(res.efx_EatBigCoin_Star_ccbi);
    //testcode
 	if (node.controller.psStar) node.controller.psStar.setPositionType(1);
	node.setPosition(pos);
	node.controller.ccbInit();
	game.Data.oLyGame.lyMap.addChild(node, 8);
//	game.Data.cameraScaleLimitMIN = 1.05;
//	game.Data.cameraScaleSpeed = 0.01;
}