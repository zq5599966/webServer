/**
 * Created with AppCode.
 * User: yop
 * Date: 15/10/27
 * Time: 下午3:33
 * To change this template use File | Settings | File Templates.
 */

LevelController.LevelMini208 = LevelController.extend({
	eventStory1 : function(grid, dir) {
		this.showStory(1, grid, ""+
		"RemoveEnemy;"+
		"MoveCamera,61,10,1;"+
		"SelectNpc;"+
		"FaceTo,left;"+
		"ShowDialog,"+ vee.Utils.getLocalizedStringForKey("Nice! You found me!", "不错，你找到我了！") +";"+
		"ShowDialog,"+ vee.Utils.getLocalizedStringForKey("Get your bonus here!", "来拿你的奖励吧！") +";"+
		"HideDialog;"+
		"TimeLine,huxi_2;"+
		"Delay,1;"+
		"AddCoin," + vee.Utils.getObjByPlatform('500','500','200') + ";"+
		"Delay,2;"+
		"GameOver"+
		"");
	}
});
