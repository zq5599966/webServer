/**
 * Created with AppCode.
 * User: WanThirty
 * Date: 15/7/6
 * Time: 下午3:48
 * To change this template use File | Settings | File Templates.
 */

var UICoinCounter = vee.Class.extend({
	lbCounter : null,

	onCreate : function () {

	},
	initCoinCounter : function (maxValue) {
		this.lbCounter.setString(game.Data.coin+"/"+game.Data.stageMaxCoin);
	},

	updateCoin : function () {
		this.playAnimate("get");
		this.lbCounter.setString(game.Data.coin+"/"+game.Data.stageMaxCoin);
	}
});