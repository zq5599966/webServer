/**
 * Created with AppCode.
 * User: WanThirty
 * Date: 15/11/25
 * Time: 下午3:18
 * To change this template use File | Settings | File Templates.
 */

var EnemyDrillDogSlime = EnemyDogSlime.extend({
	inMapBack : true,

	leftToBarrier : function() {
		this._hasG = true;
		var tgGrid = cc.p(this._grid.x-1, this._grid.y);
		var tdToBarrier = game.Logic.map.getObject(tgGrid);
		game.Logic.checkTileTrigger(tgGrid, vee.Direction.Left, tdToBarrier, this);
		game.Logic.triggerTileCallback(tdToBarrier, this, vee.Direction.Left);
		if (this._dashing) {
			this._accX = 0;
			this._speedX = 0;
			this._speedY = 0;
			this._stopY = true;
			this.setFaceTo(vee.Direction.Left, true);
			this.playAnimate("onwall", function () {
				this.playAnimate("outwall", function () {

				}.bind(this));
			}.bind(this));
		} else {
			this.onBarrier();
			this.moveRight();
		}
	},

	rightToBarrier : function() {
		this._hasG = true;
		var tgGrid = cc.p(this._grid.x+1, this._grid.y);
		var tdToBarrier = game.Logic.map.getObject(tgGrid);
		game.Logic.checkTileTrigger(tgGrid, vee.Direction.Right , tdToBarrier, this);
		game.Logic.triggerTileCallback(tdToBarrier, this, vee.Direction.Right);
		if (this._dashing) {
			this._accX = 0;
			this._speedX = 0;
			this._speedY = 0;
			this._stopY = true;
			this.setFaceTo(vee.Direction.Right, true);
			this.playAnimate("onwall", function () {
				this.playAnimate("outwall", function () {

				}.bind(this));
			}.bind(this));
		} else {
			this.onBarrier();
			this.moveLeft();
		}
	},

	extract : function () {
		this._xLimit = null;
		this._speedY = 1000;
		this._stopY = false;
		this.onBarrier();
		if (this._faceTo == vee.Direction.Left) {
			this._speedX = 300;
			this.moveRight();
		} else {
			this._speedX = -300;
			this.moveLeft();
		}
	},

	hitByStar : function (dir) {

	},

	onBarrier : function () {
		this._dashing = false;
		this._isFindPlayer = false;
		this._speedXLimit = 300;
		this.playAnimate("run");
	},

	downToBarrier : function(td) {
		if (!this._dashing) {
			this._speedXLimit = this._speedXLimitForSet;
		}
		this.pushedDir[vee.Direction.Bottom] = 1;
		this._speedY = 0;
		this._accY = 0;
		this.jumping = false;
		game.Logic.triggerTileCallback(td, this, vee.Direction.Bottom);
	},

	collide : function(dir) {
		if (game.Data.oPlayerCtl._isBounce || this._isOver) return;
		if (dir == vee.Direction.Top && !game.Data.oPlayerCtl.extendController) {
			this.popPlayerUp();
		} else {
			if (game.Data.playerInvisible) return;
			var dir = this.getElePosition().x > game.Data.oPlayerCtl.getElePosition().x ? vee.Direction.Left : vee.Direction.Right;
			game.Data.oPlayerCtl.getShock(dir, true);
			this.onGridChanged();
		}
	}
});