/**
 * Created by john on 2016/11/25.
 */
var appConfig_IOS_Free = {
    AppID : 1065433630,

    AppName : app.configManager.AppName,

    AppAlias : app.configManager.AppAlias,

    AppURL : app.configManager.AppURL,

    RateURL : app.configManager.RateURL,

    PromoURL : app.configManager.PromoURL,
    PromoChannel : app.configManager.PromoChannel,
    PromoBannerEnable : app.configManager.PromoBannerEnable,
    PromoFullScreenEnable : app.configManager.PromoFullScreenEnable,

    //plugins
    GameCenterPluginName : app.configManager.GameCenterPluginName,
    AnalyticsPluginName : app.configManager.AnalyticsPluginName,
    AnalyticsPluginADTrackName : app.configManager.AnalyticsPluginADTrackName,
    IAPPluginName : app.configManager.IAPPluginName,

    //Deprecated
    AdVideoPluginName : app.configManager.AdVideoPluginName,
    AdBannerPluginName : app.configManager.AdBannerPluginName,
    AdInterstialPluginName : app.configManager.AdInterstialPluginName,

    AdInterstialPluginCoinfig : null,
    IsBannerEnabled : app.configManager.IsBannerEnabled,
    IsInterestialEnabled : app.configManager.IsInterestialEnabled,

    AnalyticsPluginADTrackConfig : {                            //不知道什么鬼 init plugin
        AdvertiserID : "164496",
        ConversionKey : "1b0e697a2fa9501dcafa6a08e2c1c017"
    },

    GameCenterPluginConfig : {"appid" : "1041873285"},

    AnalysticsPluginConfig : "584fd4e4b27b0a25140000f5",

    AdBannerPluginConfig : {
        AppGoogleInterstialId: "ca-app-pub-1777019132527367/8229937532",
        AppFaceBookInterstialId : "150931201938556_243303672701308",
        AppGoogleRewardedVideoId : "ca-app-pub-1777019132527367/7773351931",
        QixunAppkey : "bf8e5ftafrmdbr8atfcw48cr",
    },

    //vungle视频广告id
    AdVideoPluginConfig : {
        AdsVungle : "1041873285"
    },

    //排行榜id
    LeaderboardIDs : ["com.veewo.stars"],

    IAPs : [
        {ProductID: "com.veewo.unlock.glb", NonConsumable:"false"},
        {ProductID: "com.veewo.allcat", NonConsumable:"true"},
        {ProductID: "com.veewo.power", NonConsumable:"false"},
        {ProductID: "com.veewo.moonworld", NonConsumable:"true"},
        {
            ProductID : "com.veewo.unlockdiscolevel",
            NonConsumable : "true"
        }
    ],

    Achievements : [
        "com.veewo.star1",   // star 1
        "com.veewo.star2",   // star 2
        "com.veewo.star3",   // star 3
        "com.veewo.star4",   // star 4
        "com.veewo.star5",   // star 5
        "com.veewo.flash",   // flash
        "com.veewo.jump",    // jump
        "com.veewo.heart",   // heart
        "com.veewo.coin"     // coin
    ],

    AdOdd : "ca-app-pub-1777019132527367/1974641134",
    AdEven : "ca-app-pub-1777019132527367/4442904336",
    AdPause : "ca-app-pub-1777019132527367/2966171130",
    AdGameOver : "ca-app-pub-1777019132527367/7396370731",
    AdStartUp : "ca-app-pub-1777019132527367/8873103936",
    AdExit : "ca-app-pub-1777019132527367/3451374331",

    // ShareKTPlay_android : {
    //     key : "19ypSjYv6D",
    //     secret : "96f8fb00696a9f83add4c0b8afdd19af801e54fb"
    // },

    AdPosEntityConfig : [
        "AdsAdapter",
        "AdsAdapter",
        "AdsAdapter"
    ],
}