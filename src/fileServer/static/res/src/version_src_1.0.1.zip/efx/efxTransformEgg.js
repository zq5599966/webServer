/**
 * Created with AppCode.
 * User: WanThirty
 * Date: 15/6/23
 * Time: 下午5:25
 * To change this template use File | Settings | File Templates.
 */

var EfxTransformEgg = vee.Class.extend({
	_type : null,
	setTransformType : function (type) {
		this._type = type;
	},

	hidePlayer : function () {
		game.Data.oPlayerCtl._container.setVisible(false);
	},

	createPlayer : function () {
		var playerPos = game.Data.oPlayerCtl.getElePosition();
		game.Data.oPlayerCtl._container.removeFromParent();
		var playerContent = ElePlayer.create(this._type);
		game.Data.setPlayerType(this._type);
		game.Data.oPlayerCtl = null;
		game.Data.oPlayerCtl = playerContent.controller;
		game.Data.oLyGame.lyMap.addChild(playerContent.container, 2);
		playerContent.controller.setElePosition(playerPos);
		game.Data.oPlayerCtl._speedY = 800;
		game.Data.oPlayerCtl._offsetY = 0;
	},

	remove : function () {
		game.Data.playerInvisible = false;
		this.rootNode.removeFromParent();
	}
});

EfxTransformEgg.create = function (type, pos) {
//	var node = cc.BuilderReader.load(res.efx_BianShen_Egg_ccbi);
	var node = cc.BuilderReader.load(res.efx_BianShen_Mario_ccbi);
	node.controller.setTransformType(type);
	node.setPosition(game.Data.oPlayerCtl.getElePosition());
//	node.setPosition(pos);
	game.Data.oLyGame.lyMap.addChild(node, 8);
	return node;
};