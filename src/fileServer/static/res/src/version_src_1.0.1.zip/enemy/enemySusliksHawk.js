/**
 * Created with AppCode.
 * User: WanThirty
 * Date: 15/7/16
 * Time: 上午10:39
 * To change this template use File | Settings | File Templates.
 */

var EnemySusliksHawk = Enemy.extend({
	objType : game.ObjectType.SusliksHawk,
	_hasG : false,
	needRefreshPos : false,
	cutInAnimate : function () {

	},

	bornWithPos : function (pos) {
		this.needRefreshPos = false;
		this._hasG = false;
		this.startIn();
	},

	getInhaleController : function () {
		return null;
	},

	hitByStar : function (dir) {
		if (this._isOver || !this._hasCollide) return;
		this.dieAnimate(dir);
	},

	startIn : function () {
		this._hasCollide = true;
		this.playAnimate("in", function () {
			this.playAnimate("loop");
			this.startHurt();
		}.bind(this));
//		vee.Audio.playEffect(res.inGame_monster_spikeRevoke_mp3);
	},

	startHurt : function () {
		this._container.runAction(cc.sequence(
			cc.delayTime(2),
			cc.callFunc(function () {
				this._hasCollide = false;
				this.playAnimate("out", function () {
					this.startHide();
				}.bind(this))
			}.bind(this))
		));
	},

	startHide : function () {
//		vee.Audio.playEffect(res.inGame_monster_spikeExtend_mp3);
		this._container.runAction(cc.sequence(
			cc.delayTime(2),
			cc.callFunc(function () {
				this.startIn();
			}.bind(this))
		));
	},

	collide : function (dir) {
		if (game.Data.playerHawk) {
			game.Data.oLyGame.shake();
			this.hitByStar();
			return;
		} else if ((game.Data.playerInvisible || game.Data.oPlayerCtl._isBounce) && !(dir == vee.Direction.Top && game.Data.oPlayerCtl.isSmashing())) return;
		dir = this.getElePosition().x > game.Data.oPlayerCtl.getElePosition().x ? vee.Direction.Left : vee.Direction.Right;
		game.Data.oPlayerCtl.getShock(dir, true);
	},

	dieAnimate : function (dir) {
		this.onKill();
		this._container.stopAllActions();
		var pos = this.getElePosition();
		EfxEnemyDie.show(pos);
		this._hasCollide = false;
		this._isOver = true;
		this.die();
	},

	getEleRect : function() {
		var pos = this.getElePosition();
		var rect = cc.rect(
			pos.x + this.boxOffset.x - this.boxSize.width/2,
			pos.y + this.boxOffset.y - this.boxSize.height/2,
			this.boxSize.width,
			this.boxSize.height - 30
		);
		return rect;
	},

	checkCollide : function () {
		if (game.Data.playerInvisible || !this._hasCollide) return;
		var rectEnemy = this.getEleRect();
		var rectForCheck = game.Data.oPlayerCtl.getEleRect();
		if (cc.rectIntersectsRect(rectEnemy, rectForCheck)) {
			var playerY = game.Data.oPlayerCtl.getElePosition().y;
			var enemyY = this.getElePosition().y;
			if (enemyY <= playerY) {
				var offsetY = playerY - enemyY;
				if (offsetY > this.boxSize.height/2 + this.boxOffset.y) {
					if (game.Data.oPlayerCtl._speedY < 0) {
						this.collide(vee.Direction.Top);
						return;
					}
				}
			}
			this.collide();
		}
	}
});