/**
 * Created with AppCode.
 * User: yop
 * Date: 15/9/3
 * Time: 下午7:34
 *
 * To change this template use File | Settings | File Templates.
 */

game.AvatarData = {
	//给代码生成用的
	productDataTemplate : { idx : 0, name : 'Normal', desc : '默认主角', priceDesc : '--', price : 0, iapIndex : -1  , role : res.elePlayer_Zhai_ccbi , owned : true},

	productData : [
		{ idx : 0, name : 'avatar_0_name', type : game.Roles.Cat,     picName : res.hero_show_1_cat_png,     headName : res.hero_head_1_cat_png,     cannonHeadName : res.hero_head_1_cat_png,         dieName : "res/hero_dead_1_cat.png",     desc : 'avatar_0_desc', priceDesc : '--',    price : 0,    iapIndex : -1, role : res.elePlayer_Zhai_ccbi, coinFrame : "",                 owned : true,  eventIdx : 200},
		{ idx : 1, name : 'avatar_1_name', type : game.Roles.Kevo,    picName : res.hero_show_2_kevo_png,    headName : res.hero_head_2_kevo_png,    cannonHeadName : res.hero_head_2_kevo_png,        dieName : "res/hero_dead_2_kevo.png",    desc : 'avatar_1_desc', priceDesc : '5',     price : 250,  iapIndex : -1, role : res.hero_kevo_ccbi,      coinFrame : "coin_fist.png",    owned : false, eventIdx : 203},
		{ idx : 2, name : 'avatar_2_name', type : game.Roles.Girl,    picName : res.hero_show_6_girl_png,    headName : res.hero_head_6_girl_png,    cannonHeadName : res.hero_head_6_girl_png,        dieName : "res/hero_dead_6_girl.png",    desc : 'avatar_2_desc', priceDesc : '$0.99', price : vee.Utils.getObjByPlatform(500, 1000), iapIndex : -1, role : res.hero_girl_ccbi,      coinFrame : "coin_RedGirl.png", owned : false, eventIdx : 102},
		{ idx : 3, name : 'avatar_3_name', type : game.Roles.Tiny,    picName : res.hero_show_10_tiny_png,   headName : res.hero_head_10_tiny_png,   cannonHeadName : res.hero_head_small_10_tiny_png, dieName : "res/hero_dead_10_tiny.png",   desc : "avatar_3_desc", priceDesc : '10',    price : vee.Utils.getObjByPlatform(1000, 2000), iapIndex : -1, role : res.hero_ji_ccbi,        coinFrame : "coin_chicken.png", owned : false, eventIdx : 104},
		{ idx : 4, name : 'avatar_4_name', type : game.Roles.Marvin,  picName : res.hero_show_8_marvin_png,  headName : res.hero_head_8_marvin_png,  cannonHeadName : res.hero_head_8_marvin_png,      dieName : "res/hero_dead_8_marvin.png",  desc : "avatar_4_desc", priceDesc : '10',    price : vee.Utils.getObjByPlatform(1200, 3500), iapIndex : -1, role : res.hero_marvin_ccbi,    coinFrame : "coin_42.png",      owned : false, eventIdx : 202},
		{ idx : 5, name : 'avatar_5_name', type : game.Roles.Cop,     picName : res.hero_show_4_cat_png,     headName : res.hero_head_4_cap_png,     cannonHeadName : res.hero_head_4_cap_png,         dieName : "res/hero_dead_4_cat.png",     desc : 'avatar_5_desc', priceDesc : '30',    price : vee.Utils.getObjByPlatform(1200, 3500),  iapIndex : -1, role : res.hero_cap_ccbi ,      coinFrame : "coin_gun.png",     owned : false, eventIdx : 101},
		{ idx : 6, name : 'avatar_6_name', type : game.Roles.Space,   picName : res.hero_show_5_space_png,   headName : res.hero_head_5_space_png,   cannonHeadName : res.hero_head_5_space_png,       dieName : "res/hero_dead_5_space.png",   desc : 'avatar_6_desc', priceDesc : '10',    price : vee.Utils.getObjByPlatform(1500, 3500), iapIndex : -1, role : res.hero_nasa_ccbi,      coinFrame : "coin_Xman.png",    owned : false, eventIdx : 201},
		{ idx : 7, name : 'avatar_7_name', type : game.Roles.bear,    picName : res.hero_show_9_bear_png,    headName : res.hero_head_9_bear_png,    cannonHeadName : res.hero_head_9_bear_png,        dieName : "res/hero_dead_9_bear.png",    desc : 'avatar_7_desc', priceDesc : '$0.99', price : vee.Utils.getObjByPlatform(1500, 4500), iapIndex : -1, role : res.hero_beer_ccbi,      coinFrame : "coin_bear.png",    owned : false, eventIdx : 204},
		{ idx : 8, name : 'avatar_8_name', type : game.Roles.Vampire, picName : res.hero_show_7_vampire_png, headName : res.hero_head_7_vampire_png, cannonHeadName : res.hero_head_7_vampire_png,     dieName : "res/hero_dead_7_vampire.png", desc : 'avatar_8_desc', priceDesc : '2000',  price : vee.Utils.getObjByPlatform(3000, 6000), iapIndex : -1, role : res.hero_dracula_ccbi,   coinFrame : "coin_blood.png",   owned : false, eventIdx : 103},
		{ idx : 9, name : 'avatar_9_name', type : game.Roles.Flash,   picName : res.hero_show_3_flash_png,   headName : res.hero_head_3_flash_png,   cannonHeadName : res.hero_head_3_flash_png,       dieName : "res/hero_dead_3_flash.png",   desc : 'avatar_9_desc', priceDesc : '$0.99', price : vee.Utils.getObjByPlatform(5000, 10000), iapIndex : -1, role : res.hero_davinci_ccbi,   coinFrame : "coin_power.png",   owned : false, eventIdx : 205},
		{ idx : 11,name : 'avatar_11_name',type : game.Roles.MaNtIs,  picName : res.hero_show_12_m_png,  	    headName : res.hero_head_12_m_png,       cannonHeadName : res.hero_head_12_m_png,          dieName : res.hero_dead_12_m_png,        desc : "avatar_11_desc",priceDesc : '10',    price : vee.Utils.getObjByPlatform(5000, 10000), iapIndex : -1, role : res.hero_m_ccbi,       coinFrame : "coin_42.png",     owned : false,  eventIdx : 200},
		{ idx : 12,name : 'avatar_12_name',type : game.Roles.Fox,  	  picName : res.hero_show_13_fox_png,  	    headName : res.hero_head_13_fox_png,       cannonHeadName : res.hero_head_13_fox_png,          dieName : res.hero_dead_Fox2_png,        desc : "avatar_12_desc",priceDesc : '10',    price : vee.Utils.getObjByPlatform(5000, 10000), iapIndex : -1, role : res.hero_fox_ccbi,       coinFrame : "coin_42.png",     owned : false,  eventIdx : 200},
		{ idx : 13,name : 'avatar_13_name',type : game.Roles.Robbit,  picName : res.hero_show_14_rabbit_png,  	    headName : res.hero_head_14_rabbit_png,       cannonHeadName : res.hero_head_14_rabbit_png,          dieName : res.hero_dead_14_rabbit_png,        desc : "avatar_13_desc",priceDesc : '10',    price : vee.Utils.getObjByPlatform(5000, 10000), iapIndex : -1, role : res.hero_Rabbit_ccbi,       coinFrame : "coin_42.png",     owned : false,  eventIdx : 200},
		{ idx : 14,name : 'avatar_14_name',type : game.Roles.Holloween,  picName : res.hero_show_15_holloween_png,  	    headName : res.hero_head_15_holloween_png,       cannonHeadName : res.hero_head_15_holloween_png,          dieName : res.hero_dead_15_holloween_png,        desc : "avatar_14_desc",priceDesc : '10',    price : vee.Utils.getObjByPlatform(5000, 10000), iapIndex : -1, role : res.hero_skeleton_ccbi,       coinFrame : "coin_42.png",     owned : false,  eventIdx : 200},
		{ idx : 15,name : 'avatar_15_name',type : game.Roles.Blast,  picName : res.hero_show_16_blast_png,  	    headName : res.hero_head_16_blast_png,       cannonHeadName : res.hero_head_16_blast_png,          dieName : res.hero_dead_16_blast_png,        desc : "avatar_15_desc",priceDesc : '10',    price : vee.Utils.getObjByPlatform(5000, 10000), iapIndex : -1, role : res.hero_Blast_ccbi,       coinFrame : "coin_42.png",     owned : false,  eventIdx : 200}
	],

	// all unlock
//	productData :
//		{ idx : 0, name : 'avatar_0_name', type : game.Roles.Cat,     picName : res.hero_show_1_cat_png,     headName : res.hero_head_1_cat_png,     cannonHeadName : res.hero_head_1_cat_png,         dieName : "res/hero_dead_1_cat.png",     desc : 'avatar_0_desc', priceDesc : '--',    price : 0,    iapIndex : -1, role : res.elePlayer_Zhai_ccbi, coinFrame : "",                 owned : true,  eventIdx : 200},
//		{ idx : 1, name : 'avatar_1_name', type : game.Roles.Kevo,    picName : res.hero_show_2_kevo_png,    headName : res.hero_head_2_kevo_png,    cannonHeadName : res.hero_head_2_kevo_png,        dieName : "res/hero_dead_2_kevo.png",    desc : 'avatar_1_desc', priceDesc : '5',     price : 100,  iapIndex : -1, role : res.hero_kevo_ccbi,      coinFrame : "coin_fist.png",    owned : true, eventIdx : 203},
//		{ idx : 2, name : 'avatar_2_name', type : game.Roles.Girl,    picName : res.hero_show_6_girl_png,    headName : res.hero_head_6_girl_png,    cannonHeadName : res.hero_head_6_girl_png,        dieName : "res/hero_dead_6_girl.png",    desc : 'avatar_2_desc', priceDesc : '$0.99', price : vee.Utils.getObjByPlatform(100, 1000), iapIndex : -1, role : res.hero_girl_ccbi,      coinFrame : "coin_RedGirl.png", owned : true, eventIdx : 102},
//		{ idx : 3, name : 'avatar_3_name', type : game.Roles.Tiny,    picName : res.hero_show_10_tiny_png,   headName : res.hero_head_10_tiny_png,   cannonHeadName : res.hero_head_small_10_tiny_png, dieName : "res/hero_dead_10_tiny.png",   desc : "avatar_3_desc", priceDesc : '10',    price : vee.Utils.getObjByPlatform(100, 2000), iapIndex : -1, role : res.hero_ji_ccbi,        coinFrame : "coin_chicken.png", owned : true, eventIdx : 104},
//		{ idx : 4, name : 'avatar_4_name', type : game.Roles.Marvin,  picName : res.hero_show_8_marvin_png,  headName : res.hero_head_8_marvin_png,  cannonHeadName : res.hero_head_8_marvin_png,      dieName : "res/hero_dead_8_marvin.png",  desc : "avatar_4_desc", priceDesc : '10',    price : vee.Utils.getObjByPlatform(100, 3500), iapIndex : -1, role : res.hero_marvin_ccbi,    coinFrame : "coin_42.png",      owned : true, eventIdx : 202},
//		{ idx : 5, name : 'avatar_5_name', type : game.Roles.Cop,     picName : res.hero_show_4_cat_png,     headName : res.hero_head_4_cap_png,     cannonHeadName : res.hero_head_4_cap_png,         dieName : "res/hero_dead_4_cat.png",     desc : 'avatar_5_desc', priceDesc : '30',    price : vee.Utils.getObjByPlatform(100, 3500),  iapIndex : -1, role : res.hero_cap_ccbi ,      coinFrame : "coin_gun.png",     owned : true, eventIdx : 101},
//		{ idx : 6, name : 'avatar_6_name', type : game.Roles.Space,   picName : res.hero_show_5_space_png,   headName : res.hero_head_5_space_png,   cannonHeadName : res.hero_head_5_space_png,       dieName : "res/hero_dead_5_space.png",   desc : 'avatar_6_desc', priceDesc : '10',    price : vee.Utils.getObjByPlatform(100, 3500), iapIndex : -1, role : res.hero_nasa_ccbi,      coinFrame : "coin_Xman.png",    owned : true, eventIdx : 201},
//		{ idx : 7, name : 'avatar_7_name', type : game.Roles.bear,    picName : res.hero_show_9_bear_png,    headName : res.hero_head_9_bear_png,    cannonHeadName : res.hero_head_9_bear_png,        dieName : "res/hero_dead_9_bear.png",    desc : 'avatar_7_desc', priceDesc : '$0.99', price : vee.Utils.getObjByPlatform(100, 4500), iapIndex : -1, role : res.hero_beer_ccbi,      coinFrame : "coin_bear.png",    owned : true, eventIdx : 204},
//		{ idx : 8, name : 'avatar_8_name', type : game.Roles.Vampire, picName : res.hero_show_7_vampire_png, headName : res.hero_head_7_vampire_png, cannonHeadName : res.hero_head_7_vampire_png,     dieName : "res/hero_dead_7_vampire.png", desc : 'avatar_8_desc', priceDesc : '2000',  price : vee.Utils.getObjByPlatform(100, 6000), iapIndex : -1, role : res.hero_dracula_ccbi,   coinFrame : "coin_blood.png",   owned : true, eventIdx : 103},
//		{ idx : 9, name : 'avatar_9_name', type : game.Roles.Flash,   picName : res.hero_show_3_flash_png,   headName : res.hero_head_3_flash_png,   cannonHeadName : res.hero_head_3_flash_png,       dieName : "res/hero_dead_3_flash.png",   desc : 'avatar_9_desc', priceDesc : '$0.99', price : vee.Utils.getObjByPlatform(100, 10000), iapIndex : -1, role : res.hero_davinci_ccbi,   coinFrame : "coin_power.png",   owned : true, eventIdx : 205},
//		{ idx : 11,name : 'avatar_11_name',type : game.Roles.MaNtIs,  picName : res.hero_show_12_m_png,  	 headName : res.hero_head_12_m_png,      cannonHeadName : res.hero_head_12_m_png,          dieName : res.hero_dead_12_m_png,        desc : "avatar_11_desc",priceDesc : '10',    price : vee.Utils.getObjByPlatform(100, 10000), iapIndex : -1, role : res.hero_m_ccbi,       coinFrame : "coin_42.png",     owned : true,  eventIdx : 200}
//	],

	productData_android : [
		{ idx : 0,  name : 'avatar_0_name',  type : game.Roles.Cat,     picName : res.hero_show_1_cat_png,      headName : res.hero_head_1_cat_png,      cannonHeadName : res.hero_head_1_cat_png,         dieName : res.hero_dead_1_cat_png,       desc : 'avatar_0_desc', priceDesc : '--',    price : 0,    iapIndex : -1, role : res.elePlayer_Zhai_ccbi, coinFrame : "",                 owned : true,  eventIdx : 200},
		{ idx : 1,  name : 'avatar_1_name',  type : game.Roles.Kevo,    picName : res.hero_show_2_kevo_png,     headName : res.hero_head_2_kevo_png,     cannonHeadName : res.hero_head_2_kevo_png,        dieName : res.hero_dead_2_kevo_png,      desc : 'avatar_1_desc', priceDesc : '5',     price : 250,  iapIndex : -1, role : res.hero_kevo_ccbi,      coinFrame : "coin_fist.png",    owned : false, eventIdx : 203},
		{ idx : 2,  name : 'avatar_2_name',  type : game.Roles.Girl,    picName : res.hero_show_6_girl_png,     headName : res.hero_head_6_girl_png,     cannonHeadName : res.hero_head_6_girl_png,        dieName : res.hero_dead_6_girl_png,      desc : 'avatar_2_desc', priceDesc : '$0.99', price : vee.Utils.getObjByPlatform(500, 1000), iapIndex : -1, role : res.hero_girl_ccbi,      coinFrame : "coin_RedGirl.png", owned : false, eventIdx : 102},
		{ idx : 3,  name : 'avatar_3_name',  type : game.Roles.Tiny,    picName : res.hero_show_10_tiny_png,    headName : res.hero_head_10_tiny_png,    cannonHeadName : res.hero_head_small_10_tiny_png, dieName : res.hero_dead_10_tiny_png,     desc : "avatar_3_desc", priceDesc : '10',    price : vee.Utils.getObjByPlatform(1000, 2000), iapIndex : -1, role : res.hero_ji_ccbi,       coinFrame : "coin_chicken.png", owned : false, eventIdx : 104},
		{ idx : 4,  name : 'avatar_10_name', type : game.Roles.Android, picName : res.hero_show_11_android_png, headName : res.hero_head_11_android_png, cannonHeadName : res.hero_head_11_android_png,    dieName : res.hero_dead_11_android_png,  desc : 'avatar_10_desc',priceDesc : '$0.99', price : vee.Utils.getObjByPlatform(1200, 3500), iapIndex : -1, role : res.hero_android_ccbi, coinFrame : "coin_power.png",   owned : false,  eventIdx : 202},
		{ idx : 5,  name : 'avatar_5_name',  type : game.Roles.Cop,     picName : res.hero_show_4_cat_png,      headName : res.hero_head_4_cap_png,      cannonHeadName : res.hero_head_4_cap_png,         dieName : res.hero_dead_4_cat_png,       desc : 'avatar_5_desc', priceDesc : '30',    price : vee.Utils.getObjByPlatform(1200, 3500),  iapIndex : -1, role : res.hero_cap_ccbi ,    coinFrame : "coin_gun.png",     owned : false, eventIdx : 101},
		{ idx : 6,  name : 'avatar_6_name',  type : game.Roles.Space,   picName : res.hero_show_5_space_png,    headName : res.hero_head_5_space_png,    cannonHeadName : res.hero_head_5_space_png,       dieName : res.hero_dead_5_space_png,     desc : 'avatar_6_desc', priceDesc : '10',    price : vee.Utils.getObjByPlatform(1500, 3500), iapIndex : -1, role : res.hero_nasa_ccbi,     coinFrame : "coin_Xman.png",    owned : false, eventIdx : 201},
		{ idx : 7,  name : 'avatar_7_name',  type : game.Roles.bear,    picName : res.hero_show_9_bear_png,     headName : res.hero_head_9_bear_png,     cannonHeadName : res.hero_head_9_bear_png,        dieName : res.hero_dead_9_bear_png,      desc : 'avatar_7_desc', priceDesc : '$0.99', price : vee.Utils.getObjByPlatform(1500, 4500), iapIndex : -1, role : res.hero_beer_ccbi,     coinFrame : "coin_bear.png",    owned : false, eventIdx : 204},
		{ idx : 8,  name : 'avatar_8_name',  type : game.Roles.Vampire, picName : res.hero_show_7_vampire_png,  headName : res.hero_head_7_vampire_png,  cannonHeadName : res.hero_head_7_vampire_png,     dieName : res.hero_dead_7_vampire_png,   desc : 'avatar_8_desc', priceDesc : '2000',  price : vee.Utils.getObjByPlatform(3000, 6000), iapIndex : -1, role : res.hero_dracula_ccbi,  coinFrame : "coin_blood.png",   owned : false, eventIdx : 103},
		{ idx : 9,  name : 'avatar_9_name',  type : game.Roles.Flash,   picName : res.hero_show_3_flash_png,    headName : res.hero_head_3_flash_png,    cannonHeadName : res.hero_head_3_flash_png,       dieName : res.hero_dead_3_flash_png,     desc : 'avatar_9_desc', priceDesc : '$0.99', price : vee.Utils.getObjByPlatform(5000, 10000), iapIndex : -1, role : res.hero_davinci_ccbi, coinFrame : "coin_power.png",   owned : false, eventIdx : 205},
		{ idx : 11, name : 'avatar_11_name', type : game.Roles.MaNtIs,  picName : res.hero_show_12_m_png,  	    headName : res.hero_head_12_m_png,       cannonHeadName : res.hero_head_12_m_png,          dieName : res.hero_dead_12_m_png,        desc : "avatar_11_desc",priceDesc : '10',    price : vee.Utils.getObjByPlatform(5000, 10000), iapIndex : -1, role : res.hero_m_ccbi,       coinFrame : "coin_42.png",     owned : false,  eventIdx : 200},
		{ idx : 12,name : 'avatar_12_name',  type : game.Roles.Fox,     picName : res.hero_show_13_fox_png,  	headName : res.hero_head_13_fox_png,       cannonHeadName : res.hero_head_13_fox_png,      dieName : res.hero_dead_Fox2_png,        desc : "avatar_12_desc",priceDesc : '10',    price : vee.Utils.getObjByPlatform(5000, 10000), iapIndex : -1, role : res.hero_fox_ccbi,       coinFrame : "coin_42.png",     owned : false,  eventIdx : 200},
		{ idx : 13,name : 'avatar_13_name',  type : game.Roles.Robbit,  picName : res.hero_show_14_rabbit_png,  	    headName : res.hero_head_14_rabbit_png,       cannonHeadName : res.hero_head_14_rabbit_png,          dieName : res.hero_dead_14_rabbit_png,        desc : "avatar_13_desc",priceDesc : '10',    price : vee.Utils.getObjByPlatform(5000, 10000), iapIndex : -1, role : res.hero_Rabbit_ccbi,       coinFrame : "coin_42.png",     owned : false,  eventIdx : 200},
		{ idx : 14,name : 'avatar_14_name',  type : game.Roles.Holloween,  picName : res.hero_show_15_holloween_png,  	    headName : res.hero_head_15_holloween_png,       cannonHeadName : res.hero_head_15_holloween_png,          dieName : res.hero_dead_15_holloween_png,        desc : "avatar_14_desc_android",priceDesc : '10',    price : vee.Utils.getObjByPlatform(5000, 10000), iapIndex : -1, role : res.hero_skeleton_ccbi,       coinFrame : "coin_42.png",     owned : false,  eventIdx : 200},
		{ idx : 15,name : 'avatar_15_name',  type : game.Roles.Blast,   picName : res.hero_show_16_blast_png,  	headName : res.hero_head_16_blast_png,       cannonHeadName : res.hero_head_16_blast_png,          dieName : res.hero_dead_16_blast_png,        desc : "avatar_15_desc_android",priceDesc : '10',    price : vee.Utils.getObjByPlatform(5000, 10000), iapIndex : -1, role : res.hero_Blast_ccbi,       coinFrame : "coin_42.png",     owned : false,  eventIdx : 200}
	],

	// for demo
//	productData : [
//		{ idx : 0, name : 'avatar_0_name', type : game.Roles.Cat,     picName : res.hero_show_1_cat_png,     headName : res.hero_head_1_cat_png,     cannonHeadName : res.hero_head_1_cat_png,         dieName : "res/hero_dead_1_cat.png",     desc : 'avatar_0_desc', priceDesc : '--',    price : 0,    iapIndex : -1, role : res.elePlayer_Zhai_ccbi, coinFrame : "",                 owned : true,  eventIdx : 200},
//		{ idx : 1, name : 'avatar_1_name', type : game.Roles.Kevo,    picName : res.hero_show_2_kevo_png,    headName : res.hero_head_2_kevo_png,    cannonHeadName : res.hero_head_2_kevo_png,        dieName : "res/hero_dead_2_kevo.png",    desc : 'avatar_1_desc', priceDesc : '5',     price : 250,  iapIndex : -1, role : res.hero_kevo_ccbi,      coinFrame : "coin_fist.png",    owned : true, eventIdx : 203},
//		{ idx : 2, name : 'avatar_2_name', type : game.Roles.Girl,    picName : res.hero_show_6_girl_png,    headName : res.hero_head_6_girl_png,    cannonHeadName : res.hero_head_6_girl_png,        dieName : "res/hero_dead_6_girl.png",    desc : 'avatar_2_desc', priceDesc : '$0.99', price : vee.Utils.getObjByPlatform(500, 1000), iapIndex : -1, role : res.hero_girl_ccbi,      coinFrame : "coin_RedGirl.png", owned : true, eventIdx : 102},
//		{ idx : 3, name : 'avatar_3_name', type : game.Roles.Tiny,    picName : res.hero_show_10_tiny_png,   headName : res.hero_head_10_tiny_png,   cannonHeadName : res.hero_head_small_10_tiny_png, dieName : "res/hero_dead_10_tiny.png",   desc : "avatar_3_desc", priceDesc : '10',    price : vee.Utils.getObjByPlatform(1000, 2000), iapIndex : -1, role : res.hero_ji_ccbi,       coinFrame : "coin_chicken.png", owned : true, eventIdx : 104},
//		{ idx : 4, name : 'avatar_4_name', type : game.Roles.Marvin,  picName : res.hero_show_8_marvin_png,  headName : res.hero_head_8_marvin_png,  cannonHeadName : res.hero_head_8_marvin_png,      dieName : "res/hero_dead_8_marvin.png",  desc : "avatar_4_desc", priceDesc : '10',    price : vee.Utils.getObjByPlatform(1200, 3500), iapIndex : -1, role : res.hero_marvin_ccbi,    coinFrame : "coin_42.png",     owned : true, eventIdx : 202},
//		{ idx : 5, name : 'avatar_5_name', type : game.Roles.Cop,     picName : res.hero_show_4_cat_png,     headName : res.hero_head_4_cap_png,     cannonHeadName : res.hero_head_4_cap_png,         dieName : "res/hero_dead_4_cat.png",     desc : 'avatar_5_desc', priceDesc : '30',    price : vee.Utils.getObjByPlatform(1200, 3500),  iapIndex : -1, role : res.hero_cap_ccbi ,      coinFrame : "coin_gun.png",   owned : true, eventIdx : 101},
//		{ idx : 6, name : 'avatar_6_name', type : game.Roles.Space,   picName : res.hero_show_5_space_png,   headName : res.hero_head_5_space_png,   cannonHeadName : res.hero_head_5_space_png,       dieName : "res/hero_dead_5_space.png",   desc : 'avatar_6_desc', priceDesc : '10',    price : vee.Utils.getObjByPlatform(1500, 3500), iapIndex : -1, role : res.hero_nasa_ccbi,      coinFrame : "coin_Xman.png",   owned : true, eventIdx : 201},
//		{ idx : 7, name : 'avatar_7_name', type : game.Roles.bear,    picName : res.hero_show_9_bear_png,    headName : res.hero_head_9_bear_png,    cannonHeadName : res.hero_head_9_bear_png,        dieName : "res/hero_dead_9_bear.png",    desc : 'avatar_7_desc', priceDesc : '$0.99', price : vee.Utils.getObjByPlatform(1500, 4500), iapIndex : -1, role : res.hero_beer_ccbi,      coinFrame : "coin_bear.png",   owned : true, eventIdx : 204},
//		{ idx : 8, name : 'avatar_8_name', type : game.Roles.Vampire, picName : res.hero_show_7_vampire_png, headName : res.hero_head_7_vampire_png, cannonHeadName : res.hero_head_7_vampire_png,     dieName : "res/hero_dead_7_vampire.png", desc : 'avatar_8_desc', priceDesc : '2000',  price : vee.Utils.getObjByPlatform(3000, 6000), iapIndex : -1, role : res.hero_dracula_ccbi,   coinFrame : "coin_blood.png",  owned : true, eventIdx : 103},
//		{ idx : 9, name : 'avatar_9_name', type : game.Roles.Flash,   picName : res.hero_show_3_flash_png,   headName : res.hero_head_3_flash_png,   cannonHeadName : res.hero_head_3_flash_png,       dieName : "res/hero_dead_3_flash.png",   desc : 'avatar_9_desc', priceDesc : '$0.99', price : vee.Utils.getObjByPlatform(5000, 10000), iapIndex : -1, role : res.hero_davinci_ccbi,   coinFrame : "coin_power.png", owned : true, eventIdx : 205}
//	],

	getAvatarName : function (idx) {
		if (!game.Data.isAndroid && idx == 10) {
			idx = 11;
		}
		return vee.Utils.getLocalizedStringForKey('avatar_' + idx + '_name');
	},

	getAvatarDesc : function (idx) {
		if (!game.Data.isAndroid && idx == 10) {
			idx = 11;
		}

		var descStr = vee.Utils.getLocalizedStringForKey('avatar_' + idx + '_desc');

		//add by zq 特殊关卡角色获得条件描述修改
		if(idx == 14 || idx == 15){
			if(game.Data.version.curVersion == VERSION.ANDROID_GOOGLE_FREE
				|| game.Data.version.curVersion == VERSION.IOS_FREE
				|| game.Data.version.curVersion == VERSION.IOS_FREE_CN){
				descStr = vee.Utils.getLocalizedStringForKey('avatar_' + idx + '_desc_android');
			}
		}
		//end

		return descStr;
	},

	//jin
	getProductData : function() {
		return game.Data.isAndroid ? this.productData_android : this.productData;
	},

	init : function () {
		var len = this.getProductData().length;
		for (var i = 0; i < len; ++i) {
			this.getAvatarData(i);
		}
	},

	/**
	 * @param idx
	 * @returns {game.AvatarData.productDataTemplate}
	 */
	getAvatarData : function(idx) {
		var data = this.getProductData()[idx];
		if (!data) return this.getProductData()[0];
		data.owned = (vee.VIPValues.getValue('avatar_' + idx) == 1 ? true : data.owned);
		return data;
	},

	avatarPurchased : function(idx) {
		this.getProductData()[idx].owned = true;
		vee.VIPValues.setValue('avatar_' + idx, 1);
		vee.VIPValues.save();
		LyAvatarStore.refreshState();
		vee.Analytics.logEvent("UnlockRole", {"playCount" : ""+game.Data.getTotalPlayCount()});
	},

	allPurchase : function() {
		var len = this.getProductData().length;
		for (var i = 0; i < len; ++i) {
			this.avatarPurchased(i);
			vee.Analytics.UGameEvent.unlockRoleEvent("pay", i);
		}

		vee.data["allcat"] = true;
		vee.saveData();
		LyAvatarStore.refreshState();
	},

	isAllRole : function() {
		for (var i in this.getProductData()) {
			var pd = this.getProductData()[i];
			if (!pd.owned) {
				return false;
			}
		}
		return true;
	},

	avatarSelected : function(idx) {
		vee.VIPValues.setValue('currentAvatar', idx);
		vee.VIPValues.save();
		game.Data.changeAvatar(idx);
	},

	getCurrentAvatar : function () {
		var idx = vee.VIPValues.getValue('currentAvatar');
		if (!idx) {
			return this.getProductData()[0];
		} else {
			return this.getProductData()[idx];
		}
	},

	getNextAvatar : function (nextCount, unlock) {
		if (!game.Data.isUnlocking() && !unlock) return null;
		if (!nextCount) nextCount = 0;
		var len = this.getProductData().length;
		var count = 0;
		for (var i = 0; i < len; ++i) {
			var pd = this.getProductData()[i];
			// if(pd.idx == 12 || pd.idx == 13 || pd.idx == 14) continue;
			if(pd.idx > 11) continue;
			if (!pd.owned) {
				if (count < nextCount) {
					count++;
				} else {
					return pd;
				}
			}
		}
		return null;
	},

	getUnlockedCount : function () {
		var len = this.getProductData().length;
		var count = 0;
		for (var i = 0; i < len; ++i) {
			if (this.getProductData()[i].owned) ++count;
		}
		return count;
	},

	/**
	 * add by zq for mid-aut
	 * 是否显示可解锁中秋角色弹窗
	 */
	checkUnlockMidAutRole : function(){
		var midAutRoleData = game.AvatarData.getAvatarData(12);
		if (game.Data.version.isMidAutumn && !midAutRoleData.owned){
			var level = game.LevelData.selectedLevel;
			if(game.LevelData.selectedCategory.idx == 7 && level.idx == 2 && level.getLevelState() == 2) {
				return true;
			}
		}
		return false;
	},

	unlockMidAutRole : function(){
		vee.Utils.openURL("https://www.facebook.com/veewosupercat/?ref=bookmarks");
		game.AvatarData.avatarPurchased(12);
		vee.Analytics.UGameEvent.unlockRoleEvent("facebook", 12);
	},

	checkUnlockHolloweenRole : function () {
		var holloweenData = game.AvatarData.getAvatarData(13);
		if(!holloweenData.owned){
			var level = game.LevelData.selectedLevel;
			if(game.LevelData.selectedCategory.idx == 8 && game.LevelData.selectedCategory.percent >= 100){//level.idx == 2 && level.getLevelState() == 2) {
				return true;
			}
		}
		return false;
	},
	
	// unlockHolloweenRole : function () {
	// 	vee.Ad.showVideoAd(function () {
	// 		game.AvatarData.avatarPurchased(13);
	// 		vee.Utils.scheduleOnce(function () {
	// 			game.AvatarData.avatarSelected(13);
	// 			LyUnlock.show(13);
	// 		}, 1.0);
	// 	});
	// },

	checkUnlockThanksgivingRole : function () {
		var thanksgivingData = game.AvatarData.getAvatarData(14);
		if(!thanksgivingData.owned){
			var level = game.LevelData.selectedLevel;
			if(game.LevelData.selectedCategory.idx == 9 && game.LevelData.selectedCategory.percent >= 100){//level.idx == 6 && level.getLevelState() == 2) {
				return true;
			}
		}
		return false;
	},

	unlockVideoRoleByAvatarId : function (avatarId) {
		vee.Ad.showVideoAd(function () {
			vee.Analytics.UGameEvent.showAdEvent("alerts", "video", "unlockRole_" + avatarId);
			game.AvatarData.avatarPurchased(avatarId);
			vee.Analytics.UGameEvent.unlockRoleEvent("video", avatarId);
			// vee.Analytics.UGameEvent.
			vee.Utils.scheduleOnce(function () {
				game.AvatarData.avatarSelected(avatarId);
				LyUnlock.show(avatarId);
			}, 1.0);
		}, "unlockRole");
	},
};