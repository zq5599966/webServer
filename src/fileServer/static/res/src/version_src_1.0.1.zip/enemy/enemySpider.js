/**
 * Created with AppCode.
 * User: WanThirty
 * Date: 15/7/13
 * Time: 下午1:58
 * To change this template use File | Settings | File Templates.
 */

var EnemySpider = Enemy.extend({
	objType : game.ObjectType.Spider,
	spLine : null,
	_lineTopPosY : null,
	_topLimitY : null,
	_bottomLimitY : null,
	_dur : null,
	_elePos : null,

	_popPlayerHeightMax : 1500,
	_popPlayerHeight    : 1500,

	bornWithPos : function (pos) {
		this._container.stopAllActions();
		this._hasCollide = true;
		this._hasG = false;
		this._needSafePos = false;
		this.playAnimate("run");
		var elePos = this.getElePosition();
		this.spLine.setOpacity(255);

		// spider init...
		var grid = cc.p(this._gridInMap.x, this._gridInMap.y-1);
		var tiles = 0;
		var tileOffsetY = 0;
		while (game.Logic.checkTileGridValid(grid)) {
			var obj = game.Logic.map.getObject(grid);
			if (obj && obj.gid) {
				var ti = game.Logic.getTileInfoByGID(obj.gid);
				if (ti) {
					var type = ti.type;
					if (type == game.ObjectType.Block
						|| type == game.ObjectType.Slope
						|| type == game.ObjectType.BlockHurt
						|| type == game.ObjectType.BlockOneWay)
					{
						tileOffsetY = type == game.ObjectType.BlockOneWay ? 32 : 0;
						grid.y += 1;
						break;
					}
				}
			}
			++tiles;
			grid.y -= 1;
		}
		var lineLength = game.Data.tileSizeWidth/2 + tiles * game.Data.tileSizeWidth + tileOffsetY;
		this.spLine.setScaleY(lineLength);
		this._lineTopPosY = elePos.y + lineLength;
		var mapConfig = game.Logic.configMap.getObject(this._gridInMap);
//		var mapConfig = null;
		var topLimitY, bottomLimitY;
		if (mapConfig) {
			var arrArg = mapConfig.name.split(",");
			if (arrArg.length == 2) {
				topLimitY = game.Logic.getTilePosCenterByGrid(cc.p(0, this._gridInMap.y + parseInt(arrArg[0]))).y;
				bottomLimitY = game.Logic.getTilePosCenterByGrid(cc.p(0, this._gridInMap.y + parseInt(arrArg[1]))).y;
			}
		} else {
			topLimitY = game.Logic.getTilePosCenterByGrid(this._gridInMap).y;
			bottomLimitY = elePos.y;
		}

		this._dur = (topLimitY - bottomLimitY)/200;
		this._topLimitY = topLimitY;
		this._bottomLimitY  = bottomLimitY;
		this._elePos = elePos;
		this.runMoveAnimate();
	},

	runMoveAnimate : function () {
		this._container.runAction(cc.repeat(cc.sequence(
			cc.moveTo(this._dur, cc.p(this._elePos.x, this._topLimitY)),
			cc.delayTime(0.5),
			cc.moveTo(this._dur, cc.p(this._elePos.x, this._bottomLimitY)),
			cc.delayTime(0.5)
		), 99999));
	},

	AILogicPerFrame : function(dt) {
		this.spLine.setScaleY(this._lineTopPosY - this.getElePosition().y);
	},

	collide : function (dir) {
		if (game.Data.oPlayerCtl._isBounce || !this._hasCollide) return;
		if (dir == vee.Direction.Top && !game.Data.oPlayerCtl.extendController) {
			if (!game.Data.playerHawk) {
				this.popPlayerUp();
				this.dieAnimate(dir);
			}
		} else if (game.Data.playerHawk) {
			game.Data.oLyGame.shake();
			this.dieAnimate(dir);
		} else {
			if (game.Data.playerInvisible || game.Data.oPlayerCtl._isBounce) return;
			var dir = this.getElePosition().x > game.Data.oPlayerCtl.getElePosition().x ? vee.Direction.Left : vee.Direction.Right;
			game.Data.oPlayerCtl.getShock(dir, true);
		}
	},
	getInhaleController : function () {
		if (this.inhaleController) {
			return null;
		}
		this.inhaleController = new InhaleSpiderObj();
		this.inhaleController.obj = this;
		return this.inhaleController;
	},
	dieAnimate : function (dir) {
		this.onKill();
		this.spLine.setOpacity(0);
		var pos = this.getElePosition();
		EfxEnemyDie.show(pos);
		this._hasCollide = false;
		this._isOver = true;
		this.die();
	}
});