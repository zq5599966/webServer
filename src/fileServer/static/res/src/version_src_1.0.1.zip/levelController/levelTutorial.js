/**
 * Created with AppCode.
 * User: yop
 * Date: 15/9/7
 * Time: 上午11:52
 * To change this template use File | Settings | File Templates.
 */

var IntroTips = vee.Class.extend({
	_isHide : false,
	_nextPos : null,
	activate : function(pos) {
		this._nextPos = null;
		this.rootNode.setVisible(true);
		if (this._isHide) {
			this.rootNode.setPosition(pos);
			this.playAnimate('show');
			this._isHide = false;
		} else {
			this._nextPos = pos;
		}
	},

	achieved : function() {
		if (this._isHide) return;
		this._isHide = false;
		this.playAnimate('end', this.onEnd);
		vee.Audio.playEffect(res.inGame_efx_hideLight_mp3);
	},

	onEnd : function() {
		this._isHide = true;
		if (this._nextPos) {
			this.rootNode.setPosition(this._nextPos);
			this.playAnimate('show');
			this._nextPos = null;
			this._isHide = false;
		}
	},

	onCreate : function() {
		this.rootNode.setVisible(false);
		this._isHide = true;
	}
});

LevelController.LevelTutorial = LevelController.extend({
	_target : null,
	_introTips : null,

	_guideText : null,
	_guideAnim : null,

	_logoCtl : null,

	prepare : function() {
		cc.log('prepare right');
		// 隐藏血量
		game.Data.oLyGame.ccbHPBar.setVisible(false);

		// 隐藏右上信息
		game.Data.oLyGame.nodeTRElements.setVisible(false);

		// 隐藏星星
		game.Data.oLyGame.nodeT.setVisible(false);

		// 隐藏按钮
		game.Data.oLyGame.hideControlButton(LyGame.ControlButtonType.ActionButton | LyGame.ControlButtonType.JumpButton | LyGame.ControlButtonType.MoveButton);

		// 激活目标点
		var lyIntroTips = cc.BuilderReader.load(res.introTips_ccbi);
		game.Data.oLyGame.lyMap.addChild(lyIntroTips);
		this._introTips = lyIntroTips.controller;

		// 显示标题动画
		this._guideText = vee.PopMgr.popCCB(res.guideText_ccbi).controller;
		if (!vee.Controller.isConnected) {
			this._guideText.setVisible(false);
		}
		this._guideText.show(this.firstStep.bind(this));

		// 预加载LOGO纹理
		cc.spriteFrameCache.addSpriteFrames(res.img_Logo_a_plist, res.img_Logo_a_png);
		cc.spriteFrameCache.addSpriteFrames(res.img_Logo_h_plist, res.img_Logo_h_png);
		cc.spriteFrameCache.addSpriteFrames(res.img_Logo_m_plist, res.img_Logo_m_png);
		cc.spriteFrameCache.addSpriteFrames(res.img_Logo_n_plist, res.img_Logo_n_png);
		cc.spriteFrameCache.addSpriteFrames(res.img_Logo_o_plist, res.img_Logo_o_png);
		cc.spriteFrameCache.addSpriteFrames(res.img_Logo_p_plist, res.img_Logo_p_png);
		cc.spriteFrameCache.addSpriteFrames(res.img_Logo_t_plist, res.img_Logo_t_png);
		cc.spriteFrameCache.addSpriteFrames(res.img_Logo_txt_cat_plist, res.img_Logo_txt_cat_png);

		// 预加载ccbi文件
		//vee.Audio.playEffect(res.outGame_efx_showLogo_mp3);
		this._logoCtl = cc.BuilderReader.load(res.guideLogo_ccbi).controller;
		game.Data.oLyGame.lyMap.addChild(this._logoCtl.rootNode, 99);
		vee.Analytics.logMissionStart("Tutorial");
		game.Data.oLyGame.freezeButton = true;
		LyCatGrow.show(function () {
			game.Data.oLyGame.freezeButton = false;
			EleGuide.show();
		});
		var canSkip = vee.data["skipSignTutorial"];
		game.Data.oLyGame.setSkipButtonVisible(true);
		//game.Data.oLyGame.setSkipButtonVisible(canSkip);
		vee.data["skipSignTutorial"] = true;
		vee.saveData();
	},

	firstStep : function() {
		this.activateTarget(cc.p(21,31));
		game.Data.oLyGame.showControlButton(LyGame.ControlButtonType.MoveButton, true, true);
	},

	activateTarget : function(grid) {
		this._target = grid;
		this._introTips.activate(game.Logic.getTilePosByGrid(grid));
	},

	achievedTarget : function() {
		this._introTips.achieved();
	},

	onUpdateLife : function(count) {
		game.Data.playerLife -= count;
	},

	updateText : function(grid, title, content) {
		if (title && title.length) {
			this._guideText.setText(title, content);
			vee.Audio.playEffect(res.inGame_efx_showCourseText_mp3);
		}
	},

	extraFunc : function(grid, dir, name, argument) {
		if (name && this[name]) {
			this[name](grid, dir, argument);
		}
	},

	eventShowTarget : function(grid, dir, arr) {
		if (grid.x == this._target.x && grid.y == this._target.y) {
			this.achievedTarget();
			this.activateTarget(this.getGrid(arr[1]));

			this.updateText(grid, arr[2], arr[3]);
			this.extraFunc(grid, dir, arr[4], arr[5]);
		}
	},

	eventShowJump : function(grid, dir, arr) {
		if (grid.x == this._target.x && grid.y == this._target.y) {
			this.achievedTarget();
			this._target = this.getGrid(arr[1]);

			game.Data.oLyGame.showControlButton(LyGame.ControlButtonType.JumpButton, true, true);

			this.updateText(grid, arr[2], arr[3]);
			this.extraFunc(grid, dir, arr[4], arr[5]);
		}
	},

	eventGetCoin : function(grid, dir, arr) {
		if (grid.x == this._target.x && grid.y == this._target.y) {
			this.achievedTarget();
			this._target = this.getGrid(arr[1]);

			this.updateText(grid, arr[2], arr[3]);
			this.extraFunc(grid, dir, arr[4], arr[5]);
		}
	},

	eventHideText : function() {
		this.HideText();
	},

	eventTutorialStep : function (grid, dir, arr) {
		if (arr.length > 0) {
			vee.Utils.logObj(arr);
			EleGuide.showGuide(arr[1]);
		}
	},

	eventOver : function() {
		if (this._isOver) return;
		this._isOver = true;

		game.Data.oLyGame.setSkipButtonVisible(false);
		game.Data.oLyGame.stopCamera = true;
		game.Data.oLyGame.freezeButton = true;
		game.Data.oLyGame.hideControlButton(LyGame.ControlButtonType.MoveButton | LyGame.ControlButtonType.JumpButton | LyGame.ControlButtonType.ActionButton);
		game.Data.oPlayerCtl.moveRight();
		game.Data.oPlayerCtl._isRandonBreath = false;
		game.Data.oPlayerCtl.playAnimate("huxi_1", function () {});

		var pos = game.Logic.getTilePosCenterByGrid(cc.p(91,22));
		pos = cc.p(pos.x - 568, pos.y - 384);

		this._logoCtl.rootNode.setPosition(pos);
		this._logoCtl.show();

		pos = cc.p(-pos.x, -pos.y);
		var off = vee.Utils.pSub(pos, game.Data.oLyGame.lyContainer.getPosition());
		game.Data.oLyGame.lyContainer.  runAction(cc.sequence(
			cc.spawn(
				cc.EaseExponentialOut.create(cc.moveBy(8, cc.p(0, off.y))),
				cc.EaseExponentialOut.create(cc.moveBy(1, cc.p(off.x, 0)))
			),
			cc.delayTime(1),
			cc.callFunc(function () {
				cc.spriteFrameCache.removeSpriteFramesFromFile(res.img_Logo_a_plist);
				cc.spriteFrameCache.removeSpriteFramesFromFile(res.img_Logo_h_plist);
				cc.spriteFrameCache.removeSpriteFramesFromFile(res.img_Logo_m_plist);
				cc.spriteFrameCache.removeSpriteFramesFromFile(res.img_Logo_n_plist);
				cc.spriteFrameCache.removeSpriteFramesFromFile(res.img_Logo_o_plist);
				cc.spriteFrameCache.removeSpriteFramesFromFile(res.img_Logo_p_plist);
				cc.spriteFrameCache.removeSpriteFramesFromFile(res.img_Logo_t_plist);
				cc.spriteFrameCache.removeSpriteFramesFromFile(res.img_Logo_txt_cat_plist);
			})
		));
		vee.Analytics.logMissionCompleted("Tutorial");
	},

	Highlight : function() {
		game.Data.oLyGame.setHighlightControlButton(LyGame.ControlButtonType.JumpButton, true);
	},

	HideText : function() {
		this._guideText.hide();
	},

	ShowExtra : function(grid, dir, name) {
		Trigger.ShowExtra.func(grid, dir, name);
	},

	HideExtra : function(grid, dir, name) {
		Trigger.HideExtra.func(grid, dir, name);
	},

	getGrid : function(string){
		var temp = string.split(',');
		return cc.p(temp[0], temp[1]);
	}
});

var EleGuideText = vee.Class.extend({
	/** @type {cc.Label} */
	lbTitle : null,
	/** @type {cc.Label} */
	lbContent : null,

	show : function(callback) {
		this._isHide = false;
		this.rootNode.setPosition(vee.PopMgr.centerPoint);
		this.playAnimate('guide', callback);
	},

	setText : function(title, content) {
		this._isHide = false;
		this.lbTitle.setString(title);
		this.lbContent.setString(vee.Utils.getLocalizedStringForKey(content));
		this.playAnimate('show');
	},

	_isHide : false,
	hide : function() {
		if (this._isHide) return;
		this._isHide = true;
		this.playAnimate('end');
	},

	setVisible : function(visible) {
		this.rootNode.setVisible(visible);
	}
});

var EleGuide = vee.Class.extend({
	onExit : function () {
		EleGuide.ctl = null;
	}
});

EleGuide.show = function() {
	if (!vee.Controller.isConnected) {
		var node = cc.BuilderReader.load(res.lyPosGestureStar_ccbi);
		game.Data.oLyGame.lyMapBack.addChild(node, 8);
		node.controller.playAnimate("2", function() {
			node.controller.playAnimate("loop2");
		});
		node.setPosition(game.Logic.getTilePosCenterByGrid(cc.p(16, 31)));
		EleGuide.ctl = node.controller;
	}
};

EleGuide.showGuide = function(grid, animName, callback) {
	if (!vee.Controller.isConnected) {
		var node = cc.BuilderReader.load(res.lyPosGestureStar_ccbi);
		game.Data.oLyGame.lyMapBack.addChild(node, 8);
		node.controller.playAnimate(animName, function() {
			node.controller.playAnimate("loop" + animName);
			if (callback) callback();
		});
		node.setPosition(game.Logic.getTilePosCenterByGrid(grid));
	}
};

EleGuide.ctl = null;