/**
 * Created with AppCode.
 * User: WanThirty
 * Date: 15/9/10
 * Time: 下午7:31
 * To change this template use File | Settings | File Templates.
 */

var LyGameWin = vee.Class.extend({
	nodeTL : null,
	nodeTR : null,

	btnRetry        : null,
	btnNext         : null,
	btnQuit         : null,
	btnShare        : null,
	btnKTPlay       : null,
	nodeStar        : null,
	nodeAvatar      : null,
	lbTargetCoin    : null,
	lbCoinNum       : null,
	lbCoinPerfect   : null,
	spCoinProgress  : null,
	spCoinIcon      : null,
	spAvatarHead    : null,
	nodeProgressDesc : null,
	nodeProgress    : null,
	nodeShare       : null,

	_tempStar       : null,
	oPlayer         : null,
	oCoinCtl        : null,
	oGettedCoinCtl  : null,
	lyNormalBG      : null,
	ly3starBG       : null,
	lyMiniBG        : null,
	ccbRecord       : null,

	coinStartPos : null,
	coinPos : cc.p(507,297),

	isShowMini : false,
	blockButton : false,
	unlockedIdx : -1,

	_isOver : false,

	// for progress animate
	_coin : 0,
	_gettedCoin : 0,
	_nextAvatar : null,
	_isUnlock : false,
	_showReward : true,

	_shieldTouch : false,		//动画播放完成前屏蔽按钮点击

	onCreate : function () {
		if (!VeeRecordButton.isPluginRecording) {
			this.ccbRecord.setVisible(false);
		}
		vee.Audio.playEffect(res.inGame_function_win_mp3);
		this.handleKey(true);
	},

	onKeyBack : function(){
		this.onQuit();
	},

	onExit : function () {
		game.Data.oLyGameOver = null;
		cc.spriteFrameCache.removeSpriteFramesFromFile(res.item_coin_frames_plist);
		cc.spriteFrameCache.removeSpriteFramesFromFile(res.item_plist);
	},

	initController : function () {
		cc.log("game win init controller");
		// selector...
		if(game.Data.isAndroid && game.Data.version.isAutoSave){
			vee.GameCenter.autoSaveGame(jsb.fileUtils.getWritablePath(), "autoSave");
		}

		vee.Controller.initSelector(3,1,this.onQuit.bind(this),cc.p(1,0));
		vee.Controller.registerItemByButton(BtnShop.instance.btnOpenStore,cc.p(2,0),this.ccbAvatarStore.controller.onOpenStore.bind(this),res.mfi_home_avatar_on_png);
		vee.Controller.registerItemByButton(this.btnNext,cc.p(1,0),this.onNext.bind(this),"res/mfi_pause_btn_big.png");
		if (game.Data.stageType != game.StageType.Mini) {
			vee.Controller.registerItemByButton(this.btnRetry,cc.p(0,0),this.onRetry.bind(this),"res/mfi_pause_btn_small.png");
		}
		vee.Controller.activeSelector();
		// button action...
		if (vee.Utils.isRecordAvaliable()) {
			var btnRecordCtl = this.ccbRecord.controller;
			vee.Controller.registerButtonAction(
				[vee.KeyCode.AXIS_LEFT_TRIGGER,vee.KeyCode.BUTTON_LEFT_SHOULDER],
				btnRecordCtl.onTouch.bind(btnRecordCtl)
			);
		}
		var btnStoreCtl = this.ccbAvatarStore.controller;
		vee.Controller.registerButtonAction(
			[vee.KeyCode.AXIS_RIGHT_TRIGGER,vee.KeyCode.BUTTON_RIGHT_SHOULDER],
			btnStoreCtl.onOpenStore.bind(btnStoreCtl)
		);
		vee.Controller.activeButton();
	},

	// showEvent : function () {
	//
	// },

	ccbInit : function () {

		// if (game.Data.isFreeGame) {
		// 	cc.log("zq debug lyGameWin ccbInit");
		// 	vee.Utils.scheduleOnce(function () {
		// 		vee.Ad.showInterstitialByOnlineConfig("game_win");
		// 	}, 1);
		// }

		vee.Controller.clearAll();

		game.Data.oLyGameOver = this;
		game.Data.stageFinish(game.FinishType.WIN);

		game.Data.addMiniCount();


		this.spCoinProgress.getTexture().setAliasTexParameters();


		this._initAvatarStore();

		this._checkMini();

		this.checkAvatar(game.Data.getTempCoin());

		// default coin display
		this.oCoinCtl = vee.ScoreController.registerController(this.lbTargetCoin, this._coin, LyGameWin.formatFunc);
		this.oGettedCoinCtl = vee.ScoreController.registerController(this.lbCoinNum, this._gettedCoin);


		this._checkBigStar();

		this._checkStartAdSign();

		// calc is stage coin all collected
		game.Data.oLvCtl.complete();

		vee.GameCenter.submitScore(game.LevelData.getStar(), 0);
		game.LevelData.save();

		this._logAnalyticsEvent();

		this._checkNewMoonWorld();


		// adaption...
		vee.PopMgr.setNodePos(this.nodeTL, vee.PopMgr.PositionType.TopLeft);
		vee.PopMgr.setNodePos(this.nodeTR, vee.PopMgr.PositionType.TopRight);
		this.nodeTL.runAction(cc.sequence(
			cc.delayTime(3.0),
			cc.callFunc(this.initController.bind(this)),
			cc.delayTime(0.2),
			cc.callFunc(this.removeGame.bind(this)),
			cc.delayTime(1),
			cc.callFunc(this.startProgress.bind(this))
		));

		if (this.btnKTPlay) {

			this.btnKTPlay.setVisible(game.Data.version.isKTPlay);

		}

		if (this.nodeShare) {
			if (vee.KTPlay.isNewNotice()) {
				this.spDot = new cc.Sprite(res.image_redot_png);
				this.nodeShare.addChild(this.spDot);
				this.spDot.setPosition(cc.p(52, 34));
			}
		}

	},

	_initAvatarStore : function () {
		var node = LyAvatarStore.load();
		this.rootNode.addChild(node);
		node.controller.onLoaded();
	},

	showAdCallbackForOpen : function () {

		this._shieldTouch = false;

		if(game.Data.willShowVideoAd){
			vee.Ad.showRevivalVideoAd();
			return;
		}

		if (game.Data.isFreeGame && !game.Data.shownVideoAd) {
			cc.log("zq debug lyGameWin ccbInit");
			vee.Ad.showInterstitialByOnlineConfig("game_win");
			vee.Analytics.UGameEvent.showAdEvent("game_win", "interstial");
		}

		game.Data.shownVideoAd = false;
	},

	_checkMini : function () {
		if (game.Data.stageType == game.StageType.Mini) {
			game.MiniLevelData.setMiniGameProgress(2, game.LevelData.selectedCategory.idx, game.Data.performingTMXIdx);

			this.btnRetry.setVisible(false);

			// this._shieldTouch = true;

			if (game.Data.version.isKTPlay) {

				// this.playAnimate("mini endKT", this.showAdCallbackForOpen);
				this.playAnimate("mini endKT");
			} else {

				// this.playAnimate("mini end", this.showAdCallbackForOpen);
				this.playAnimate("mini end");
			}
		} else {
			if (game.Data.version.isKTPlay) {
				// this.playAnimate("normalKT", this.showAdCallbackForOpen);
				this.playAnimate("normalKT");
			} else {
				// this.playAnimate("normal", this.showAdCallbackForOpen);
				this.playAnimate("normal");
			}
		}
		cc.log("mini game = "+game.Data.getMiniCount());

		var spCount = game.Data.getMiniCount();
		this.miniIdx = game.MiniLevelData.getMiniGameIdx(game.LevelData.selectedCategory.idx);
		if (spCount >= 2 && this.miniIdx != null) {
			if ( vee.Utils.isLucky(spCount/(spCount+1)) ) {
				this.blockButton = true;
				this.isShowMini = true;
			}
			if (game.Data.isAllLevelOpen) {
				this.blockButton = true;
				this.isShowMini = true;
			}
		}
	},

	_checkBigStar : function () {
		if (game.Data.stageType == game.StageType.Mini) {
			this.lyNormalBG.setVisible(true);
		} else {
			this._tempStar = game.LevelData.selectedLevel.getCurrentStarAchieved();
			cc.log("star = "+this._tempStar);
			var delay = 3;
			var starIdx = 1;
			for (var i = 1; i < 4; ++i) {
				var node = this["nodeStar"+i];
				if (game.LevelData.selectedLevel.isStarAchieved(i)) {
					node.controller.setGettedStar();
				}

				cc.log("fuck::::IDX = " + i + "    " + this.checkTempStarArchive(i));
				if (this.checkTempStarArchive(i)) {
					node.starIdx = starIdx;
					node.runAction(cc.sequence(
						cc.delayTime(delay),
						cc.callFunc(function () {
							this.controller.show();
							vee.Audio.playEffect("res/inGame_function_winStar"+this.starIdx+".mp3");
						}.bind(node))
					));
					++starIdx;
					delay += 0.4;
				}
			}
			// calc 3 star
			if (game.Data.collectedStarCount == 3) {
				this.ly3starBG.setVisible(true);
				if (game.Data.getPlayCount() > 5 && !game.Data.isRated()) {
					LyGameWin.isShowRate = true;
				}
			} else {
				this.lyNormalBG.setVisible(true);
			}
		}
	},
	_checkStartAdSign : function () {
		if (game.Data.stageType == game.StageType.Event) {
			if (game.Data.isLastStageAllCoin) {
				this.lbCoinPerfect.setVisible(true);
				game.LevelData.selectedLevel.levelComplete(true /* all coin collect? */);
			} else {
				this.lbCoinPerfect.setVisible(false);
				game.LevelData.selectedLevel.levelComplete(false /* all coin collect? */);
			}
		} else if (game.Data.getTempCoin() >= game.Data.stageMaxCoin) {
			this.lbCoinPerfect.setVisible(true);
			game.LevelData.selectedLevel.levelComplete(true /* all coin collect? */);
		} else {
			this.lbCoinPerfect.setVisible(false);
			game.LevelData.selectedLevel.levelComplete(false /* all coin collect? */);
		}
	},
	_checkNewMoonWorld : function () {
		game.Data.newReverseWorldIdx = -1;
		var count = game.LevelData.categoryCount - 1;
		for (var i = 0; i < count; ++i) {
			game.LevelData.checkLevelLockState(i);
		}
	},
	_logAnalyticsEvent : function () {
		var category = game.LevelData.selectedCategory.idx + 1;
		var level = game.LevelData.selectedLevel.idx + 1;
		var lvName = "";
		if (game.Data.stageType == game.StageType.Mini) {
			lvName = "Mini";
		} else if (game.Data.stageType == game.StageType.Event) {
			lvName = "Event";
		}

		vee.Analytics.logEvent("GameWin" + lvName + category + "0" + level,
			{star : ""+game.LevelData.selectedLevel.getAchievedStarCount(), coin : ""+this._gettedCoin});

		vee.Analytics.UGameEvent.gameEndEvent(lvName, "success");
	},

	checkAvatar : function (coinNum) {
		this._coin = game.LevelData.getCoin();
		if (!this._coin) this._coin = 0;
		this._gettedCoin = coinNum;
		// set default display
		var targetAvatar = game.AvatarData.getNextAvatar();
		var rate = 1;
		if (targetAvatar) {
			this._coinFrameName = targetAvatar.coinFrame;
			this.spAvatarHead.setTexture(targetAvatar.headName);
			this.setProgressEnable(true);
			LyGameWin.targetCoin = targetAvatar.price;
			rate = this._coin / targetAvatar.price;
			this.spCoinProgress.setScaleX(rate*this._maxPercent);
			// for progress animate
			this._nextAvatar = targetAvatar;
			// cast unlock
			game.LevelData.addCoin(this._gettedCoin);
			if (this._gettedCoin == 0) this._progressEnable = false;
			var coin = game.LevelData.getCoin();
			if (coin >= targetAvatar.price) {
				game.LevelData.resetCoin(coin);

				// game.AvatarData.avatarPurchased(targetAvatar.idx);
				// this.unlockedIdx = targetAvatar.idx;

				//add by zq :历史遗留问题 fuck
				var tmpIdx = targetAvatar.idx;
				if(tmpIdx >= 11){
					tmpIdx = tmpIdx - 1;
				}
				game.AvatarData.avatarPurchased(tmpIdx);
				vee.Analytics.UGameEvent.unlockRoleEvent("coin", tmpIdx);
				this.unlockedIdx = tmpIdx;
				//end

				game.Data.setUnlocking(false);
				this._isUnlock = true;
				this.blockButton = true;
			} else {
				this._isUnlock = false;
			}
			this.spCoinIcon.setSpriteFrame(targetAvatar.coinFrame);
		} else {
			this._isUnlock = false;
			if (!game.AvatarData.isAllRole()) {
				this.isShowMini = false;
			}
			this.setProgressEnable(false);
			this.blockButton = false;
		}
	},

	checkTempStarArchive : function (idx) {
		switch (idx) {
			case 1 :
				return (this._tempStar & 0x0001) > 0;
			case 2 :
				return (this._tempStar & 0x0010) > 0;
			case 3 :
				return (this._tempStar & 0x0100) > 0;
			default :
				return false;
		}
	},

	checkHasUnlockRoleBySpecialLevel : function () {

		if(game.AvatarData.checkUnlockMidAutRole()){
//			vee.PopMgr.alert("mid aut role unlock view", "fuck view", function(){
//				game.AvatarData.unlockMidAutRole();
//			});
			AlertFacebook.show();
			return true;
		}

		if(game.AvatarData.checkUnlockHolloweenRole()){
			// AlertUnlockRoleByVideo.show(13);
			game.AvatarData.avatarPurchased(13);
			vee.Analytics.UGameEvent.unlockRoleEvent("allStar", 13);
			LyUnlock.show(13);
			return true;
		}

		if(game.AvatarData.checkUnlockThanksgivingRole()){
			// AlertUnlockRoleByVideo.show(14);
			game.AvatarData.avatarPurchased(14);
			vee.Analytics.UGameEvent.unlockRoleEvent("allStar", 14);
			LyUnlock.show(14);
			return true;
		}

		return false;
	},

	_showAlerts : function () {
		if (this._isOver) return;

		if(this.checkHasUnlockRoleBySpecialLevel()){
			return;
		}

		this.blockButton = false;
		if (this.unlockedIdx >= 0) {
			var callback = null;
			if (game.Data.newReverseWorldIdx > -1) {
				callback = this._showMoonCategoryAlert.bind(this);
			} else if (game.Data.newMoonLevelIdx > -1) {
				callback = this._showMoonLevelAlert.bind(this);
			}
			LyUnlock.show(this.unlockedIdx, callback);
			this.oCoinCtl.setNumber(LyGameWin.targetCoin);
			this.unlockedIdx = -1;
		} else if (game.Data.newReverseWorldIdx > -1) {
			this._showMoonCategoryAlert();
		} else if (game.Data.newMoonLevelIdx > -1) {
			this._showMoonLevelAlert();
		} else if (this.isShowMini) {
			LySpecial.show();
			this.isShowMini = false;
		} else if (this._nextAvatar && this._showReward) {
			LyReward.showLogic(true, this._nextAvatar.price - this._coin);
			this._showReward = false;
		} else if (LyGameWin.isShowRate && !this._isUnlock
			|| (game.dataManager.isNewVersionRate()
			&& game.LevelData.selectedCategory
			&& game.LevelData.selectedLevel
			&& game.LevelData.selectedLevel.idx > 0 )) {
			if (this.isShowMini) {
				this.blockButton = false;
				this.isShowMini = false;
			}
			// if (game.LevelData.selectedCategory && game.LevelData.selectedLevel) {
			if (game.LevelData.selectedCategory && game.LevelData.selectedLevel) {
				var category = game.LevelData.selectedCategory.idx + 1;
				var level = game.LevelData.selectedLevel.idx + 1;
				if (category > 1 && level > 2) {
				// if (level > 1) {
					//for demo
					LyRate.show();
					LyGameWin.isShowRate = false;
					game.dataManager.setVersionRateFalse();
				}
			}
			game.Data.resetPlayCount();
		}
	},

	_showMoonCategoryAlert : function () {
		LyUnlockedMoonWorld.show(false);
		game.Data.newReverseWorldIdx = -1;
	},

	_showMoonLevelAlert : function () {
		LyUnlockedMoon.show();
	},

	onRetry : function () {
		if (this.blockButton || this._isOver || this._shieldTouch) return;
		vee.Audio.playEffect(res.inGame_menu_click_mp3);
		if (game.Data.costEnergy()) {
			vee.dataManager.setEnergy(vee.dataManager.getEnergy() + 1);
		}
		this.winRetry();
		vee.Controller.deactiveSelector();
		this._isOver = true;
	},

	winRetry : function() {
		//EfxCostEnergy.show(this.btnRetry.getPosition(), this.rootNode);
		cc.log("2 performingTMXIdx = "+game.Data.performingTMXIdx);
		if (game.Data.stageType == game.StageType.Event && game.Data.lastTMXIdx != null) {
			game.Data.performingTMXIdx = game.Data.lastTMXIdx;
		}
		cc.log("1 performingTMXIdx = "+game.Data.performingTMXIdx);
		vee.Transition.out(res.MapTransition_ccbi, function () {
			this._openGame(game.Data.performingTMXIdx,false);
		}.bind(this));
	},

	onNext : function () {
		if (this.blockButton || this._isOver || this._shieldTouch) return;
		// vee.Utils.logObj(game.LevelData.selectedLevel, "on next select level data======");
		cc.log("zq debug 111111111 select level idx===%d", game.LevelData.selectedLevel.idx);
		// var selectLevelData = game.LevelData.selectedLevel;
		if (game.LevelData.selectedLevel.isHaveNextLevel()) {
			cc.log("zq debug 2222222222 select level idx===%d", game.LevelData.selectedLevel.idx);
			if(game.LevelData.selectedCategory.idx == 9 && !game.LevelData.checkParkourlevelUnlock(game.LevelData.selectedLevel.idx + 1)){
				ccbAlertUnlockLevel.show(game.LevelData.selectedLevel.idx + 1, function() {
					game.LevelData.selectedLevel.setNextSelectLevel();
					this.goNextLevelEvent();
				}.bind(this));
			}
			else{
				cc.log("zq debug lygame win level event");
				game.LevelData.selectedLevel.setNextSelectLevel();
				this.goNextLevelEvent();
			}
		}
		else if(game.LevelData.selectedLevel.isGoNextCategory() ){
			this.goNextLevelEvent();
		}
		else {
			vee.Transition.out(res.MapTransition_ccbi, function () {
				LyLevelSelect.show();
			}.bind(this));
			vee.Controller.deactiveSelector();
			this._isOver = true;
		}
	},
	
	goNextLevelEvent : function () {

		if (game.Data.costEnergy()) {
			vee.dataManager.setEnergy(vee.dataManager.getEnergy() + 1);
		}
		this.winNext();
		vee.Controller.deactiveSelector();
		this._isOver = true;
	},

	winNext : function() {
		//EfxCostEnergy.show(this.btnNext.getPosition(), this.rootNode);
		game.Logic.startGame(game.LevelData.getCurrentLevelMapIndex(), false);
	},

	onShare : function () {
		if (this.blockButton) return;
		//TODO:: share screen
	},

	onQuit : function () {
		if (this.blockButton || this._isOver || this._shieldTouch) return;

		vee.dataManager.setEnergy(vee.dataManager.getEnergy() + 1);

		vee.Transition.out(res.MapTransition_ccbi, function () {
			LyLevelSelect.show();
		}.bind(this));
		vee.Controller.deactiveSelector();
		this._isOver = true;
	},

	onKTPlay : function () {
		vee.KTPlay.show();
	},

	startProgress : function () {
		this._progressAnimate();

	},

	removeGame : function() {
		var objs = game.Logic.dynamicObjMap.getObjects();
		for (var i in objs) {
			var obj = objs[i];
			if (obj && obj._eleType == game.EleType.Enemy) {
				obj.die();
			}
		}
		vee.PopMgr.closeLayerByCtl(game.Logic.oLyGame);
	},

	miniIdx : null,
	showMini : function () {
		game.MiniLevelData.setMiniGameProgress(1, game.LevelData.selectedCategory.idx, this.miniIdx);
		var endCallback = function () {
			this._openGame(this.miniIdx, false, game.StageType.Mini);
			// this.showAdCallbackForOpen();
		}.bind(this);

		if (game.Data.isIOSCN || game.Data.isAndroid) {
			this.playAnimate("miniKT", endCallback);
		} else {
			this.playAnimate("mini", endCallback);
		}
	},

	_openGame : function(tmxIdx, isSavePoint, stageType) {
		vee.PopMgr.closeAll();
		cc.director.purgeCachedData();
		var node = vee.PopMgr.popCCB("res/veeGameLayer.ccbi");
		cc.log('opening level: ' + tmxIdx);
		game.Data.oLyGame.onLoaded();
		game.Data.oLyGame.initStage(tmxIdx, isSavePoint, stageType);
	},

	_progressEnable : true,
	setProgressEnable : function (isEnable) {
		this._progressEnable = isEnable;
		this.nodeProgress.setVisible(isEnable);
		this.nodeProgressDesc.setVisible(isEnable);
	},

	_maxPercent : 42,
	_progressAnimate : function () {
		cc.log("_progressEnable = "+this._progressEnable);
		if (!this._progressEnable) {
			this._showAlerts();
			return;
		}
		// preset arguments...
		if (this._nextAvatar) {
			this.spAvatarHead.setTexture(this._nextAvatar.headName);
			var targetCoin = this._nextAvatar.price;
			LyGameWin.targetCoin = targetCoin;
			if (this._isUnlock) {
				// refresh coin
				var coinOff = targetCoin - this._coin;
				this._showCoinParticle(coinOff);
			} else {
				// refresh coin
				this._showCoinParticle(this._gettedCoin);
			}
		}
	},

	_coinOff : 0,
	_coinCount : 0,
	_coinItr : 0,
	_coinFrameName : null,
	_showCoinParticle : function (coinOff) {
		this._coinOff = coinOff;
		if (coinOff > 40) {
			this._coinItr = Math.ceil(coinOff / 40);
		} else {
			this._coinItr = 1;
		}
		this._coinCount = 0;
		this.coinStartPos = vee.Utils.pAdd(this.lbCoinNum.getPosition(), this.nodeTR.getPosition());
		vee.Utils.scheduleCallbackForTarget(this.nodeTR, this.updateShowCoin.bind(this), 0.05);
	},

	updateShowCoin : function (dt) {
		if (this._coinOff > 0) {
			if (this._coinItr > this._coinOff) {
				this._coinItr = this._coinOff;
			}
			this._coinOff -= this._coinItr;
			this._gettedCoin -= this._coinItr;
			this.oGettedCoinCtl.setNumber(this._gettedCoin);
			this._coinCount += this._coinItr;
			var sp = new cc.Sprite("#"+this._coinFrameName);
			sp.setPosition(this.coinStartPos);
			sp.itr = this._coinItr;
			if (this._coinOff <= 0) sp.isOver = true;
			sp.runAction(cc.sequence(
				cc.jumpTo(0.5, this.coinPos.x, this.coinPos.y, 100, 1),
				cc.callFunc(function () {
					this._coin += sp.itr;
					this.oCoinCtl.setNumber(this._coin);
					this.spCoinProgress.stopAllActions();
					this.spCoinProgress.runAction(cc.scaleTo(0.04, this._coin/LyGameWin.targetCoin*this._maxPercent, 1));
					if (sp.isOver) {
						this._showAlerts();
					}
					sp.removeFromParent();
					vee.Audio.playEffect(res.inGame_function_countCoins_mp3);
				}.bind(this))
			));
			this.rootNode.addChild(sp, 10);
		} else {
			vee.Utils.unscheduleAllCallbacksForTarget(this.nodeTR);
		}
	},

	changeAvatar : function (idx) {
		var data = game.AvatarData.getAvatarData(idx);
		if (data) {
			this.nodeAvatar.removeAllChildren();
			var roleContent = ElePlayer.create(data.role);
			this.nodeAvatar.addChild(roleContent.container);
			roleContent.controller.playAnimate("huxi_1");
		}
	}
});

LyGameWin.show = function () {

	var fileName = res.GameWin_ccbi;
	if (game.Data.checkIs61()) {

		fileName = res.GameWinChild_ccbi;
	}
	var node = vee.PopMgr.popCCB(fileName, {alpha : 0});

	// node.controller.ccbInit();

	// if(game.Data.willShowVideoAd){
	// 	vee.Ad.showRevivalVideoAd(function () {
	// 		node.controller.ccbInit();
	// 	});
	// 	return node;
	// }
	// else if (game.Data.isFreeGame) {
	// 	cc.log("zq debug lyGameWin ccbInit");
	// 	vee.Ad.showInterstitialByOnlineConfig("game_win");
	// }

	node.controller.ccbInit();

	return node;
};

LyGameWin.targetCoin = null;

LyGameWin.formatFunc = function (label, displayValue, str) {
	label.setString(displayValue+" / "+LyGameWin.targetCoin);
};

LyGameWin.isShowRate = false;