/**
 * Created with AppCode.
 * User: WanThirty
 * Date: 15/8/21
 * Time: 下午3:03
 * To change this template use File | Settings | File Templates.
 */

var TileData = cc.Class.extend({
	gid         : 0,
	grid        : null,
	layer       : null,
	check       : true,
	refreshSign : false,

	tileInfo    : null,
	left        : 0,
	right       : 0,
	top         : 0,
	bottom      : 0,

	setTileDataPos : function (pos) {
		this.left   = pos.x;
		this.bottom = pos.y;
		this.top    = this.bottom + TILE_WIDTH;
		this.right  = this.left + TILE_WIDTH;
	},
	init : function () {}, // called when the arguments has set up
	collide : function(nodeCtl, dir){},
	viewIn : function (){},
	viewOut : function (){},
	checkOrigin : function(pos, node){},
	checkTop : function(pos, node){},
	checkTopLeft : function(pos, node){},
	checkTopRight : function(pos, node){},
	checkLeft : function(pos, node){},
	checkRight : function(pos, node){},
	checkBottom : function(pos, node){},
	checkBottomLeft : function(pos, node){},
	checkBottomRight : function(pos, node){}
});


TileData.createTileData = function (gid) {
	var td = this.gid2td["Tile"+gid];
	if (td) {
		return new td();
	} else {
		var ti = game.TileIDInfo["Tile"+gid];
		if (ti) {
			var ret = new TileData();
			ret.tileInfo = ti;
			ret.check = false;
			return ret;
		}
	}
};


TileData.BlockData = TileData.extend({
	tileInfo : game.TileInfo.TileBlock,
	checkOriginPosY : function (boxSize, boxOff) {
		return this.bottom + this.tileInfo.edgeLeft + boxSize.height/2 - boxOff.y;
	},
	checkOrigin : function(pos, nodeCtl){
		var ret = null;
		var offset = vee.Utils.pSub(pos, cc.p(this.left, this.bottom));

		var checkPosY = this.checkOriginPosY(nodeCtl.boxSize, nodeCtl.boxOffset);
		if (nodeCtl.isJumping()) {
			if (checkPosY > pos.y) {
				if (nodeCtl._speedY < 0) {
					nodeCtl.downToBarrier(this);
					nodeCtl.setJumping(false);
				}
				var forRet = cc.p(pos.x, checkPosY);
				var nextGrid = game.Logic.getTileGridByPos(forRet);
				if (nodeCtl._grid.y - nextGrid.y > 1) {
					ret = cc.p(pos.x, this.bottom - nodeCtl.boxSize.height/2);
				} else {
					ret = forRet;
				}
			}
		} else {
			nodeCtl.downToBarrier(this);
			ret = cc.p(pos.x, checkPosY);
			game.Logic.calcSpeedScaleRate(nodeCtl, this.tileInfo);
		}

		return ret;
	},
	checkTopPosY : function (boxSize, boxOff) {
		return this.bottom + this.tileInfo.edgeLeft + boxSize.height/2 - boxOff.y;
	},
	checkTop : function(pos, nodeCtl){
		var ret = null;

		var checkPosY = this.checkTopPosY(nodeCtl.boxSize, nodeCtl.boxOffset);
		if (checkPosY > pos.y) {
			if (nodeCtl.isJumping()) {
				if (nodeCtl._speedY < 0) {
					game.Logic.checkTileTrigger(this.grid, vee.Direction.Bottom, this, nodeCtl);
					nodeCtl.downToBarrier(this);
					ret = cc.p(pos.x, checkPosY);
					nodeCtl.setJumping(false);
				}
			} else {
				nodeCtl.downToBarrier(this);
				ret = cc.p(pos.x, checkPosY);
				game.Logic.calcSpeedScaleRate(nodeCtl, this.tileInfo);
			}
		}

		return ret;
	},
	checkTopLeftPosY : function (boxSize, boxOff) {
		return this.bottom + this.tileInfo.edgeLeft + boxSize.height/2 - boxOff.y;
	},
	checkTopLeft : function(pos, nodeCtl){
		if (this.left - pos.x > game.Data.playerBottomEdgeWidth) return null;// && !nodeCtl.isJumping()
		var ret = null;

		var checkPosY = this.checkTopLeftPosY(nodeCtl.boxSize, nodeCtl.boxOffset);
		if (nodeCtl.isJumping()) {
			if (checkPosY > pos.y) {// - 16
				var checkPosX = this.left - nodeCtl.boxSize.width/2;
				if (checkPosX < pos.x) {
					if (nodeCtl.getElePosition().y >= checkPosY && nodeCtl._speedY < 0) {
						game.Logic.checkTileTrigger(this.grid, vee.Direction.Bottom, this, nodeCtl);
						nodeCtl.downToBarrier(this);
						ret = cc.p(pos.x, checkPosY);
						nodeCtl.setJumping(false);
					} else {
						if (nodeCtl._speedX > 0) {
							game.Logic.checkTileTrigger(this.grid, vee.Direction.Bottom, this, nodeCtl);
							nodeCtl.rightToBarrier(this);
						}
						// Push player!
						var pushOffset = pos.x - checkPosX;
						if (pushOffset > 8) pushOffset = 8;
						ret = cc.p(pos.x - pushOffset, pos.y);
					}
				}
			}
		} else {
			nodeCtl.downToBarrier(this);
			ret = cc.p(pos.x, checkPosY);
			game.Logic.calcSpeedScaleRate(nodeCtl, this.tileInfo);
		}

		return ret;
	},
	checkTopRightPosY : function (boxSize, boxOff) {
		return this.bottom + this.tileInfo.edgeLeft + boxSize.height/2 - boxOff.y;
	},
	checkTopRight : function(pos, nodeCtl){
		if (pos.x - this.right > game.Data.playerBottomEdgeWidth && !nodeCtl.isJumping()) return null;
		var ret = null;
		var offset = vee.Utils.pSub(pos, cc.p(this.left, this.bottom));

		var checkPosY = this.checkTopRightPosY(nodeCtl.boxSize, nodeCtl.boxOffset);
		if (nodeCtl.isJumping()) {
			if (checkPosY > pos.y) {// - 16
				var checkPosX = this.right + nodeCtl.boxSize.width/2;
				if (checkPosX > pos.x) {
					if (nodeCtl.getElePosition().y >= checkPosY && nodeCtl._speedY < 0) {
						game.Logic.checkTileTrigger(this.grid, vee.Direction.Bottom, this, nodeCtl);
						nodeCtl.downToBarrier(this);
						ret = cc.p(pos.x, checkPosY);
						nodeCtl.setJumping(false);
					} else {
						if (nodeCtl._speedX < 0) {
							game.Logic.checkTileTrigger(this.grid, vee.Direction.Bottom, this, nodeCtl);
							nodeCtl.leftToBarrier(this);
						}
						// Push player!
						var pushOffset = checkPosX - pos.x;
						if (pushOffset > 8) pushOffset = 8;
						ret = cc.p(pos.x+pushOffset, pos.y);
					}
				}
			}
		} else {
			nodeCtl.downToBarrier(this);
			ret = cc.p(pos.x, checkPosY);
			game.Logic.calcSpeedScaleRate(nodeCtl, this.tileInfo);
		}

		return ret;
	},
	checkLeft : function(pos, nodeCtl){
		var ret = null;

		if (pos.y < this.bottom + this.tileInfo.edgeLeft + nodeCtl.boxSize.height/2) {
			var checkPosX = this.left - nodeCtl.boxSize.width/2;
			if (checkPosX < pos.x) {
				game.Logic.checkTileTrigger(this.grid, vee.Direction.Right, this, nodeCtl);
				nodeCtl.rightToBarrier(this);
				// Push player
				var pushOffset = pos.x - checkPosX;
				if (pushOffset > 8) pushOffset = 8;
				ret = cc.p(pos.x-pushOffset, pos.y);
			}
		}

		return ret;
	},
	checkRight : function(pos, nodeCtl){
		var ret = null;

		if (pos.y < this.bottom + this.tileInfo.edgeLeft + nodeCtl.boxSize.height/2) {
			var checkPosX = this.right + nodeCtl.boxSize.width/2;
			if (checkPosX > pos.x) {
				game.Logic.checkTileTrigger(this.grid, vee.Direction.Left, this, nodeCtl);
				nodeCtl.leftToBarrier(this);
				// Push player
				var pushOffset = checkPosX - pos.x;
				if (pushOffset > 8) pushOffset = 8;
				ret = cc.p(pos.x+pushOffset, pos.y);
			}
		}

		return ret;
	},
	checkBottom : function(pos, nodeCtl){
		var ret = null;

		var checkPosY = this.bottom - nodeCtl.boxSize.height/2 - nodeCtl.boxOffset.y;
		if (checkPosY < pos.y) {
			game.Logic.checkTileTrigger(this.grid, vee.Direction.Top, this, nodeCtl);
			if (nodeCtl._speedY > 0) nodeCtl.upToBarrier(this);
			ret = cc.p(pos.x, checkPosY);
		}

		return ret;
	},
	checkBottomLeft : function(pos, nodeCtl){
		if (this.left - pos.x < game.Data.playerTopEdgeWidth) {
			return this.checkBottom(pos, nodeCtl);
		}
	},
	checkBottomRight : function(pos, nodeCtl){
		if (pos.x - this.right < game.Data.playerTopEdgeWidth) {
			return this.checkBottom(pos, nodeCtl)
		}
	}
});
TileData.UPSlopeData = TileData.BlockData.extend({
	tileInfo : game.TileInfo.TileUPSlope,

	checkOriginPosY : function(offset, boxSize, boxOff) {
		var ret = offset.x * this.tileInfo.slope + this.tileInfo.edgeLeft + this.bottom + boxSize.height/2 - boxOff.y;
		checkPosY = Math.min(ret, this.bottom + this.tileInfo.edgeRight + boxSize.height/2 - boxOff.y);
		return ret;
	},
	checkOrigin : function (pos, nodeCtl) {
		var ret = null;
		var offset = vee.Utils.pSub(pos, cc.p(this.left, this.bottom));

		var checkPosY = this.checkOriginPosY(offset, nodeCtl.boxSize, nodeCtl.boxOffset);
		if (nodeCtl.isJumping()) {
			if (checkPosY > pos.y) {
				if (nodeCtl._speedY < 0) {
					nodeCtl.downToBarrier(this);
					nodeCtl.setJumping(false);
				}
				var forRet = cc.p(pos.x, checkPosY);
				var nextGrid = game.Logic.getTileGridByPos(forRet);
				if (nodeCtl._grid.y - nextGrid.y > 1) {
					ret = cc.p(pos.x, this.bottom - nodeCtl.boxSize.height/2);
				} else {
					ret = forRet;
				}
			}
		} else {
			nodeCtl.downToBarrier();
			ret = cc.p(pos.x, checkPosY);
			game.Logic.calcSpeedScaleRate(nodeCtl, this.tileInfo);
		}

		return ret;
	},
	checkLeft : function(pos, nodeCtl){
		var ret = null;

		if (pos.y < this.bottom + this.tileInfo.edgeLeft) {
			var checkPosX = this.left - nodeCtl.boxSize.width/2;
			if (checkPosX < pos.x) {
				game.Logic.checkTileTrigger(this.grid, vee.Direction.Right, this, nodeCtl);
				nodeCtl.rightToBarrier(this);
				// Push player
				var pushOffset = pos.x - checkPosX;
				if (pushOffset > 8) pushOffset = 8;
				ret = cc.p(pos.x-pushOffset, pos.y);
			}
		}

		return ret;
	},
	checkRight : function(pos, nodeCtl){
		var ret = null;

		if (pos.y < this.bottom + this.tileInfo.edgeRight) {
			var checkPosX = this.right + nodeCtl.boxSize.width/2;
			if (checkPosX > pos.x) {
				game.Logic.checkTileTrigger(this.grid, vee.Direction.Left, this, nodeCtl);
				nodeCtl.leftToBarrier(this);
				// Push player
				var pushOffset = checkPosX - pos.x;
				if (pushOffset > 8) pushOffset = 8;
				ret = cc.p(pos.x+pushOffset, pos.y);
			}
		}

		return ret;
	},
	checkTopPosY : function (offset, boxSize, boxOff) {
		var ret = offset.x * this.tileInfo.slope + this.tileInfo.edgeLeft + this.bottom + boxSize.height/2 - boxOff.y;
		ret = Math.min(ret, this.bottom + this.tileInfo.edgeRight + boxSize.height/2 - boxOff.y);
		return ret;
	},
	checkTop : function(pos, nodeCtl){
		var ret = null;
		var offset = vee.Utils.pSub(pos, cc.p(this.left, this.bottom));

		var checkPosY = this.checkTopPosY(offset, nodeCtl.boxSize, nodeCtl.boxOffset);
		if (nodeCtl.isJumping()) {
			if (checkPosY > pos.y) {
				if (nodeCtl._speedY < 0) {
					game.Logic.checkTileTrigger(this.grid, vee.Direction.Bottom, this, nodeCtl);
					nodeCtl.downToBarrier(this);
					ret = cc.p(pos.x, checkPosY);
					nodeCtl.setJumping(false);
				}
			}
		} else {
			nodeCtl.downToBarrier(this);
			ret = cc.p(pos.x, checkPosY);
			game.Logic.calcSpeedScaleRate(nodeCtl, this.tileInfo);
		}

		return ret;
	},
	checkTopLeftPosY : function(offset, boxSize, boxOff) {
		var ret = offset.x * this.tileInfo.slope + this.tileInfo.edgeLeft + this.bottom + boxSize.height/2 - boxOff.y;
		ret = Math.min(ret, this.bottom + this.tileInfo.edgeRight + boxSize.height/2 - boxOff.y);
		return ret;
	},
	checkTopLeft : function(pos, nodeCtl){
		if (this.left - pos.x > game.Data.playerBottomEdgeWidth && !nodeCtl.isJumping()) return null;
		var ret = null;
		var offset = vee.Utils.pSub(pos, cc.p(this.left, this.bottom));

		var checkPosY = this.checkTopLeftPosY(offset, nodeCtl.boxSize, nodeCtl.boxOffset);
		if (nodeCtl.isJumping()) {
			if (checkPosY > pos.y) {
				var checkPosX = this.left - nodeCtl.boxSize.width/2;
				if (checkPosX < pos.x) {
					if (nodeCtl.getElePosition().y >= checkPosY && nodeCtl._speedY < 0) {
						game.Logic.checkTileTrigger(this.grid, vee.Direction.Bottom, this, nodeCtl);
						nodeCtl.downToBarrier(this);
						ret = cc.p(pos.x, checkPosY);
						nodeCtl.setJumping(false);
					} else {
						if (nodeCtl._speedX > 0) {
							game.Logic.checkTileTrigger(this.grid, vee.Direction.Bottom, this, nodeCtl);
							nodeCtl.rightToBarrier(this);
						}
						// Push player!
						var pushOffset = pos.x - checkPosX;
						if (pushOffset > 8) pushOffset = 8;
						ret = cc.p(pos.x - pushOffset, pos.y);
					}
				}
			}
		} else {
			nodeCtl.downToBarrier(this);
			ret = cc.p(pos.x, checkPosY);
			game.Logic.calcSpeedScaleRate(nodeCtl, this.tileInfo);
		}

		return ret;
	},
	checkTopRightPosY : function (offset, boxSize, boxOff) {
		var ret = offset.x * this.tileInfo.slope + this.tileInfo.edgeLeft + this.bottom + boxSize.height/2 - boxOff.y;
		ret = Math.min(ret, this.bottom + this.tileInfo.edgeRight + boxSize.height/2 - boxOff.y);
		return ret;
	},
	checkTopRight : function(pos, nodeCtl){
		if (pos.x - this.right > game.Data.playerBottomEdgeWidth && !nodeCtl.isJumping()) return null;
		var ret = null;
		var offset = vee.Utils.pSub(pos, cc.p(this.left, this.bottom));

		var checkPosY = this.checkTopRightPosY(offset, nodeCtl.boxSize, nodeCtl.boxOffset);
		if (nodeCtl.isJumping()) {
			if (checkPosY > pos.y) {
				var checkPosX = this.right + nodeCtl.boxSize.width/2;
				if (checkPosX > pos.x) {
					if (nodeCtl.getElePosition().y >= checkPosY && nodeCtl._speedY < 0) {
						game.Logic.checkTileTrigger(this.grid, vee.Direction.Bottom, this, nodeCtl);
						nodeCtl.downToBarrier(this);
						ret = cc.p(pos.x, checkPosY);
						nodeCtl.setJumping(false);
					} else {
						if (nodeCtl._speedX < 0) {
							game.Logic.checkTileTrigger(this.grid, vee.Direction.Bottom, this, nodeCtl);
							nodeCtl.leftToBarrier(this);
						}
						// Push player!
						var pushOffset = checkPosX - pos.x;
						if (pushOffset > 8) pushOffset = 8;
						ret = cc.p(pos.x+pushOffset, pos.y);
					}
				}
			}
		} else {
			nodeCtl.downToBarrier(this);
			ret = cc.p(pos.x, checkPosY);
			game.Logic.calcSpeedScaleRate(nodeCtl, this.tileInfo);
		}

		return ret;
	}
});
TileData.UPSlopeZeroToHalfData = TileData.UPSlopeData.extend({
	tileInfo : game.TileInfo.TileUpSlopeZeroToHalf
});
TileData.UPSlopeHalfToTopData = TileData.UPSlopeData.extend({
	tileInfo : game.TileInfo.TileUpSlopeHalfToTop
});
TileData.DOWNSlopeData = TileData.UPSlopeData.extend({
	tileInfo : game.TileInfo.TileDownSlope,
	checkOriginPosY : function(offset, boxSize, boxOff) {
		var ret = offset.x * this.tileInfo.slope + this.tileInfo.edgeLeft + this.bottom + boxSize.height/2 - boxOff.y;
		ret = Math.min(ret, this.bottom + this.tileInfo.edgeLeft + boxSize.height/2 - boxOff.y);
		return ret;
	},
	checkTopPosY : function (offset, boxSize, boxOff) {
		var ret = offset.x * this.tileInfo.slope + this.tileInfo.edgeLeft + this.bottom + boxSize.height/2 - boxOff.y;
		ret = Math.min(ret, this.bottom + this.tileInfo.edgeLeft + boxSize.height/2 - boxOff.y);
		return ret;
	},
	checkTopLeftPosY : function(offset, boxSize, boxOff) {
		var ret = offset.x * this.tileInfo.slope + this.tileInfo.edgeLeft + this.bottom + boxSize.height/2 - boxOff.y;
		ret = Math.min(ret, this.bottom + this.tileInfo.edgeLeft + boxSize.height/2 - boxOff.y);
		return ret;
	},
	checkTopRightPosY : function (offset, boxSize, boxOff) {
		var ret = offset.x * this.tileInfo.slope + this.tileInfo.edgeLeft + this.bottom + boxSize.height/2 - boxOff.y;
		ret = Math.min(ret, this.bottom + this.tileInfo.edgeLeft + boxSize.height/2 - boxOff.y);
		return ret;
	}
});
TileData.DOWNSlopeTopToHalfData = TileData.DOWNSlopeData.extend({
	tileInfo : game.TileInfo.TileDownSlopeTopToHalf
});
TileData.DOWNSlopeHalfToZertData = TileData.DOWNSlopeData.extend({
	tileInfo : game.TileInfo.TileDownSlopeHalfToZero
});
TileData.UPSlopeLeftToZero = TileData.BlockData.extend({
	tileInfo : game.TileInfo.TileUpSlopeLeftToZero,
	checkOrigin : function(pos, nodeCtl){
		var ret = null;
		var offset = vee.Utils.pSub(pos, cc.p(this.left, this.bottom));

		if (offset.x > this.tileInfo.edgeBottom) {
			var checkPosY;
			if (offset.x > this.tileInfo.edgeTop) {
				checkPosY = this.bottom + TILE_WIDTH + nodeCtl.boxSize.height/2 - nodeCtl.boxOffset.y;
			} else {
				checkPosY = (offset.x - this.tileInfo.edgeBottom) * this.tileInfo.slope + (this.bottom + nodeCtl.boxSize.height/2 - nodeCtl.boxOffset.y);
			}
			if (nodeCtl.isJumping()) {
				if (checkPosY > pos.y) {
					if (nodeCtl._speedY < 0) {
						nodeCtl.setJumping(false);
						nodeCtl.downToBarrier(this);
					}
					ret = cc.p(pos.x, checkPosY);
				}
			} else {
				nodeCtl.downToBarrier(this);
				ret = cc.p(pos.x, checkPosY);
				game.Logic.calcSpeedScaleRate(nodeCtl, this.tileInfo);
			}
		}

		return ret;
	},
	checkTop : function(pos, nodeCtl){
		var ret = null;
		var offset = vee.Utils.pSub(pos, cc.p(this.left, this.bottom));

		if (offset.x > this.tileInfo.edgeBottom) {
			var checkPosY;
			if (offset.x > this.tileInfo.edgeTop) {
				checkPosY = this.bottom + TILE_WIDTH + nodeCtl.boxSize.width/2 - nodeCtl.boxOffset.y;
			} else {
				checkPosY = (offset.x - this.tileInfo.edgeBottom) * this.tileInfo.slope + (this.bottom + nodeCtl.boxSize.height/2 - nodeCtl.boxOffset.y);
			}
			if (nodeCtl.isJumping()) {
				if (nodeCtl._speedY < 0 && checkPosY > pos.y) {
					nodeCtl.setJumping(false);
					nodeCtl.downToBarrier(this);
					ret = cc.p(pos.x, checkPosY);
				}
			} else {
				nodeCtl.downToBarrier(this);
				ret = cc.p(pos.x, checkPosY);
				game.Logic.calcSpeedScaleRate(nodeCtl, this.tileInfo);
			}
		}

		return ret;
	},
	checkTopLeft : function(pos, nodeCtl){
		if (this.left - pos.x > game.Data.playerBottomEdgeWidth) return;
		return this.checkTop(pos, nodeCtl);
	},
	checkTopRight : function(pos, nodeCtl){
		if (pos.x - this.right > game.Data.playerBottomEdgeWidth) return;
		return this.checkTop(pos, nodeCtl);
	},
	checkLeft : function(pos, nodeCtl){
		var ret = null;
		var offset = vee.Utils.pSub(pos, cc.p(this.left, this.bottom));

		var checkPosX = offset.y * this.tileInfo.slope + this.tileInfo.edgeBottom + this.left;
		if (nodeCtl._speedX >= 0 && checkPosX < pos.x) {
			nodeCtl.rightToBarrier(this);
			ret = cc.p(checkPosX, pos.y);
			game.Logic.calcSpeedScaleRate(nodeCtl, this.tileInfo);
		}

		return ret;
	},
	checkBottom : function(pos, nodeCtl){
		var ret = null;
		var offset = vee.Utils.pSub(pos, cc.p(this.left, this.bottom));

		if (pos.x > this.left + this.tileInfo.edgeBottom) {
			var checkPosY = this.bottom - nodeCtl.boxSize.width/2 - nodeCtl.boxOffset.y;
			if (checkPosY < pos.y) {
				if (nodeCtl._speedY > 0) nodeCtl.upToBarrier(this);
				ret = cc.p(pos.x, checkPosY);
			}
		}

		return ret;
	},
	checkBottomLeft : function(pos, nodeCtl){
		return this.checkBottom(pos, nodeCtl);
	},
	checkBottomRight : function(pos, nodeCtl){
		var ret = null;

		if (pos.x < this.right + game.Data.playerTopEdgeWidth) {
			var checkPosY = this.bottom - nodeCtl.boxSize.width/2 - nodeCtl.boxOffset.y;
			if (checkPosY < pos.y) {
				if (nodeCtl._speedY > 0) nodeCtl.upToBarrier(this);
				ret = cc.p(pos.x, checkPosY);
			}
		}

		return ret;
	}
});
TileData.UPSlopeLeftToHalfData = TileData.UPSlopeLeftToZero.extend({
	tileInfo : game.TileInfo.TileUpSlopeLeftToHalf
});
TileData.DOWNSlopeRightToZeroData = TileData.BlockData.extend({
	tileInfo : game.TileInfo.TileDownSlopeRightToZero,
	checkOrigin : function(pos, nodeCtl){
		var ret = null;
		var offset = vee.Utils.pSub(pos, cc.p(this.left, this.bottom));

		if (offset.x < this.tileInfo.edgeBottom) {
			var checkPosY;
			if (offset.x < this.tileInfo.edgeTop) {
				checkPosY = this.bottom + TILE_WIDTH + nodeCtl.boxSize.width/2 - nodeCtl.boxOffset.y;
			} else {
				checkPosY = (offset.x - this.tileInfo.edgeTop) * this.tileInfo.slope + TILE_WIDTH + (this.bottom + nodeCtl.boxSize.height/2 - nodeCtl.boxOffset.y);
			}
			if (nodeCtl.isJumping()) {
				if (checkPosY > pos.y) {
					if (nodeCtl._speedY < 0) {
						nodeCtl.setJumping(false);
						nodeCtl.downToBarrier(this);
					}
					ret = cc.p(pos.x, checkPosY);
				}
			} else {
				nodeCtl.downToBarrier(this);
				ret = cc.p(pos.x, checkPosY);
				game.Logic.calcSpeedScaleRate(nodeCtl, this.tileInfo);
			}
		}

		return ret;
	},
	checkTop : function(pos, nodeCtl){
		var ret = null;
		var offset = vee.Utils.pSub(pos, cc.p(this.left, this.bottom));

		if (offset.x < this.tileInfo.edgeBottom) {
			var checkPosY;
			if (offset.x < this.tileInfo.edgeTop) {
				checkPosY = this.bottom + TILE_WIDTH + nodeCtl.boxSize.height/2 - nodeCtl.boxOffset.y;
			} else {
				checkPosY = (offset.x - this.tileInfo.edgeTop) * this.tileInfo.slope + TILE_WIDTH + (this.bottom + nodeCtl.boxSize.height/2 - nodeCtl.boxOffset.y);
			}
			if (nodeCtl.isJumping()) {
				if (nodeCtl._speedY < 0 && checkPosY > pos.y) {
					nodeCtl.setJumping(false);
					nodeCtl.downToBarrier(this);
					ret = cc.p(pos.x, checkPosY);
				}
			} else {
				nodeCtl.downToBarrier(this);
				ret = cc.p(pos.x, checkPosY);
				game.Logic.calcSpeedScaleRate(nodeCtl, this.tileInfo);
			}
		}

		return ret;
	},
	checkTopLeft : function(pos, nodeCtl){
		if (this.left - pos.x > game.Data.playerBottomEdgeWidth) return;
		return this.checkTop(pos, nodeCtl);
	},
	checkTopRight : function(pos, nodeCtl){
		if (pos.x - this.right > game.Data.playerBottomEdgeWidth) return;
		return this.checkTop(pos, nodeCtl);
	},
	checkRight : function(pos, nodeCtl){
		var ret = null;
		var offset = vee.Utils.pSub(pos, cc.p(this.left, this.bottom));

		var checkPosX = offset.y * this.tileInfo.slope + this.tileInfo.edgeBottom + this.left;
		if (nodeCtl._speedX <= 0 && checkPosX > pos.x) {
			nodeCtl.rightToBarrier(this);
			ret = cc.p(checkPosX, pos.y);
		}

		return ret;
	},
	checkBottom : function(pos, nodeCtl){
		var ret = null;

		if (pos.x < this.left + this.tileInfo.edgeBottom) {
			var checkPosY = this.bottom - nodeCtl.boxSize.height/2 - nodeCtl.boxOffset.y;
			if (checkPosY < pos.y) {
				if (nodeCtl._speedY > 0) nodeCtl.upToBarrier(this);
				ret = cc.p(pos.x, checkPosY);
			}
		}

		return ret;
	},
	checkBottomLeft : function(pos, nodeCtl){
		var ret = null;

		if (pos.x > this.left - game.Data.playerTopEdgeWidth) {
			var checkPosY = this.bottom - nodeCtl.boxSize.height/2 - nodeCtl.boxOffset.y;
			if (checkPosY < pos.y) {
				if (nodeCtl._speedY > 0) nodeCtl.upToBarrier(this);
				ret = cc.p(pos.x, checkPosY);
			}
		}

		return ret;
	},
	checkBottomRight : function(pos, nodeCtl){
		return this.checkBottom(pos, nodeCtl);
	}
});
TileData.DOWNSlopeRightToHalfData = TileData.DOWNSlopeRightToZeroData.extend({
	tileInfo : game.TileInfo.TileDownSlopeRightToHalf
});

TileData.BounceBlockData = TileData.BlockData.extend({
	tileInfo : game.TileInfo.TileBlockBounce,
	init : function () {
		this.tile = this.layer.getTileAt(this.grid);
	},

	/**
	 *
	 * @param pos
	 * @param nodeCtl {ElePlayer}
	 * @returns {*}
	 */
	checkOrigin : function(pos, nodeCtl){
		var ret = null;

		var checkPosY = this.tile.getPositionY() + this.tile.getScaleY()*TILE_WIDTH + nodeCtl.boxSize.height/2 - nodeCtl.boxOffset.y;
		if (nodeCtl.isJumping()) {
//			cc.log("zq debug bounce block check origin======1111111   ElePos==%d   checkPosy==%d   pos.y==%d", nodeCtl.getElePosition().y, checkPosY, pos.y);
			if (nodeCtl.getElePosition().y >= checkPosY && pos.y <= checkPosY || nodeCtl == game.Data.oPlayerCtl && nodeCtl.isSmashing() && nodeCtl.beginSmashPos.y >= checkPosY) {
//				cc.log("zq debug bounce block check origin======2222222");
				nodeCtl.setJumping(false);
				nodeCtl.downToBarrier(this);
				ret = cc.p(pos.x, checkPosY);
			}
		} else {
//			nodeCtl.downToBarrier(this);
//			ret = cc.p(pos.x, checkPosY);
//			game.Logic.calcSpeedScaleRate(nodeCtl, this.tileInfo);
// 			cc.log("zq debug bounce block check origin======333333");
		}

		return ret;
	},
	checkTop : function(pos, nodeCtl){
		var ret = null;

		var checkPosY = this.tile.getPositionY() + this.tile.getScaleY()*TILE_WIDTH + nodeCtl.boxSize.height/2 - nodeCtl.boxOffset.y;
		if (nodeCtl.isJumping()) {
			// cc.log("zq debug bounce block check origin======4444444");
			if (nodeCtl.getElePosition().y >= checkPosY && pos.y <= checkPosY || nodeCtl == game.Data.oPlayerCtl && nodeCtl.isSmashing() && nodeCtl.beginSmashPos.y >= checkPosY) {
				nodeCtl.setJumping(false);
				game.Logic.checkTileTrigger(this.grid, vee.Direction.Bottom, this, nodeCtl);
				nodeCtl.downToBarrier(this);
				ret = cc.p(pos.x, checkPosY);
			}
			else {
				// ret = pos;
				// cc.log("zq debug bounce block check origin======5555555");
			}
		} else {
			// cc.log("zq debug bounce block check origin======6666666");
			nodeCtl.downToBarrier(this);
			ret = cc.p(pos.x, checkPosY);
			game.Logic.calcSpeedScaleRate(nodeCtl, this.tileInfo);
		}

		return ret;
	},
	checkTopLeft : function(pos, nodeCtl){
		if (this.left - pos.x > game.Data.playerBottomEdgeWidth) return;
		return this.checkTop(pos, nodeCtl);
	},
	checkTopRight : function(pos, nodeCtl){
		if (pos.x - this.right > game.Data.playerBottomEdgeWidth) return;
		return this.checkTop(pos, nodeCtl);
	},
	checkLeft : function(pos, nodeCtl){return null;},
	checkRight : function(pos, nodeCtl){return null;},
	checkBottom : function(pos, nodeCtl){return null;},
	checkBottomLeft : function(pos, nodeCtl){return null;},
	checkBottomRight : function(pos, nodeCtl){return null;},
	collide : function (nodeCtl, dir) {
		if (nodeCtl._eleType == game.EleType.Player) {
//			nodeCtl._jumpCount = 0;
			nodeCtl.holdJump = true;
			nodeCtl._speedX = 0;
			nodeCtl._accX = 0;
			if (game.Data.isHoldJumpButtom || nodeCtl._isSmashing) {
				nodeCtl._speedY = 1600;
				nodeCtl._isJumpLimitY = false;
				nodeCtl.holdJump = false;
			} else if (this.shouldJump) {
				nodeCtl._speedY = 1020;
				nodeCtl._isJumpLimitY = false;
				game.Data.cameraRestoreY = true;
				nodeCtl.holdJump = false;
			}
			if (this.shouldJump || game.Data.isHoldJumpButtom) {
				if (game.Data.oLyGame._holdLeft) {
					nodeCtl.moveLeft();
				} else if (game.Data.oLyGame._holdRight) {
					nodeCtl.moveRight();
				} else if(game.Data.stageType == game.StageType.Parkour && game.Data.oPlayerCtl != null){
					game.Data.oPlayerCtl.parkourMove();
				}
			}
			this.shouldJump = false;
			if (this.isBouncing) return;

			this.isBouncing = true;
			var pos = game.Logic.getTilePosByGrid(this.grid);
			if (!this.tile) {
				var sprTile = this.layer.getTileAt(this.grid);
				this.tile = sprTile;
			}
			this.tile.stopAllActions();
			this.shouldJump = false;
			vee.Audio.playEffect(res.inGame_efx_spring_mp3);
			this.tile.runAction(cc.sequence(
				cc.spawn(
					cc.moveTo(0.15, cc.p(pos.x, pos.y + 6)),
					cc.scaleTo(0.15, 1, 0.5)
				),
				cc.delayTime(0.05),
				cc.callFunc(function () {
					this.shouldJump = true;
					nodeCtl.holdJump = false;
				}.bind(this)),
				cc.delayTime(0.05),
				cc.callFunc(function () {
					this.shouldJump = false;
				}.bind(this)),
				cc.spawn(
					cc.scaleTo(0.15, 1),
					cc.moveTo(0.15, pos)
				),
				cc.callFunc(function () {
					this.isBouncing = false;
				}.bind(this))
			));
		}
	}
});
TileData.BlockOneWayData = TileData.BounceBlockData.extend({
	tileInfo : game.TileInfo.TileBlockOneWay,
	collide : function (nodeCtl, dir) {}
});
TileData.BlockHurtData = TileData.BlockData.extend({
	tileInfo : game.TileInfo.TileBlockHurt,
	collide : function (nodeCtl, dir) {
		if (nodeCtl._eleType == game.EleType.Player) {
			if (game.Data.playerHawk || game.Data.playerInvisible && !nodeCtl._isSmashing) return;
			if (this.gid == 34) {
				if (dir == vee.Direction.Bottom && nodeCtl._grid.x == this.grid.x) {
					nodeCtl.getShock(vee.Direction.revert(nodeCtl._faceTo), true);
				}
			} else {
				nodeCtl.getShock(vee.Direction.revert(nodeCtl._faceTo), true);
			}
		} else if (nodeCtl._eleType == game.EleType.Enemy) {
			nodeCtl.dieEffect();
		}
	}
});
TileData.BlockHurtHalfData = TileData.BlockHurtData.extend({
	tileInfo : game.TileInfo.TileBlockHurtHalf
});
TileData.BlockHideData = TileData.BlockData.extend({
	tileInfo : game.TileInfo.TileBlockHide,
	init : function () {
		this.tile = this.layer.getTileAt(this.grid);
		this.tile.setVisible(false);
	},
	checkOriginPosY : function (boxSize, boxOff) {
		return this.top + boxSize.height/2 - boxOff.y;
	},
	checkOrigin : function(pos, nodeCtl){
		if (!this.tile.isVisible()) return;
		var ret = null;
		var offset = vee.Utils.pSub(pos, cc.p(this.left, this.bottom));

		var checkPosY = this.checkOriginPosY(nodeCtl.boxSize, nodeCtl.boxOffset);
		if (nodeCtl.isJumping()) {
			if (checkPosY > pos.y) {
				if (nodeCtl._speedY < 0) {
					nodeCtl.downToBarrier(this);
					nodeCtl.setJumping(false);
				}
				var forRet = cc.p(pos.x, checkPosY);
				var nextGrid = game.Logic.getTileGridByPos(forRet);
				if (nodeCtl._grid.y - nextGrid.y > 1) {
					ret = cc.p(pos.x, this.bottom - nodeCtl.boxSize.height/2 - nodeCtl.boxOffset.y);
				} else {
					ret = forRet;
				}
			}
		} else {
			nodeCtl.downToBarrier();
			ret = cc.p(pos.x, checkPosY);
			game.Logic.calcSpeedScaleRate(nodeCtl, this.tileInfo);
		}

		return ret;
	},
	checkTopPosY : function (boxSize, boxOff) {
		return this.top + boxSize.height/2 - boxOff.y;
	},
	checkTop : function(pos, nodeCtl){
		if (!this.tile.isVisible()) return;
		var ret = null;
		var checkPosY = this.checkTopPosY(nodeCtl.boxSize, nodeCtl.boxOffset);
		if (checkPosY > pos.y) {
			if (nodeCtl.isJumping()) {
				if (nodeCtl._speedY < 0) {
					game.Logic.checkTileTrigger(this.grid, vee.Direction.Bottom, this, nodeCtl);
					nodeCtl.downToBarrier(this);
					ret = cc.p(pos.x, checkPosY);
					nodeCtl.setJumping(false);
				}
			} else {
				nodeCtl.downToBarrier(this);
				ret = cc.p(pos.x, checkPosY);
				game.Logic.calcSpeedScaleRate(nodeCtl, this.tileInfo);
			}
		}

		return ret;
	},
	checkTopLeftPosY : function (boxSize, boxOff) {
		return this.top + boxSize.height/2 - boxOff.y;
	},
	checkTopLeft : function(pos, nodeCtl){
		if (!this.tile.isVisible()) return;
		if (this.left - pos.x > game.Data.playerBottomEdgeWidth && !nodeCtl.isJumping()) return null;
		var ret = null;

		var checkPosY = this.checkTopLeftPosY(nodeCtl.boxSize, nodeCtl.boxOffset);
		if (checkPosY > pos.y) {
			var checkPosX = this.left - nodeCtl.boxSize.width/2;
			if (checkPosX < pos.x) {
				if (nodeCtl.getElePosition().y >= checkPosY && nodeCtl._speedY < 0) {
					game.Logic.checkTileTrigger(this.grid, vee.Direction.Bottom, this, nodeCtl);
					nodeCtl.downToBarrier(this);
					ret = cc.p(pos.x, checkPosY);
					nodeCtl.setJumping(false);
				} else {
					if (nodeCtl._speedX > 0) {
						game.Logic.checkTileTrigger(this.grid, vee.Direction.Bottom, this, nodeCtl);
						nodeCtl.rightToBarrier(this);
					}
					// Push player!
					var pushOffset = pos.x - checkPosX;
					if (pushOffset > 8) pushOffset = 8;
					ret = cc.p(pos.x - pushOffset, pos.y);
				}
			}
		}

		return ret;
	},
	checkTopRightPosY : function (boxSize, boxOff) {
		return this.top + boxSize.height/2 - boxOff.y;
	},
	checkTopRight : function(pos, nodeCtl) {
		if (!this.tile.isVisible()) return;
		if (pos.x - this.right > game.Data.playerBottomEdgeWidth && !nodeCtl.isJumping()) return null;
		var ret = null;
		var offset = vee.Utils.pSub(pos, cc.p(this.left, this.bottom));

		var checkPosY = this.checkTopRightPosY(nodeCtl.boxSize, nodeCtl.boxOffset);
		if (checkPosY > pos.y) {
			var checkPosX = this.right + nodeCtl.boxSize.width/2;
			if (checkPosX > pos.x) {
				if (nodeCtl.getElePosition().y >= checkPosY && nodeCtl._speedY < 0) {
					game.Logic.checkTileTrigger(this.grid, vee.Direction.Bottom, this, nodeCtl);
					nodeCtl.downToBarrier(this);
					ret = cc.p(pos.x, checkPosY);
					nodeCtl.setJumping(false);
				} else {
					if (nodeCtl._speedX < 0) {
						game.Logic.checkTileTrigger(this.grid, vee.Direction.Bottom, this, nodeCtl);
						nodeCtl.leftToBarrier(this);
					}
					// Push player!
					var pushOffset = checkPosX - pos.x;
					if (pushOffset > 8) pushOffset = 8;
					ret = cc.p(pos.x+pushOffset, pos.y);
				}
			}
		}

		return ret;
	},
	checkLeft : function(pos, nodeCtl){
		if (!this.tile.isVisible()) return;
		var ret = null;
		if (pos.y < this.top + nodeCtl.boxSize.height/2) {
			var checkPosX = this.left - nodeCtl.boxSize.width/2;
			if (checkPosX < pos.x) {
				game.Logic.checkTileTrigger(this.grid, vee.Direction.Right, this, nodeCtl);
				nodeCtl.rightToBarrier(this);
				// Push player
				var pushOffset = pos.x - checkPosX;
				if (pushOffset > 8) pushOffset = 8;
				ret = cc.p(pos.x-pushOffset, pos.y);
			}
		}

		return ret;
	},
	checkRight : function(pos, nodeCtl){
		if (!this.tile.isVisible()) return;
		var ret = null;
		if (pos.y < this.top + nodeCtl.boxSize.height/2) {
			var checkPosX = this.right + nodeCtl.boxSize.width/2;
			if (checkPosX > pos.x) {
				game.Logic.checkTileTrigger(this.grid, vee.Direction.Left, this, nodeCtl);
				nodeCtl.leftToBarrier(this);
				// Push player
				var pushOffset = checkPosX - pos.x;
				if (pushOffset > 8) pushOffset = 8;
				ret = cc.p(pos.x+pushOffset, pos.y);
			}
		}

		return ret;
	},
	checkBottom : function(pos, nodeCtl){
		var ret = null;
		var checkPosY = this.bottom - nodeCtl.boxSize.height/2 - nodeCtl.boxOffset.y;
		if (checkPosY < pos.y) {
			game.Logic.checkTileTrigger(this.grid, vee.Direction.Top, this, nodeCtl);
			if (nodeCtl._speedY > 0) {
				if (!this.tile.isVisible()) {
					this.tile.setVisible(true);
					EfxHideBlockIn.show(cc.p(this.left+TILE_WIDTH_HALF, this.bottom+TILE_WIDTH_HALF));
				}
				nodeCtl.upToBarrier(this);
			}
			ret = cc.p(pos.x, checkPosY);
		}

		return ret;
	},
	checkBottomLeft : function(pos, nodeCtl){
		var checkEdgeWidth;
		if (this.tile.isVisible()) checkEdgeWidth = game.Data.playerTopEdgeWidth;
		else checkEdgeWidth = game.Data.dynamicBlockTopEdgeWidth;
		if (this.left - pos.x < checkEdgeWidth) {
			return this.checkBottom(pos, nodeCtl);
		}
	},
	checkBottomRight : function(pos, nodeCtl){
		var checkEdgeWidth;
		if (this.tile.isVisible()) checkEdgeWidth = game.Data.playerTopEdgeWidth;
		else checkEdgeWidth = game.Data.dynamicBlockTopEdgeWidth;
		if (pos.x - this.right < checkEdgeWidth) {
			return this.checkBottom(pos, nodeCtl)
		}
	}
});
TileData.DynamicBlockData = TileData.BlockData.extend({
	checkBottomLeft : function(pos, nodeCtl){
		if (this.left - pos.x < game.Data.dynamicBlockTopEdgeWidth) {
			return this.checkBottom(pos, nodeCtl);
		}
	},
	checkBottomRight : function(pos, nodeCtl){
		if (pos.x - this.right < game.Data.dynamicBlockTopEdgeWidth) {
			return this.checkBottom(pos, nodeCtl)
		}
	}
});
TileData.BlockFadeData = TileData.BlockOneWayData.extend({
	tileInfo : game.TileInfo.TileBlockHide,
	init : function () {
		this.tile = this.layer.getTileAt(this.grid);
	},
	collide : function (nodeCtl, dir) {
		if (nodeCtl._eleType == game.EleType.Player && dir == vee.Direction.Bottom && !this._isFading) {
			this._isFading = true;
			vee.Audio.playEffect(res.inGame_efx_bubbleVanish_mp3);
			this.tile.runAction(cc.sequence(
				cc.spawn(
					cc.sequence(
						cc.delayTime(0.5),
						cc.callFunc(function(){
							this.check = false;
						}.bind(this))
					),
					cc.sequence(
						cc.rotateTo(0.1, -4),
						cc.rotateTo(0.1, 3),
						cc.rotateTo(0.1, -2),
						cc.rotateTo(0.1, 2),
						cc.rotateTo(0.1, 0),
						cc.moveBy(0.2, cc.p(0,-30))
					),
					cc.fadeTo(0.7, 0)
				),
				cc.delayTime(1),
				cc.moveBy(0.01, cc.p(0,30)),
				cc.fadeTo(0.2, 255),
				cc.callFunc(function () {
					this._isFading = false;
					this.check = true;
				}.bind(this))
			));
		}
	}
});
TileData.BlockBombData = TileData.BlockData.extend({
	tileInfo : game.TileInfo.TileBlockBomb,
	bombEfx : null,
	isPlayerBomb : false,
	collide : function (nodeCtl, dir, forceTrigger){
		if (this.bombEfx && (this.bombEfx.boomed || this.bombEfx.isStatic)) return;
		var trigger = false;
		if (nodeCtl) {
			if (nodeCtl._eleType == game.EleType.Player) {
				if ((dir == vee.Direction.Bottom && nodeCtl.isSmashing())
					|| (dir == vee.Direction.Top && nodeCtl._speedY > game.Data.playerYTriggerSpeed))
				{
					trigger = true;
				}
			} else if (nodeCtl._eleType == game.EleType.Enemy) {
				if ((dir == vee.Direction.Left || dir == vee.Direction.Right) && nodeCtl.isDashing()) {
					trigger = true;
				}
			} else if (nodeCtl._type == game.ObjectType.Bullet) {
				trigger = true;
			}
		}

		if (trigger || forceTrigger) {
			var off = vee.Direction.direction2Point(dir);
			var nextGrid = vee.Utils.pAdd(this.grid, cc.p(off.x, off.y));
			var targetGrid = cc.p(nextGrid.x, nextGrid.y);
			var oPlayer = game.Data.oPlayerCtl;
//			if (game.Logic.isGridSame(oPlayer._grid, nextGrid)) {
//				var playerNewGrid = null;
//				if (off.x < 0) { // left
//					playerNewGrid = cc.p(oPlayer._grid.x-1, oPlayer._grid.y);
//				} else { // right
//					playerNewGrid = cc.p(oPlayer._grid.x+1, oPlayer._grid.y);
//				}
//				oPlayer.setElePosition(game.Logic.getTilePosByGrid(playerNewGrid));
//			}
			// should move and boom
			if (!this.bombEfx) {
				if (this.isPlayerBomb) {
					this.bombEfx = EfxPlayerTNT.create(game.Logic.getTilePosCenterByGrid(this.grid));
					this.bombEfx.bornAnimate();
				} else this.bombEfx = EfxTNT.create(game.Logic.getTilePosCenterByGrid(this.grid));
			}
			var nextObj = game.Logic.map.getObject(nextGrid);
//			if (this.layer.getTileGIDAt(nextGrid) == 0 && !this.isPlayerBomb && !game.Logic.isGridSame(nextGrid, oPlayer._grid)) {
			if (((nextObj && nextObj.gid == 0) || !nextObj) && !this.isPlayerBomb && !game.Logic.isGridSame(nextGrid, oPlayer._grid)) {
				// 1. create new tile
				this.layer.setTileGID(this.gid, nextGrid);
				var newTd = game.Logic.getTileData(nextGrid, this.layer);
				game.Logic.map.setObject(newTd, nextGrid);
				var newTile = this.layer.getTileAt(nextGrid);

				// 2. show efx
				newTd.bombEfx = this.bombEfx;
				if (this.isPlayerBomb) {
					newTd.isPlayerBomb = true;
					newTile.setVisible(false);
					newTd.bombEfx.breathAnimate();
					newTd.bombEfx._container.runAction(cc.sequence(
						cc.EaseExponentialOut.create(cc.moveTo(0.3, game.Logic.getTilePosCenterByGrid(nextGrid))),
						cc.callFunc(function () {
							newTd.bombEfx.boomAnimate();
						})
					));
				} else {
					newTile.setPosition(game.Logic.getTilePosByGrid(this.grid));
					var newPos = vee.Utils.pAdd(newTile.getPosition(), cc.p(off.x*TILE_WIDTH, -off.y*TILE_WIDTH));
					newTile.runAction(cc.sequence(
						cc.EaseExponentialOut.create(cc.moveTo(0.3, newPos)),
						cc.callFunc(function () {
							newTile.setVisible(false);
							this.bombEfx._container.setPosition(vee.Utils.pAdd(newPos, cc.p(TILE_WIDTH_HALF, TILE_WIDTH_HALF)));
							this.bombEfx.boomAnimate();
						}.bind(this))
					));
				}

				// 3. remove old tile
				this.layer.removeTileAt(this.grid);
				game.Logic.map.removeObject(this.grid);
				vee.Audio.playEffect(res.inGame_efx_bombCount_mp3);
				EfxHitBlock.create(game.Logic.getTilePosCenterByGrid(nextGrid), vee.Direction.revert(dir));
				if (this.layer.isExtra) {
					if (nextGrid.x < this.layer.originX) this.layer.originX = nextGrid.x;
					else if (nextGrid.x > this.layer.maxX) this.layer.maxX = nextGrid.x;
					if (nextGrid.y < this.layer.originY) this.layer.originY = nextGrid.y;
					else if (nextGrid.y > this.layer.maxY) this.layer.maxY = nextGrid.y;
				}
				runAct = true;
			} else {
				// just...boooom!
				if (this.isBooming) {
//					this.bombEfx.boomAnimate(true);
					return;
				}
				this.isBooming = true;
				if (!this.bombEfx.isStatic) {
					targetGrid = cc.p(this.grid.x, this.grid.y);
					if (!this.tile) {
						var sprTile = this.layer.getTileAt(this.grid);
						this.tile = sprTile;
					}
					this.tile.setVisible(false);
					this.bombEfx.boomAnimate();
				}
			}

			var boomFunc = function () {
				var dur = 0.02;
				var amplitudeY = 5;
				game.Data.oLyGame.rootNode.runAction(cc.Sequence.create(
					cc.MoveBy.create(dur, 0, -amplitudeY),
					cc.MoveBy.create(dur, 0, amplitudeY*2),
					cc.MoveBy.create(dur, 0, -amplitudeY),
					cc.MoveBy.create(dur, 0, amplitudeY),
					cc.MoveBy.create(dur, 0, -amplitudeY*2),
					cc.MoveBy.create(dur, 0, amplitudeY)
				));

				var gridTL = cc.p(targetGrid.x-1, targetGrid.y-1);
				var gridForCheck = null;
				for (var x = 0; x < 3; ++x) {
					for (var y = 0; y < 3; ++y) {
						gridForCheck = cc.p(gridTL.x+x, gridTL.y+y);
						var tdForCheck = game.Logic.map.getObject(gridForCheck);
						if (tdForCheck) {
							game.Logic.checkTileTrigger(gridForCheck, vee.Direction.pointToDirection(cc.p(x-1,y-1)), tdForCheck, nodeCtl, true);
							if (game.Logic.isBreakableBlock(tdForCheck.gid)
							|| tdForCheck.gid == game.BlockType.BombBlock
							|| tdForCheck.gid == game.BlockType.SkillSmash
							|| tdForCheck.gid == game.BlockType.SkillBullet
							|| tdForCheck.gid == game.BlockType.SkillTeleport
							|| tdForCheck.gid == game.BlockType.SkillBomb
							|| tdForCheck.gid == game.BlockType.QuestionBlock
							) {
								tdForCheck.collide(null, null, true);
							}
						}
						if (x == 1 && y == 1) {
							var gid, layer;
							if (this.tempData) {
								gid = this.tempData.gid;
								layer = this.tempData.layer;
							}
							this.layer.removeTileAt(gridForCheck);
							game.Logic.map.removeObject(gridForCheck);
							if (this.tempData) {
								layer.setTileGID(gid, gridForCheck);
								var td = game.Logic.getTileData(gridForCheck, layer);
								game.Logic.map.setObject(td, gridForCheck);
								var tile = layer.getTileAt(gridForCheck);
								if (!this.tempData.tileInfo.slope && (this.tempData.tileInfo.type != game.ObjectType.BlockOneWay && this.tempData.tileInfo.type != game.ObjectType.BlockBounce)) {
									tile.setVisible(false);
								}
							}
						}
					}
				}
				var gridTLPos = game.Logic.getTilePosByGrid(gridTL);
				gridTLPos.y -= TILE_WIDTH*2;
				var rectBoom = cc.rect(gridTLPos.x, gridTLPos.y, TILE_WIDTH*3, TILE_WIDTH*3);
				var objs = game.Logic.dynamicObjMap.getObjects();
				for (var i in objs) {
					var obj = objs[i];
					if (obj && obj._eleType == game.EleType.Enemy && cc.rectContainsPoint(rectBoom, obj.getElePosition())) {
						obj.hitByStar();
					}
				}
			}.bind(this);

			this.bombEfx.setBoomFunc(boomFunc);
		}
	}
});
TileData.BlockBreakableData = TileData.BlockData.extend({
	tileInfo : game.TileInfo.TileBlockBreakable,
	collide : function (nodeCtl, dir, force) {
		if (this.removed) return;
		var isHit = false;
		if (force) {
			isHit = true;
		} else {
			switch (dir) {
				case vee.Direction.Top:
				case vee.Direction.TopLeft:
				case vee.Direction.TopRight:
					if (nodeCtl._speedY > game.Data.playerYTriggerSpeed) {
						isHit = true;
					}
					break;
				case vee.Direction.Bottom:
				case vee.Direction.BottomLeft:
				case vee.Direction.BottomRight:
					if (nodeCtl._isSmashing){
						isHit = true;
					}
					break;
				case vee.Direction.Left:
					if (nodeCtl.isDashing()) {
						isHit = true;
					}
					break;
				case vee.Direction.Right:
					if (nodeCtl.isDashing()) {
						isHit = true;
					}
					break;
				default:
					break;
			}
		}

		if (isHit) {
			vee.Audio.playEffect("res/inGame_efx_blockBreak_"+vee.Utils.randomInt(1,4)+".mp3");
			vee.Audio.playEffect(res.inGame_efx_blockBreak_mp3);
			this.removed = true;
			var gid = this.layer.getTileGIDAt(this.grid);
			this.layer.removeTileAt(this.grid);
			game.Logic.map.removeObject(this.grid);
			if (game.Logic._tmxLayerGrass) game.Logic._tmxLayerGrass.removeTileAt(this.grid);
			EfxBlockBreak.show(game.Logic.getTilePosCenterByGrid(this.grid), null);
			this.afterCollide(gid);
			if (nodeCtl) {
				var nodeX = nodeCtl._pos.x;
				var td = null;
				var triggerGrid = null;
				if (nodeX < this.left + 20) {
					td = game.Logic.map.getObject(cc.p(this.grid.x-1, this.grid.y));
					triggerGrid = cc.p(this.grid.x-1, this.grid.y);
				} else if (nodeX > this.right - 20) {
					td = game.Logic.map.getObject(cc.p(this.grid.x+1, this.grid.y));
					triggerGrid = cc.p(this.grid.x+1, this.grid.y);
				}
				if (td && game.Logic.isBreakableBlock(td.gid)) {
					td.collide(nodeCtl, dir, force);
					game.Logic.checkTileTrigger(triggerGrid, dir, td, nodeCtl);
				}
			}
		}
	},

	afterCollide : function () {

	}
});
TileData.BlockSinkData = TileData.BlockData.extend({
	tileInfo : game.TileInfo.TileBlockSink,
	_speedLimit : 5,
	_shouldBlockBottom : true,
	spSink1 : null,
	spSink2 : null,
	init : function () {
		var BottomTileGID = this.layer.getTileGIDAt(cc.p(this.grid.x, this.grid.y+1));
		if (BottomTileGID == this.gid) {
			this._shouldBlockBottom = false;
		}
		// add sink effect
		var posCenter = cc.p(this.left + TILE_WIDTH_HALF, this.bottom + TILE_WIDTH_HALF);
		var startPos = vee.Utils.pAdd(posCenter, cc.p(0,25));
		var endPos = vee.Utils.pAdd(posCenter, cc.p(0,-25));

		if (TileData.BlockSinkDataEfxPool.length > 0) {
			this.spSink1 = TileData.BlockSinkDataEfxPool.shift();
		} else {
			this.spSink1 = new cc.Sprite(res.efx_arrow_png);
			game.Data.oLyGame.lyMap.addChild(this.spSink1, 102);
		}
		this.spSink1.setPosition(startPos);
		this.spSink1.setOpacity(30);
		this.spSink1.setScaleY(0);
		this.spSink1.runAction(cc.repeat(
			cc.sequence(
				cc.moveTo(0, startPos),
				cc.fadeTo(0, 25),
				cc.scaleTo(0, 1, 0),
				cc.spawn(
					cc.moveTo(2, endPos),
					cc.scaleTo(2, 1, 1),
					cc.fadeTo(2, 0)
				)
			),
			9999)
		);

		if (TileData.BlockSinkDataEfxPool.length > 0) {
			this.spSink2 = TileData.BlockSinkDataEfxPool.shift();
		} else {
			this.spSink2 = new cc.Sprite(res.efx_arrow_png);
			game.Data.oLyGame.lyMap.addChild(this.spSink2, 102);
		}
		this.spSink2.setPosition(posCenter);
		this.spSink2.setOpacity(15);
		this.spSink2.setScaleY(0.5);
		this.spSink2.runAction(cc.repeat(
			cc.sequence(
				cc.spawn(
					cc.moveTo(1, endPos),
					cc.scaleTo(1, 1, 1),
					cc.fadeTo(1, 0)
				),
				cc.moveTo(0, startPos),
				cc.fadeTo(0, 25),
				cc.scaleTo(0, 1, 0),
				cc.spawn(
					cc.moveTo(1, posCenter),
					cc.scaleTo(1, 1, 0.5),
					cc.fadeTo(1, 15)
				)
			),
			9999)
		);
	},
	viewOut : function () {
//		TileData.BlockSinkDataEfxPool.push(this.spSink1);
//		TileData.BlockSinkDataEfxPool.push(this.spSink2);
	},
	sink : function (pos, checkPosY, nodeCtl) {
        if (nodeCtl._eleType == game.EleType.Player && nodeCtl._moveState == MoveState.Bounce) {
        nodeCtl._isBounce = false;
        nodeCtl.setMoveState(MoveState.Breath);
        }
		if (checkPosY > pos.y) {
			if (nodeCtl._eleType == game.EleType.Player) {
				nodeCtl._jumpCount = 1;
				nodeCtl.resetJumpCount = false;
				nodeCtl.stopJumpCounter();
//				nodeCtl.rootNode.setScaleY(1);
//				nodeCtl.rootNode.setPosition(cc.p(0, 0));
			}
			if (Math.abs(nodeCtl._speedX) > this._speedLimit) {
				nodeCtl._speedX = nodeCtl.getFaceToNumber()*this._speedLimit;
			}
			if (nodeCtl._speedY < -this._speedLimit) nodeCtl._speedY = -this._speedLimit;
			else if (nodeCtl._speedY > 300) nodeCtl._speedY = 300;
		}
	},
	checkOriginPosY : function (boxSize, boxOff) {
		return this.bottom + this.tileInfo.edgeLeft + boxSize.height/2 - boxOff.y;
	},
	checkOrigin : function(pos, nodeCtl){
		var checkPosY = this.checkOriginPosY(nodeCtl.boxSize, nodeCtl.boxOffset);
		this.sink(pos, checkPosY, nodeCtl);
	},
	checkTopPosY : function (boxSize, boxOff) {
		return this.bottom + this.tileInfo.edgeLeft + boxSize.height/2 - boxOff.y;
	},
	checkTop : function(pos, nodeCtl){
		var checkPosY = this.checkTopPosY(nodeCtl.boxSize, nodeCtl.boxOffset);
		this.sink(pos, checkPosY, nodeCtl);
	},
	checkTopLeftPosY : function (boxSize, boxOff) {
		return this.bottom + this.tileInfo.edgeLeft + boxSize.height/2 - boxOff.y;
	},
	checkTopLeft : function(pos, nodeCtl){
		if (this.left - pos.x > game.Data.playerBottomEdgeWidth) return null;// && !nodeCtl.isJumping()
		var checkPosY = this.checkTopLeftPosY(nodeCtl.boxSize, nodeCtl.boxOffset);
		this.sink(pos, checkPosY, nodeCtl);
	},
	checkTopRightPosY : function (boxSize, boxOff) {
		return this.bottom + this.tileInfo.edgeLeft + boxSize.height/2 - boxOff.y;
	},
	checkTopRight : function(pos, nodeCtl){
		if (pos.x - this.right > game.Data.playerBottomEdgeWidth && !nodeCtl.isJumping()) return null;
		var checkPosY = this.checkTopRightPosY(nodeCtl.boxSize, nodeCtl.boxOffset);
		this.sink(pos, checkPosY, nodeCtl);
	},
	checkLeft : function(pos, nodeCtl){},
	checkRight : function(pos, nodeCtl){},
	checkBottom : function(pos, nodeCtl){
		var ret = null;
		if (this._shouldBlockBottom) {
			var checkPosY = this.bottom - nodeCtl.boxSize.height/2 - nodeCtl.boxOffset.y;
			if (checkPosY < pos.y && nodeCtl._speedY > 0) {
				game.Logic.checkTileTrigger(this.grid, vee.Direction.Top, this, nodeCtl);
				if (nodeCtl._speedY > 0) nodeCtl.upToBarrier(this);
				ret = cc.p(pos.x, checkPosY);
			}
		}
		return ret;
	},
	checkBottomLeft : function(pos, nodeCtl){
		if (this.left - pos.x < game.Data.playerTopEdgeWidth) {
			return this.checkBottom(pos, nodeCtl);
		}
	},
	checkBottomRight : function(pos, nodeCtl){
		if (pos.x - this.right < game.Data.playerTopEdgeWidth) {
			return this.checkBottom(pos, nodeCtl)
		}
	}
});
TileData.BlockSinkDataEfxPool = [];
TileData.BlockTrapData = TileData.BlockData.extend({
	tileInfo : game.TileInfo.TileBlockTrap,
	trapCtl : null,
	trapped : false,

	init : function () {
		var node = cc.BuilderReader.load(res.eleTrap_ccbi);
		node.setPosition(cc.p(this.left + TILE_WIDTH_HALF, this.bottom + TILE_WIDTH_HALF));
		game.Data.oLyGame.lyMapBack.addChild(node, 1);
		node.controller.ccbInit();
		node.controller.grid = cc.p(this.grid.x, this.grid.y-1);
		this.trapCtl = node.controller;
		node.controller.trapBlockData = this;
	},
	collide : function (nodeCtl, dir) {
		if (!this.trapped && dir == vee.Direction.Bottom) {
			this.trapped = true;
			this.trapCtl.attack();
		}
	}
});
TileData.BlockSmashData = TileData.BlockBreakableData.extend({
	tileInfo : game.TileInfo.TileBlockBreakable,
	skillObjType : game.ObjectType.BoxSmash,
	skillType : game.PlayerType.Smash,

	afterCollide : function (gid) {
		if (gid == 66) {
			// removed not add item
			return;
		}
		var item = Item.createWithInfo({type : this.skillObjType});
		if (item) {
			// show item
			var pos = game.Logic.getTilePosByGrid(this.grid);
			item.controller.initPosition(cc.p(pos.x + TILE_WIDTH/2, pos.y + TILE_WIDTH/2));
			item.controller._layerBelong = this.layer;
			game.Logic.objMap.setObject(item.controller, this.grid);
			item.controller.setGridInMap(this.grid);
//			game.Data.refreshSkillBoxes(this.skillType);
		}
	}
});
TileData.BlockBulletData = TileData.BlockSmashData.extend({
	tileInfo : game.TileInfo.TileBlockBreakable,
	skillObjType : game.ObjectType.BoxBullet,
	skillType : game.PlayerType.Bullet
});
TileData.BlockTeleportData = TileData.BlockSmashData.extend({
	tileInfo : game.TileInfo.TileBlockBreakable,
	skillObjType : game.ObjectType.BoxTeleport,
	skillType : game.PlayerType.Teleport
});
TileData.BlockSkillBombData = TileData.BlockSmashData.extend({
	tileInfo : game.TileInfo.TileBlockBreakable,
	skillObjType : game.ObjectType.BoxBomb,
	skillType : game.PlayerType.Bomb
});
TileData.BlockHawkData = TileData.BlockSmashData.extend({
	tileInfo : game.TileInfo.TileBlockBreakable,
	skillObjType : game.ObjectType.BoxHawk,
	skillType : game.PlayerType.Hawk
});

TileData.BlockScaleData = TileData.BlockData.extend({
	tileInfo : game.TileInfo.TileBlockScale,
	_isScaleUp : false,
	_scaleDir : null,
	_lastScaleDir : null,
	_isAnimating : false,

	parentBlock : null,
	childBlocks : null,


	FINAL_TILEID_BASE :         141,
	FINAL_TILEID_TOPLEFT :      142,
	FINAL_TILEID_TOPRIGHT :     143,
	FINAL_TILEID_BOTTOMLEFT :   144,
	FINAL_TILEID_BOTTOMRIGHT :  145,

	_isStopCamera : false,

	init : function()
	{
//		cc.log("block scale data viewIn-------------" + this.grid);
		var obj = game.Logic.configMap.getObject(this.grid);
		if(obj){
			var initDir = parseInt(obj.name);
			this._scaleDir = initDir;
			this.scaleUp(null, initDir);
		}
	},

	collide : function (nodeCtl, dir)
	{
		if (this._isAnimating) return;
		switch (dir) {
			case vee.Direction.Top: {
				if(game.Data.oPlayerCtl._faceTo == vee.Direction.Right){
					this._scaleDir = vee.Direction.TopRight;
				}
				else{
					this._scaleDir = vee.Direction.TopLeft;
				}
				this.scaleBlock(nodeCtl._pos, this._scaleDir);
			}
				break;
			case vee.Direction.Bottom: {
				if (nodeCtl._eleType == game.EleType.Player && nodeCtl.isSmashing()) {

					if(game.Data.oPlayerCtl._faceTo == vee.Direction.Right){
						this._scaleDir = vee.Direction.BottomRight;
					}
					else{
						this._scaleDir = vee.Direction.BottomLeft;
					}
					if(game.Data.isEnableCameraYOff){
						this._isStopCamera = true;
					}

					this.scaleBlock(nodeCtl._pos, this._scaleDir);
				}
			}
				break;
			case vee.Direction.Right: {
				if (nodeCtl.isDashing()) {
					this._scaleDir = vee.Direction.TopRight;
					this.scaleBlock(nodeCtl._pos, this._scaleDir);
				}
			}
				break;
			case vee.Direction.Left: {
				if (nodeCtl.isDashing()) {
					this._scaleDir = vee.Direction.TopLeft;
					this.scaleBlock(nodeCtl._pos, this._scaleDir);
				}
			}
				break;
		}
	},



	checkUpByDir : function(dir){

		//获取周围地图块数据
		var right = game.Logic.getTileDataByDir(this.grid, vee.Direction.Right);
		var rightTop = game.Logic.getTileDataByDir(this.grid, vee.Direction.TopRight);
		var top = game.Logic.getTileDataByDir(this.grid, vee.Direction.Top);
		var left = game.Logic.getTileDataByDir(this.grid, vee.Direction.Left);
		var leftTop = game.Logic.getTileDataByDir(this.grid, vee.Direction.TopLeft);
		var bottom = game.Logic.getTileDataByDir(this.grid, vee.Direction.Bottom);
		var rightBottom = game.Logic.getTileDataByDir(this.grid, vee.Direction.BottomRight);
		var leftBottom = game.Logic.getTileDataByDir(this.grid, vee.Direction.BottomLeft);

		switch(dir) {
			case vee.Direction.TopLeft :  //往左上扩张
			{
				if(top || left || leftTop){
					return false;
				}
				break;
			}
			case vee.Direction.TopRight :
			{
				if(top || right || rightTop){
					return false;
				}
				break;
			}
			case vee.Direction.BottomRight :
			{
				if(bottom || right || rightBottom){
					return false;
				}
				break;
			}
			case vee.Direction.BottomLeft :
			{
				if(bottom || left || leftBottom){
					return false;
				}
				break;
			}
			default :
				return false;
		}

		return true;
	},

	scaleBlock : function (pos, dir)
	{
		if (!this._isScaleUp)
			this.scaleUp(pos, dir);
		else
			this.scaleDown(pos, dir);
	},


	// aux funcs...
	scaleUp : function (pos, dir)
	{
		if(this.checkUpByDir(dir)){
			this._isScaleUp = true;
			this._isAnimating = true;
			this._lastScaleDir = dir;

			this.layer.setTileGID(0, this.grid);

			ItemScaleBlock.show(this.grid, dir, true, this.createBlocks.bind(this));
		}
		else{
//			cc.log("grid===x=%d  y=%d", this.grid.x, this.grid.y);
//			vee.Utils.logObj(dir, "zq debug checkUpByDir can not scale up dir====");
		}
	},

	scaleDown : function (pos, dir)
	{

//		if(this._isStopCamera){
//			game.Data.isEnableCameraYOff = false;
//		}

		this._isScaleUp = false;
		if (this.parentBlock) {
			if(this._isStopCamera){
				this.parentBlock._isStopCamera = true;
				game.Data.isEnableCameraYOff = false;
			}
			this.parentBlock.scaleDown(pos, dir);
			return;
		}

		this.layer.setTileGID(0, this.grid);

		for (var idx in this.childBlocks)
		{
			var td = this.childBlocks[idx];
			this.layer.setTileGID(0, td.grid);
			game.Logic.map.removeObject(td.grid);
		}
		this.childBlocks = [];



		ItemScaleBlock.show(this.grid, this._lastScaleDir, false, function(){
			this.layer.setTileGID(this.FINAL_TILEID_BASE, this.grid);
			this.gid = this.FINAL_TILEID_BASE;
			cc.log("start update======" + this._isStopCamera);
			if(this._isStopCamera){
				this._isStopCamera = false;
				game.Data.isEnableCameraYOff = true;
			}
		}.bind(this));
	},

	createBlocks : function ()
	{

		this.childBlocks = [];
		this._isAnimating = false;
		var dirPoint = vee.Direction.direction2Point(this._scaleDir);

		var newGid = this.getBaseBlockScaleUpGid();
//		cc.log("new gid=======%d", newGid);
		this.layer.setTileGID(newGid, this.grid);
		this.gid = newGid;

		var firstGrid = cc.p(this.grid.x + dirPoint.x, this.grid.y);
		var td1 = this.createChildBlocks(firstGrid);
		this.childBlocks.push(td1);

		var secondGrid = cc.p(this.grid.x, this.grid.y + dirPoint.y);
		var td2 = this.createChildBlocks(secondGrid);
		this.childBlocks.push(td2);

		var thirdGrid = vee.Utils.pAdd(this.grid, dirPoint);
		var td3 = this.createChildBlocks(thirdGrid);
		this.childBlocks.push(td3);
	},

	getBaseBlockScaleUpGid : function(){
		switch (this._scaleDir){
			case vee.Direction.TopRight:
				return this.FINAL_TILEID_BOTTOMLEFT;
			case vee.Direction.TopLeft:
				return this.FINAL_TILEID_BOTTOMRIGHT;
			case vee.Direction.BottomRight:
				return this.FINAL_TILEID_TOPLEFT;
			case vee.Direction.BottomLeft:
				return this.FINAL_TILEID_TOPRIGHT;
		}
	},

	getNewGidByGrid : function(grid){
		var dirPoint = vee.Utils.pSub(grid, this.grid);
		var dir = vee.Direction.pointToDirection(dirPoint);
		var gid = 0;

//
		if(this.gid == this.FINAL_TILEID_TOPLEFT){
			if(dir == vee.Direction.Right){
				gid = this.FINAL_TILEID_TOPRIGHT;
			}
			else if(dir == vee.Direction.Bottom){
				gid = this.FINAL_TILEID_BOTTOMLEFT;
			}
			else{
				gid = this.FINAL_TILEID_BOTTOMRIGHT;
			}
		}

		else if(this.gid == this.FINAL_TILEID_TOPRIGHT){
			if(dir == vee.Direction.Left){
				gid = this.FINAL_TILEID_TOPLEFT;
			}
			else if(dir == vee.Direction.Bottom){
				gid = this.FINAL_TILEID_BOTTOMRIGHT;
			}
			else{
				gid = this.FINAL_TILEID_BOTTOMLEFT;
			}
		}

		else if(this.gid == this.FINAL_TILEID_BOTTOMLEFT){
			if(dir == vee.Direction.Right){
				gid = this.FINAL_TILEID_BOTTOMRIGHT;
			}
			else if(dir == vee.Direction.Top){
				gid = this.FINAL_TILEID_TOPLEFT;
			}
			else{
				gid = this.FINAL_TILEID_TOPRIGHT;
			}
		}

		else if(this.gid == this.FINAL_TILEID_BOTTOMRIGHT){
			if(dir == vee.Direction.Left){
				gid = this.FINAL_TILEID_BOTTOMLEFT;
			}
			else if(dir == vee.Direction.Top){
				gid = this.FINAL_TILEID_TOPRIGHT;
			}
			else{
				gid = this.FINAL_TILEID_TOPLEFT;
			}
		}
//		cc.log("dir point=======x=%d  y=%d   gid =%d", dirPoint.x, dirPoint.y, gid);
		return gid;
	},

	createChildBlocks : function (grid) {
		var gid = this.getNewGidByGrid(grid);
//		cc.log("child gid=======%d", gid);
		var td = game.Logic.getTileDataByGid(gid, grid, this.layer);
		td.parentBlock = this;
		td._isScaleUp = true;
		game.Logic.map.setObject(td, grid);
		this.layer.setTileGID(gid, grid);
		return td;
	}
});

TileData.RunBackwardBlockData = TileData.BlockData.extend({
	collide : function (nodeCtl, dir) {
		if (nodeCtl._eleType == game.EleType.Player && nodeCtl._moveState === MoveState.Breath) {
			//cc.log(nodeCtl._moveState);
			if (dir === vee.Direction.Right) {
				nodeCtl.setFaceTo(vee.Direction.Left, true);
			} else if (dir === vee.Direction.Left) {
				nodeCtl.setFaceTo(vee.Direction.Right, true);
			}

			if (game.Data.stageType === game.StageType.Parkour) {
				nodeCtl.parkourMove();
			}
			//vee.Audio.playEffect();
		}
	}
});

TileData.gid2td = {
	// Tile
	Tile1 : TileData.BlockData,
	Tile2 : TileData.BlockData,
	Tile3 : TileData.BlockData,
	Tile4 : TileData.BlockData,
	Tile5 : TileData.BlockData,
	Tile6 : TileData.BlockData,
	Tile7 : TileData.BlockData,
	Tile8 : TileData.BlockData,
	Tile9 : TileData.BlockData,
	Tile10 : TileData.BlockData,
	Tile11 : TileData.BlockData,
	Tile12 : TileData.BlockData,
	Tile13 : TileData.BlockData,
	Tile14 : TileData.BlockData,
	Tile15 : TileData.BlockData,
	Tile16 : TileData.BlockData,
	Tile17 : TileData.BlockData,
	Tile18 : TileData.BlockData,
	Tile19 : TileData.BlockData,
	Tile20 : TileData.BlockData,
	Tile30 : TileData.BlockData,
	Tile37 : TileData.BlockSinkData,
	Tile38 : TileData.BlockSinkData,

	Tile41 : TileData.UPSlopeData,
	Tile42 : TileData.DOWNSlopeData,
	Tile43 : TileData.UPSlopeZeroToHalfData,
	Tile44 : TileData.UPSlopeHalfToTopData,
	Tile45 : TileData.DOWNSlopeTopToHalfData,
	Tile46 : TileData.DOWNSlopeHalfToZertData,
	Tile47 : TileData.UPSlopeLeftToZero,
	Tile48 : TileData.DOWNSlopeRightToZeroData,
	Tile57 : TileData.UPSlopeLeftToHalfData,
	Tile58 : TileData.DOWNSlopeRightToHalfData,
	Tile61 : TileData.DynamicBlockData,
	Tile62 : TileData.BlockBreakableData,
	Tile64 : TileData.BlockData,
	Tile65 : TileData.BounceBlockData,
	Tile66 : TileData.BlockBreakableData,
	Tile67 : TileData.BlockOneWayData,
	Tile68 : TileData.BlockOneWayData,
	Tile69 : TileData.BlockBreakableData,

	Tile70 : TileData.BlockBreakableData,

	Tile134 : TileData.RunBackwardBlockData,        //parkour 反弹砖块
	Tile135 : TileData.RunBackwardBlockData,

	Tile71 : TileData.BlockHurtHalfData,
	Tile72 : TileData.BlockHurtData,
	Tile73 : TileData.BlockHurtData,
	Tile77 : TileData.BlockHideData,
	Tile78 : TileData.BlockFadeData,
	Tile79 : TileData.BlockBombData,
	Tile93 : TileData.BlockOneWayData,
	Tile94 : TileData.BlockData,
	Tile97 : TileData.BlockOneWayData,
	Tile108 : TileData.BlockData,
	Tile109 : TileData.BlockData,
	Tile110 : TileData.BlockData,
	Tile122 : TileData.BlockTrapData,
	Tile136 : TileData.BlockHawkData,
	Tile137 : TileData.BlockSmashData,
	Tile138 : TileData.BlockBulletData,
	Tile139 : TileData.BlockTeleportData,
	Tile140 : TileData.BlockSkillBombData,

	Tile141 : TileData.BlockScaleData,
	Tile142 : TileData.BlockScaleData,
	Tile143 : TileData.BlockScaleData,
	Tile144 : TileData.BlockScaleData,
	Tile145 : TileData.BlockScaleData
};
