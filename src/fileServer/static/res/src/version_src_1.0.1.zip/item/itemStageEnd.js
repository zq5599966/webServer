/**
 * Created with AppCode.
 * User: WanThirty
 * Date: 15/9/15
 * Time: 上午11:24
 * To change this template use File | Settings | File Templates.
 */

var ItemStageEnd = Item.extend({
	ps1 : null,
	ps2 : null,

	_pos : null,

	bornWithPos : function (pos) {
		this._pos = pos;
		this.setElePosition(cc.p(pos.x, pos.y - TILE_WIDTH_HALF));
		this.loopAnimate();
	},

	inAnimate : function () {
		this.playAnimate("in", function () {
			this.rootNode.removeFromParent();
		}.bind(this));
	},

	outAnimate : function () {
		this.playAnimate("out");
	},

	loopAnimate : function () {
		this.playAnimate("loop");
	},

	_isOver : false,
	collide : function () {
		if (game.Data.oPlayerCtl._pos.x < this._pos.x - 5 || game.Data.oPlayerCtl._pos.x > this._pos.x + 5 || this._isOver) return;
		ItemTransformBox.transformBackFromHawk();
		this._isOver = true;
		this.outAnimate();
		if (game.Data.oPlayerCtl.extendController) {
			game.Data.oPlayerCtl.extendController.touchGround();
		}

		if (game.LevelData.selectedCategory && game.LevelData.selectedLevel) {
			var category = game.LevelData.selectedCategory.idx + 1;
			var level = game.LevelData.selectedLevel.idx + 1;
			if (game.Data.stageType == game.StageType.Normal) {
				vee.Analytics.logMissionCompleted("Level" + category + "-" + level);
			}
		}

		if (game.Data.stageType == game.StageType.Mini) {
			vee.Analytics.logMissionCompleted("LevelMini" + game.Data.performingTMXIdx);
		}

		if (game.Data.isClearVersion || game.Data.isFreeGame) {
			cc.log("选ID：" + game.LevelData.selectedLevel.idx);
			cc.log("选关卡数：" + game.LevelData.selectedCategory.levelCount);
			if ((game.LevelData.selectedLevel.idx == game.LevelData.selectedCategory.levelCount - 1) && (game.LevelData.selectedCategory.idx < 5)) {
				game.LevelData.setLockStatus(game.LevelData.selectedCategory.idx + 1, game.LevelData.LockStatus.UNLOCKED);
			}
		}

		game.Data.oLyGame.stopCamera = true;
		game.Data.oLyGame.freezeButton = true;
		game.Data.oPlayerCtl.gameOverOut(function() {
			cc.log("unlocking = "+game.Data.isUnlocking());
			cc.log("event count = "+game.Data.getEventCount());
			if (game.LevelData.selectedCategory) {
				var category = game.LevelData.selectedCategory.idx + 1;
				var level = game.LevelData.selectedLevel.idx + 1;
				if (category == 2 && level == 7) {
					vee.data["tenStage"] = true;
					vee.saveData();
				}
			}

			var nextAvatar = game.AvatarData.getNextAvatar(0, true);
			if (nextAvatar && nextAvatar.idx == 1) {
				var unlockedFirst = vee.data["fn"];
				var category = game.LevelData.selectedCategory.idx + 1;
				var level = game.LevelData.selectedLevel.idx + 1;
				if (!unlockedFirst) {
					if (category == 1 && level == 3) {
						game.Data.addEventCount(2);
						vee.data["fn"] = true;
						vee.saveData();
						if (!game.Data.isRated()) {
							LyGameWin.isShowRate = true;
						}
					} else {
						nextAvatar = null;
					}
				}
			}
			if (!game.Data.isUnlocking()
				&& game.Data.getEventCount() >= 2
				&& nextAvatar) {
				var tmxIdx = nextAvatar.eventIdx;
				cc.log("event = "+game.Data.getEventCount());
				vee.Transition.out(res.MapTransition_ccbi, function () {
					vee.PopMgr.closeAll();
					cc.director.purgeCachedData();
					var node = vee.PopMgr.popCCB("res/veeGameLayer.ccbi");
					cc.log('opening level: ' + tmxIdx);
					game.Data.oLyGame.onLoaded();
					game.Data.oLyGame.initStage(tmxIdx, false, game.StageType.Event);
				});
			} else {

				var showWinPop = function () {
					var container = game.Data.oPlayerCtl.getContainerNode();
					var rootNode = game.Data.oPlayerCtl.rootNode;
					container.setPosition(cc.p(0,0));
					container.retain();
					container.removeFromParent();
					var winNode = LyGameWin.show();
					winNode.controller.nodeAvatar.addChild(container);
					container.release();
					game.Data.oLyGameOver.oPlayer = rootNode;

					rootNode.controller.playAnimate("huxi_2", function() {
						if (game.Data.oLyGameOver) {
							game.Data.oLyGameOver.oPlayer.controller.randomBreath();
						}
					});
				}.bind(this);

				if(game.Data.willShowVideoAd){
					vee.Ad.showRevivalVideoAd(showWinPop);
					return;
				}
				else if (game.Data.isFreeGame) {
					cc.log("zq debug lyGameWin ccbInit");
					vee.Ad.showInterstitialByOnlineConfig("game_win");
					vee.Analytics.UGameEvent.showAdEvent("game_win", "interstial");

				}
				showWinPop();

			}
		});
	}
});

ItemStageEnd.show = function (pos) {
	var node = cc.BuilderReader.load(res.efx_GamePiont_ccbi);
	game.Data.oLyGame.lyMap.addChild(node, 1);
	node.setPosition(cc.p(pos.x, pos.y - TILE_WIDTH_HALF));
	node.controller.inAnimate();
};

var EfxStageEnd = vee.Class.extend({
	ccbInit : function () {
		this.playAnimate("show", function () {
			this.rootNode.removeFromParent();
		}.bind(this));
	}
});

EfxStageEnd.show = function (pos) {
	var node = cc.BuilderReader.load(res.efx_stageEnd_ccbi);
	node.setPosition(pos);
	game.Data.oLyGame.lyMap.addChild(node, 11);
	node.controller.ccbInit();
};