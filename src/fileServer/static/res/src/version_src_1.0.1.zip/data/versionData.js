/**
 * Created with AppCode.
 * User: ZQ
 * Date: 16/7/4
 * Time: 下午1:19
 * To change this template use File | Settings | File Templates.
 */
var game = game = game || {};

var VERSION = {
		//android
		ANDROID_GOOGLE_FREE : 1,        //android谷歌免费版
		ANDROID_WECHAT : 2,             //android谷歌微信版
		ANDROID_GENUINE : 3,            //android收费版（纯净版）

		//ios
		IOS_GENUINE : 101,                //ios收费版 （纯净版）
		IOS_FREE : 102,                   //ios免费版
		IOS_FREE_CN : 103                 //ios免费中文版
};

game.Data.version = {

	curVersion : VERSION.IOS_GENUINE,

	codeVersion : 10,	//版本更新递增

	zqdebug : false,

	/**le
	 * for android free version
	 * 购买月世界弹窗修改案l
	 * 月世界解锁逻辑改为2-1通过之后解锁第1，2大关的月世界。其余的改为通过当前大关的第一小关解锁
	 * 月世界小关解锁跳转（关闭弹窗跳转改为只关闭弹窗）
	 */
	newVersion : true,

	isNewIosVersion : true,

	isKTPlay : false,

	isAutoSave : true,

	isMidAutumn : true,             //中秋关卡

	/**
	 * 1-2关卡结束强制弹出评星按钮
	 */
	isNewRateVersion : true,

	isAdmobAd : false,

	isSetShowSpecialEvent : true,  //是否启用活动关卡显示规则

	isQXSdk : false,


	//online update data
	resVersionCode : 1.0,		  //热更资源版本号


	init : function(){

		game.Data.zqdebug = this.zqdebug;

		if (cc.sys.os == cc.sys.OS_ANDROID) {
			game.Data.isAndroid = true;
		}
		else{
			game.Data.isAndroid = false;
		}

		game.Data.isFreeGame = false;
		game.Data.isReverseWorldOpen = false;
		game.Data.isIOSCN = false;
		game.Data.isWeiXin = false;
		this.newVersion = false;
		this.isNewIosVersion = false;
		this.isKTPlay = false;
		this.isAutoSave = false;

		
		switch (this.curVersion){

			case VERSION.IOS_FREE:
				game.Data.isFreeGame = true;
				this.newVersion = true;
				this.isNewIosVersion = true;
				game.Data.isReverseWorldOpen = true;
				this.isNewRateVersion = true;
				this.isAdmobAd = true;
				this.isSetShowSpecialEvent = true;
				this.isQXSdk = true;

				break;

			case VERSION.IOS_GENUINE:
				game.Data.isReverseWorldOpen = true;
				vee.data["moon"] = true;
				this.isNewRateVersion = true;

				this.isSetShowSpecialEvent = true;
				break;

			case VERSION.IOS_FREE_CN:
				game.Data.isFreeGame = true;
				game.Data.isIOSCN = true;
				this.newVersion = true;
				this.isNewIosVersion = true;
				this.isAdmobAd = true;
				game.Data.isReverseWorldOpen = true;
				this.isKTPlay = true;
				break;

			case VERSION.ANDROID_GOOGLE_FREE:
				game.Data.isFreeGame = true;
				game.Data.isReverseWorldOpen = true;
				this.newVersion = true;
				this.isAutoSave = true;
				this.isNewRateVersion = true;
				this.isAdmobAd = true;

				this.isSetShowSpecialEvent = true;

				this.isQXSdk = true;
				break;

			case VERSION.ANDROID_WECHAT:
				game.Data.isWeiXin = true;
				game.Data.isReverseWorldOpen = true;
				break;

			case VERSION.ANDROID_GENUINE:
				game.Data.isReverseWorldOpen = true;
				game.Data.isClearVersion = true;
				break;
		}

		app.configManager.init();


		// game.dataManager.setResVersionCode();
	},


	/**
	 * 是否显示活动关卡相关内容
	 */
	isShowSpecialLevel : function () {
		if(this.isSetShowSpecialEvent){
			cc.log("check is show special level event");
			//是否通过1-3或者是否通过2-1
			var categoryData = game.LevelData.getCategory(0);
			var isLevelPass = categoryData.getLevelData(2).isLevelPassed;
			// vee.Utils.logObj(categoryData, "category data====");
			// vee.Utils.logObj(categoryData.getLevelData(2), "level data====");
			if(isLevelPass || game.LevelData.getCategory(1).getLevelData(0).isLevelPassed ){
				return true;
			}
			return false;
		}
	}
}
