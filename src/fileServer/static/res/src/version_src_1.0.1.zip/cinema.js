/**
 * Created with AppCode.
 * User: WanThirty
 * Date: 16/1/19
 * Time: 下午4:14
 * To change this template use File | Settings | File Templates.
 */

var Cinema = {
	smallcat : null,
	phantom : null,
	enemy : [],
	checkDogPos : null,
	_walkSfx : null,

	analyseTag : false,

	init : function () {
		this.enemy = [];
		this.smallcat = null;
		this.phantom = null;
		LyBlackCutScene.ctl = null;
		this.checkDogPos = game.Logic.getTilePosCenterByGrid(cc.p(21,44));
		game.Data.oLyGame.stopCamera = true;
		game.Data.cameraRestoreY = false;
		game.Data.oLyGame.lyContainer.setPosition(game.Logic.getCameraPosByGrid(cc.p(12,22)));
		game.Data.oLyGame.hideControlButton(LyGame.ControlButtonType.ActionButton);
		game.Data.oLyGame.hideControlButton(LyGame.ControlButtonType.JumpButton);
		game.Data.oLyGame.hideControlButton(LyGame.ControlButtonType.MoveButton);
		game.Data.oLyGame.nodeT.setVisible(false);
		game.Data.oLyGame.nodeTRElements.setVisible(false);
		game.Data.oLyGame.nodeTLElements.setVisible(false);

		this.smallcat = game.Data.npcmap["SmallCat"];
		this.phantom = game.Data.npcmap["Phantom"];
		var pos = this.phantom._container.getPosition();
		this.phantom.setElePosition(cc.p(pos.x + TILE_WIDTH_HALF, pos.y));
		this.phantom.setJumping(false);
		this.phantom._speedY = 0;
		game.Data.arrUpdateObj.push(game.Data.npcmap["Phantom"]);

		game.Logic.deployTileConfig(cc.p(30,41));

		var canSkip = vee.data["skipSign"+game.Data.performingTMXIdx];
		//game.Data.oLyGame.setSkipButtonVisible(canSkip);
		game.Data.oLyGame.setSkipButtonVisible(true);
		vee.data["skipSign"+game.Data.performingTMXIdx] = true;
		vee.saveData();

		if (this.analyseTag) {
			cc.log("记录开始");
			vee.Analytics.logMissionStart("LevelStoryAnimate");
		}

		var func5 = function () {
			var dur = Cinema.getMoveDur(14);
			var pos = game.Logic.getTilePosCenterByGrid(cc.p(11,44));
			Cinema.smallcat.setFaceTo(vee.Direction.Left);
			Cinema.smallcat.playAnimate("escape");
			Cinema.smallcat._container.runAction(cc.sequence(
				cc.moveTo(dur, pos),
				cc.callFunc(function () {
					Cinema.smallcat.playAnimate("fright");
				})
			));
			Cinema.moveCamera(14,42,dur,Cinema.EaseType.EASEINOUT);;
		};

		var func4 = function () {
			Cinema.smallcat._container.runAction(cc.sequence(
				cc.delayTime(0.5),
				cc.callFunc(function () {
					Cinema.moveCamera(31,42,1.6,Cinema.EaseType.EASEINOUT);
				}),
				cc.delayTime(0.8),
				cc.callFunc(function () {
					var objs = game.Logic.dynamicObjMap.getObjects();
					var count = 0;
					for (i in objs) {
						var obj = objs[i];
						obj.idxInMap = i;
						if (obj) {
							if (vee.Utils.getObjByPlatform(true, true, false)) {
								Cinema.enemy.unshift(obj);
								obj.movePos = cc.p(11,44);
								obj.findTargetWithDelay(0.3*(3+count), function() {
									this._dashing = true;
									this._speedXLimit = 520;
									this.playAnimate("eat");
									this.moveLeft();
								}.bind(obj));
								++count;
							} else {
								Cinema.enemy.push(obj);
								obj.movePos = cc.p(11,44);
								obj.findTargetWithDelay(0.3*(5-count), function() {
									this._dashing = true;
									this._speedXLimit = 520;
									this.playAnimate("eat");
									this.moveLeft();
								}.bind(obj));
								++count;
							}
						}
					}
					vee.Utils.scheduleCallbackForTarget(Cinema, Cinema.updateCheckDog)
					vee.Audio.playMusic(res.bgm_mini_mp3);
				}),
				cc.delayTime(0.5),
				cc.callFunc(function () {
					Cinema.smallcat.playAnimate("fright");
				}),
				cc.delayTime(0.7),
				cc.callFunc(func5)
			));
		};

		var func3 = function () {
			game.Data.oLyGame.shake();
			game.Logic.checkTileTrigger(cc.p(22,44), vee.Direction.Origin, null, Cinema.smallcat);
			Cinema.smallcat.playAnimate("landing");
			Cinema.moveCamera(25,42,1.2);
			Cinema.smallcat._container.runAction(cc.sequence(
				cc.moveBy(1.2, cc.p(TILE_WIDTH*5+TILE_WIDTH_HALF, 0)),
				cc.callFunc(func4)
			));
		};

		var func2 = function () {
			vee.Audio.stopEffect(Cinema._walkSfx);
			vee.Audio.playEffect(res.inGame_character_littleShock_mp3);
			Cinema.smallcat.playAnimate("fright", function () {
				var dur = Cinema.getMoveDur(11);
				var pos = game.Logic.getTilePosCenterByGrid(cc.p(22,44));
				Cinema.smallcat._container.runAction(cc.sequence(
					cc.EaseOut.create(cc.moveBy(0.3, cc.p(0, 60)), 3),
					cc.callFunc(function () {
						vee.Audio.playEffect(res.inGame_character_littleDrop_mp3);
						Cinema.smallcat.playAnimate("drop");
					}),
					cc.moveTo(dur, cc.p(pos.x + TILE_WIDTH_HALF, pos.y)),
					cc.callFunc(func3)
				));
				Cinema.moveCamera(22,42,dur+1,Cinema.EaseType.EASEINOUT);
			});
		};

		var func1 = function () {
			Cinema._walkSfx = vee.Audio.playEffect(res.inGame_character_littleWalk_mp3);
			Cinema.smallcat.playAnimate("run");
			var dur = Cinema.getMoveDur(22);
			var pos = game.Logic.getTilePosCenterByGrid(cc.p(22,22));
			Cinema.smallcat._container.runAction(cc.sequence(
				cc.moveTo(dur+2, cc.p(pos.x + TILE_WIDTH_HALF, pos.y)),
				cc.callFunc(function () {
					game.Logic.checkTileTrigger(cc.p(22,22), vee.Direction.Origin, null, Cinema.smallcat);
					game.Logic.checkTileTrigger(cc.p(22,21), vee.Direction.Origin, null, Cinema.smallcat);
					Cinema.smallcat.playAnimate("huxi_1");
				}),
				cc.delayTime(0.5),
				cc.callFunc(func2)
			));
			game.Data.oLyGame.lyMap.runAction(cc.sequence(
				cc.delayTime(Cinema.getMoveDur(12)),
				cc.callFunc(function () {
					Cinema.moveCamera(22,22,Cinema.getMoveDur(10));
				})
			));
		};

		var arrActSeq = [];
		arrActSeq.push(cc.delayTime(0.5));
		arrActSeq.push(cc.callFunc(func1));

		game.Data.oLyGame.lyMapBack.runAction(cc.sequence(arrActSeq));
	},

	updateCheckDog : function () {
		for (var i in Cinema.enemy) {
			var obj = Cinema.enemy[i];
			if (obj._pos.x < Cinema.checkDogPos.x) {
				Cinema.phantom.BButtonSmash();
				game.Logic.checkTileTrigger(cc.p(14,40), vee.Direction.Origin, null, Cinema.smallcat);
				vee.Utils.unscheduleCallbackForTarget(Cinema, Cinema.updateCheckDog);
			}
		}
	},

	smashCallback : function () {
		var func8 = function () {
			game.Data.arrUpdateObj = [];
			Cinema.MoveRole(Cinema.phantom, 28, 44, function () {
				Cinema.phantom.playAnimate("huxi_1");
				game.Logic.setBomb(cc.p(29, 44));
				var bombTd = game.Logic.map.getObject(cc.p(29, 44));
				bombTd.collide(this, vee.Direction.Origin, true);
				Cinema.JumpRole(Cinema.phantom, 29, 43, 2, function () {
					Cinema.moveCamera(32, 42, 8);
					Cinema.JumpRole(Cinema.phantom, 32, 41, 3, function () {
						LyBlackCutScene.getCtl().playAnimate("out");
						Cinema.JumpRole(Cinema.phantom, 34, 40, 2, function () {
							cc.log("1");
							Cinema.JumpRole(Cinema.phantom, 37, 39, 2, function () {
								cc.log("2");
								Cinema.MoveRole(Cinema.phantom, 41, 39, function () {
									cc.log("3");
									vee.Audio.stopMusic();
									vee.Audio.playMusic(res.bgm_3_mp3);
									vee.Utils.unscheduleCallbackForTarget(Cinema, Cinema.updateSmallCatPos);
									var phantomPos = game.Logic.getTilePosCenterByGrid(cc.p(46, 22));
									var smallcatPos = game.Logic.getTilePosCenterByGrid(cc.p(45, 22));

									Cinema.smallcat._container.setPosition(smallcatPos);
									Cinema.smallcat.playAnimate("run");
									Cinema.MoveRole(Cinema.smallcat, 55, 22, function () {
										Cinema.smallcat.playAnimate("huxi_1");
									});

									Cinema.phantom._container.setPosition(phantomPos);
									Cinema.phantom.playAnimate("run");
									Cinema.MoveRole(Cinema.phantom, 57, 22, function () {
										Cinema.phantom.playAnimate("huxi_1");
										Cinema.smallcat.playAnimate("worship");
										Cinema.phantom.setFaceTo(vee.Direction.Left);
										Story.showStory("" +
										"SelectNpc,Phantom;" +
										"Delay,0.5;"+
										"ShowDialog," + vee.Utils.getLocalizedStringForKey("Hey kid. Are you ok?") + ";" +
										"ShowDialog," + vee.Utils.getLocalizedStringForKey("Well, take care!") + ";" +
										"HideDialog," +
										"SelectNpc,Phantom;" +
										"MoveRole,58,22;" +
										"SelectNpc,SmallCat;" +
										"MoveRole,56,22;" +
										"TimeLine,worship;" +
										"Delay,0.5;" +
										"SelectNpc,Phantom;" +
										"FaceTo,left;" +
										"Delay,0.5;" +
										"ShowDialog," + vee.Utils.getLocalizedStringForKey("You better go home.") + ";" +
										"HideDialog;" +
										"FaceTo,right;" +
										"MoveRole,60,22;" +
										"SelectNpc,SmallCat;" +
										"MoveRole,58,22;" +
										"TimeLine,worship;" +
										"Delay,0.5;" +
										"SelectNpc,Phantom;" +
										"FaceTo,left;" +
										"Delay,0.5;" +
										"ShowDialog," + vee.Utils.getLocalizedStringForKey("Don't follow me.") + ";" +
										"ShowDialog," + vee.Utils.getLocalizedStringForKey("Alright, here's a small gift for you!") + ";" +
										"HideDialog;" +
										"Trigger,40,23;" +
										"Delay,0.5;" +
										"SelectNpc,SmallCat;" +
										"FaceTo,left;" +
										"Delay,0.5;" +
										"SelectNpc,Phantom;" +
										"ShowDialog," + vee.Utils.getLocalizedStringForKey("We’ll meet if fate beholds.") + ";" +
										"HideDialog;" +
										"Delay,0.5;" +
										"SelectNpc,SmallCat;" +
										"FaceTo,right;" +
										"Delay,0.5;" +
										"SelectNpc,Phantom;" +
										"FaceTo,right;" +
										"MoveRole,68,22;" +
										"SelectNpc,SmallCat;" +
										"FaceTo,left;" +
										"MoveRole,56,22" +
										"", cc.p(56, 22));
									});

									LyBlackCutScene.getCtl().playAnimate("in");
									game.Data.oLyGame.lyContainer.stopAllActions();
									game.Data.oLyGame.lyContainer.setPosition(game.Logic.getCameraPosByGrid(cc.p(56, 22)));
								});
							});
						});
					});
				});
			});
		};

		var func7 = function () {
			Cinema.smallcat._container.setVisible(false);
			Cinema.smallcat._container.setLocalZOrder(3);
			Cinema.smallcat.playAnimate("safe");
			Cinema.phantom.BButtonTeleport();
			vee.Utils.scheduleCallbackForTarget(Cinema, Cinema.updateSmallCatPos);
			Cinema.smallcat._container.runAction(cc.sequence(
				cc.delayTime(0.2),
				cc.callFunc(function () {
					Cinema.smallcat._container.setVisible(true);
					Cinema.smallcat._container.setPosition(game.Logic.getTilePosCenterByGrid(cc.p(16,44)));
					Cinema.enemy[0].playAnimate("get");
				}),
				cc.delayTime(0.3),
				cc.callFunc(func8),
				cc.delayTime(0.3),
				cc.callFunc(function () {
					Cinema.phantom.BButtonBullet();
				})
			));
			var dur = Cinema.getMoveDur(12);
			Cinema.moveCamera(30, 42, dur, Cinema.EaseType.EASEINOUT);
		};

		var func6 = function () {
			Cinema.moveBy(Cinema.phantom, 10);
			Cinema.smallcat._container.runAction(cc.sequence(
				cc.callFunc(function () {
					Cinema.smallcat.playAnimate("run");
				}),
				cc.moveBy(0.2, cc.p(32, 0)),
				cc.callFunc(function () {
					Cinema.smallcat.playAnimate("shiver");
				}),
				cc.delayTime(0.5),
				cc.callFunc(function () {
					Cinema.enemy[1]._dashing = true;
					Cinema.enemy[1]._speedXLimit = 450;
					Cinema.enemy[1].playAnimate("get");
					Cinema.enemy[1]._container.runAction(cc.sequence(
						cc.delayTime(0.5),
						cc.callFunc(function () {
							Cinema.enemy[1].playAnimate("eat");
							Cinema.moveToGrid(Cinema.enemy[1], cc.p(11,44), function () {
								Cinema.enemy[1].stopMove();
								Cinema.enemy[1]._speedX = 0;
								Cinema.enemy[1].playAnimate("get", function () {
									Cinema.enemy[1].hitByStar = function () {};
									Cinema.moveToGrid(Cinema.enemy[1], cc.p(28,44), function () {
										Cinema.enemy[1].dieAnimate();
										Cinema.enemy[1] = null;
									});
									Cinema.enemy[1].playAnimate("eat");
									Cinema.enemy[1]._speedXLimit = 520;
								});
							});
						})
					));
				}),
				cc.delayTime(0.9),
				cc.callFunc(func7)
			));
		};

		vee.Utils.unscheduleAllCallbacksForTarget(Cinema.enemy[2]);
		Cinema.enemy[2].dieAnimate();
		Cinema.enemy.pop();
		for (var i in Cinema.enemy) {
			var obj = Cinema.enemy[i];
			obj._stopY = true;
			obj.stopMove();
			obj.playAnimate("get", function () {
				this.playAnimate("run");
			}.bind(obj));
			obj._container.runAction(cc.sequence(
				cc.EaseExponentialOut.create(cc.moveBy(0.5, cc.p(30, 60))),
				cc.callFunc(function () {
					this._stopY = false;
				}.bind(obj))
			));
		}

		vee.Audio.stopMusic();
		vee.Audio.playMusic(res.bgm_invisible_10s_mp3);
		var dur = Cinema.getMoveDur(4);
		var pos = game.Logic.getTilePosCenterByGrid(cc.p(14,44));
		Cinema.smallcat._container.runAction(cc.sequence(
			cc.delayTime(0.6),
			cc.callFunc(function () {
				Cinema.smallcat.setFaceTo(vee.Direction.Right);
				Cinema.smallcat.playAnimate("escape");
			}),
			cc.moveTo(dur, cc.p(pos.x - 15, pos.y)),
			cc.callFunc(function () {
				Cinema.smallcat.playAnimate("shiver");
			}),
			cc.delayTime(0.4),
			cc.callFunc(func6)
		));
	},

	phantomPos : null,
	updateSmallCatPos : function () {
		this.phantomPos = Cinema.phantom._container.getPosition();
		Cinema.smallcat._container.setPosition(cc.p(Cinema.phantomPos.x - 5, Cinema.phantomPos.y - 34));
	},

	// only support left and right
	moveCamera : function (x,y,dur,easeType) {  // target grid X, target grid Y, dur
		if (!easeType) easeType = Cinema.EaseType.LINER;
		var targetPos  = game.Logic.getCameraPosByGrid(cc.p(x,y));
		var dur = parseFloat(dur);
		var moveAction = cc.moveTo(dur, targetPos);
		var warppedAction = null;
		switch (easeType) {
			case Cinema.EaseType.LINER:
				warppedAction = moveAction;
				break;
			case Cinema.EaseType.EASEIN:
				warppedAction = cc.EaseIn.create(moveAction, 3);
				break;
			case Cinema.EaseType.EASEOUT:
				warppedAction = cc.EaseOut.create(moveAction, 3);
				break;
			case Cinema.EaseType.EASEINOUT:
				warppedAction = cc.EaseInOut.create(moveAction, 3);
				break;
			default:
				break;
		}
		if (warppedAction) {
			game.Data.oLyGame.lyContainer.runAction(warppedAction);
		}
	},
	moveToGrid : function (obj, grid, callback) {
		var pos = game.Logic.getTilePosCenterByGrid(grid);
		obj.checkPosForCinema = pos;
		if (pos.x > obj._pos.x) {
			obj.moveRight();
		} else {
			obj.moveLeft();
		}
		obj.checkPosUpdateFunc = function () {
			if ((obj._speedX > 0 && obj._pos.x > obj.checkPosForCinema.x) ||
				(obj._speedX < 0 && obj._pos.x < obj.checkPosForCinema.x)) {
				obj.stopMove();
				vee.Utils.unscheduleCallbackForTarget(obj, obj.checkPosUpdateFunc);
				if (callback) callback();
			}
		}.bind(obj);
		vee.Utils.scheduleCallbackForTarget(obj, obj.checkPosUpdateFunc);
	},
	moveBy : function (obj, Xoffset, callback) {
		obj.checkPosForCinema = cc.p(obj._pos.x + Xoffset, 0);
		if (obj.checkPosForCinema.x > obj._pos.x) {
			obj.moveRight();
		} else {
			obj.moveLeft();
		}
		obj.checkPosUpdateFunc = function () {
			if ((obj._speedX > 0 && obj._pos.x > obj.checkPosForCinema.x) ||
				(obj._speedX < 0 && obj._pos.x < obj.checkPosForCinema.x)) {
				obj.stopMove();
				vee.Utils.unscheduleCallbackForTarget(obj, obj.checkPosUpdateFunc);
				if (callback) callback();
			}
		}.bind(obj);
		vee.Utils.scheduleCallbackForTarget(obj, obj.checkPosUpdateFunc);
	},
	getMoveDur : function (grids) {
		return grids*0.2;
	},
	MoveRole : function (obj, x, y, callback) {    // target grid X, target grid Y
		var targetGrid = cc.p(x,y);
		var targetPos  = game.Logic.getTilePosCenterByGrid(targetGrid);

		var nowPos     = obj._container.getPosition();
		var nowGrid    = game.Logic.getTileGridByPos(nowPos);

		var offX = targetGrid.x - nowGrid.x;
		if (offX) {
			if (offX > 0) obj.setFaceTo(vee.Direction.Right);
			else obj.setFaceTo(vee.Direction.Left);
		}

		var dis = vee.Utils.manhattanDistance(vee.Utils.pSub(targetGrid, nowGrid));
		var dur = Cinema.getMoveDur(dis);

		if (!callback) callback = function(){};
		obj.playAnimate("run");
		obj._container.runAction(cc.sequence(
			cc.moveTo(dur, targetPos),
			cc.callFunc(callback)
		));
	},
	JumpRole : function (obj, x, y, h, callback) {    // target grid X, target grid Y, jump height(optional)
		var targetGrid = cc.p(x, y);
		var targetPos = game.Logic.getTilePosCenterByGrid(targetGrid);
		var height = h;
		height = height * TILE_WIDTH;

		var nowPos     = obj._container.getPosition();
		var nowGrid    = game.Logic.getTileGridByPos(nowPos);
		var dis = vee.Utils.manhattanDistance(vee.Utils.pSub(targetGrid, nowGrid));
		var dur = dis*0.2;
		if (!callback) callback = function(){};
		obj._container.runAction(cc.sequence(
			cc.delayTime(0),
			cc.callFunc(function () {
				obj.playAnimate("run_jump_up");
			}),
			cc.jumpTo(0.7, targetPos.x, targetPos.y, height, 1),
			cc.callFunc(callback)
		));
	},
	storyOver : function () {
		if (this.analyseTag) {
			cc.log("记录结束");
			vee.Analytics.logMissionCompleted("LevelStoryAnimate");
		}
		var pos = game.Logic.getTilePosCenterByGrid(cc.p(56,21));
		Story.isShowStory = false;
		Cinema.smallcat.playAnimate("jump");
		Cinema.smallcat._container.runAction(
			cc.EaseExponentialOut.create(cc.moveTo(0.8, pos))
		);
		Cinema.smallcat._container.runAction(cc.sequence(
			cc.delayTime(0.6),
			cc.callFunc(function () {
				Cinema.closeCinema();
				vee.Transition.out(res.MapTransition_ccbi, function () {
					vee.PopMgr.closeAll();
					cc.director.purgeCachedData();
					vee.PopMgr.popCCB("res/veeGameLayer.ccbi");
					game.Data.oLyGame.onLoaded();
					game.Data.oLyGame.initStage('Tutorial');
				});
			})
		));
	},

	setAnalyse : function(tag) {
		this.analyseTag = tag;
	},

	closeCinema : function () {
		vee.Utils.unscheduleAllCallbacksForTarget(Cinema);
		for (var i in Cinema.enemy) {
			var obj = Cinema.enemy[i];
			vee.Utils.unscheduleAllCallbacksForTarget(obj);
		}
		vee.Utils.unscheduleAllCallbacksForTarget(Cinema.smallcat);
		vee.Utils.unscheduleAllCallbacksForTarget(Cinema.phantom);
	}
};

Cinema.isCinema = false;
Cinema.EaseType = {
	LINER : 1,
	EASEIN : 2,
	EASEOUT : 3,
	EASEINOUT : 4
};

var LyBlackCutScene = vee.Class.extend({
	ccbInit : function () {

	}
});
LyBlackCutScene.ctl = null;
LyBlackCutScene.getCtl = function () {
	if (!LyBlackCutScene.ctl) {
		var node = vee.PopMgr.popCCB(res.lyBlackCutScene_ccbi);
		node.controller.ccbInit();
		LyBlackCutScene.ctl = node.controller;
	}
	return LyBlackCutScene.ctl;
};
LyBlackCutScene.remove = function () {
	if (LyBlackCutScene.ctl) {
		LyBlackCutScene.ctl.rootNode.removeFromParent();
		LyBlackCutScene.ctl = null;
	}
};

var LyCatGrow = vee.Class.extend({
	ccbInit : function (callback) {
		this.playAnimate("show", function () {
			this.playAnimate("star", function () {
				vee.PopMgr.closeLayerByCtl(this);
				if (callback) callback();
			}.bind(this))
		}.bind(this));
	}
});

LyCatGrow.show = function (callback) {
	var node = vee.PopMgr.popCCB(res.lyBG_story_2_ccbi, {alpha : 0});
	node.controller.ccbInit(callback);
};











