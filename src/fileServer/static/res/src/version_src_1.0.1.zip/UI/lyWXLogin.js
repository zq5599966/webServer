/**
 * Created with AppCode.
 * User: WanThirty
 * Date: 16/4/12
 * Time: 下午6:26
 * To change this template use File | Settings | File Templates.
 */

var LyWXLogin = vee.Class.extend({

	ccbInit : function () {
		this.playAnimate("show");
		LyWXLogin.ctl = this;
	},

	onWX : function () {
		vee.IAPMgr.WeiXinLogin();
	},

	onQQ : function () {
		vee.IAPMgr.QQLogin();
	},

	onClose : function () {
		LyWXLogin.ctl = null;
		this.playAnimate("hide", function () {
			vee.PopMgr.closeLayerByCtl(this);
		}.bind(this));
	},

	onExit : function () {
		vee.IAPMgr.removeAllCallback();
	}

});

LyWXLogin.ctl = null;

LyWXLogin.show = function () {
	var node = vee.PopMgr.popCCB(res.lyWXLogin_ccbi, {alpha : 0});
	node.controller.ccbInit();
	vee.IAPMgr.LoginSuccessCallback = function () {
		if (LyWXLogin.ctl) {
			LyWXLogin.ctl.onClose();
		}
	};

	vee.IAPMgr.LoginFailedCallback = function () {
		vee.Utils.scheduleBack(function () {
			vee.PopMgr.alert("登陆失败，请重新登陆", "登陆失败", function () {});
		});
	};
};