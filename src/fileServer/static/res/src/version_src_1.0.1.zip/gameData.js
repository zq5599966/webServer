/**
 * Created with AppCode.
 * User: WanThirty
 * Date: 4/17/15
 * Time: 1:38 PM
 * To change this template use File | Settings | File Templates.
 */

var game = game = game || {};

var TILE_WIDTH = 64;
var TILE_WIDTH_HALF = 32;
var TILE_WIDTH_3_1 = 21;
var TILE_WIDTH_3_2 = 43;

game.Data = {
	// Scalar
	winSize             : cc.size(768,1136),
	tileSizeWidth       : 64,
	tileSizeWidthHalf   : 32,
	secretLayerStatus   : 1,
	isDoorIn            : true,
	doorOutOffset       : cc.p(0,0),
	isHoldJumpButtom    : false,
	isChangingBG        : false,
	performingTMXIdx    : null,
	lastTMXIdx          : null,
	realLastTmxIdx      : null,
	savePointSaved      : false,
	savePointLifePrice  : 100,
	overRevivePrice     : 200,
	energyReviveDelay   : 600000,
	//energyReviveDelay   : 90000,
	smallButtonRate     : 0.6,
	//jin
	videoReward : 500,	//视频广告赠予金币数
	energyUnlimitedTime : 20,	//不消耗生命持续时间
	//level61Time : 1,
	level61Time : 1440,

	// sign
	isSelectingReverseWorld : false,
	newReverseWorldIdx : -1,
	newMoonLevelIdx : -9,
	isResetSkip : true,

	// stage temp data
	collectedStarCount  : 0,
	stageMaxCoin        : 0,
	stageType           : 1,
	playerDeadGrid      : null,
	bgName              : null,
	gameStartTime       : null,
	jumpCount           : 0,
	isEnableCameraYOff  : true,
	retryCount          : 0,
	tempPlayerCtl       : null,
	deadCount           : 0,
	mapRightEdge        : 0,

	// Global object
	oLyGame         : null,
	oLyGameOver     : null,

	oPlayerCtl      : null,
	oLvCtl          : null,
	/**@type{LyLevelSelect}**/
	oLvSelectCtl    : null,
	oLvLoadingCtl   : null,
	oPauseCtl       : null,
	oEnergyCtl      : null,
	tmxInfoStack    : null,
	itemCoinPool    : [],
	enemyPool       : [],
	usingEnemyPool  : [],
	npcmap          : {},
	arrUpdateObj    : [],
	arrGrabbedPlatform : [],
	arrSkillBoxes   : [],

	// Player config infos
	playerLife : 0,
	playerMaxLife : 5,
	coin : 0,
	playerType : 0,
	roleType : null,

	isUpdatePlayerPos : false,

	playerSizeWidth : 64,
	playerTopEdgeWidth : 10,
	playerBottomEdgeWidth : 20,
	dynamicBlockTopEdgeWidth : 25,

	G : -4000,
	playerXacc : 3000,
	playerXdecay : 2560,
	playerXSpeedLimit : 440,
	playerXBurstSpeed : 600,
	playerBurstHoldTime : 0.1,

	playerYSpeedLimit : -1000,
	playerYJumpSpeed : 1080,
    playerYTriggerSpeed : 800,
	playerYMiniJumpSpeed : 480,
	playerJumpHeight : 230,

	playerInvisible : false,
	playerHawk : false,

	// player ability args...
	playerTeleportLength : 3,
	BButtonCDTime : 0,
	bulletCount : 1,

	cameraXPos : 0,
	cameraXPosLimit : 50,
	cameraXMoveSpeed : 100,
	cameraXrevived : true,
	cameraYPos : 0,
	cameraYPosOff : -60,
	cameraYPosLimit : 260,
	cameraYMoveRate : 0.65,
	cameraYRestoreSpeed : 200,
	cameraRestoreY : 1,
	cameraYrevived : true,

	cameraScaleRate : 1,
	cameraScaleSpeed : 0.01,
	cameraScaleLimitMAX : 1,
	cameraScaleLimitMIN : 1,

	btnMovePos : null,
	btnDropPos : null,
	btnJumpPos : null,

	isAndroid           : true,
	isFreeGame          : true,
	
	isWeiXin            : false,
	isReverseWorldOpen  : true,
	isIOSCN             : false,
	is61                : false,
	isClearVersion      : false,

	isAllLevelOpen      : false, // for debug

	orderId : null,
	isAutoLoginGoogle : false,

	isAndroidTV_test : false,    //参展用，no pay

	isInLevelSceen : false,      //add by zq 是否在游戏关卡界面


	willShowVideoAd : false,	//add by zq 游戏结束播放视频广告
	shownVideoAd : false,		//add by zq 已经播放过视频广告则不显示插屏广告

	willShowLoginPop : false,	//将要显示连续登录弹窗

	noPurchase : true,
	curSceen : null,			//add by zq

	// zqdebug : true,			//see versionData

//	newVersion : true,           //android免费版

	// funcs
	init : function() {
		this.winSize = vee.Director.getWinSize();
		this.loadBtnPos();

		game.LevelData.initReverseWorldData();

		/*
		if (cc.sys.os == cc.sys.OS_ANDROID) {
			this.isAndroid = true;
		}
		else{
			this.isAndroid = false;
		}
		*/

		//end

		/*Deprecated change by zq 20161227 see src/data/appConfig/appConfigManager.js
		if (this.isFreeGame) {
			app.Config.AnalysticsPluginConfig = "8D7311350BF429B979C6101EA7D97F44";
			app.Config.AdPosEntityConfig = ["AdsAdapter","AdsAdapter","AdsAdapter"];

			if (this.isAndroid) {
				app.Config.IAPConfig = {IAPID : ""};//"MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAhb+hA/lLAbVynW5AOQAurv4nsgDTRh4PsuHH3smCq01FGc4VqR4r/Uc1sOHZ3cR0ocHc2ISycIXd2A8/FW6ZQ9nRVHunYXqKwGSMZiImrPKH3qz4bChdxs42AtSTMutDBVIc3AVjbkOD5yaPh09xUxZ9lJDmJrXRoj0sKvn2FCyYpSYQyJZjTBOZs1+fGjaUK9ytiF5lZkhdIfsHkZA256kwq1uYGOi/KQk59qeCqfMg8ovA1Kgno+mitR2aG8A9PimG7WNPneqy3Ss7Lo68C5tT8RaWnXg2ZnLaWbZveyVfJFY2jGrI/K1CV8f+MJ7OqSu24nFXlPbgG22IuJaBhQIDAQAB"};
				app.Config.AppID = "com.veewo.supercat";
				app.Config.packageName = "com.veewo.supercat";
				app.Config.GameCenterPluginConfig = {"appid" : "com.veewo.supercat"};
				app.Config.Achievements = [
					"CgkIu7e9p-oLEAIQAQ",   // star 1
					"CgkIu7e9p-oLEAIQAg",   // star 2
					"CgkIu7e9p-oLEAIQAw",   // star 3
					"CgkIu7e9p-oLEAIQBA",   // star 4
					"CgkIu7e9p-oLEAIQBQ",   // star 5
					"CgkIu7e9p-oLEAIQAA",   // flash
					"CgkIu7e9p-oLEAIQBg",   // jump
					"CgkIu7e9p-oLEAIQBw",   // heart
					"CgkIu7e9p-oLEAIQCg"    // coin
				];
			} else {
				if (!game.Data.isIOSCN) {
					app.Config.AnalysticsPluginConfig = "584fd4e4b27b0a25140000f5";
					app.Config.AdBannerPluginConfig = {
//						AppGoogleInterstialId: "ca-app-pub-1777019132527367/2672393133",
						AppGoogleInterstialId: "ca-app-pub-1777019132527367/8229937532",
						AppFaceBookInterstialId : "150931201938556_243303672701308",
						AppGoogleRewardedVideoId : "ca-app-pub-1777019132527367/7773351931"
					};
				}
				else{
					app.Config.AdBannerPluginConfig.AppGoogleInterstialId = "ca-app-pub-1777019132527367/2672393133";
				}
				app.Config.AppID = 1065433630;
				app.Config.IAPs = [
					{ProductID: "com.veewo.unlock.glb", NonConsumable:"false"},
					{ProductID: "com.veewo.allcat", NonConsumable:"true"},
					{ProductID: "com.veewo.power", NonConsumable:"false"},
					{ProductID: "com.veewo.moonworld", NonConsumable:"true"},
					{ProductID: "com.veewo.unlockdiscolevel", NonConsumable:"true"}
				];
				app.Config.Achievements = [
					"com.veewo.star1",   // star 1
					"com.veewo.star2",   // star 2
					"com.veewo.star3",   // star 3
					"com.veewo.star4",   // star 4
					"com.veewo.star5",   // star 5
					"com.veewo.flash",   // flash
					"com.veewo.jump",    // jump
					"com.veewo.heart",   // heart
					"com.veewo.coin"     // coin
				];
			}
		} else {
			app.Config.AnalysticsPluginConfig = "9206B621D983CC3399084911F328C4C6";
			if (this.isAndroid) {
				app.Config.IAPConfig = {IAPID : "MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAhrqgfHPe/00xUx3hqR2fTYhnOkKHf+QEhmkvulwareMnmis6iB6EGUBUbs4CZz+xC5z0teVOoYRnvOp01S2233HF57mxcmeMWROkKscm3TKtAKQH3MC9Sqqe4FYkFNxRK/lfrlGQvxPyy8bTqE5+MUtnb4w0IoVdmcQ36Wm9AwWxccak2Oi6EO16ddWNyP4k0A0FpfRLeAA9Apt+yEjU/bDLE51WqmC7/hJALRaqAUf1MjkkUZXFcj3ByhhQYZEcSWVVA0lZHW8EOSvOwU98uLbednvIPeqAwti35J4rPxmCUp/D3G7neKQaxciw1umaDtrvu7wbPCksZ9g9je8ECwIDAQAB"};
				app.Config.AppID = "com.veewo.procat";
				app.Config.packageName = "com.veewo.procat";
				app.Config.GameCenterPluginConfig = {"appid" : "com.veewo.procat"};
				app.Config.Achievements = [
					"CgkIrY2Z6NMaEAIQAQ",   // star 1
					"CgkIrY2Z6NMaEAIQAg",   // star 2
					"CgkIrY2Z6NMaEAIQAw",   // star 3
					"CgkIrY2Z6NMaEAIQBA",   // star 4
					"CgkIrY2Z6NMaEAIQBQ",   // star 5
					"CgkIrY2Z6NMaEAIQBg",   // flash
					"CgkIrY2Z6NMaEAIQBw",   // jump
					"CgkIrY2Z6NMaEAIQCA",   // heart
					"CgkIrY2Z6NMaEAIQCQ"    // coin
				];
			} else {
				app.Config.AppID = 1041873285;
				app.Config.Achievements = [
					"com.veewo.star1",   // star 1
					"com.veewo.star2",   // star 2
					"com.veewo.star3",   // star 3
					"com.veewo.star4",   // star 4
					"com.veewo.star5",   // star 5
					"com.veewo.flash",   // flash
					"com.veewo.jump",    // jump
					"com.veewo.heart",   // heart
					"com.veewo.coin"     // coin
				];
			}
		}

		if (this.isIOSCN) {
			app.Config.AppID = 1106818579;
			app.Config.IAPs = [
				{ProductID: "com.veewo.unlock.cn", NonConsumable:"false"},
				{ProductID: "com.veewo.allcat.cn", NonConsumable:"true"},
				{ProductID: "com.veewo.power.cn", NonConsumable:"false"},
				{ProductID: "com.veewo.moonworld.cn", NonConsumable:"true"}
			];
		}
		if (this.isWeiXin) {
			app.Config.AppDefaultClass = "com/tencent/tmgp/VeeCommon/VeeCommon";
			app.Config.IAPs = [
				{ProductID: "com.veewo.unlock", NonConsumable:"false"},
				{
					idx : "1",
					ProductID : "com.veewo.allcat",
					ProductName : "pdName1",
					ProdustDesc : "pdDesc1",
					ProductNum : "1",
					ProductPrice : "60"
				},
				{
					idx : "2",
					ProductID : "com.veewo.power",
					ProductName : "pdName2",
					ProdustDesc : "pdDesc2",
					ProductNum : "1",
					ProductPrice : "60"
				},
				{
					idx : "3",
					ProductID : "com.veewo.get1energy",
					ProductName : "pdName3",
					ProdustDesc : "pdDesc3",
					ProductNum : "1",
					ProductPrice : "12"
				},
				{
					idx : "4",
					ProductID : "com.veewo.getblackcat",
					ProductName : "pdName4",
					ProdustDesc : "pdDesc4",
					ProductNum : "1",
					ProductPrice : "12"
				},
				{
					idx : "5",
					ProductID : "com.veewo.getcoin",
					ProductName : "pdName5",
					ProdustDesc : "pdDesc5",
					ProductNum : "1",
					ProductPrice : "12"
				},
				{
					idx : "6",
					ProductID : "com.veewo.revivelife",
					ProductName : "pdName6",
					ProdustDesc : "pdDesc6",
					ProductNum : "1",
					ProductPrice : "12"
				},
				{
					idx : "7",
					ProductID : "com.veewo.gettips",
					ProductName : "pdName7",
					ProdustDesc : "pdDesc7",
					ProductNum : "1",
					ProductPrice : "6"
				}
			];
			app.Config.IAPConfig = {
				qqAppId : "1105244297",
				qqAppKey : "GQLuOHdcVCRxjFZL",
				wxAppId : "wx338c6b9e0c9bb5e7",
				msdkKey : "692c4dae5b6bc64a86b373b8d30e130f",
				offerId : "1105244297"
			};
		}
		*/

		// vee.Utils.logObj(app.Config, "zq debug config====");
	},

	loadBtnPos : function () {
		this.btnMovePos = this.getPositionFromStr(vee.data["btnpos1"]);
		this.btnDropPos = this.getPositionFromStr(vee.data["btnpos2"]);
		this.btnJumpPos = this.getPositionFromStr(vee.data["btnpos3"]);
	},

	getPositionFromStr : function (str) {
		if (!str) {
			return null;
		}
		var arrArg = str.split(",");
		if (arrArg.length != 2) {
			return null;
		}
		return cc.p(parseInt(arrArg[0]), parseInt(arrArg[1]));
	},

	resetData : function () {
		game.Data.newMoonLevelIdx = -1;
		cc.log("reset data!");
		game.Data.oPlayerCtl = null;
		this.isLastStageAllCoin = false;
		this.resetTempCoin();
		this.itemCoinPool = [];
		this.enemyPool = [];
		this.usingEnemyPool = [];
		this.tmxInfoStack = [];
		this.arrGrabbedPlatform = [];
		this.arrUpdateObj = [];
		this.arrSkillBoxes = [];
		this.playerInvisible = false;
		this.npcmap = {};
		this.jumpCount = 0;
		this.isEnableCameraYOff = true;
		this.deadCount = 0;
		this.deadCount = 0;
		this.playerHawk = false;
		if (this.isResetSkip) {
			Story.isSkip = false;
			Story.handSkip = false;
		} else {
			this.isResetSkip = true;
		}
		ItemCoin.pool = [];
		EfxDust.init();
		EfxSwitch.pool = [];
		EfxGetCoin.pool = [];
		EfxEnemyDie.pool = [];
		EfxBlockBreak.pool = [];
		EfxUFO.pool = [];
		ElePlayer.tempPlayerCtl = null;
		TileData.BlockSinkDataEfxPool = [];
		EleText.Clear();
		// reset temp stage data
		this.collectedStarCount = 0;
		this.stageMaxCoin = 0;
		Trigger.cameraYFreezed = false;

		EleText.Clear();
		this.bulletCount = 1;
		this.roleType = game.AvatarData.getCurrentAvatar().type;
		switch (this.roleType) {
			case game.Roles.Cop :{
				this.bulletCount = 2;
			}
				break;
			case game.Roles.Girl :{
				this.playerLife = 3;
			}
				break;
			default :
				break;
		}
		this.resetPlayerLife();
	},

	isLastStageAllCoin : false,
	resetEventData : function () {
		game.Data.newMoonLevelIdx = -1;
		game.Data.oPlayerCtl = null;
		this.isLastStageAllCoin = false;
		this.itemCoinPool = [];
		this.enemyPool = [];
		this.usingEnemyPool = [];
		this.tmxInfoStack = [];
		this.arrGrabbedPlatform = [];
		this.arrUpdateObj = [];
		this.arrSkillBoxes = [];
		this.playerInvisible = false;
		this.npcmap = {};
		ItemCoin.pool = [];
		EfxDust.init();
		EfxSwitch.pool = [];
		EfxGetCoin.pool = [];
		EfxEnemyDie.pool = [];
		EfxBlockBreak.pool = [];
		TileData.BlockSinkDataEfxPool = [];
		EleText.Clear();
		// reset temp stage data
		if (this.getTempCoin() >= this.stageMaxCoin) {
			this.isLastStageAllCoin = true;
		}
		this.resetTempCoin();
		this.stageMaxCoin = 0;

		EleText.Clear();
		this.bulletCount = 1;
		this.roleType = game.AvatarData.getCurrentAvatar().type;
		switch (this.roleType) {
			case game.Roles.Cop :{
				this.bulletCount = 2;
			}
				break;
			case game.Roles.Girl :{
				this.playerLife = 3;
			}
				break;
			default :
				break;
		}
		this.resetPlayerLife();
	},

	resetPlayerLife : function() {
		if (this.roleType == game.Roles.Girl) {
			this.playerLife = 3;
		} else {
			this.playerLife = 2;
		}
	},

	setPlayerType : function (type) {
		if (!this.oPlayerCtl) return;
		if (type == game.PlayerType.Normal) {
			switch (this.roleType) {
				case game.Roles.Cop:
					type = game.PlayerType.Bullet;
					break;
//				case game.Roles.bear:
//					type = game.PlayerType.Smash;
//					break;
				default :
					this.oLyGame.hideBButton();
					break;
			}
		}
		else if (type != this.playerType) {
			this.playerType = type;
			this.oLyGame.showBButton();
		}
		this.oPlayerCtl._dtCounter = 9999;
		this.playerType = type;
		if (game.Data.oPlayerCtl.elf) {
			game.Data.oPlayerCtl.elf.show(true);
		}
		switch (this.playerType) {
			case game.PlayerType.Smash:{
				this.BButtonCDTime = 1;
			}
				break;
			case game.PlayerType.Teleport:{
				this.BButtonCDTime = 1;
			}
				break;
			case game.PlayerType.Bullet:{
				this.BButtonCDTime = 0.4;
			}
				break;
			case game.PlayerType.Bomb:{
				this.BButtonCDTime = 1;
			}
				break;
			default :
				break;
		}
		this.oLyGame.refreshBButton(type);
		this.refreshSkillBoxes(type);
	},

	setPlayerInvisible : function (invisible) {
		this.playerInvisible = invisible;
	},

	changePosFunc : null,
	onPlayerChangePos : function (pos) {
		if (this.changePosFunc) this.changePosFunc(pos);
	},
	// for save point
	gridChangeFunc : null,
	onPlayerGridChange : function (grid) {
		if (this.gridChangeFunc) this.gridChangeFunc(grid);
		if (this.npcmap && !Story.isShowStory && !Cinema.isCinema) {
			var pos;
			var playerPos = game.Data.oPlayerCtl._container.getPosition();
			for (var i in this.npcmap) {
				var obj = this.npcmap[i];
				if (obj) {
					pos = obj._container.getPosition();
					if (pos.x > playerPos.x) {
						obj.setFaceTo(vee.Direction.Left);
					} else {
						obj.setFaceTo(vee.Direction.Right);
					}
				}
			}
		}
	},

	costLife : function(count, force) {
		if (!count) count = 1;
		this.oLvCtl.onUpdateLife(-count);
		this.playerLife -= count;
		this.oLyGame.refreshHeart();
		if (this.playerLife <= 0) {
			if ((this.isFreeGame && this.deadCount < 1 && vee.Ad.checkCacheVideoAd() && game.Logic._deadZoneRevivalCount > 0)) {
				++this.deadCount;
				game.Logic._deadZoneRevivalCount = game.Logic._deadZoneRevivalCount - 1;
				/*
				LyVideoAlert.show(LyVideoAlert.Type.FOR_LIFE);
				*/
				ccbRevivalVideoAlert.show(ccbRevivalVideoAlert.revivalType.NORMAL);
				cc.log("zq debug cost life revival video pop========111111");
				//end
			} else {
				this.gameOver();
				cc.log("zq debug cost life revival video pop========222222");
			}
			return false;
		} else if (game.Data.checkIs61() && this.playerLife == 1) {
			if (!game.Data.playerHawk) {
				ElePlayer.transformTo(game.RoleNameStrData.SmallFox);
				ElePlayer.efxMarioShrink();
			}
		}
		return true;
	},


	playOverGid : {},

	gameOver : function () {

		this.playOverGid = cc.p(this.oPlayerCtl._grid.x, this.oPlayerCtl._grid.y);

		vee.Utils.unscheduleAllCallbacksForTarget(game.Data);
		vee.Audio.playEffect(res.inGame_event_deathNoLife_mp3);
		game.Data.oLyGame.gameSlow();
		game.Data.oLyGame._isOver = true;
		this.stageFinish(game.FinishType.DEAD);
		this.oPlayerCtl.elf.hide();
		this.oPlayerCtl._isOver = true;
		this.playerLife = 0;
		this.gameFail();
		this.oPlayerCtl._container.runAction(cc.sequence(
			cc.delayTime(0.4),
			cc.callFunc(function () {
				this.oLyGame.gameOver();
				this.oPlayerCtl.gameOver();
				this.oPlayerCtl._container.stopAllActions();
				this.oPlayerCtl.rootNode.setVisible(false);
				EfxPlayerDie.show(this.oPlayerCtl.getElePosition(), function () {
					if (game.Data.stageType == game.StageType.Mini) {
						vee.GameModule.SceneMgr.openOver();
					} else {
						vee.Transition.out(res.MapTransition_ccbi, function () {
							vee.GameModule.SceneMgr.openOver();
						});
					}
				});
			}.bind(this))
		));
	},

	gameFail : function () {
		if (game.LevelData.selectedLevel) {
			game.LevelData.selectedLevel.levelFail(this.oPlayerCtl._grid);
		}
	},

	addLife : function(count) {
		if (!count) count = 1;
		this.oLvCtl.onUpdateLife(count);

		if (game.Data.checkIs61() && this.playerLife == 1) {
			if (!game.Data.playerHawk) {
				ElePlayer.transformTo(game.RoleNameStrData.Fox);
				ElePlayer.efxMarioGrow();
			}
		}

		this.playerLife += count;
		if (this.playerLife > this.playerMaxLife) {
			this.playerLife = this.playerMaxLife;
		}
		this.oLyGame.refreshHeart();
	},

	addLifeTo : function (to) {
		this.playerLife = to;
		this.oLyGame.refreshHeart();
	},

	addTMXInfo : function(tmxFileName, playerGrid, objMap, tiggerMap) {
		this.tmxInfoStack.push({
			tmxFileName : tmxFileName,
			playerGrid : playerGrid,
			objMap : objMap,
			triggerMap : tiggerMap
		});
	},

	getTMXInfoByName : function (tmxFileName) {
		for (var i = 0; i < this.tmxInfoStack.length; ++i) {
			var info = this.tmxInfoStack[i];
			if (info.tmxFileName == tmxFileName) {
				return {idx : i, info : info};
			}
		}
		return null;
	},

	getEnemyFromPool : function (objType) {
		var len = this.enemyPool.length;
		for (var i = 0; i < len; ++i) {
			var obj = this.enemyPool[i];
			if (obj.objType == objType) {
				obj.rootNode.setVisible(true);
				this.enemyPool.splice(i,1);
				return obj.rootNode;
			}
		}
		return null;
	},

	removeUsingEnemy : function (ctl) {
		for (var i = 0, l = this.usingEnemyPool.length; i < l; ++i) {
			var enemyCtl = this.usingEnemyPool[i];
			if (enemyCtl == ctl) {
				this.usingEnemyPool.splice(i, 1);
			}
		}
	},

	registerUpdateObj : function (obj) {
		this.arrUpdateObj.push(obj);
	},

	removeUpdateObj : function (obj) {
		for (var i = 0, l = this.arrUpdateObj.length; i < l; ++i) {
			var objForCheck = this.arrUpdateObj[i];
			if (objForCheck == obj) {
				this.arrUpdateObj.splice(i, 1);
			}
		}
	},

	addGrabbedPlatform : function (obj) {
		this.arrGrabbedPlatform.push(obj);
	},

	removeGrabbedPlatform : function (obj) {
		for (var i = 0, l = this.arrGrabbedPlatform.length; i < l; ++i) {
			var objForCheck = this.arrGrabbedPlatform[i];
			if (objForCheck == obj) {
				this.arrGrabbedPlatform.splice(i, 1);
			}
		}
	},

	detachAllGrabbedPlatform : function () {
		var len = this.arrGrabbedPlatform.length;
		for (var i = 0; i < len; ++i) {
			var objForCheck = this.arrGrabbedPlatform[i];
			if (objForCheck) objForCheck._isGetPlayer = false;
		}
	},

	getPointFromString : function (str) {
		var arr = str.split(",");
		if (arr.length == 2) {
			return cc.p(parseInt(arr[0]), parseInt(arr[1]));
		} else {
			return null;
		}
	},

	getPointFromString1 : function (str) {
		str = str.substring(1, str.length-1)
		var arr = str.split(",");
		if (arr.length == 2) {
			return cc.p(parseInt(arr[0]), parseInt(arr[1]));
		} else {
			return null;
		}
	},

	addPerformingSkillBoxes : function (grid, layer) {
		var gid = layer.getTileGIDAt(grid);
		if (gid >= 137 && gid <= 140) {
			game.Data.arrSkillBoxes.push({gid : gid, grid : cc.p(grid.x, grid.y), layer : layer});
		}
	},

	refreshSkillBoxes : function (type) {
		var len = this.arrSkillBoxes.length;
		var playerTypeGid = this.playerType2gid(type);
		cc.log("playerTypeGid = "+playerTypeGid);
		for (var i = 0; i < len; ++i) {
			var obj = this.arrSkillBoxes[i];
			var gid = obj.layer.getTileGIDAt(obj.grid);
			cc.log("gid = "+gid);
			if (gid == playerTypeGid) {
				obj.layer.setTileGID(game.BlockType.BreakableBlock, obj.grid);
			}
		}
	},

	playerType2gid : function (type) {
		switch (type) {
			case game.PlayerType.Smash:{
				return game.BlockType.SkillSmash;
			}
				break;
			case game.PlayerType.Teleport:{
				return game.BlockType.SkillTeleport;
			}
				break;
			case game.PlayerType.Bullet:{
				return game.BlockType.SkillBullet;
			}
				break;
			case game.PlayerType.Bomb:{
				return game.BlockType.SkillBomb;
			}
				break;
			default :
				break;
		}
	},

	changeAvatar : function (idx) {
		if (this.oLyGameOver) {
			this.oLyGameOver.changeAvatar(idx);
		}
		BtnShop.refreshHead();
		LyAvatarStore.refreshState();
	},

	stageFinish : function (type) {
		vee.Audio.stopMusic();
		var category = game.LevelData.selectedCategory.idx + 1;
		var level = game.LevelData.selectedLevel.idx + 1;
		var lvName = "";
		if (this.stageType == game.StageType.Mini) {
			lvName = "Mini";
		} else if (this.stageType == game.StageType.Event) {
			lvName = "Event";
		}
		switch (type) {
			case game.FinishType.WIN:
				break;
			case game.FinishType.DEAD:
				this.playerDeadGrid = cc.p(this.oPlayerCtl._grid.x, this.oPlayerCtl._grid.y);
				vee.Analytics.logEvent("GameOver" + lvName + category + "0" + level,
					{"gridx" : ''+this.playerDeadGrid.x, "gridy" : ''+this.playerDeadGrid.y});

				vee.Analytics.UGameEvent.gameEndEvent(lvName, "fail");
				break;
			case game.FinishType.QUIT:
				break;
			default :
				break;
		}
		if (vee.data["stad"] && type != game.FinishType.QUIT) {

		}
	},

	// data...
	getSavePointIdx : function () {
		return vee.dataManager.getSavePointIdx();
	},

	setSavePointIdx : function (idx) {
		vee.dataManager.setSavePointIdx(''+idx);
	},

	resetTempCoin : function () {
		vee.dataManager.setTpCoin(0);
	},

	getTempCoin : function () {
		return vee.dataManager.getTpCoin();
	},

	addTempCoin : function (count) {
		if (!count) count = 1;
		vee.dataManager.setTpCoin(vee.dataManager.getTpCoin() + count);
		if (this.oLyGame) this.oLyGame.refreshCoin();
	},

	setSelectedLvIdx : function (idx) {
		vee.dataManager.setSelectLvIdx(idx);
	},

	getSelectedLvIdx : function () {
		return vee.dataManager.getSelectLvIdx();
	},

	getEnergy : function () {
		var e = parseInt(vee.dataManager.getEnergy());
		if (!e && e != 0) {
			this.fillEnergy();
			e = 5;
		}
		if (e < 5) {
			var ts = this.getEnergyReviveTs();
			var nowTs = new Date().getTime();
			var tsOff = nowTs - ts;
			if (tsOff > 0) {
				var reviveCount = 1;
				reviveCount += Math.floor(tsOff/this.energyReviveDelay);
				this.addEnergy(reviveCount);
				e = parseInt(vee.dataManager.getEnergy());
				if (e < 5) vee.dataManager.setEnergyTs(this.nextEnergyTsFromNow());
			}
		}
		return e;
	},

	//jin
	onEnergyEmpty : function(emptyType) {
		if (game.Data.getPower() > 0) {
			AlertUsePower.show(emptyType);
		} else {
			AlertGetPower.show(emptyType);
		}
	},

	getPower : function() {
		return parseInt(vee.dataManager.getPower());
	},

	getPowerLeftTime : function() {
		var tCur = vee.Utils.getTimeNow();
		var tStart = vee.dataManager.getPowerTs();
		var tLeft = game.Data.energyUnlimitedTime * 60 - (tCur - tStart) / 1000;
		return tLeft > 0 ? tLeft : 0;
	},

	getLevel61LeftTime : function() {
		var tCur = vee.Utils.getTimeNow();
		var tStart = vee.data["level61_ts"];
		var tLeft = game.Data.level61Time * 60 - (tCur - tStart) / 1000;
		return tLeft > 0 ? tLeft : 0;
	},

	addEnergy : function (count) {
		count = count ? count : 1;
		var e = parseInt(vee.dataManager.getEnergy());
		if (e >= 5) return;
		var newE = (e + count) > 5 ? 5 : (e + count);
		vee.dataManager.setEnergy(newE);
	},

	fillEnergy : function () {
		vee.dataManager.setEnergy(5);
	},

	energyUnlimited : function (min) {
		var ts = new Date().getTime();
		vee.data["ultE_ts"] = ts;
		vee.data["ultEitv"] = (min*60*1000);
		vee.saveData();
	},

	isEnergyUnlimited : function () {
		if (this.isAndroidTV_test) return true;
		var tsNow = new Date().getTime();
		var energyTs = parseInt(vee.data["ultE_ts"]);
		var energyItv = parseInt(vee.data["ultEitv"]);
		if (tsNow - energyItv < energyTs) {
			return true;
		} else {
			return false;
		}
	},

	costEnergy : function () {
		var e = parseInt(vee.dataManager.getEnergy());
		if (game.Data.isEnergyUnlimited() || !game.Data.isFreeGame) {
			return true;
		} else if (e < 1) {
			return false;
		} else {
			if (e == 5) {
				vee.dataManager.setEnergyTs(this.nextEnergyTsFromNow());
			}
			if (this.oEnergyCtl) this.oEnergyCtl.costAnimate();
			vee.dataManager.setEnergy(e - 1);
			return true;
		}
	},

	nextEnergyTsFromNow : function () {
		var nowTs = new Date().getTime();
		return nowTs + this.energyReviveDelay;// 5 min...
	},

	getEnergyReviveTs : function () {
		return vee.dataManager.getEnergyTs();
	},

	getMiniCount : function () {
		if (game.LevelData.selectedCategory && game.LevelData.selectedCategory.idx > 0) {
			var count = parseInt(vee.data["mini"]);
			if (!count && count != 0) {
				count = 0;
				vee.saveData();
			}
			return count;
		} else {
			return 0;
		}
	},

	addMiniCount : function (count) {
		if (game.LevelData.selectedCategory && game.LevelData.selectedCategory.idx > 0) {
			if (game.Data.stageType == game.StageType.Mini) return;
			if (!count) count = 1;
			var mini = this.getMiniCount();
			vee.data["mini"] = mini + parseInt(count);
			vee.saveData();
		}
	},

	resetMiniCount : function () {
		vee.data["mini"] = 0;
		vee.saveData();
	},

	getEventCount : function () {
		var count = parseInt(vee.data["event"]);
		if (!count && count != 0) {
			count = 0;
			vee.saveData();
		}
		return count;
	},

	addEventCount : function (count) {
		if (!count) count = 1;
		var event = this.getEventCount();
		vee.data["event"] = event + parseInt(count);
		vee.saveData();
	},

	resetEventCount : function () {
		vee.data["event"] = 0;
		vee.saveData();
	},

	setUnlocking : function (isUnlock) {
		vee.data["ulk"] = isUnlock;
		vee.saveData();
		this.resetEventCount();
	},

	isUnlocking : function () {
		if (vee.data["ulk"]) {
			return true;
		} else {
			return false;
		}
	},

	addPlayCount : function () {
		var pc = this.getPlayCount();
		vee.data["pc"] = parseInt(pc) + 1;
		vee.saveData();
	},

	isRated : function () {
		return vee.data["rated"];
	},

	rated : function () {
		vee.data["rated"] = true;
		vee.saveData();
	},

	getPlayCount : function () {
		var count = parseInt(vee.data["pc"]);
		if (!count && count != 0) {
			count = 0;
			vee.saveData();
		}
		return count;
	},

	resetPlayCount : function () {
		vee.data["pc"] = 0;
		vee.saveData();
	},

	getTotalPlayCount : function () {
		var count = parseInt(vee.data["tpc"]);
		if (!count && count != 0) {
			count = 0;
			vee.saveData();
		}
		return count;
	},

	addTotalPlayCount : function () {
		var tpc = this.getTotalPlayCount();
		vee.data["tpc"] = parseInt(tpc) + 1;
		vee.saveData();

		cc.log("zq debug playCount=====%d", vee.data["tpc"]);
		vee.Analytics.UGameEvent.registerSuperProperty("super_playCount", vee.data["tpc"]);
	},

	// about ads...
	playCountThisGame : 0,
	banAdThisGame : false,
	showBanAd : function () {
		if (vee.data["stad"]
			&& vee.data["tenStage"]
			&& (this.playCountThisGame == 0 || this.playCountThisGame >= 5)
			&& !this.banAdThisGame)
		{
			LyReward.show(LyReward.Type.BanAd);
		}
	},

	getAdConfigBy : function (type) {
		if (type == game.AdType.GameStart) {
			var c = game.Data.getTotalPlayCount();
			if (c%2 == 0) {
				type = "Even";
			} else {
				type = "Odd";
			}
		}
		return {AppGoogleInterstialId: app.Config["Ad"+type]};
	},

	isStaticBG : function () {
		return vee.data["staticBG"];
	},

	setStaticBG : function (isStatic) {
		vee.data["staticBG"] = isStatic;
		vee.saveData();
	},

	isGestureControl : function () {
		return vee.data["gesture"];
	},

	setGestureControl : function (isGesture) {
		vee.data["gesture"] = isGesture;
		vee.saveData();
	},

	isSmallButton : function () {
		return vee.data["small"];
	},
	setSmallButton : function (isSmall) {
		vee.data["small"] = isSmall;
		vee.saveData();
	},

	isNewReverseWorld : false,
	isShowBtnWorld : function () {
		return vee.data["show_btn_world"];
	},

	checkShowBtnWorld : function () {
		var isShow = vee.data["show_btn_world"];
		if (!isShow) {
			var avatarData = game.AvatarData.getAvatarData(1);
			// it means... kevo is unlocking, stage 1-3 is finished.
			if ((this.isUnlocking() || avatarData.owned) && this.isReverseWorldOpen) {
				this.isNewReverseWorld = true;
				vee.data["show_btn_world"] = true;
				vee.saveData();
			}
		}
	},

	checkIs61 : function () {
		if (game.LevelData.selectedCategory) {
			var category = game.LevelData.selectedCategory.idx + 1;
			if (category == 7) {
				return true;
			}
		}
		return false;
	},

	checkIsMidAutumn : function(){
		if(game.Data.version.isMidAutumn && game.LevelData.selectedCategory)	{
			var category = game.LevelData.selectedCategory.idx + 1;
			if (category == 8) {
				return true;
			}
		}
		return false;
	},

	checkIsHolloween : function () {

		if(game.Data.version.isSetShowSpecialEvent && game.LevelData.selectedCategory)	{
			var category = game.LevelData.selectedCategory.idx + 1;
			if (category == 9) {
				return true;
			}
		}
		return false;
	},

	checkIsThanksgiving : function () {
		if(game.Data.version.isSetShowSpecialEvent && game.LevelData.selectedCategory)	{
			var category = game.LevelData.selectedCategory.idx + 1;
			if (category == 10) {
				return true;
			}
		}
		return false;
	},

	isTipsPurchased : function (idx) {
		return vee.data["buy"+idx+"tips"];
	},
	
	purchaseTip : function (idx) {
		vee.data["buy"+idx+"tips"] = true;
		vee.saveData();
	},

	getStoryHasPlayed : function (tmxIdx, storyIdx) {
		var stageTypeStr = this.getStageTypeString(game.Data.stageType);
		var storyHasPlayed = vee.data[stageTypeStr+"story"+tmxIdx+"-"+storyIdx];
		return storyHasPlayed;
	},

	setStoryHasPlayed : function (tmxIdx, storyIdx, state) {
		var stageTypeStr = this.getStageTypeString(game.Data.stageType);
		vee.data[stageTypeStr+"story"+tmxIdx+"-"+storyIdx] = state;
		vee.saveData();
	},

	getStageTypeString : function (stageType) {
		switch (stageType) {
			case game.StageType.Event:
				return "Event";
			case game.StageType.Mini:
				return "Mini";
			default :
				return "";
		}
	},

	isInParkour : function(){
		return this.stageType == game.StageType.Parkour;
	},

	isUnlockMoon : function(){

	}
};

game.AdType = {
	Odd      : "Odd",
	Even     : "Even",
	Pause    : "Pause",
	GameOver : "GameOver",
	StartUp  : "StartUp",
	Exit     : "Exit",
	GameStart : 1
};

game.PlayerType = {
	Normal      : 1,
	Bullet      : 2,
	Smash       : 3,
	Teleport    : 4,
	Bomb        : 5,
	Hawk        : 6
};

game.StageType = {
	Normal  : 1,
	Mini    : 2,
	Event   : 3,
	Parkour : 4
};

game.Roles = {
	Cat     : 1,
	Normal  : 2,
	Kevo    : 3,
	Flash   : 4,
	Cop     : 5,
	Space   : 6,
	Girl    : 7,
	Vampire : 8,
	Marvin  : 9,
	bear    : 10,
	Tiny    : 11,
	//jin
	MaNtIs  : 12,
	Android : 13,
	Fox : 14,
	Robbit : 15,     //mid-aut
	Holloween : 16,
	Blast : 17
};

game.RoleNameStrData = {
	'cat'      : res.elePlayer_Zhai_ccbi,
	'Kevo'     : res.hero_kevo_ccbi,
	'Flash'    : res.hero_davinci_ccbi,
	'Cop'      : res.hero_cap_ccbi,
	'Spaceman' : res.hero_nasa_ccbi,
	'Hermione' : res.hero_girl_ccbi,
	'Vampire'  : res.hero_dracula_ccbi,
	'M-42'     : res.hero_marvin_ccbi,
	'Bear'     : res.hero_beer_ccbi,
	'Tiny'     : res.hero_ji_ccbi,
	'Phantom'  : res.hero_blackcat_ccbi,
	'SmallCat' : res.hero_smallcat_ccbi,
	'MaNtIs'   : res.hero_m_ccbi,
	'Android'  : res.hero_android_ccbi,
	'SmallFox' : res.hero_smallfox_ccbi,
	'Fox'      : res.hero_fox_ccbi
};

game.RoleNameStrDataRevert = {
	"res/elePlayer_Zhai.ccbi" : 'cat',
	"res/hero_kevo.ccbi" : 'Kevo',
	"res/hero_davinci.ccbi" : 'Flash',
	"res/hero_cap.ccbi" : 'Cop',
	"res/hero_nasa.ccbi" : 'Spaceman',
	"res/hero_girl.ccbi" : 'Hermione',
	"res/hero_dracula.ccbi" : 'Vampire',
	"res/hero_marvin.ccbi" : 'M-42',
	"res/hero_beer.ccbi" : 'Bear',
	"res/hero_ji.ccbi" : 'Tiny',
	"res/hero_blackcat.ccbi" : 'Phantom',
	"res/hero_smallcat.ccbi" : 'SmallCat',
	"res/hero_m.ccbi"		 : 'MaNtIs',
	"res/hero_android.ccbi"  : 'Android'
};

game.RoleSoundData = {
	'cat'      : { soundFileCharacterName : "",          soundIdxRange : 2},
	'Kevo'     : { soundFileCharacterName : "kevo",      soundIdxRange : 2},
	'Flash'    : { soundFileCharacterName : "flashEyes", soundIdxRange : 2},
	'Cop'      : { soundFileCharacterName : "cop",       soundIdxRange : 2},
	'Spaceman' : { soundFileCharacterName : "spaceman",  soundIdxRange : 2},
	'Hermione' : { soundFileCharacterName : "hermione",  soundIdxRange : 2},
	'Vampire'  : { soundFileCharacterName : "vampire",   soundIdxRange : 2},
	'M-42'     : { soundFileCharacterName : "m-42",      soundIdxRange : 2},
	'Bear'     : { soundFileCharacterName : "fearBear",  soundIdxRange : 2},
	'Tiny'     : { soundFileCharacterName : "tiny",      soundIdxRange : 3},
	'Phantom'  : { soundFileCharacterName : "phantom",   soundIdxRange : 2},
	'SmallCat' : { soundFileCharacterName : "smallCat",  soundIdxRange : 2},
	'MaNtIs'   : { soundFileCharacterName : "mantis",    soundIdxRange : 2},
	'Android'  : { soundFileCharacterName : "android",   soundIdxRange : 2}
};

game.LayerType = {
	Main : 1,
	Extra : 2
};

game.SecretLayerStatus = {
	Hide : 0,
	Show : 1
};

game.EleType = {
	Player : 0,
	Enemy : 1,
	Item : 2,
	Trigger : 3
};

game.FinishType = {
	WIN  : 1,
	DEAD : 2,
	QUIT : 3
};

//jin
game.LifeEmptyType = {
	Select : 0,
	Lose : 1
	//WinRetry : 2,
	//WinNext : 3
};

game.ObjectType = {
	None           : -1,
	// Enemy
	Slime          : 0,
	DogSlime       : 1,
	Cannon         : 2,
	Susliks        : 3,
	Spider         : 4,
	Moth           : 5,
	ArmorSlime     : 6,
	ArmorSlimeHawk : 7,
	SusliksHawk    : 8,
	Bee            : 9,
	FastBee        : 10,
	JumpSlime      : 11,
	JumpSlimeLink  : 12,
	Fish           : 13,
	Flight         : 14,
	MadBee         : 15,
	DrillDog       : 16,
	MapEater       : 17,
	JumpFrog       : 18,

	// Item
	Coin            : 100,
	Egg             : 101,
	Heart           : 102,
	Accelerater     : 103,
	BigCoin         : 104,
	DynamicBlock    : 105,
	MovingPlatform  : 106,
	GravityPlatform : 107,
	FallingBlock    : 108,
	Fire            : 112,
	BoxSmash        : 113,
	BoxBullet       : 114,
	BoxTeleport     : 115,
	BoxBomb         : 116,
	Drawer          : 117,
	Bullet          : 118,
	SavePoint       : 119,
	StageEnd        : 120,
	SkillSmash      : 121,
	SkillBullet     : 122,
	SkillTeleport   : 123,
	SkillBomb       : 124,
	BoxHawk         : 125,
	ReverseKey      : 126,

	//add for Mid-Autumn Festival
	ScaleBlock         : 130,

	// Block
	Block           : 1000,
	BlockOneWay     : 1001,
	Slope           : 1002,
	BlockHide       : 1003,
	BlockStab       : 1004,
	BlockHurt       : 1005,
	BlockBounce     : 1006,
	BlockBomb       : 1007,
	BlockBreakable     : 1008,
	BlockSwitchOn      : 1009,
	BlockSwitchOff     : 1010,
	BlockSwitchDisable : 1011,
	BlockSink          : 1012,
	BlockTrap          : 1013,

	BlockScale         : 1019,



	// Others
	NPC : 2000
};

game.enemyStringMap = {
	slime          : game.ObjectType.Slime,
	dogSlime       : game.ObjectType.DogSlime,
	carrot         : game.ObjectType.Cannon,
	spider         : game.ObjectType.Spider,
	moth           : game.ObjectType.Moth,
	armorSlime     : game.ObjectType.ArmorSlime,
	armorSlimeHawk : game.ObjectType.armorSlimeHawk,
	susliksHawk    : game.ObjectType.SusliksHawk,
	Bees           : game.ObjectType.Bee,
	fastBee        : game.ObjectType.FastBee,
	fish           : game.ObjectType.Fish,
	jumpSlime      : game.ObjectType.JumpSlime,
	flight         : game.ObjectType.Flight,
	madbee         : game.ObjectType.MadBee,
	frog           : game.ObjectType.JumpFrog
};

game.itemStringMap = {
	coin : game.ObjectType.Coin,
	egg : game.ObjectType.Egg,
	heart : game.ObjectType.Heart,
	key : game.ObjectType.ReverseKey,

	boxSmash : game.ObjectType.BoxSmash,
	boxBullet : game.ObjectType.BoxBullet,
	boxTeleport : game.ObjectType.BoxTeleport,
	boxBomb : game.ObjectType.BoxBomb
};

game.BlockType = {
	HideBlock       : 10,
	DynamicBlock    : 61,
	BreakableBlock  : 66,
	SwitchShow      : 108,
	SwitchHide      : 109,
	SwitchDisable   : 110,
	BounceBlock     : 65,
	BombBlock       : 79,
	QuestionBlock   : 62,
	Coin            : 81,
	MovingPlatform  : 74,
	FallingPlatform : 75,
	GravityPlatform : 76,
	SkillSmash      : 137,
	SkillBullet     : 138,
	SkillTeleport   : 139,
	SkillBomb       : 140,
	MoonBlock       : 107
};

game.TileInfo = {
	TileBlock : {
		type : game.ObjectType.Block,
		GID : 10,
		isVertical : false,
		orientation : vee.Direction.Top,
		edgeTop : 0,
		edgeBottom : 0,
		edgeLeft : game.Data.tileSizeWidth,
		edgeRight : game.Data.tileSizeWidth,
		slope : 0,
		speedScale : 1
	},
	TileBlockHide : {
		type : game.ObjectType.BlockHide,
		GID : 10,
		isVertical : false,
		orientation : vee.Direction.Top,
		edgeTop : 0,
		edgeBottom : 0,
		edgeLeft : game.Data.tileSizeWidth,
		edgeRight : game.Data.tileSizeWidth,
		slope : 0,
		speedScale : 1
	},
	TileBlockHurt : {
		type : game.ObjectType.BlockHurt,
		GID : 10,
		isVertical : false,
		orientation : vee.Direction.Top,
		edgeTop : 0,
		edgeBottom : 0,
		edgeLeft : game.Data.tileSizeWidth,
		edgeRight : game.Data.tileSizeWidth,
		slope : 0,
		speedScale : 1
	},
	TileBlockHurtHalf : {
		type : game.ObjectType.BlockHurt,
		GID : 10,
		isVertical : false,
		orientation : vee.Direction.Top,
		edgeTop : 0,
		edgeBottom : 0,
		edgeLeft : TILE_WIDTH_HALF,
		edgeRight : TILE_WIDTH_HALF,
		slope : 0,
		speedScale : 1
	},
	TileBlockHalf : {
		type : game.ObjectType.BlockStab,
		GID : 10,
		isVertical : false,
		orientation : vee.Direction.Top,
		edgeTop : 0,
		edgeBottom : 0,
		edgeLeft : game.Data.tileSizeWidthHalf - 4,
		edgeRight : game.Data.tileSizeWidthHalf - 4,
		slope : 0,
		speedScale : 1
	},
	TileBlockTopHalf : {
		type : game.ObjectType.Block,
		GID : 10,
		isVertical : false,
		orientation : vee.Direction.Bottom,
		edgeTop : 0,
		edgeBottom : 0,
		edgeLeft : game.Data.tileSizeWidth - 10,
		edgeRight : game.Data.tileSizeWidth - 10,
		slope : 0,
		speedScale : 1
	},
	TileBlockOneWay : {
		type : game.ObjectType.BlockOneWay,
		GID : 10,
		isVertical : false,
		orientation : vee.Direction.Top,
		edgeTop : 0,
		edgeBottom : 0,
		edgeLeft : game.Data.tileSizeWidth,
		edgeRight : game.Data.tileSizeWidth,
		slope : 0,
		speedScale : 1
	},
	TileUPSlope : {
		type : game.ObjectType.Slope,
		GID : 34,
		isVertical : false,
		orientation : vee.Direction.Top,
		edgeTop : 0,
		edgeBottom : 0,
		edgeLeft : 0,
		edgeRight : game.Data.tileSizeWidth,
		slope : 1,
		speedScale : 0.7
	},
	TileDownSlope : {
		type : game.ObjectType.Slope,
		GID : 44,
		isVertical : false,
		orientation : vee.Direction.Top,
		edgeTop : 0,
		edgeBottom : 0,
		edgeLeft : game.Data.tileSizeWidth,
		edgeRight : 0,
		slope : -1,
		speedScale : 0.7
	},
	TileUpSlopeZeroToHalf : {
		type : game.ObjectType.Slope,
		GID : 34,
		isVertical : false,
		orientation : vee.Direction.Top,
		edgeTop : 0,
		edgeBottom : 0,
		edgeLeft : 0,
		edgeRight : game.Data.tileSizeWidthHalf,
		slope : 0.5,
		speedScale : 0.85
	},
	TileUpSlopeHalfToTop : {
		type : game.ObjectType.Slope,
		GID : 34,
		isVertical : false,
		orientation : vee.Direction.Top,
		edgeTop : 0,
		edgeBottom : 0,
		edgeLeft : game.Data.tileSizeWidthHalf+1,
		edgeRight : game.Data.tileSizeWidth,
		slope : 0.5,
		speedScale : 0.85
	},
	TileUpSlopeLeftToHalf : {
		type : game.ObjectType.Slope,
		GID : 56,
		isVertical : false,
		orientation : vee.Direction.Left,
		edgeTop : game.Data.tileSizeWidthHalf,
		edgeBottom : 0,
		edgeLeft : 0,
		edgeRight : 0,
		slope : 2,
		speedScale : 0.5
	},
	TileUpSlopeLeftToZero : {
		type : game.ObjectType.Slope,
		GID : 56,
		isVertical : false,
		orientation : vee.Direction.Left,
		edgeTop : game.Data.tileSizeWidth,
		edgeBottom : game.Data.tileSizeWidthHalf,
		edgeLeft : 0,
		edgeRight : 0,
		slope : 2,
		speedScale : 0.5
	},
	TileDownSlopeTopToHalf : {
		type : game.ObjectType.Slope,
		GID : 44,
		isVertical : false,
		orientation : vee.Direction.Top,
		edgeTop : 0,
		edgeBottom : 0,
		edgeLeft : game.Data.tileSizeWidth,
		edgeRight : game.Data.tileSizeWidthHalf+1,
		slope : -0.5,
		speedScale : 0.85
	},
	TileDownSlopeHalfToZero : {
		type : game.ObjectType.Slope,
		GID : 44,
		isVertical : false,
		orientation : vee.Direction.Top,
		edgeTop : 0,
		edgeBottom : 0,
		edgeLeft : game.Data.tileSizeWidthHalf,
		edgeRight : 0,
		slope : -0.5,
		speedScale : 0.85
	},
	TileDownSlopeRightToHalf : {
		type : game.ObjectType.Slope,
		GID : 56,
		isVertical : false,
		orientation : vee.Direction.Right,
		edgeTop : game.Data.tileSizeWidthHalf,
		edgeBottom : game.Data.tileSizeWidth,
		edgeLeft : 0,
		edgeRight : 0,
		slope : -2,
		speedScale : 0.5
	},
	TileDownSlopeRightToZero : {
		type : game.ObjectType.Slope,
		GID : 56,
		isVertical : false,
		orientation : vee.Direction.Right,
		edgeTop : 0,
		edgeBottom : game.Data.tileSizeWidthHalf,
		edgeLeft : 0,
		edgeRight : 0,
		slope : -2,
		speedScale : 0.5
	},
	TileBlockBounce : {
		type : game.ObjectType.BlockBounce,
		GID : 10,
		isVertical : false,
		orientation : vee.Direction.Top,
		edgeTop : 0,
		edgeBottom : 0,
		edgeLeft : TILE_WIDTH,
		edgeRight : TILE_WIDTH,
		slope : 0,
		speedScale : 1
	},
	TileBlockFade : {
		type : game.ObjectType.Block,
		GID : 10,
		isVertical : false,
		orientation : vee.Direction.Top,
		edgeTop : 0,
		edgeBottom : 0,
		edgeLeft : game.Data.tileSizeWidth,
		edgeRight : game.Data.tileSizeWidth,
		slope : 0,
		speedScale : 1
	},
	TileBlockBomb : {
		type : game.ObjectType.BlockBomb,
		GID : 10,
		isVertical : false,
		orientation : vee.Direction.Top,
		edgeTop : 0,
		edgeBottom : 0,
		edgeLeft : game.Data.tileSizeWidth,
		edgeRight : game.Data.tileSizeWidth,
		slope : 0,
		speedScale : 1
	},
	TileBlockBreakable : {
		type : game.ObjectType.BlockBreakable,
		GID : 10,
		isVertical : false,
		orientation : vee.Direction.Top,
		edgeTop : 0,
		edgeBottom : 0,
		edgeLeft : game.Data.tileSizeWidth,
		edgeRight : game.Data.tileSizeWidth,
		slope : 0,
		speedScale : 1
	},
	TileBlockSwitchOn : {
		type : game.ObjectType.BlockSwitchOn,
		GID : 10,
		isVertical : false,
		orientation : vee.Direction.Top,
		edgeTop : 0,
		edgeBottom : 0,
		edgeLeft : game.Data.tileSizeWidth,
		edgeRight : game.Data.tileSizeWidth,
		slope : 0,
		speedScale : 1
	},
	TileBlockSwitchOff : {
		type : game.ObjectType.BlockSwitchOff,
		GID : 10,
		isVertical : false,
		orientation : vee.Direction.Top,
		edgeTop : 0,
		edgeBottom : 0,
		edgeLeft : game.Data.tileSizeWidth,
		edgeRight : game.Data.tileSizeWidth,
		slope : 0,
		speedScale : 1
	},
	TileBlockSwitchDisable : {
		type : game.ObjectType.BlockSwitchDisable,
		GID : 10,
		isVertical : false,
		orientation : vee.Direction.Top,
		edgeTop : 0,
		edgeBottom : 0,
		edgeLeft : game.Data.tileSizeWidth,
		edgeRight : game.Data.tileSizeWidth,
		slope : 0,
		speedScale : 1
	},
	TileBlockSink : {
		type : game.ObjectType.BlockSink,
		GID : 10,
		isVertical : false,
		orientation : vee.Direction.Top,
		edgeTop : 0,
		edgeBottom : 0,
		edgeLeft : game.Data.tileSizeWidth,
		edgeRight : game.Data.tileSizeWidth,
		slope : 0,
		speedScale : 1
	},
	TileBlockTrap : {
		type : game.ObjectType.BlockTrap,
		GID : 10,
		isVertical : false,
		orientation : vee.Direction.Top,
		edgeTop : 0,
		edgeBottom : 0,
		edgeLeft : game.Data.tileSizeWidth,
		edgeRight : game.Data.tileSizeWidth,
		slope : 0,
		speedScale : 1
	},

	TileBlockScale : {
		type : game.ObjectType.BlockScale,
		edgeTop : 0,
		edgeBottom : 0,
		edgeLeft : game.Data.tileSizeWidth,
		edgeRight : game.Data.tileSizeWidth,
		slope : 0,
		speedScale : 1
	},

	TileHorizonBounce : {
		type : game.ObjectType.Block,
		edgeTop : 0,
		edgeBottom : 0,
		edgeLeft : game.Data.tileSizeWidth,
		edgeRight : game.Data.tileSizeWidth,
		slope : 0,
		speedScale : 1
	},


	// enemies...
	TileEnemySlime : {
		type : game.ObjectType.Slime,
		faceDir : vee.Direction.Left
	},
	TileEnemyDogSlime : {
		type : game.ObjectType.DogSlime,
		faceDir : vee.Direction.Left
	},
	TileEnemyCannon : {
		type : game.ObjectType.Cannon,
		faceDir : vee.Direction.Left
	},
	TileEnemySpider : {
		type : game.ObjectType.Spider,
		faceDir : vee.Direction.Left
	},
	TileEnemyArmorSlime : {
		type : game.ObjectType.ArmorSlime,
		faceDir : vee.Direction.Left
	},
	TileEnemyArmorSlimeHawk : {
		type : game.ObjectType.ArmorSlimeHawk,
		faceDir : vee.Direction.Left
	},
	TileEnemySusliksHawk : {
		type : game.ObjectType.SusliksHawk,
		faceDir : vee.Direction.Left
	},
	TileEnemyJumpSlime : {
		type : game.ObjectType.JumpSlime,
		faceDir : vee.Direction.Left
	},
	TileEnemyMoth : {
		type : game.ObjectType.Moth,
		faceDir : vee.Direction.Left
	},
	TileEnemyBee : {
		type : game.ObjectType.Bee,
		faceDir : vee.Direction.Left
	},
	TileEnemyFastBee : {
		type : game.ObjectType.FastBee,
		faceDir : vee.Direction.Left
	},
	TileEnemyFish : {
		type : game.ObjectType.Fish,
		faceDir : vee.Direction.Left
	},
	TileEnemyFlight : {
		type : game.ObjectType.Flight,
		faceDir : vee.Direction.Left
	},
	TileEnemyMadBee : {
		type : game.ObjectType.MadBee,
		faceDir : vee.Direction.Left
	},
	TileEnemyDrillDog : {
		type : game.ObjectType.DrillDog,
		faceDir : vee.Direction.Left
	},
	TileEnemyJumpFrog : {
		type : game.ObjectType.JumpFrog,
		faceDir : vee.Direction.Left
	},
	TileEnemyMapEater : {
		type : game.ObjectType.MapEater,
		faceDir : vee.Direction.Left
	},

	// items...
	TileItemCoin : {
		type : game.ObjectType.Coin
	},
	TileItemBigCoin : {
		type : game.ObjectType.BigCoin
	},
	TileItemEgg : {
		type : game.ObjectType.Egg
	},
	TileItemHeart : {
		type : game.ObjectType.Heart
	},
	TileItemAccelerater : {
		type : game.ObjectType.Accelerater
	},
	TileItemMovingPlatform : {
		type : game.ObjectType.MovingPlatform
	},
	TileItemGravityPlatform : {
		type : game.ObjectType.GravityPlatform
	},
	TileItemFallingBlock : {
		type : game.ObjectType.FallingBlock
	},
	TileItemFire : {
		type : game.ObjectType.Fire
	},
	TileItemBoxSmash : {
		type : game.ObjectType.BoxSmash
	},
	TileItemBoxBullet : {
		type : game.ObjectType.BoxBullet
	},
	TileItemBoxTeleport : {
		type : game.ObjectType.BoxTeleport
	},
	TileItemBoxBomb : {
		type : game.ObjectType.BoxBomb
	},
	TileItemBoxHawk : {
		type : game.ObjectType.BoxHawk
	},
	TileItemDrawer : {
		type : game.ObjectType.Drawer
	},
	TileItemReverseKey : {
		type : game.ObjectType.ReverseKey
	},
	TileItemSavePoint : {
		type : game.ObjectType.SavePoint
	},
	TileItemStageEnd : {
		type : game.ObjectType.StageEnd
	},

	TileItemScaleBlock : {
		type : game.ObjectType.ScaleBlock
	},

	TileNPC : {
		type : game.ObjectType.NPC
	}
};

game.TileIDInfo = {
	// Tile
	Tile1 : game.TileInfo.TileBlock,
	Tile2 : game.TileInfo.TileBlock,
	Tile3 : game.TileInfo.TileBlock,
	Tile4 : game.TileInfo.TileBlock,
	Tile5 : game.TileInfo.TileBlock,
	Tile6 : game.TileInfo.TileBlock,
	Tile7 : game.TileInfo.TileBlock,
	Tile8 : game.TileInfo.TileBlock,
	Tile9 : game.TileInfo.TileBlock,
	Tile10 : game.TileInfo.TileBlock,
	Tile11 : game.TileInfo.TileBlock,
	Tile12 : game.TileInfo.TileBlock,
	Tile13 : game.TileInfo.TileBlock,
	Tile14 : game.TileInfo.TileBlock,
	Tile15 : game.TileInfo.TileBlock,
	Tile16 : game.TileInfo.TileBlock,
	Tile17 : game.TileInfo.TileBlock,
	Tile18 : game.TileInfo.TileBlock,
	Tile19 : game.TileInfo.TileBlock,
	Tile20 : game.TileInfo.TileBlock,
	Tile30 : game.TileInfo.TileBlock,
	Tile41 : game.TileInfo.TileUPSlope,
	Tile42 : game.TileInfo.TileDownSlope,
	Tile43 : game.TileInfo.TileUpSlopeZeroToHalf,
	Tile44 : game.TileInfo.TileUpSlopeHalfToTop,
	Tile45 : game.TileInfo.TileDownSlopeTopToHalf,
	Tile46 : game.TileInfo.TileDownSlopeHalfToZero,
	Tile47 : game.TileInfo.TileUpSlopeLeftToZero,
	Tile48 : game.TileInfo.TileDownSlopeRightToZero,
	Tile57 : game.TileInfo.TileUpSlopeLeftToHalf,
	Tile58 : game.TileInfo.TileDownSlopeRightToHalf,
	Tile61 : game.TileInfo.TileBlock,
	Tile62 : game.TileInfo.TileBlockBreakable,
	Tile64 : game.TileInfo.TileBlock,
	Tile65 : game.TileInfo.TileBlockBounce,
	Tile66 : game.TileInfo.TileBlockBreakable,
	Tile67 : game.TileInfo.TileBlockOneWay,
	Tile68 : game.TileInfo.TileBlockOneWay,
	Tile69 : game.TileInfo.TileBlockBreakable,

	Tile70 : game.TileInfo.TileBlockBreakable,

	Tile134 : game.TileInfo.TileHorizonBounce,      //parkour 反弹砖块
	Tile135 : game.TileInfo.TileHorizonBounce,

	Tile71 : game.TileInfo.TileBlockHurt,
	Tile72 : game.TileInfo.TileBlockHurt,
	Tile73 : game.TileInfo.TileBlockHurt,
	Tile77 : game.TileInfo.TileBlockHalf,
	Tile78 : game.TileInfo.TileBlockFade,
	Tile79 : game.TileInfo.TileBlockBomb,
	Tile93 : game.TileInfo.TileBlockOneWay,
	Tile94 : game.TileInfo.TileBlock,
	Tile97 : game.TileInfo.TileBlockOneWay,
	Tile108 : game.TileInfo.TileBlock,
	Tile109 : game.TileInfo.TileBlock,
	Tile110 : game.TileInfo.TileBlock,
	Tile137 : game.TileInfo.TileBlockBreakable,
	Tile138 : game.TileInfo.TileBlockBreakable,
	Tile139 : game.TileInfo.TileBlockBreakable,
	Tile140 : game.TileInfo.TileBlockBreakable,
	Tile37 : game.TileInfo.TileBlockSink,
	Tile38 : game.TileInfo.TileBlockSink,

	Tile141 : game.TileInfo.TileBlockScale,
	Tile142 : game.TileInfo.TileBlockScale,
	Tile143 : game.TileInfo.TileBlockScale,
	Tile144 : game.TileInfo.TileBlockScale,
	Tile145 : game.TileInfo.TileBlockScale,

	// Enemy
	Tile111 : game.TileInfo.TileEnemySlime,
	Tile112 : game.TileInfo.TileEnemyDogSlime,
	Tile113 : game.TileInfo.TileEnemyCannon,
	Tile114 : game.TileInfo.TileEnemySusliksHawk,
	Tile115 : game.TileInfo.TileEnemyArmorSlime,
	Tile116 : game.TileInfo.TileEnemyArmorSlimeHawk,
	Tile117 : game.TileInfo.TileEnemySpider,
	Tile118 : game.TileInfo.TileEnemyFastBee,
	Tile119 : game.TileInfo.TileEnemyMoth,
	Tile127 : game.TileInfo.TileEnemyJumpSlime,
	Tile128 : game.TileInfo.TileEnemyBee,
	Tile129 : game.TileInfo.TileEnemyFish,
	Tile125 : game.TileInfo.TileEnemyMadBee,
	Tile124 : game.TileInfo.TileEnemyFlight,
	Tile126 : game.TileInfo.TileEnemyDrillDog,
	Tile121 : game.TileInfo.TileEnemyJumpFrog,

	// temp
	Tile123 : game.TileInfo.TileItemDrawer,
	Tile122 : game.TileInfo.TileBlockTrap,
//	Tile121 : game.TileInfo.TileEnemyMapEater,


	// Item
	Tile63 : game.TileInfo.TileItemEgg,
	Tile64 : game.TileInfo.TileItemEgg,
	Tile81 : game.TileInfo.TileItemCoin,
	Tile82 : game.TileInfo.TileItemBigCoin,
	Tile83 : game.TileInfo.TileItemHeart,
	Tile84 : game.TileInfo.TileItemBoxSmash,
	Tile85 : game.TileInfo.TileItemBoxBullet,
	Tile86 : game.TileInfo.TileItemBoxTeleport,
	Tile87 : game.TileInfo.TileItemBoxBomb,
	Tile74 : game.TileInfo.TileItemMovingPlatform,
	Tile75 : game.TileInfo.TileItemFallingBlock,
	Tile76 : game.TileInfo.TileItemGravityPlatform,
	Tile99 : game.TileInfo.TileItemStageEnd,
	Tile100 : game.TileInfo.TileItemSavePoint,
	Tile107 : game.TileInfo.TileItemReverseKey,
	Tile130 : game.TileInfo.TileItemFire,

	// Others
	Tile120 : game.TileInfo.TileNPC
};

game.CCBClass = {
	CCB_LY_GAME : "1"
}
