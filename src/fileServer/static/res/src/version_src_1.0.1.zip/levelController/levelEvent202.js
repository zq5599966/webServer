/**
 * Created with AppCode.
 * User: yop
 * Date: 15/11/2
 * Time: 下午5:49
 * To change this template use File | Settings | File Templates.
 */


LevelController.LevelEvent202 = LevelController.extend({
	eventStory1 : function(grid, dir) {
		this.showStory(1, grid, ""+
		"SelectNpc,Flash;"+
		"FaceTo,right;"+
		"MoveCamera,34,24,2;"+
		"FaceTo,left;"+
		"ShowDialog,"+ vee.Utils.getLocalizedStringForKey("Oh, here you are!", "嘿，你来啦！") +";"+
		"ShowDialog,"+ vee.Utils.getLocalizedStringForKey("Our new friend is behind me!", "身后这位是我们的新伙伴！") +";"+
		"ShowDialog,"+ vee.Utils.getLocalizedStringForKey("We're discussing the data we just collected!", "我们正在讨论所收集到的数据！") +";"+
		"HideDialog;"+
		"Delay,1;"+
		"SelectNpc;"+
		"ShowDialog,"+ vee.Utils.getLocalizedStringForKey("Don't bug me! I'm dealing with it!", "我正犯头疼呢，没看到吗……") +";"+
		"ShowDialog,"+ vee.Utils.getLocalizedStringForKey("All right! Anyway, you need to collect that rubbish -- I mean, data.", "好吧……不管怎样，你都要收集这些垃圾，我是说，数据。") +";"+
		"ShowDialog,"+ vee.Utils.getLocalizedStringForKey("I know you hate me. Everyone does.", "我知道你恨我。所有人都是。") +";"+
		"HideDialog;"+
		"UnlockRole;"+
		"TimeLine,huxi_2;"+
		"Delay,1;"+
		"Trigger,36,26"+
		"");
	}
});