/**
 * Created with AppCode.
 * User: yop
 * Date: 15/11/4
 * Time: 下午2:59
 * To change this template use File | Settings | File Templates.
 */


LevelController.Level117 = LevelController.extend({

	prepare : function(){
        this._story = [];
		game.Data.gameStartTime = new Date().getTime();
	},

	complete : function () {
		var nowTS = new Date().getTime();
		var off = nowTS - game.Data.gameStartTime;
		off = Math.floor(off/1000);
		if (off < 60) {
			vee.GameCenter.unlockAchievement(5);
		}
	},

	eventStory1 : function(grid, dir) {
		this.showStory(1, grid, ""+
		"SelectNpc,Flash;"+
		"FaceTo,left;"+
		"MoveCamera,46,14,2;"+
		"ShowDialog,"+ vee.Utils.getLocalizedStringForKey("Take it easy.", "慢点！") +";"+
		"HideDialog;"+
		"MoveRole,49,14;"+
		"ShowDialog,"+ vee.Utils.getLocalizedStringForKey("Notice the cliff, you can't jump over it.", "这个悬崖太远了，你跳不过来的。") +";"+
		"ShowDialog,"+ vee.Utils.getLocalizedStringForKey("Okay", "嗯……") +";"+
		"ShowDialog,"+ vee.Utils.getLocalizedStringForKey("The terrain seems so fragile there!", "不过这一带的地块似乎很脆弱。") +";"+
		"HideDialog;"+
		"Trigger,50,16;"+
		"Trigger,51,16;"+
		"MoveCamera,44,17,1;"+
		"Delay,1;"+
		"MoveCamera,46,14,1;"+
		"ShowDialog,"+ vee.Utils.getLocalizedStringForKey("Take it with you, it might help you!", "带上这个精灵吧，会有帮助的。") +";"+
		"HideDialog;"+
		"Trigger,55,15;"+
		"MoveCamera,42,14,1;"+
		"ShowDialog,"+ vee.Utils.getLocalizedStringForKey("Come over here, hurry!", "赶紧过来吧！") +";"+
		"ShowDialog,"+ vee.Utils.getLocalizedStringForKey("I will wait for you there!", "我在前面等你~") +";"+
		"HideDialog;"+
		"MoveRole,54,14;"+
		"ResetRole,69,14"+
		"");
	},

	skip1 : function() {
		cc.log("skip 1 called!");
	},

	eventStory2 : function(grid, dir) {
		this.showStory(2, grid, ""+
		"SelectNpc,Flash;"+
		"FaceTo,right;"+
		"ResetRole,95,25;"+
		"MoveCamera,94,28,1.0;"+
		"Jump,97,28;"+
		"Jump,99,33;"+
		"FaceTo,left;"+
		"MoveCamera,97,33,1.0;"+
		"ShowDialog,"+ vee.Utils.getLocalizedStringForKey("Ah, here you are!", "啊，你也到了啊。") +";"+
		"ShowDialog,"+ vee.Utils.getLocalizedStringForKey("I'm faster than you.", "我比你快，") +";"+
		"ShowDialog,"+ vee.Utils.getLocalizedStringForKey("I've gotta go now,I can't wait any longer!", "先走啦，不等你了~") +";"+
		"HideDialog;"+
		"MoveRole,106,33;"+
		"RemoveRole"+
		"");
		this.blockStory(3,true);
	},

	skip2 : function() {
		cc.log("skip 2 called!");
		this.skipStory(3);
		this.blockStory(3,true);
	},

	eventStory3 : function(grid, dir) {
		this.showStory(3, grid, ""+
		"SelectNpc,Flash;"+
		"FaceTo,left;"+
		"MoveCamera,67,13,1.0;"+
		"ShowDialog,"+ vee.Utils.getLocalizedStringForKey("Cool, never thought that you could go that far.", "厉害，我从未料到你可以来到这里！") +";"+
		"ShowDialog,"+ vee.Utils.getLocalizedStringForKey("I'm counting on you！", "我很看好你的！") +";"+
		"ShowDialog,"+ vee.Utils.getLocalizedStringForKey("Keep going on!", "要加油哦~") +";"+
		"HideDialog;"+
		"Delay,1"+
		"");
		this.blockStory(2,true);
	},

	skip3 : function() {
		cc.log("skip 3 called!");
		this.skipStory(2);
		this.blockStory(2,true);
	}
});