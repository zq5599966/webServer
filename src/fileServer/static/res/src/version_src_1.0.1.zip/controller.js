/**
 * Created with AppCode.
 * User: Thirty Wan
 * Date: 16/2/25
 * Time: 下午2:51
 * To change this template use File | Settings | File Templates.
 */
var vee = vee = vee || {};

vee.KeyCode = {
	JOYSTICK_LEFT_X : 1000,
	JOYSTICK_LEFT_Y : 1001,
	JOYSTICK_RIGHT_X : 1002,
	JOYSTICK_RIGHT_Y : 1003,

	BUTTON_A : 1004,
	BUTTON_B : 1005,
	BUTTON_C : 1006,
	BUTTON_X : 1007,
	BUTTON_Y : 1008,
	BUTTON_Z : 1009,

	BUTTON_DPAD_UP : 1010,
	BUTTON_DPAD_DOWN : 1011,
	BUTTON_DPAD_LEFT : 1012,
	BUTTON_DPAD_RIGHT : 1013,
	BUTTON_DPAD_CENTER : 1014,

	BUTTON_LEFT_SHOULDER : 1015,
	BUTTON_RIGHT_SHOULDER : 1016,

	AXIS_LEFT_TRIGGER : 1017,
	AXIS_RIGHT_TRIGGER : 1018,

	BUTTON_LEFT_THUMBSTICK : 1019,
	BUTTON_RIGHT_THUMBSTICK : 1020,

	BUTTON_START : 1021,
	BUTTON_SELECT : 1022,
	BUTTON_PAUSE : 1023,

	KEY_MAX : 1024
};

vee.Controller = {
	States: {
		CONTROLLER_ATTACH : 1,
		CONTROLLER_DETACH : 2
	},

	isActive : false,
	isConnected : false,
	rootNode : null,
	// controller event listener
	_listener : null,
	isControllerControlling : false,
	// sprites about controller, should hide when controller detach
	_arrSprites : [],
	_controllerCallbacks : [],

	active : function () {
		this.isActive = true;
		if (!this.rootNode) {
			var cNode = new cc.Node();
			vee.PopMgr._root.addChild(cNode, 10);
			this.rootNode = cNode;

			var listener = cc.EventListenerController.create();
            vee.Utils.logKey(listener);
			listener.onConnected = this._onConnected.bind(this);
			listener.onDisconnected = this._onDisconnected.bind(this);
			listener.onKeyDown = this._onKeyDown.bind(this);
			listener.onKeyUp = this._onKeyUp.bind(this);
			listener.onKeyRepeat = this._onKeyRepeat.bind(this);
			listener.onAxisEvent = this._onAxisEvent.bind(this);
            
            cc.eventManager.addListener(listener, this.rootNode);
//            cc.log("linstener = "+listener);
			cc.Controller.startDiscoveryController();

			this._listener = listener;
			vee.GestureController.registerController(this.rootNode, this, false);
		}
	},

	// for check is using controller or touch screen
	onGestureBegin : function (ctx) {
		if (this.isControllerControlling) {
			this.isControllerControlling = false;
			this.controllerDetach();
		}
		return true;
	},
	onControllerEvent : function () {
		if (this.isControllerControlling) {
			return true;
		} else {
			this.isControllerControlling = true;
			this.controllerAttach();
			return false;
		}
	},
	controllerDetach : function () {
		// TODO: hide all elements about controller
		for (var i in this._arrSprites) {
			/**@type {cc.Sprite}*/
			var sp = this._arrSprites[i];
			if (cc.sys.isObjectValid(sp)) {
				sp.stopAllActions();
				sp.runAction(cc.fadeTo(0.3, 0));
			}
		}
		if (this._isActiveSelector) {
			if (cc.sys.isObjectValid(this._cursor)) {
				this._cursor.stopAllActions();
				this._cursor.runAction(cc.fadeTo(0.3, 0));
			}
		}
		this._callControllerCallback(this.States.CONTROLLER_DETACH);
	},
	controllerAttach : function () {
		// TODO: show all elements about controller if needed
		for (var i in this._arrSprites) {
			/**@type {cc.Sprite}*/
			var sp = this._arrSprites[i];
			if (cc.sys.isObjectValid(sp)) {
				sp.stopAllActions();
				sp.runAction(cc.fadeTo(0.3, 255));
			}
		}
		if (this._isActiveSelector) {
			var item = this._itemMap.getObject(this._cursorGrid);
			this._showCursorAt(item);
		}
		this._callControllerCallback(this.States.CONTROLLER_ATTACH);
	},
	registerControllerSprite : function (spr) {
		if (spr) {
			spr.setVisible(this.isConnected);
			this._arrSprites.push(spr);
		}
	},
	removeControllerSprite : function (spr) {
		for (var i in this._arrSprites) {
			var checkSpr = this._arrSprites[i];
			if (checkSpr == spr) {
				cc.log("removed spr tag = "+spr.getTag());
				this._arrSprites.splice(i,1);
				break;
			}
		}
	},
	registerControllerCallback : function (callback) {
		this._controllerCallbacks.push(callback);
	},
	removeControllerCallback : function (callback) {
		for (var i in this._controllerCallbacks) {
			var checkCallback = this._controllerCallbacks[i];
			if (callback == checkCallback) {
				this._controllerCallbacks.splice(i,1);
				break;
			}
		}
	},
	_callControllerCallback : function (state) {
		for (var i in this._controllerCallbacks) {
			var callback = this._controllerCallbacks[i];
			if (callback) callback(state);
		}
	},

	// for cache controller button map
	cacheControllerState : function (ctl) {
		var tempControllerData = {
			tempItemMap : vee.Controller.getItemMap(),
			tempBtnMap : vee.Controller.getButtonMap(),
			tempIsActiveSelector : vee.Controller._isActiveSelector,
			tempSelectorBButtonCallback : vee.Controller._BButtonCallback,
			tempCursorGrid : vee.Controller._cursorGrid,
			tempIsActiveButton : vee.Controller._isActiveButton
		};
		if (ctl) ctl._tempControllerData = tempControllerData;

		vee.Controller.clearAllButtonAction();
		vee.Controller.deactiveSelector();
		vee.Controller.deactiveButton();
		return tempControllerData;
	},

	reviveControllerStateByCtl : function (ctl) {
		this.reviveControllerState(ctl._tempControllerData);
	},

	reviveControllerState : function (tempControllerData) {
		vee.Controller.setButtonMap(tempControllerData.tempBtnMap);
		vee.Controller.setItemMap(tempControllerData.tempItemMap);
		vee.Controller._cursorGrid = tempControllerData.tempCursorGrid;
		vee.Controller._BButtonCallback = tempControllerData.tempSelectorBButtonCallback;
		vee.Controller.deactiveSelector();
		if (tempControllerData.tempIsActiveSelector) {
			cc.log("selector revived");
			vee.Controller.activeSelector();
		}
		vee.Controller.deactiveButton();
		if (tempControllerData.tempIsActiveButton) {
			vee.Controller.activeButton();
		}
	},

	_tempButtonActive : false,
	_tempSelectorActive : false,
	tempDisable : function () {
		this._tempButtonActive = this._isActiveButton;
		this._tempSelectorActive = this._isActiveSelector;
		this.deactiveButton();
		this.deactiveSelector();
	},
	tempRevive : function () {
		if (this._tempButtonActive) {
			this.activeButton();
		}
		if (this._tempSelectorActive) {
			this.activeSelector();
		}
	},

	keyCode2Dir : function (keycode) {
		switch (keycode) {
			case vee.KeyCode.BUTTON_DPAD_UP:
				return vee.Direction.Top;
			case vee.KeyCode.BUTTON_DPAD_DOWN:
				return vee.Direction.Bottom;
			case vee.KeyCode.BUTTON_DPAD_LEFT:
				return vee.Direction.Left;
			case vee.KeyCode.BUTTON_DPAD_RIGHT:
				return vee.Direction.Right;
			default :
				return null;
		}
	},
	dir2KeyCode : function (dir) {
		switch (dir) {
			case vee.Direction.Top:
				return vee.KeyCode.BUTTON_DPAD_UP;
			case vee.Direction.Bottom:
				return vee.KeyCode.BUTTON_DPAD_DOWN;
			case vee.Direction.Left:
				return vee.KeyCode.BUTTON_DPAD_LEFT;
			case vee.Direction.Right:
				return vee.KeyCode.BUTTON_DPAD_RIGHT;
		}
	},

	axis2Dir : function (axis, value) {
		switch (axis) {
			case vee.KeyCode.JOYSTICK_LEFT_X:
				if (value > 0.4) {
					return vee.Direction.Right;
				} else if (value < -0.4) {
					return vee.Direction.Left;
				}
			case vee.KeyCode.JOYSTICK_LEFT_Y:
				if (value > 0.4) {
					return vee.Direction.Bottom;
				} else if (value < -0.4) {
					return vee.Direction.Top;
				}
		}
		return null;
	},

	// event from contorller
	_onConnected : function (eventController) {
		cc.log("controller connected");
		this.isConnected = true;
		this.controllerAttach();
		if (this.rootNode) {
			var ctl = VeeMfiConnect.create();
			ctl.showConnect();
			this.rootNode.addChild(ctl.rootNode);
			vee.PopMgr.setNodePos(ctl.rootNode, vee.PopMgr.PositionType.Top);
		}
	},
	_onDisconnected : function (eventController) {
		cc.log("controller disconnected");
		this.isConnected = false;
		this.controllerDetach();
		if (this.rootNode) {
			var ctl = VeeMfiConnect.create();
			ctl.showDisconect();
			this.rootNode.addChild(ctl.rootNode);
			vee.PopMgr.setNodePos(ctl.rootNode, vee.PopMgr.PositionType.Top);
		}
	},
	_onKeyDown : function (keyCode, eventController) {
//		cc.log("按钮按下：" + keyCode);
		if (this.onControllerEvent()) {
			this._selectorInput(keyCode);
		}
		if (this._globalKeyDown) {
			this._globalKeyDown();
		}
		this._actionInput(keyCode, true);
	},
	_onKeyUp : function (keyCode, eventController) {
//		cc.log("按钮弹起：" + keyCode);
		this._actionInput(keyCode, false);
		if (this._globalKeyUp) this._globalKeyUp();
	},
	_onKeyRepeat : function (keyCode, eventController) {

	},
	_xTempDir : null,
	_yTempDir : null,
	_LTriggerDown : false,
	_axisState : {
		key1017 : false,
		key1018 : false
	},
	_onAxisEvent : function (keyCode, value, eventController) {
		if (this.onControllerEvent()) {
			if (keyCode == vee.KeyCode.JOYSTICK_LEFT_X) {
				var dir = this.axis2Dir(keyCode, value);
				this.calcInputDirX(dir);
			} else if (keyCode == vee.KeyCode.JOYSTICK_LEFT_Y) {
				var dir = this.axis2Dir(keyCode, value);
				this.calcInputDirY(dir);
			} else {
				// trigger
				if (value > 0.5) {
					var axisState = this._axisState["key"+keyCode];
					if (!axisState) {
						this._axisState["key"+keyCode] = true;
						this._onKeyDown(keyCode);
					}
				} else {
					if (this._axisState["key"+keyCode]) {
						this._axisState["key"+keyCode] = false;
						this._onKeyUp(keyCode);
					}
				}
			}
		}
	},

	calcInputDirX : function (inputDir) {
		if (this._xTempDir) {
			if (inputDir != this._xTempDir) {
				this._onKeyUp(this.dir2KeyCode(this._xTempDir));
				this._onKeyDown(this.dir2KeyCode(inputDir));
			}
		} else {
			this._onKeyDown(this.dir2KeyCode(inputDir));
		}
		this._xTempDir = inputDir;
	},
	calcInputDirY : function (inputDir) {
		if (this._yTempDir) {
			if (inputDir != this._yTempDir) {
				this._onKeyUp(this.dir2KeyCode(this._yTempDir));
				this._onKeyDown(this.dir2KeyCode(inputDir));
			}
		} else {
			this._onKeyDown(this.dir2KeyCode(inputDir));
		}
		this._yTempDir = inputDir;
	},

	_globalKeyDown : null,
	_globalKeyUp : null,
	registerGlobalButtonAction : function (onKeyDown, onKeyUp) {
		this._globalKeyDown = onKeyDown;
		this._globalKeyUp = onKeyUp;
	},
	clearGlobalButtonAction : function () {
		this._globalKeyDown = null;
		this._globalKeyUp = null;
	},

	clearAll : function () {
		this.clearGlobalButtonAction();
		this.clearAllItem();
		this.clearAllButtonAction();
	},







	/** Menu Selector **/
	/**
	 * For use controller to choose menu item:
	 * 1. initSelector
	 * 2. register menu item
	 * 3. active selector (if needed)
	 */
	// for selector, you can use it to control menu by controller
	_itemMap : null,
	/** @type {cc.Sprite} */
	_cursor : null,
	_isActiveSelector : false,
	_cursorGrid : null,
	_BButtonCallback : null,

	// init selector map and create cursor
	initSelector : function (sizeW, sizeH, BButtonCallback, defaultSelectorGrid) {
		if (sizeH && sizeW) this._itemMap = vee.Map.create(cc.size(sizeW, sizeH), cc.p(1,1));
		if (!this.isActive) return;
		this._BButtonCallback = BButtonCallback;
		// if controller is inactive, show the cursor when init
		if (defaultSelectorGrid) this._cursorGrid = defaultSelectorGrid;
		if (this._isActiveSelector) this.activeSelector(defaultSelectorGrid, true);
	},

	// TOP LEFT is the ORIGINAL POINT, remember!
	registerItem : function (item, grid) {
		item.grid = grid;
		this._itemMap.setObject(item, grid);
	},

	registerItemByButton : function (button, grid, callback, highlightSprite, spriteOffset) {
		var item = this.createItemByButton(button, callback, highlightSprite, spriteOffset);
		this.registerItem(item, grid);
	},

	createItem : function (pos, size, onBtnUp, onBtnDown, highlightSprite, node, spriteOffset) {
		return {
			pos : pos,
			size : size,
			onBtnUp : onBtnUp,
			onBtnDown : onBtnDown,
			highlightSprite : highlightSprite,
			spriteOffset : spriteOffset,
			node : node
		};
	},

	createItemByButton : function (button, callback, highlightSprite, spriteOffset) {
		if (!button) {
			cc.log("Error in createItemByButton : button cannot be null!")
		}
		return this.createItem(button.getPosition(), button.getContentSize(), null, callback, highlightSprite, button, spriteOffset);
	},

	clearItem : function (grid, safePos) {
		this._itemMap.removeObject(grid);
		if (safePos) {
			this._move(vee.Direction.Left);
			this._move(vee.Direction.Right);
			this._move(vee.Direction.Bottom);
			this._move(vee.Direction.Top);
		}
	},

	clearAllItem : function () {
		this._itemMap = null;
	},

	setItemMap : function (map) {
		this._itemMap = map;
	},

	getItemMap : function () {
		return this._itemMap;
	},

	getItemMapCopy : function () {
		return vee.Utils.copy(this._itemMap);
	},

	getSelectorGrid : function () {
		return cc.p(this._cursorGrid.x,this._cursorGrid.y);
	},

	activeSelector : function (defaultSelectorGrid) {
		if (this._isActiveSelector) return;
		if (!this._itemMap) return;
		var defaultGrid = null;
		if (defaultSelectorGrid) {
			defaultGrid = defaultSelectorGrid;
		} else {
			if (this._cursorGrid) {
				defaultGrid = this._cursorGrid;
			} else {
				cc.log("To active Selector, please define default selector grid first!");
			}
		}
		this._isActiveSelector = true;
		// set cursor at default pos
		var defaultItem = this._itemMap.getObject(defaultGrid);
		this._showCursorAt(defaultItem);
	},

	deactiveSelector : function (animate) {
		if (!this.isActive) return;
		cc.log("fuck deactive selector========");
		this._isActiveSelector = false;
		if (!cc.sys.isObjectValid(this._cursor)) {
			this._cursor = null;
		}
		if (this._cursor && animate) {
			this._cursor.stopAllActions();
			this._cursor.runAction(cc.fadeTo(0.1, 0));
		}
	},

	// custom key down event for selector
	_selectorInput : function (keyCode) {
		if (this._isActiveSelector) {
			var dir = this.keyCode2Dir(keyCode);
			if (dir) {
				this._move(dir);
			} else {
				switch (keyCode) {
					case vee.KeyCode.BUTTON_A:
					case vee.KeyCode.BUTTON_DPAD_CENTER:
						this._onA();
						break;
					case vee.KeyCode.BUTTON_B:
						this._onB();
						break;
				}
			}
		}
	},
	_onA : function () {
		var item = this._itemMap.getObject(this._cursorGrid);
		if (item && item.onBtnDown) {
			item.onBtnDown();
		}
	},
	_onB : function () {
		if (this._BButtonCallback) this._BButtonCallback();
	},

	_canLoop : false,
	_move : function (dir) {
		if (!this._isActiveSelector) return;
		var item = this._getItemByDir(this._cursorGrid, dir);
		this._showCursorAt(item);
	},

	// get item
	_getItemByDir : function (grid, dir) {
		var item = null;
		var dirOff = vee.Direction.direction2Point(dir);

		var nextGrid = vee.Utils.pAdd(grid, dirOff);
		var deep = 1;
		do {
			item = this._getItemInLine(nextGrid, vee.Direction.getDirectionClockwise(dir, true), deep+2);
			++deep;
			nextGrid = vee.Utils.pAdd(grid, cc.p(dirOff.x*deep, dirOff.y*deep));
			nextGrid = this._itemMap.lawGrid(nextGrid);
		} while(!item && nextGrid);

		return item;
	},
	// for function _getItemInLine
	_getItemByOffset : function (grid, dirOffset, offset) {
		var nextGrid = vee.Utils.pAdd(grid, cc.p(dirOffset.x*offset, dirOffset.y*offset));
//		cc.log("check wide grid : "+nextGrid.x+","+nextGrid.y);
		return this._itemMap.getObject(nextGrid);
	},
	/**
	 * Search item in a line
	 * @param grid: start point
	 * @param dir: direction of line
	 * @param deepLimit: X2+1 = line length
	 * @returns {Object} item
	 * @private
	 */
	_getItemInLine : function (grid, dir, deepLimit) {
//		cc.log("check grid : "+grid.x+","+grid.y);
		var item = this._itemMap.getObject(grid);
		var dirOff = vee.Direction.direction2Point(dir);
		if (!item) {
			for (var deep = 1; deep <= deepLimit; ++deep) {
				item = this._getItemByOffset(grid, dirOff, deep);
				if (item) break;
				item = this._getItemByOffset(grid, dirOff, -deep);
				if (item) break;
			}
		}
		return item;
	},

	_showCursorAt : function (item, isInit) {
		if (!item) return;

		if (item.node && item.highlightSprite && this.isControllerControlling) {
			if (!cc.sys.isObjectValid(this._cursor)) {
				this._cursor = null;
			}
			if (this._cursor) {
				this._cursor.setTexture(item.highlightSprite);
				this._cursor.retain();
				this._cursor.removeFromParent();
				item.node.addChild(this._cursor);
				this._cursor.release();
			} else {
				this._cursor = cc.Sprite.create(item.highlightSprite);
				item.node.addChild(this._cursor);
			}

			var anc = item.node.getAnchorPoint();
			var spritePos = cc.p(anc.x * item.size.width, anc.y * item.size.height);
			var offset = cc.p(0,0);
			if (item.spriteOffset) offset = item.spriteOffset;
			this._cursor.setPosition(vee.Utils.pAdd(spritePos, offset));
			this._cursor.stopAllActions();
			this._cursor.setScale(1.3);
			this._cursor.setOpacity(255);
			this._cursor.runAction(cc.sequence(
				cc.EaseExponentialOut.create(cc.scaleTo(0.2, 1)),
				cc.repeat(cc.sequence(
					cc.fadeTo(0.5, 50),
					cc.fadeTo(0.5, 255)
				), 9999)
			));
		}
		vee.Utils.logObj(item.grid, "cursor grid");
		this._cursorGrid = cc.p(item.grid.x, item.grid.y);
	},








	/** Button Action **/
	// for button function, use it for move, jump, attack...
	_isActiveButton : false,
	_buttonMap : {},
	registerButtonAction : function (keyCode, onKeyDown, onKeyUp) {
		if (_.isArray(keyCode)) {
			for (var i in keyCode) {
				var code = keyCode[i];
				this._registerAction(code, onKeyDown, onKeyUp);
			}
		} else {
			this._registerAction(keyCode, onKeyDown, onKeyUp);
		}
	},

	_registerAction : function (keyCode, onKeyDown, onKeyUp) {
		this._buttonMap[keyCode] = {};
		this._buttonMap[keyCode].onKeyDown = onKeyDown;
		this._buttonMap[keyCode].onKeyUp = onKeyUp;
	},

	getButtonActionKeyDown : function (keyCode) {
		var action = this._buttonMap[keyCode].onKeyDown;
		return action;
	},

	getButtonActionKeyUp : function (keyCode) {
		var action = this._buttonMap[keyCode].onKeyUp;
		return action;
	},

	clearButtonAction : function (keyCode) {
		this._buttonMap[keyCode] = null;
	},

	clearAllButtonAction : function () {
		this._buttonMap = null;
		this._buttonMap = {};
	},

	setButtonMap : function (map) {
		this._buttonMap = map;
	},

	getButtonMap : function () {
		return this._buttonMap;
	},

	activeButton : function () {
		if (!this.rootNode) return;
		this._isActiveButton = true;
	},

	deactiveButton : function () {
		this._isActiveButton = false;
	},

	_actionInput : function(keyCode, isDown) {
		if (this._isActiveButton) {
			var buttonAction = this._buttonMap[keyCode];
			if (buttonAction) {
				if (isDown && buttonAction.onKeyDown) buttonAction.onKeyDown();
				else if (buttonAction.onKeyUp) buttonAction.onKeyUp();
			}
		}
	}
};
