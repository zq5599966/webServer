/**
 * Created with AppCode.
 * User: Yop Chan
 * Date: 15/12/22
 * Time: 下午4:36
 * To change this template use File | Settings | File Templates.
 */

var EfxApplause = vee.Class.extend({

	show : function () {
		if (this._isAnimating) return;
		this.playAnimate("open");
	},

	onExit : function () {
		EfxApplause.share = null;
	}
});

EfxApplause.show = function () {
	if (!EfxApplause.share)	{
		var node = cc.BuilderReader.load(res.efx_applause_ccbi);
		game.Data.oLyGame.rootNode.addChild(node, 999);
		EfxApplause.share = node.controller;
	}
	EfxApplause.share.show();
};

/** @type {EfxApplause} */
EfxApplause.share = null;

EfxApplause.Analysis = {
	//一次起跳获取的金币数量
	coinsInOneJump : 0,
	//一次起跳踩死的怪物数量
	enemiesInOneJump : 0,
	//跳跃的距离
	distanceInOneJump : 0,
	//跳跃的高度
	heightInOneJump : 0,

	_conditions : [
		{coin : 0, enemy : 4, height : 0, distance : 0}
	],
	_beginPos : null,

	onJump : function(pos) {
		if (this._beginPos) return;
		this.coinsInOneJump = 0;
		this.enemiesInOneJump = 0;
		this.distanceInOneJump = 0;
		this.heightInOneJump = 0;
		this._beginPos = pos;
	},

	onKillEnemy : function () {
		this.enemiesInOneJump++;
	},

	onGetCoin : function () {
		this.coinsInOneJump++;
	},

	onLand : function (pos) {
		if (!this._beginPos) return;
		this.distanceInOneJump = Math.abs(pos.x - this._beginPos.x);
		this.heightInOneJump = this._beginPos.y - pos.y;
		this._beginPos = null;
		this.checkConditions();
	},

	getBeginPos : function () {
		return this._beginPos;
	},

	addCondition : function(con) {
		this._conditions.push(con);
	},

	checkConditions : function() {
		var len = this._conditions.length;
		for (var i = 0; i < len; i++ ){
			if(this.checkCondition(this._conditions[i])) {
				EfxApplause.show();
				break;
			}
		}
		for (var i = 1; i < len; i++) {
			this._conditions.pop();
		}
	},

	/**
	 * @param {EfxApplause.Analysis.ApplauseCondition} con
	 */
	checkCondition : function(con) {
		if (con.coin > 0 && this.coinsInOneJump < con.coin) return false;
		if (con.enemy > 0 && this.enemiesInOneJump < con.enemy) return false;
		if (con.height > 0 && this.heightInOneJump < con.height) return false;
		if (con.height < 0 && this.heightInOneJump > con.height) return false;
		if (con.distance > 0 && this.distanceInOneJump < con.distance) return false;
		return true;
	}
}

EfxApplause.Analysis.ApplauseCondition = {
	coin : 0,
	enemy : 0,
	height : 0,
	distance : 0
}

EfxApplause.addCondition = function(coin, enemy, height, distance) {
	EfxApplause.Analysis.addCondition({
		coin : (coin ? coin : 0),
		enemy : (enemy ? enemy : 0),
		height : (height ? height : 0),
		distance : (distance ? distance : 0)
	});
}


Trigger.Applause = Trigger.extend({
	_isShow : false,

	func : function(grid, dir, isShowOnce) {
		if (!this.name) {
			EfxApplause.show();
			return;
		}
		var arrArg = this.name.split(",");
		EfxApplause.addCondition(arrArg[0], arrArg[1], arrArg[2], arrArg[3]);
	}

});

Trigger.ApplauseOnce = Trigger.extend({
	_isShow : false,

	func : function(grid, dir, isShowOnce) {
		if (this._isShow) return;

		this._isShow = true;

		if (!this.name) {
			if (!this._isShow) EfxApplause.show();
			return;
		}

		var arrArg = this.name.split(",");
		EfxApplause.addCondition(arrArg[0], arrArg[1], arrArg[2], arrArg[3]);
	}

});