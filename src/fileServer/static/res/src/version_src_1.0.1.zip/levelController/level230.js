/**
 * Created with AppCode.
 * User: yop
 * Date: 15/10/27
 * Time: 下午7:01
 * To change this template use File | Settings | File Templates.
 */


LevelController.Level230 = LevelController.extend({
	eventStory1 : function(grid, dir) {
		this.showStory(1, grid, ""+
		"SelectNpc,Flash;"+
		"FaceTo,left;"+
		"MoveCamera,62,12,1.5;"+
		"ShowDialog,"+ vee.Utils.getLocalizedStringForKey("You made it!", "嘿，你总算过来了。") +";"+
		"ShowDialog,"+ vee.Utils.getLocalizedStringForKey("Look, there's a sprite.", "看，这里有个精灵，") +";"+
		"ShowDialog,"+ vee.Utils.getLocalizedStringForKey("Sprite is the superpower within this phantom world.", "精灵们是幻影世界的超能量。") +";"+
		"ShowDialog,"+ vee.Utils.getLocalizedStringForKey("Take this with you to use its magical powers.", "带上它吧，这样你就可以使用精灵的能力了。") +";"+
		"HideDialog"+
		"");
	},

	skip1 : function() {
		cc.log("skip 1 called!");
		this.skipStory(2);
	},

	eventStory2 : function(grid, dir) {
		this.showStory(2, grid, ""+
		"SelectNpc,Flash;"+
		"FaceTo,right;"+
		"MoveCamera,68,12,1.5;"+
		"Trigger,77,6;"+
		"ShowDialog,"+ vee.Utils.getLocalizedStringForKey("Nice, You opened up a new shortcut!", "太棒了，你打开了一个新的通道！") +";"+
		"ShowDialog,"+ vee.Utils.getLocalizedStringForKey("Come on, let's go!", "我们走吧，我在前面等你。") +";"+
		"HideDialog;"+
		"MoveCamera,70,16,0.35;"+
		"Jump,66,15;"+
		"Jump,69,18;"+
		"MoveCamera,75,17,1;"+
		"MoveRole,85,18;"+
		"Jump,88,16;"+
		"RemoveRole"+
		"");
	},

	skip2 : function() {
		cc.log("skip 2 called!");
	},
	
	_event1Over : false,
	eventCustomController : function () {
		if (this._event1Over) return;
		this._event1Over = true;
		if (vee.Controller.isControllerControlling) return;
		vee.PopMgr.alert(
			vee.Utils.getLocalizedStringForKey("Do you want to change the position or size of control button?"),
			vee.Utils.getLocalizedStringForKey("Custom Controller"),
			function () {
			LyPosSetting.show();
		});
	}
});
