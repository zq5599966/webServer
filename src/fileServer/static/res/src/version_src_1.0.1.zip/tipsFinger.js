/**
 * Created with AppCode.
 * User: WanThirty
 * Date: 15/6/4
 * Time: 下午2:23
 * To change this template use File | Settings | File Templates.
 */

var TipsFinger = vee.Class.extend({
	onCreate : function () {

	}
});