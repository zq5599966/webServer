/**
 * Created with AppCode.
 * User: WanThirty
 * Date: 4/17/15
 * Time: 11:04 AM
 * To change this template use File | Settings | File Templates.
 */

var LyGame = vee.Class.extend({
	lyContainer : null,
	lyMap : null,
	lyMapBack : null,
	lyBG : null,
	ccbHPBar : null,
	lyTouch : null,
	lbCoinNum : null,
	spCoinIcon : null,

	nodeT : null,
	nodeTR : null,
	nodeTL : null,
	nodeBL : null,
	nodeTLElements : null,
	nodeTRElements : null,
	nodeStar : null,
	nodeSkip : null,

	btnMove : null,
	btnJump : null,
	btnSmash : null,
	btnPause : null,
	btnSkip : null,

	blackEdgeBL : null,
	blackEdgeTL : null,

	ccbRecord : null,
	ccbTips : null,

	_holdLeft : false,
	_holdRight : false,
	drawNode : null,
	bgCtl : null,
	_keyState : null,
	_btnPos : null,
	_moveBtnRect : null,
	_isOver : false,
	_spBtnR : null,
	_xRightEdge : 0,

	lyGesture : null,

	lbKeyCode : null,

	/** @type {EfxHighlightButton} */
	_efxHighlightButton : null,

	_startDateTime : 0,
	_tmpHeartNum : 0,	 //关卡内HP恢复次数
	_tmpCostLifeNum : 0, //关卡内消耗HP次数
	_isBlackCatModel : false,

	/**
	 * add by zq for ugame analytics
	 */
	initAnalyticsData : function () {
		this._isBlackCatModel = false;
		this._startDateTime = new Date().getTime();
		this._tmpHeartNum = 0;
		this._tmpCostLifeNum = 0;
	},

	onCreate : function() {
		VeeRecordButton.stopRecord();
		game.Data.oLyGame = this;
	},

	onLoaded : function () {
		game.Data.curSceen = "lyGame";

		this.initAnalyticsData();

		game.Data.isInLevelSceen = true;

		vee.Controller.clearAll();
		vee.Controller.deactiveButton();
		vee.Controller.deactiveSelector();
		// preload sprite frames...
		cc.spriteFrameCache.addSpriteFrames(res.item_coin_frames_plist, res.item_coin_frames_png);
		cc.spriteFrameCache.addSpriteFrames(res.item_plist, res.item_png);

		// preset button state...
		this.btnMove.addTargetWithActionForControlEvents(this, this.onMove,
			cc.CONTROL_EVENT_TOUCH_DOWN | cc.CONTROL_EVENT_TOUCH_DRAG_EXIT | cc.CONTROL_EVENT_TOUCH_DRAG_OUTSIDE | cc.CONTROL_EVENT_TOUCH_CANCEL | cc.CONTROL_EVENT_TOUCH_DRAG_ENTER | cc.CONTROL_EVENT_TOUCH_UP_INSIDE | cc.CONTROL_EVENT_TOUCH_UP_OUTSIDE | cc.CONTROL_EVENT_TOUCH_DRAG_INSIDE);
		this.btnJump.addTargetWithActionForControlEvents(this, this.onJump,
			cc.CONTROL_EVENT_TOUCH_DOWN | cc.CONTROL_EVENT_TOUCH_DRAG_EXIT | cc.CONTROL_EVENT_TOUCH_DRAG_OUTSIDE | cc.CONTROL_EVENT_TOUCH_CANCEL | cc.CONTROL_EVENT_TOUCH_DRAG_ENTER | cc.CONTROL_EVENT_TOUCH_UP_INSIDE | cc.CONTROL_EVENT_TOUCH_UP_OUTSIDE);
		this.btnSmash.addTargetWithActionForControlEvents(this, this.onSmash,
			cc.CONTROL_EVENT_TOUCH_DOWN | cc.CONTROL_EVENT_TOUCH_DRAG_EXIT | cc.CONTROL_EVENT_TOUCH_DRAG_OUTSIDE | cc.CONTROL_EVENT_TOUCH_CANCEL | cc.CONTROL_EVENT_TOUCH_DRAG_ENTER | cc.CONTROL_EVENT_TOUCH_UP_INSIDE | cc.CONTROL_EVENT_TOUCH_UP_OUTSIDE);

		this.resetButtonState();

		this._keyState = [];
		this.handleKey(true);

		vee.GestureController.registerController(this.lyTouch, this, false);

		// setting UI position adaption...
		vee.PopMgr.setNodePos(this.nodeT, vee.PopMgr.PositionType.Top);
		vee.PopMgr.setNodePos(this.nodeTL, vee.PopMgr.PositionType.TopLeft);
		vee.PopMgr.setNodePos(this.nodeTR, vee.PopMgr.PositionType.TopRight);
		vee.PopMgr.setNodePos(this.nodeBL, vee.PopMgr.PositionType.BottomLeft);

		this.resetGestureControl();
		this.resetButtonSize();
		this._spBtnR = new cc.Sprite(res.mfi_btn_R_png);
		this.btnSkip.addChild(this._spBtnR);
		var btnSize = this.btnSkip.getContentSize();
		this._spBtnR.setPosition(cc.p(btnSize.width, btnSize.height*0.8));
		vee.Controller.registerControllerSprite(this._spBtnR);

		this.nodeSkip.removeFromParent(false);
		this.nodeSkip.retain();
		vee.PopMgr.rootNode.addChild(this.nodeSkip, 999);
		this.nodeSkip.release();
		var btnPos = this.nodeSkip.getPosition();
		var transferPos = vee.Utils.pAdd(btnPos, cc.p(vee.PopMgr.winSize.width, vee.PopMgr.winSize.height));
		this.nodeSkip.setPosition(transferPos);
		this._controllerCallback = this.onControllerStateChange.bind(this);
		vee.Controller.registerControllerCallback(this._controllerCallback);
	},

	onKeyBack : function() {
		if(game.Data.performingTMXIdx == "Story1" || game.Data.performingTMXIdx == "Tutorial" || Story.isShowStory){
			this.onSkip();
		}
		else{
			this.onPause();
		}
	},

	resetGestureControl : function () {
		var scale = game.Data.isSmallButton() ? game.Data.smallButtonRate : 1;
		this.lyGesture.controller.setEnabled(game.Data.isGestureControl());
		this.lyGesture.controller.setScale(scale);
	},

	resetButtonSize : function () {
		var isSmall = game.Data.isSmallButton();
		if (isSmall) {
			this.btnMove.setScale(game.Data.smallButtonRate);
			this.btnJump.setScale(game.Data.smallButtonRate);
			this.btnSmash.setScale(game.Data.smallButtonRate);
		} else {
			this.btnMove.setScale(1);
			this.btnJump.setScale(1);
			this.btnSmash.setScale(1);
		}
	},

	onKeyPressed : function(keyCode) {
		if (this._keyState[keyCode]) return;
		this._keyState[keyCode] = true;
		switch (keyCode) {
			// DPad left
			case 156:
				this.onLeft(this, cc.CONTROL_EVENT_TOUCH_DOWN);
				break;
			// DPad right
			case 157:
				this.onRight(this, cc.CONTROL_EVENT_TOUCH_DOWN);
				break;
			// A
			case 121:
				this.onJump(this, cc.CONTROL_EVENT_TOUCH_DOWN);
				break;
			// B
			case 122:
				this.onSmash(this, cc.CONTROL_EVENT_TOUCH_DOWN);
				break;
			// X
			case 144:
				this.onSmash(this, cc.CONTROL_EVENT_TOUCH_DOWN);
				break;
			// Y
			case 145:
				this.onJump(this, cc.CONTROL_EVENT_TOUCH_DOWN);
				break;
			default :
		}
	},

	onKeyReleased : function(keyCode){
		switch (keyCode) {
			// DPad left
			case 156:
				this.onLeft(this, cc.CONTROL_EVENT_TOUCH_UP_INSIDE);
				break;
			// DPad right
			case 157:
				this.onRight(this, cc.CONTROL_EVENT_TOUCH_UP_INSIDE);
				break;
			// A
			case 121:
				this.onJump(this, cc.CONTROL_EVENT_TOUCH_UP_INSIDE);
				break;
			// B
			case 122:
				this.onSmash(this, cc.CONTROL_EVENT_TOUCH_UP_INSIDE);
				break;
			// X
			case 144:
				this.onSmash(this, cc.CONTROL_EVENT_TOUCH_UP_INSIDE);
				break;
			// Y
			case 145:
				this.onJump(this, cc.CONTROL_EVENT_TOUCH_UP_INSIDE);
				break;
			default :
				return false;
		}
		this._keyState[keyCode] = false;
		return true;
	},

	onExit : function() {
		game.Data.isInLevelSceen = false;

		vee.Controller.deactiveButton();
		this.nodeSkip.removeFromParent(true);
		game.Data.oLyGame = null;
		vee.PopMgr.rootNode.getScheduler().setTimeScale(1);
//		cc.spriteFrameCache.removeSpriteFramesFromFile(res.item_plist, res.item_png);
		this.stopUpdate();
		vee.Controller.removeControllerCallback(this._controllerCallback);
		vee.Controller.removeControllerSprite(this._spBtnR);
	},

	loadingFinish : function () {
		if (!Cinema.isCinema) {
			vee.Controller.clearAllButtonAction();

			if(!game.Data.isInParkour()){
				vee.Controller.registerButtonAction(
					vee.KeyCode.BUTTON_DPAD_LEFT,
					this.leftBtnDown.bind(this),
					this.leftBtnUp.bind(this)
				);
				vee.Controller.registerButtonAction(
					vee.KeyCode.BUTTON_DPAD_RIGHT,
					this.rightBtnDown.bind(this),
					this.rightBtnUp.bind(this)
				);
			}

			vee.Controller.registerButtonAction(
				[vee.KeyCode.BUTTON_A,vee.KeyCode.BUTTON_DPAD_UP],
				this.jumpButtonDown.bind(this),
				this.jumpButtonUp.bind(this)
			);
			vee.Controller.registerButtonAction(
				[vee.KeyCode.BUTTON_B,vee.KeyCode.BUTTON_X,vee.KeyCode.BUTTON_DPAD_CENTER],
				this.BButtonDown.bind(this),
				this.BButtonUp.bind(this)
			);
			vee.Controller.registerButtonAction(
				[vee.KeyCode.BUTTON_RIGHT_SHOULDER,vee.KeyCode.AXIS_RIGHT_TRIGGER,vee.KeyCode.BUTTON_PAUSE],
				this.onPause.bind(this)
			);
			vee.Controller.registerButtonAction(
				[vee.KeyCode.BUTTON_LEFT_SHOULDER,vee.KeyCode.AXIS_LEFT_TRIGGER],
				this.ccbRecord.controller.onTouch.bind(this.ccbRecord.controller)
			);
			// in tutorial, the skip button should be active
			if (this.nodeSkip.isVisible()) {
				this.setSkipButtonVisible(true);
			}
			vee.Controller.activeButton();
			if (vee.Controller.isControllerControlling) {
				this.hideButtons();
			}
		}
	},

	_controllerCallback : null,
	onControllerStateChange : function (state) {
		if (state == vee.Controller.States.CONTROLLER_ATTACH) {
			this.hideButtons();
		} else if (state == vee.Controller.States.CONTROLLER_DETACH) {
			if (!Story.isShowStory && !Cinema.isCinema) {
				this.showButtons(false);
			}
		}
	},

	// run main schedule
	updateCall : null,
	startUpdate : function () {
		this.updateCall = this.updateFunc.bind(this);
		vee.Utils.scheduleCallbackForTarget(this.rootNode, this.updateCall);
	},

	stopUpdate : function () {
		vee.Utils.unscheduleAllCallbacksForTarget(this.rootNode);
	},

	resetButtonState : function () {
		// reset button position
		game.Data.loadBtnPos();
		if (game.Data.btnMovePos) {
			this.btnMove.setPosition(game.Data.btnMovePos);
		} else {
			vee.PopMgr.setNodePos(this.btnMove, vee.PopMgr.PositionType.BottomLeft);
		}
		var pos = null;
		if (game.Data.btnJumpPos) {
			this.btnJump.setPosition(game.Data.btnJumpPos);
		} else {
			vee.PopMgr.setNodePos(this.btnJump, vee.PopMgr.PositionType.BottomRight);
			pos = this.btnJump.getPosition();
		}
		if (game.Data.btnDropPos) {
			this.btnSmash.setPosition(game.Data.btnDropPos);
		} else {
			this.btnSmash.setPosition(vee.Utils.pAdd(pos, cc.p(-this.btnSmash.getContentSize().width, 0)));
		}

		this._btnPos = this.btnMove.getPosition();
		var btnSize = this.btnMove.getContentSize();
		var isSmall = game.Data.isSmallButton();
		var scaleRate = isSmall ? game.Data.smallButtonRate : 1;
		btnSize.width = btnSize.width*scaleRate;
		btnSize.height = btnSize.height*scaleRate;
		this._moveBtnRect = cc.rect(this._btnPos.x - btnSize.width/2, this._btnPos.y - btnSize.height/2, btnSize.width, btnSize.height);
	},

	hideBButton : function () {
		this.hideControlButton(LyGame.ControlButtonType.ActionButton);
	},
	showBButton : function () {
		this.btnSmash.setVisible(false);
		this.showControlButton(LyGame.ControlButtonType.ActionButton, true);
	},

	checkIsParkourState : function () {

		if(game.Data.isInParkour() && game.Data.isUpdatePlayerPos){
			return true;
		}

		return false;
	},

	_touchPos : null,
	onGestureBegin : function (ctx) {
		var castPos = ctx.getBeginPoint();
		if (cc.rectContainsPoint(this._moveBtnRect, castPos)) {
			this._touchPos = castPos;
		}

		if(this.checkIsParkourState()){
			this.onJump(this, cc.CONTROL_EVENT_TOUCH_DOWN);
		}

		return true;
	},

	_forcePos : null,
	onGestureMove : function (ctx, off) {
		var castPos = ctx.getLastPoint();
		if (cc.rectContainsPoint(this._moveBtnRect, castPos)) {
			this._touchPos = castPos;
		}
		if (ctx.getForce() > 3) {
			this._forcePos = ctx.getLastPoint();
		}
	},

	onGestureLeave : function(ctx) {
		if (this._forcePos) {
			var lastPos = ctx.getLastPoint();
			// force touch for iPhone 6s
//			if (vee.Utils.distanceBetweenPoints(this._forcePos, lastPos) < 10) {
//				var mapPos = this.lyContainer.getPosition();
//				var checkPos = cc.p(lastPos.x - mapPos.x, lastPos.y - mapPos.y);
//
//				var checkGrid = game.Logic.getTileGridByPos(checkPos);
//				var td = game.Logic.map.getObject(checkGrid);
//				if (td && game.Logic.isBreakableBlock(td.gid)) {
//					td.collide(null,null,true);
//				}
//			}
		}
		this._touchPos = null;
		this._forcePos = null;

		if(this.checkIsParkourState()){
			this.onJump(this, cc.CONTROL_EVENT_TOUCH_UP_INSIDE);
		}
	},

	gameOver : function () {
		this.stopUpdate();
		this._isOver = true;
	},

	_isFirstPlay : false,
	setFirstPlay : function(isFirstPlay) {
		this._isFirstPlay = isFirstPlay;
	},

	isFirstPlay : function() {
		return this._isFirstPlay;
	},

	initStage : function(idx, isSavePoint, stageType) {
		cc.log("start game : "+idx);
		if (idx != game.Data.realLastTmxIdx) {
			game.Data.retryCount = 0;
		}
		if ((idx+"").substring(0,5) == "Story") {
			Cinema.isCinema = true;
		} else {
			Cinema.isCinema = false;
		}
		this.setSkipButtonVisible(false);
		game.Data.realLastTmxIdx = idx;
		vee.Ad.addAdPlayCount();
		++game.Data.playCountThisGame;
		if (idx == "Tutorial" && vee.Utils.isRecordAvaliable()) {
			this.isPause = true;
			this.ccbRecord.setVisible(false);
		}
		if (!stageType) stageType = game.StageType.Normal;
		game.Data.stageType = stageType;

		if (!game.Data.performingTMXIdx) {
			game.Data.lastTMXIdx = idx;
		} else {
			game.Data.lastTMXIdx = game.Data.performingTMXIdx;
		}

		if (stageType == game.StageType.Normal) {
			game.Data.addPlayCount();
			if (game.Data.isFreeGame) {
				vee.Ad.changeEntityAdIDTo("mini_over");
			}
		} else {
			if (game.Data.isFreeGame) {
				vee.Ad.changeEntityAdIDTo("game_over");
			}
		}
		if (game.Data.isFreeGame) {
			vee.Ad.changeEntityAdIDTo("game_win");
		}

		if (game.LevelData.selectedLevel && stageType == game.StageType.Normal) {
			game.LevelData.selectedLevel.gameBegin(isSavePoint);
		}
		if (!isSavePoint) game.Data.setSavePointIdx(-999);
		game.Data.performingTMXIdx = idx;
		if (stageType != game.StageType.Event) {
			game.Data.resetData();
			if (stageType == game.StageType.Normal) {
				game.Data.addEventCount();
			}
		} else {
			game.Data.resetEventData();
			game.Data.resetEventCount();
		}
		this.refreshCoin();
		this.createLevelStars();
		this.stopCamera = false;
		this.freezeButton = false;
		// Show player life count
		this.refreshHeart();
		game.Data.coin = 0;
		var nextAvatar = game.AvatarData.getNextAvatar();
		if (nextAvatar) {
			ItemCoin.coinFrameName = nextAvatar.coinFrame;
		} else {
			ItemCoin.coinFrameName = null;
		}

		if (Cinema.isCinema) {
			ItemCoin.coinFrameName = "coin_fist.png";
		}

		// Init tmx
		this.lyContainer.removeAllChildren();
		this.lyMap = new cc.Layer();
		this.lyMap.setPosition(cc.p(3,3));
		this.lyMapBack = new cc.Layer();
		this.lyMapBack.setPosition(cc.p(3,3));

		var lvName = "";
		var tmxFileName = "res/map"+idx+".tmx";
		cc.log("stageType = "+stageType);
		if (stageType == game.StageType.Mini) {
			this.nodeT.setVisible(false);
			lvName = "Mini";
			tmxFileName = "res/mapMini"+idx+".tmx";
		} else if (stageType == game.StageType.Event) {
			lvName = "Event";
			tmxFileName = "res/mapEvent"+idx+".tmx";
		}

		if (game.LevelData.selectedCategory && game.LevelData.selectedLevel) {
			var category = game.LevelData.selectedCategory.idx + 1;
			var level = game.LevelData.selectedLevel.idx + 1;
			// keyanaly
			vee.Analytics.logEvent("GameStart" + lvName + category + "0" + level);

			vee.Analytics.UGameEvent.gameStartEvent(lvName);

			if (stageType == game.StageType.Normal || stageType == game.StageType.Parkour) {
				if (category > 100) {
					vee.Analytics.logMissionStart("Level" + (category-100) + "-" + level + "R");
				} else {
					vee.Analytics.logMissionStart("Level" + category + "-" + level);
				}
			}
		}

		if (stageType == game.StageType.Mini) {
			vee.Analytics.logMissionStart("LevelMini" + idx);
		}

		var tmx = this.showTMX(tmxFileName);
		LyLevelLoading.show();
		this.lyContainer.addChild(tmx,2);
		tmx.addChild(this.lyMap, 100);
		tmx.addChild(this.lyMapBack);

		var levelCtl = LevelController.getController(lvName+idx);
		game.Data.oLvCtl = levelCtl;

		// set coin frame
		if (game.Data.checkIs61()) {
			this.spCoinIcon.setSpriteFrame("CoinChild_small.png");
		} else {
			var targetAvatar = game.AvatarData.getNextAvatar();
			if (targetAvatar) {
				this.spCoinIcon.setSpriteFrame(targetAvatar.coinFrame);
			}
		}

		game.Data.addTotalPlayCount();
		if ((game.Data.roleType == game.Roles.Marvin) || (game.Data.roleType == game.Roles.Android)) {
			this.lbCoinNum.setPositionX(this.lbCoinNum.getPositionX() - 50);
			this.spCoinIcon.setPositionX(this.spCoinIcon.getPositionX() - 50);
		}

		if (game.Data.stageType == game.StageType.Normal
			&& game.Data.isWeiXin
			&& idx != "Tutorial"
			&& idx != "Story1") {
			this.ccbTips.setVisible(true);
		} else {
			this.ccbTips.setVisible(false);
		}
		this.ccbTips.controller.ccbInit();

		this.refreshTipsButton();
	},

	showTMX : function (tmxFileName) {
		var tmx = game.Logic.createTMXMap(tmxFileName);
		return tmx;
	},

	createLevelStars : function () {
		var oLevelCtl = game.LevelData.selectedLevel;
		for (var i = 1; i < 4; ++i) {
			var starNode = UIStar.create(true);
			starNode.setPosition(cc.p((i - 2)*36, 0));
			starNode.setTag(i);
			this.nodeStar.addChild(starNode);
			if (game.LevelData.selectedLevel) {
				if (game.LevelData.selectedLevel.isTempStarAchieved(i)) {
					starNode.controller.setLocked(false);
				} else if (game.LevelData.selectedLevel.isStarAchieved(i)) {
					starNode.controller.setGettedStar();
				}
			}
		}
	},

	unlockStar : function (idx) {
		var starNode = this.nodeStar.getChildByTag(idx);
		if (starNode) {
			starNode.controller.unlockAnimate();
		}
	},

	refreshCoin : function () {
		if ((game.Data.roleType == game.Roles.Marvin) || (game.Data.roleType == game.Roles.Android)) {
			this.lbCoinNum.setString(game.Data.getTempCoin() + " / " + game.Data.stageMaxCoin);
		} else {
			this.lbCoinNum.setString(game.Data.getTempCoin());
		}

	},

	refreshHeart : function() {
		this.ccbHPBar.controller.setHP(game.Data.playerLife);
	},

	refreshBButton : function (type) {
		switch (type) {
			case game.PlayerType.Smash:{
				this.btnSmash.setBackgroundSpriteForState(cc.Scale9Sprite.create(res.btn_a_1_fall_png), cc.CONTROL_STATE_NORMAL);
				this.btnSmash.setBackgroundSpriteForState(cc.Scale9Sprite.create(res.btn_a_1_fall_on_png), cc.CONTROL_STATE_HIGHLIGHTED);
			}
				break;
			case game.PlayerType.Teleport:{
				this.btnSmash.setBackgroundSpriteForState(cc.Scale9Sprite.create(res.btn_a_3_blink_png), cc.CONTROL_STATE_NORMAL);
				this.btnSmash.setBackgroundSpriteForState(cc.Scale9Sprite.create(res.btn_a_3_blink_on_png), cc.CONTROL_STATE_HIGHLIGHTED);
			}
				break;
			case game.PlayerType.Bullet:{
				this.btnSmash.setBackgroundSpriteForState(cc.Scale9Sprite.create(res.btn_a_2_shoot_png), cc.CONTROL_STATE_NORMAL);
				this.btnSmash.setBackgroundSpriteForState(cc.Scale9Sprite.create(res.btn_a_2_shoot_on_png), cc.CONTROL_STATE_HIGHLIGHTED);
			}
				break;
			case game.PlayerType.Bomb:{
				this.btnSmash.setBackgroundSpriteForState(cc.Scale9Sprite.create(res.btn_a_4_bomb_png), cc.CONTROL_STATE_NORMAL);
				this.btnSmash.setBackgroundSpriteForState(cc.Scale9Sprite.create(res.btn_a_4_bomb_on_png), cc.CONTROL_STATE_HIGHLIGHTED);
			}
				break;
			default :
				break;
		}
	},

	refreshTipsButton : function () {
		this.ccbTips.controller.refreshBtnFrame();

	},

	showPowerDesc : function (type) {
		EfxPowerDesc.show(type, vee.Utils.pSub(this.nodeT.getPosition(), cc.p(0, 110)));
	},

	getElePosInScreen : function (pos) {
		var containerPos = this.lyContainer.getPosition();
		containerPos = cc.p(-containerPos.x, -containerPos.y);
		return vee.Utils.pSub(pos, containerPos);
	},

	getCoinIconPos : function () {
		return vee.Utils.pAdd(this.nodeTR.getPosition(), this.spCoinIcon.getPosition());
	},

	_cameraPos : null,
	_sclRate : null,
	initCamera : function (pos) {
		var category = game.LevelData.selectedCategory;
		if (category && category.idx > 99) {
			game.Data.cameraXPos = game.Data.cameraXPosLimit;
		} else {
			game.Data.cameraXPos = -game.Data.cameraXPosLimit;
		}
		game.Data.cameraYPos = game.Data.cameraYPosOff;
		this._cameraPos = game.Logic.getCameraOffset(game.Data.oPlayerCtl._faceTo, this._isFreezeX, this._isFreezeY);
		this._sclRate = game.Logic.getCameraScaleRate(game.Data.oPlayerCtl._moveState == MoveState.Dash || game.Data.oPlayerCtl._moveState == MoveState.DashJump);
		this.lyContainer.setScale(this._sclRate);
		if (this._isFreezeY) pos.y = this._freezeY;
		this._castPos = cc.p((this._cameraPos.x-pos.x*this._sclRate), (this._cameraPos.y-pos.y*this._sclRate));
		this.lyContainer.setPosition(this._castPos);
	},

	updateFunc : function (dt) {
		if (game.Data.oLyGameOver) return;
		dt = parseFloat(dt.toFixed(3)) > 0.02 ? 0.02 : dt;

		vee.Utils.beginTiming();
		var objs = game.Logic.dynamicObjMap.getObjects();
		for (var i in objs) {
			var obj = objs[i];
			if (obj && !obj.uncheck) {
				obj.updatePos(dt);
			}
		}
//		vee.Utils.endTiming("dynamic obj map");

		for (var i in game.Data.arrUpdateObj) {
			var obj = game.Data.arrUpdateObj[i];
			if (obj && !obj.uncheck) {
				obj.updatePos(dt);
			}
		}
//		vee.Utils.endTiming("arr update obj");

		var oPlayer = game.Data.oPlayerCtl;
		if (oPlayer && game.Data.isUpdatePlayerPos) {
			oPlayer.updatePos(dt);
			this.setCameraFollow(oPlayer.getElePosition(), dt);
		}
//		vee.Utils.endTiming("is update player pos");
	},

	_castPos : null,
	stopCamera : false,

	debugPreCamera : null,

	setCameraFollow : function(pos, dt) {
		if (this.stopCamera || !game.Data.oPlayerCtl) return;
		var oPlayer = game.Data.oPlayerCtl;
		this._cameraPos = game.Logic.getCameraOffset(oPlayer._faceTo, this._isFreezeX, this._isFreezeY);
		this._sclRate = 1;//game.Logic.getCameraScaleRate(oPlayer._moveState == MoveState.Dash || oPlayer._moveState == MoveState.DashJumpUp || oPlayer._moveState == MoveState.DashJumpDown);
//		this.lyContainer.setScale(this._sclRate);
		if (this._isFreezeY) pos.y = this._freezeY;
		this._castPos = cc.p((this._cameraPos.x-pos.x*this._sclRate), (this._cameraPos.y-pos.y*this._sclRate));
		this._safeCameraPos();
		if (this.bgCtl) this.bgCtl.setOffset(vee.Utils.pSub(this._castPos, this.lyContainer.getPosition()));

//		if(null == this.debugPreCamera || this.debugPreCamera != this._cameraPos.y){
////
//			this.debugPreCamera = this._cameraPos.y;
////
////			cc.log("camera debug start");
////
//			cc.log("cast pos=========  y=%d   posy====", this._cameraPos.y, pos.y);
////			vee.Utils.logObj(this._isFreezeX, "is freeze x====");
////			vee.Utils.logObj(this._isFreezeY, "is freeze y====");
//////		cc.log("play pos=========x=%d  y=%d ", oPlayer.getElePosition().x, oPlayer.getElePosition().y);
////
////			cc.log("camera debug end")
//		}


		this.lyContainer.setPosition(this._castPos);
	},

	_safeCameraPos : function () {
		this._castPos.x = this._castPos.x > -64 ? -64 : this._castPos.x;
		this._castPos.x = this._castPos.x < this._xRightEdge ? this._xRightEdge : this._castPos.x;
	},
	setCameraXRightEdge : function (rightEdge) {
		this._xRightEdge = 1136 - game.Data.mapRightEdge - TILE_WIDTH_HALF;
	},
	_isFreezeY : false,
	_freezeY : 0,
	setCameraYFreeze : function(isfreeze, y) {
		if (this._isFreezeY == isfreeze) return;
		this._isFreezeY = isfreeze;
		this._freezeY = y;
	},
	_isFreezeX : false,
	_freezeX : 0,
	setCameraXFreeze : function(isfreeze, x) {
		if (this._isFreezeX == isfreeze) return;
		this._isFreezeX = isfreeze;
		this._freezeX = x;
	},

	showStoryBlackEdge : function () {
		if (vee.Utils.isRecordAvaliable()) {
			this.ccbRecord.setVisible(false);
		}

		this.blackEdgeTL.stopAllActions();
		this.blackEdgeTL.setOpacity(0);
		this.blackEdgeTL.setPosition(cc.p(0,0));
		this.blackEdgeTL.runAction(cc.spawn(
			cc.EaseExponentialOut.create( cc.moveTo(0.6, cc.p(0,-100)) ),
			cc.EaseExponentialOut.create( cc.fadeTo(0.6, 255) )
		));
		this.blackEdgeBL.stopAllActions();
		this.blackEdgeBL.setOpacity(0);
		this.blackEdgeBL.setPosition(cc.p(0,-100));
		this.blackEdgeBL.runAction(cc.spawn(
			cc.EaseExponentialOut.create( cc.moveTo(0.6, cc.p(0,0)) ),
			cc.EaseExponentialOut.create( cc.fadeTo(0.6, 255) )
		));

		this.hideButtons();
	},

	shake : function () {
		var dur = 0.03;
		var amplitudeY = 18;
		this.rootNode.runAction(cc.Sequence.create(
			cc.MoveBy.create(dur,   0, -amplitudeY),
			cc.MoveBy.create(dur,   0, amplitudeY*2),
			cc.MoveBy.create(dur,   0, -amplitudeY),
			cc.MoveBy.create(dur/2, 0, amplitudeY),
			cc.MoveBy.create(dur/2, 0, -amplitudeY*2),
			cc.MoveBy.create(dur/2, 0, amplitudeY)
		));
	},

	timeScale : 1,
	startSlowRate : 0.05,
	slowDur : 0.1,
	slowReviveRate : 0.02,
	gameSlow : function () {
		this.timeScale = this.startSlowRate;
		vee.PopMgr.rootNode.getScheduler().setTimeScale(this.timeScale);
		this.nodeBL.runAction(cc.sequence(
			cc.delayTime(this.slowDur),
			cc.callFunc(function () {
				vee.Utils.scheduleCallbackForTarget(this.nodeBL, this.updateSlow.bind(this));
			}.bind(this))
		));
	},

	updateSlow : function () {
		if (this.timeScale >= 1) {
			vee.PopMgr.rootNode.getScheduler().setTimeScale(1);
			this.timeScale = 1;
			vee.Utils.unscheduleAllCallbacksForTarget(this.nodeBL);
			// reset
			this.timeScale = 1;
			this.startSlowRate = 0.05;
			this.slowDur = 0.1;
			this.slowReviveRate = 0.02;
			return;
		}
		vee.PopMgr.rootNode.getScheduler().setTimeScale(this.timeScale);
		this.timeScale += this.slowReviveRate;
	},

	hideStoryBlackEdge : function () {
		if (vee.Utils.isRecordAvaliable()) {
			if(!this.ccbRecord.isRecording)
			this.ccbRecord.setVisible(true);
		}

		this.blackEdgeTL.runAction(cc.spawn(
			cc.EaseExponentialOut.create( cc.moveTo(1, cc.p(0,0)) ),
			cc.EaseExponentialOut.create( cc.fadeTo(1, 0) )
		));
		this.blackEdgeBL.runAction(cc.spawn(
			cc.EaseExponentialOut.create( cc.moveTo(1, cc.p(0,-100)) ),
			cc.EaseExponentialOut.create( cc.fadeTo(1, 0) )
		));
	},
	showButtons : function (animate) {
		if (vee.Controller.isControllerControlling) return;
		if (game.Data.playerType != game.PlayerType.Normal) {
			this.showControlButton(LyGame.ControlButtonType.ActionButton, animate);
		}
		this.showControlButton(LyGame.ControlButtonType.JumpButton, animate);
		this.showControlButton(LyGame.ControlButtonType.MoveButton, animate);
	},
	hideButtons : function () {
		this.hideControlButton(LyGame.ControlButtonType.ActionButton);
		this.hideControlButton(LyGame.ControlButtonType.JumpButton);
		this.hideControlButton(LyGame.ControlButtonType.MoveButton);
	},

	hideUI : function () {
		this.hideControlButton(LyGame.ControlButtonType.ActionButton);
		this.hideControlButton(LyGame.ControlButtonType.JumpButton);
		this.hideControlButton(LyGame.ControlButtonType.MoveButton);

		this.nodeTL.setVisible(false);
		this.nodeT.setVisible(false);
		this.nodeTR.setVisible(false);
	},

	_tempRButtonAction : null,
	setSkipButtonVisible : function (v) {
		this.nodeSkip.setVisible(v);
		if (v) {
			this._tempRButtonAction = vee.Controller.getButtonActionKeyDown(vee.KeyCode.BUTTON_RIGHT_SHOULDER);
			vee.Controller.registerButtonAction(
				[vee.KeyCode.BUTTON_RIGHT_SHOULDER, vee.KeyCode.AXIS_RIGHT_TRIGGER],
				this.onSkip.bind(this)
			);
			vee.Controller.activeButton();
		} else {
			vee.Controller.registerButtonAction(
				[vee.KeyCode.BUTTON_RIGHT_SHOULDER, vee.KeyCode.AXIS_RIGHT_TRIGGER],
				this._tempRButtonAction
			);
		}
	},

	freezeButton : false,
	onMove : function (pSender, state) {
		if (this.freezeButton) return;
		if (state & cc.CONTROL_EVENT_TOUCH_DOWN ||
			state & cc.CONTROL_EVENT_TOUCH_DRAG_ENTER ||
			state & cc.CONTROL_EVENT_TOUCH_DRAG_INSIDE)
		{
			if (!this._touchPos) return;
			if (this._efxHighlightButton) this._efxHighlightButton.onMove();
			if (this._touchPos.x < this._btnPos.x) {
				// left button down
				this.btnMove.setBackgroundSpriteForState(cc.Scale9Sprite.create(res.btn_move_on_left_png), cc.CONTROL_STATE_HIGHLIGHTED);
				this.rightBtnUp();
				this._holdLeft = true;
				if (game.Data.oPlayerCtl.extendController) {
					game.Data.oPlayerCtl.extendController.onMoveBtnDown(vee.Direction.Right);
					return;
				}
				game.Data.oPlayerCtl.moveLeft();
			} else {
				// right button down
				this.btnMove.setBackgroundSpriteForState(cc.Scale9Sprite.create(res.btn_move_on_right_png), cc.CONTROL_STATE_HIGHLIGHTED);
				this.leftBtnUp();
				this._holdRight = true;
				if (game.Data.oPlayerCtl.extendController) {
					game.Data.oPlayerCtl.extendController.onMoveBtnDown(vee.Direction.Left);
					return;
				}
				game.Data.oPlayerCtl.moveRight();
			}
		}
		if (state & cc.CONTROL_EVENT_TOUCH_DRAG_EXIT ||
			state & cc.CONTROL_EVENT_TOUCH_DRAG_OUTSIDE ||
			state & cc.CONTROL_EVENT_TOUCH_CANCEL ||
			state & cc.CONTROL_EVENT_TOUCH_UP_INSIDE ||
			state & cc.CONTROL_EVENT_TOUCH_UP_OUTSIDE)
		{
			this._holdLeft = false;
			this._holdRight = false;
			if (game.Data.oPlayerCtl.extendController) {
				game.Data.oPlayerCtl.extendController.onMoveBtnUp();
				return;
			}
			this.rightBtnUp();
			this.leftBtnUp();
		}
	},

	leftBtnDown : function () {
		if (this.freezeButton) return;
		this._holdLeft = true;
		if (game.Data.oPlayerCtl.extendController) {
			game.Data.oPlayerCtl.extendController.onMoveBtnDown(vee.Direction.Right);
			return;
		}
		game.Data.oPlayerCtl.moveLeft();
	},
	leftBtnUp : function () {
		this._holdLeft = false;
		if (game.Data.oPlayerCtl.extendController) {
			game.Data.oPlayerCtl.extendController.onMoveBtnUp();
			return;
		}
		if (!this._holdRight && !game.Data.isInParkour()) game.Data.oPlayerCtl.stopMove();
	},

	rightBtnDown : function () {
		if (this.freezeButton) return;
		this._holdRight = true;
		if (game.Data.oPlayerCtl.extendController) {
			game.Data.oPlayerCtl.extendController.onMoveBtnDown(vee.Direction.Left);
			return;
		}
		game.Data.oPlayerCtl.moveRight();
	},
	rightBtnUp : function () {
		this._holdRight = false;
		if (game.Data.oPlayerCtl.extendController) {
			game.Data.oPlayerCtl.extendController.onMoveBtnUp();
			return;
		}
		if (!this._holdLeft && !game.Data.isInParkour()) game.Data.oPlayerCtl.stopMove();
	},

	onJump : function(pSender, state) {
		if (state & cc.CONTROL_EVENT_TOUCH_DOWN ||
			state & cc.CONTROL_EVENT_TOUCH_DRAG_ENTER)
		{
			this.jumpButtonDown();
		}
		if (state & cc.CONTROL_EVENT_TOUCH_DRAG_EXIT ||
			state & cc.CONTROL_EVENT_TOUCH_DRAG_OUTSIDE ||
			state & cc.CONTROL_EVENT_TOUCH_CANCEL ||
			state & cc.CONTROL_EVENT_TOUCH_UP_INSIDE ||
			state & cc.CONTROL_EVENT_TOUCH_UP_OUTSIDE)
		{
			this.jumpButtonUp();
		}
	},

	jumpButtonDown : function () {
		if (this.freezeButton) return;
		if (this._efxHighlightButton) this._efxHighlightButton.onJump();
		if (game.Data.oPlayerCtl.extendController) {
			game.Data.oPlayerCtl.extendController.onAButton();
			return;
		}
		game.Data.oPlayerCtl.jump();
		game.Data.isHoldJumpButtom = true;
	},

	jumpButtonUp : function () {
		if (this.freezeButton) return;
		game.Data.oPlayerCtl._jumpButtonReleased = true;
		game.Data.isHoldJumpButtom = false;
	},

	onSmash : function(pSender, state) {
		if (state & cc.CONTROL_EVENT_TOUCH_DOWN ||
			state & cc.CONTROL_EVENT_TOUCH_DRAG_ENTER)
		{
			this.BButtonDown();
		}
		if (state & cc.CONTROL_EVENT_TOUCH_DRAG_EXIT ||
			state & cc.CONTROL_EVENT_TOUCH_DRAG_OUTSIDE ||
			state & cc.CONTROL_EVENT_TOUCH_CANCEL ||
			state & cc.CONTROL_EVENT_TOUCH_UP_INSIDE ||
			state & cc.CONTROL_EVENT_TOUCH_UP_OUTSIDE)
		{
			this.BButtonUp();
		}
	},

	BButtonDown : function () {
		if (this.freezeButton) return;
		game.Data.oPlayerCtl.BButton();
		if (this._efxHighlightButton) this._efxHighlightButton.onAction();
	},

	BButtonUp : function () {
		if (this.freezeButton) return;
		game.Data.oPlayerCtl.BButton(true);
	},

	onClearPool : function () {
		for (var i in game.Data.enemyPool) {
			var obj = game.Data.enemyPool[i];
			obj._container.removeFromParent();
		}
		game.Data.enemyPool = [];
	},

	onLeft : function(pSender, state) {
		if (this.freezeButton) return;
		if (state & cc.CONTROL_EVENT_TOUCH_DOWN ||
			state & cc.CONTROL_EVENT_TOUCH_DRAG_ENTER) {
			this.rightBtnUp();
			this._holdLeft = true;
			if (game.Data.oPlayerCtl.extendController) {
				game.Data.oPlayerCtl.extendController.onMoveBtnDown(vee.Direction.Right);
				return;
			}
			if (this._efxHighlightButton) this._efxHighlightButton.onMove();
			game.Data.oPlayerCtl.moveLeft();
		}
		if (state & cc.CONTROL_EVENT_TOUCH_DRAG_EXIT ||
			state & cc.CONTROL_EVENT_TOUCH_DRAG_OUTSIDE ||
			state & cc.CONTROL_EVENT_TOUCH_CANCEL ||
			state & cc.CONTROL_EVENT_TOUCH_UP_INSIDE ||
			state & cc.CONTROL_EVENT_TOUCH_UP_OUTSIDE)
		{
			this._holdLeft = false;
			if (game.Data.oPlayerCtl.extendController) {
				game.Data.oPlayerCtl.extendController.onMoveBtnUp();
				return;
			}
			if (!this._holdRight) {
				game.Data.oPlayerCtl.stopMove();
			} else if (state & cc.CONTROL_EVENT_TOUCH_UP_OUTSIDE) {
				this.rightBtnUp();
			}
			if (this._touchPos && (state & cc.CONTROL_EVENT_TOUCH_DRAG_EXIT || state & cc.CONTROL_EVENT_TOUCH_DRAG_OUTSIDE)
				&& cc.rectContainsPoint(this._rectRightButton, this._touchPos)) {
				this.rightBtnDown();
			} else if (this._holdRight) {
				this.rightBtnUp();
			}
		}
	},

	onRight : function(pSender, state) {
		if (this.freezeButton) return;
		if (state & cc.CONTROL_EVENT_TOUCH_DOWN ||
			state & cc.CONTROL_EVENT_TOUCH_DRAG_ENTER) {
			this.leftBtnUp();
			this._holdRight = true;
			if (game.Data.oPlayerCtl.extendController) {
				game.Data.oPlayerCtl.extendController.onMoveBtnDown(vee.Direction.Left);
				return;
			}
			if (this._efxHighlightButton) this._efxHighlightButton.onMove();
			game.Data.oPlayerCtl.moveRight();
		}
		if (state & cc.CONTROL_EVENT_TOUCH_DRAG_EXIT ||
			state & cc.CONTROL_EVENT_TOUCH_DRAG_OUTSIDE ||
			state & cc.CONTROL_EVENT_TOUCH_CANCEL ||
			state & cc.CONTROL_EVENT_TOUCH_UP_INSIDE ||
			state & cc.CONTROL_EVENT_TOUCH_UP_OUTSIDE)
		{
			this._holdRight = false;
			if (game.Data.oPlayerCtl.extendController) {
				game.Data.oPlayerCtl.extendController.onMoveBtnUp();
				return;
			}
			if (!this._holdLeft) {
				game.Data.oPlayerCtl.stopMove();
			} else if (state & cc.CONTROL_EVENT_TOUCH_UP_OUTSIDE) {
				this.leftBtnUp();
			}
			if (this._touchPos && (state & cc.CONTROL_EVENT_TOUCH_DRAG_EXIT || state & cc.CONTROL_EVENT_TOUCH_DRAG_OUTSIDE)
				&& cc.rectContainsPoint(this._rectLeftButton, this._touchPos)) {
				this.leftBtnDown();
			} else if (this._holdLeft) {
				this.leftBtnUp();
			}
		}
	},

	onSkip : function () {
		if (game.Data.performingTMXIdx == "Story1") {
			Cinema.closeCinema();
			vee.Transition.out(res.MapTransition_ccbi, function () {
				vee.PopMgr.closeAll();
				cc.director.purgeCachedData();
				vee.PopMgr.popCCB("res/veeGameLayer.ccbi");
				game.Data.oLyGame.onLoaded();
				game.Data.oLyGame.initStage('Tutorial');
			});
		} else if (game.Data.performingTMXIdx == "Tutorial") {

			vee.Transition.out(res.MapTransition_ccbi, function () {
				LyLevelSelect.show();
			});
			/*
			LyLevelLoading.show();
			vee.Audio.startPreloadAudio(function () {
				if(game.Data.oLvLoadingCtl){
					game.Data.oLvLoadingCtl.loaded();
					LyLevelSelect.show();
				}
			});
			*/
		} else if (Story.isShowStory) {
			Story.skipStory();
		}
		this.setSkipButtonVisible(false);
	},

	isPause : false,
	onPause : function () {
		if (Story.isShowStory
			|| this.isPause
			|| game.Data.performingTMXIdx == "Tutorial"
			|| this._isOver
			|| Cinema.isCinema) return;

		this.pauseGame();
		LyPause.show();
	},

	pauseGame : function (isHoldMoveButton) {
		this.isPause = true;
		vee.PopMgr.pause(this.rootNode, true);
		if (this.gestureController) this.gestureController.setEnabled(false);
//		vee.PopMgr.pause(this.rootNode);
//		if (!isHoldMoveButton) {
			this.leftBtnUp();
			this.rightBtnUp();
//		}
	},

	resumeGame : function () {
		this.isPause = false;
		if (this.gestureController) this.gestureController.setEnabled(true);
		vee.PopMgr.resume();
	},

	/**
	 * @param {LyGame.ControlButtonType} buttonMask
	 */
	hideControlButton : function(buttonMask) {
		if (this._efxHighlightButton && (this._efxHighlightButton.getButtonMask() & buttonMask)) {
			this._efxHighlightButton.remove();
			this._efxHighlightButton = null;
		}
		if (buttonMask & LyGame.ControlButtonType.MoveButton) {
			this.btnMove.setVisible(false);
		}
		if (buttonMask & LyGame.ControlButtonType.ActionButton) {
			this.btnSmash.setVisible(false);
		}
		if (buttonMask & LyGame.ControlButtonType.JumpButton) {
			this.btnJump.setVisible(false);
		}
	},

	/**
	 * @param {LyGame.ControlButtonType} buttonMask
	 */
	showControlButton : function(buttonMask, animate, highlight) {
		if (this.lyGesture.controller.getEnabled() || vee.Controller.isControllerControlling) return;
		var isSmall = game.Data.isSmallButton();
		if (buttonMask & LyGame.ControlButtonType.MoveButton) {
			if (animate) {
				var node = cc.BuilderReader.load(res.guideBtnMove_ccbi);
				if (isSmall) node.setScale(game.Data.smallButtonRate);
				this.rootNode.addChild(node);
				node.controller.show(highlight);
			} else this.btnMove.setVisible(true);
		}
		if (buttonMask & LyGame.ControlButtonType.ActionButton) {
			if (animate) {
				var node = cc.BuilderReader.load(res.guideBtnA_ccbi);
				if (isSmall) node.setScale(game.Data.smallButtonRate);
				this.rootNode.addChild(node);
				node.controller.show(highlight);
				this.setHighlightControlButton(buttonMask);
			} else this.btnSmash.setVisible(true);
		}
		if (buttonMask & LyGame.ControlButtonType.JumpButton) {
			if (animate) {
				var node = cc.BuilderReader.load(res.guideBtnB_ccbi);
				if (isSmall) node.setScale(game.Data.smallButtonRate);
				this.rootNode.addChild(node);
				node.controller.show(highlight);
			} else this.btnJump.setVisible(true);
		}
	},

	setHighlightControlButton : function(buttonMask, quick) {
		var isSmall = game.Data.isSmallButton();
		var isGesture = this.lyGesture.controller.getEnabled();
		if (this._efxHighlightButton && (!(this._efxHighlightButton.getButtonMask() & buttonMask) || this._efxHighlightButton.isGesture != isGesture)) {
			this._efxHighlightButton.remove();
			this._efxHighlightButton = null;
		}
		if (!this._efxHighlightButton) {
			var node = cc.BuilderReader.load(isGesture ? res.btnLightGesture_ccbi : (buttonMask & LyGame.ControlButtonType.MoveButton ? res.btnLightMove_ccbi : res.btnLight_ccbi));
			this.rootNode.addChild(node);
			if (isSmall && !isGesture) node.setScale(game.Data.smallButtonRate);
			this._efxHighlightButton = node.controller;
		}
		this._efxHighlightButton.show(buttonMask, quick);
	}
});

LyGame.ControlButtonType = {
	MoveButton : 0x0001,
	ActionButton : 0x0010,
	JumpButton : 0x0100
};

LyGame.ctl = null;
LyGame.getCtl = function () {
	if (!LyGame.ctl) {
		LyGame.ctl = LyGame.create();
	}
	return LyGame.ctl;
};

var BtnTips = vee.Class.extend({
	spTip : null,
	ccbInit : function () {
		this.playAnimate("delay");
	},

	onTip : function () {
		var tipsSign = game.Data.isTipsPurchased(game.Data.performingTMXIdx);
		if (tipsSign) {
			// show tips
			LyTipsDesc.show();
			game.Logic.showTipsLayer();
		} else {
			// show buy tips alert
			vee.IAPMgr.buyProduct(7, function () {
				game.Data.purchaseTip(game.Data.performingTMXIdx);
				game.Data.oLyGame.refreshTipsButton();
				LyTipsDesc.show();
				game.Logic.showTipsLayer();
			});
		}
	},

	refreshBtnFrame : function ()
	{
		var isPurchased = game.Data.isTipsPurchased(game.Data.performingTMXIdx);
		if (isPurchased) {
			this.spTip.setTexture(res.btn_tip_1_png);
		} else {
			this.spTip.setTexture(res.btn_tip_0_png);
		}
	}
});
