/**
 * Created with AppCode.
 * User: yop
 * Date: 15/10/27
 * Time: 下午3:33
 * To change this template use File | Settings | File Templates.
 */

LevelController.LevelMini200 = LevelController.extend({
	eventStory1 : function(grid, dir) {
		this.showStory(1, grid, ""+
		"RemoveEnemy;"+
		"MoveCamera,35,25,2;"+
		"SelectNpc;"+
		"FaceTo,left;"+
		"ShowDialog,"+ vee.Utils.getLocalizedStringForKey("Well done! You survived.", "干的不错，你还活着。") +";"+
		"ShowDialog,"+ vee.Utils.getLocalizedStringForKey("But don't lose your attention!", "别放松警惕！") +";"+
		"HideDialog;"+
		"TimeLine,huxi_2;"+
		"Delay,1;"+
		"AddCoin," + vee.Utils.getObjByPlatform('400','700','400') + ";"+
		"Delay,2;"+
		"GameOver"+
		"");
	}
});
