/**
 * Created with AppCode.
 * User: Yop Chan
 * Date: 14-11-11
 * Time: 15:03
 * To change this template use File | Settings | File Templates.
 */

var vee = vee = vee || {};

var ShareResult ={
	kShareSuccess : 0,
	kShareFail : 1,
	kShareCancel : 2,
	kShareTimeOut : 3,
	kLoginSuccess : 4,
	kLoginFailed : 5,
	kGetFriendsIDSuccess : 6,
	kGetFriendsIDFailed : 7,
	kGetFriendsNameSuccess : 8,
	kGetFriendsNameFailed : 9,
	kSendRequestSuccess : 10,
	kTiming : 11
};

vee.Leaderboard = {
	leaderboardPlugin : null,
	_url : "http://leaderboard.veewo.com",

	init : function() {
		if (!this.leaderboardPlugin){
			var pluginName = game.getConfig().LeaderboardPluginName;
			this.leaderboardPlugin = plugin.PluginManager.getInstance().loadPlugin(pluginName);
			if (this.leaderboardPlugin && game.getConfig().LeaderboardPluginInfo){
				this.leaderboardPlugin.configDeveloperInfo(game.getConfig().LeaderboardPluginInfo);
			}
			if (!this.leaderboardPlugin) {
				this.leaderboardPlugin = null;
			}
		}
	},

	login : function(funcSuccess, funcFail) {
		if(this.leaderboardPlugin){
			this.leaderboardPlugin.setResultListener({
				onShareResult : function(ret, msg) {
					switch (ret){
						case ShareResult.kLoginFailed:
						case ShareResult.kShareTimeOut:
							cc.log("得到facebook结果：" + ShareResult.kLoginFailed);
							if(_.isFunction(funcFail))
							funcFail();
							break;
						case ShareResult.kLoginSuccess:
							cc.log("得到facebook结果：" + ShareResult.kLoginSuccess);
							if(_.isFunction(funcSuccess))
							funcSuccess();
							break;
//						case  ShareResult.kTiming:
//							cc.log("得到facebook结果：" + ShareResult.kTiming);
//							vee.Leaderboard.timingSession();
						default :
							break;
					}
				}
			});
			this.leaderboardPlugin.callFuncWithParam("login");
		}
	},

	logout : function() {
		if(this.leaderboardPlugin && this.isLoggedIn()){
			this.leaderboardPlugin.callFuncWithParam("logout");
		}
	},

//	timingSession : function() {
//		cc.log("开始记时");
//		vee.Utils.scheduleOnce(function() {
//			if (!vee.Leaderboard.isLoggedIn()) {
//				vee.Leaderboard.stopSession();
//			}
//		}.bind(this), 10.0);
//	},

	stopSession : function() {
		cc.log("停止session");
		if(this.leaderboardPlugin && this.isLoggedIn()){
			this.leaderboardPlugin.callFuncWithParam("stopSessionRequest");
		}
	},

	getUserId : function() {
		if(this.leaderboardPlugin && this.isLoggedIn()){
			return this.leaderboardPlugin.callStringFuncWithParam("getUserID");
		}else{
			return null;
		}
	},

	getUserName : function() {
		if(this.leaderboardPlugin && this.isLoggedIn()){
			return this.leaderboardPlugin.callStringFuncWithParam("getUserName");
		}else{
			return null;
		}
	},

	isLoggedIn : function() {
		if(this.leaderboardPlugin){
			return this.leaderboardPlugin.callBoolFuncWithParam("isLoggedIn");
		}else{
			return false;
		}
	},

	submitScore : function(userID, score, leaderboardID, appAlias, funcSuccess, funcFail) {
		vee.Utils.getObjWithURL(
			this._url,
			function(data){
				vee.Utils.logObj(data, "提交分数回调：");
				if (data) {
					funcSuccess(data);
				} else {
					funcFail();
				}
			},
			"setscore",
			JSON.stringify({
				"user_id": userID,
				"score": score,
				"app_alias": appAlias,
				"leaderboard_id": leaderboardID
			}),true
		);
	},

	getScores : function(userIdArray, leaderboardID, appAlias, funcSuccess, funcFail) {
		vee.Utils.getObjWithURL(
			this._url,
			function(data){
				if(data){
					funcSuccess(JSON.parse(data));
				}else {
					funcFail();
				}
			},
			"getscores",
			JSON.stringify({
				"user_ids": userIdArray,
				"app_alias": appAlias,
				"leaderboard_id": leaderboardID
			}),true
		);
	},

	getFriendsAndMyIDs : function(funcSuccess, funcFail) {
		if(this.leaderboardPlugin){
			this.leaderboardPlugin.setResultListener({
				onShareResult : function(ret, msg) {
					switch (ret){
						case ShareResult.kGetFriendsIDFailed:
							cc.log("得到facebook结果：" + ShareResult.kGetFriendsIDFailed);
							if(_.isFunction(funcFail))
								funcFail();
							break;
						case ShareResult.kGetFriendsIDSuccess:
							cc.log("得到facebook结果：" + ShareResult.kGetFriendsIDSuccess);
							if(_.isFunction(funcSuccess)){
								var idArray = msg.split(",");
								cc.log("facebook IDs：" + msg);
								cc.log("数组长度：" + idArray.length);
								for(var i = 0; i < idArray.length; i++){
									cc.log("好友ID：" + idArray[i]);
								}
								funcSuccess(idArray);
							}
							break;
						default :
							break;
					}
				}
			});
			this.leaderboardPlugin.callFuncWithParam("getFriendsAndMyIDs");
		}
	},

	getFriendsAndMyNames : function(funcSuccess, funcFail) {
		if(this.leaderboardPlugin){
			this.leaderboardPlugin.setResultListener({
				onShareResult : function(ret, msg) {
					switch (ret){
						case ShareResult.kGetFriendsNameFailed:
							cc.log("得到facebook结果：" + ShareResult.kGetFriendsNameFailed);
							if(_.isFunction(funcFail))
								funcFail();
							break;
						case ShareResult.kGetFriendsNameSuccess:
							cc.log("得到facebook结果：" + ShareResult.kGetFriendsNameSuccess);
							if(_.isFunction(funcSuccess)){
								cc.log("facebook names：" + msg);
								var nameArray = msg.split(",");
								for(var i = 0; i < nameArray.length; i++){
									cc.log("好友姓名：" + nameArray[i]);
								}
								funcSuccess(nameArray);
							}
							break;
						default :
							break;
					}
				}
			});
			this.leaderboardPlugin.callFuncWithParam("getFriendsAndMyNames");
		}
	},

	sendRequest : function(funcSuccess) {
		if(this.leaderboardPlugin){
			this.leaderboardPlugin.setResultListener({
				onShareResult : function(ret, msg) {
					switch (ret){
						case ShareResult.kSendRequestSuccess:
							cc.log("得到facebook结果：" + ShareResult.kSendRequestSuccess);
							if(_.isFunction(funcSuccess)){
								var requestNum = Number(msg);
								funcSuccess(requestNum);
							}
							break;
						default :
							break;
					}
				}
			});
			this.leaderboardPlugin.callFuncWithParam("sendRequest");
		}
	},

	getAllNotifications : function() {
		if(this.leaderboardPlugin){
			this.leaderboardPlugin.callFuncWithParam("getAllNotifications");
		}
	}
};
