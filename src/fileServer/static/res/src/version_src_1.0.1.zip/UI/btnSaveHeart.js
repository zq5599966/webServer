/**
 * Created with AppCode.
 * User: WanThirty
 * Date: 15/9/12
 * Time: 下午5:28
 * To change this template use File | Settings | File Templates.
 */

var BtnSaveHeart = vee.Class.extend({
	lbCoinNum : null,

	onCreate : function () {
		this.lbCoinNum.setString(game.Data.savePointLifePrice);
	},

	showAnimate : function () {
		this.playAnimate("show");
	},
	
	hideAnimate : function () {
		this.playAnimate("end");
	},

	onBuy : function () {
		if (game.LevelData.getCoin() < game.Data.savePointLifePrice) {
			AlertMoreCoin.show();
		} else {
			game.LevelData.costCoin(game.Data.savePointLifePrice);
			game.Data.oLyGame.refreshCoin();
			game.Data.addLifeTo(game.Data.playerMaxLife);
			EfxGetLife.show(game.Data.oPlayerCtl.getElePosition());
			BtnSaveHeart.hide();
		}
	},

	onExit : function () {
		BtnSaveHeart.ctl = null;
	}
});

BtnSaveHeart.ctl = null;
BtnSaveHeart.hasShown = false;

BtnSaveHeart.show = function () {
	if (BtnSaveHeart.hasShown || game.Data.playerLife >= game.Data.playerMaxLife) return;
	BtnSaveHeart.hasShown = true;
	if (!BtnSaveHeart.ctl) {
		var node = cc.BuilderReader.load(res.saveHeart_ccbi);
		game.Data.oLyGame.nodeT.addChild(node, 8);
		BtnSaveHeart.ctl = node.controller;
	}
	BtnSaveHeart.ctl.showAnimate();
	game.Data.gridChangeFunc = function (grid) {
		if (!(grid.x + 1 >= ItemSavePoint.btnBuyGrid.x
			&& grid.x - 1 <= ItemSavePoint.btnBuyGrid.x
			&& grid.y == ItemSavePoint.btnBuyGrid.y))
		{
			BtnSaveHeart.hide();
		}
	};
};

BtnSaveHeart.hide = function () {
	if (!BtnSaveHeart.hasShown) return;
	BtnSaveHeart.hasShown = false;
	game.Data.gridChangeFunc = null;
	if (BtnSaveHeart.ctl) BtnSaveHeart.ctl.hideAnimate();
};