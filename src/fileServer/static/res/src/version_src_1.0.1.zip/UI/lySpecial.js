/**
 * Created with AppCode.
 * User: WanThirty
 * Date: 15/10/28
 * Time: 下午5:34
 * To change this template use File | Settings | File Templates.
 */

var LySpecial = vee.Class.extend({
	lbTitle     : null,
	lbContent   : null,
	lbDetail    : null,

	btnConfirm  : null,
	btnClose    : null,
	btnRewardCoin : null,
	spHead      : null,

	_isOver     : false,
	_tempControllerState : null,

	onCreate : function () {
		game.Data.resetMiniCount();
	},

	ccbInit : function () {
		this.playAnimate("OPEN");
		var frame = null;
		var adata = game.AvatarData.getNextAvatar(0, true);
		if (adata) {
			frame = adata.headName;
		} else {
			var arr = [0,1,2,3,4,5,6,7,8,9];
			var curIdx = game.AvatarData.getCurrentAvatar().idx;
			arr.splice(curIdx, 1);
			adata = game.AvatarData.getAvatarData(vee.Utils.randomChoice(arr));
			frame = adata.headName;
		}
		this.spHead.setTexture(frame);
		this.handleKey(true);
		this._tempControllerState = vee.Controller.cacheControllerState();
	},

	initController : function () {
		vee.Controller.initSelector(1,1, this.onClose.bind(this), cc.p(0,0));
		vee.Controller.registerItemByButton(this.btnConfirm, cc.p(0,0), this.onConfirm.bind(this), "res/mfi_btn_on_210.png");
		vee.Controller.activeSelector();
	},

	onKeyBack : function(){
		this.onClose();
		return true;
	},

	onConfirm : function () {
		if (this._isOver) return;
		this._isOver = true;
		vee.Controller.deactiveSelector();
		game.Data.resetMiniCount();
		cc.log("mini count = "+game.Data.getMiniCount());
		this.playAnimate("HIDE", function () {
			game.Data.oLyGameOver.showMini();
			vee.PopMgr.closeLayer();
		}.bind(this));
	},

	onRewardCoin : function () {

	},

	onClose : function () {
		if (this._isOver) return;
		this._isOver = true;

		vee.Controller.deactiveSelector();
		this.playAnimate("HIDE", function () {
			vee.Controller.reviveControllerState(this._tempControllerState);
			vee.PopMgr.closeLayer();
		});
		game.Data.oLyGameOver.blockButton = false;
	}
});

LySpecial.show = function () {
	var node = vee.PopMgr.popCCB(res.vAlertboxChallenge_ccbi, { alpha : 0 });
	node.controller.ccbInit();
	vee.Audio.playEffect(res.inGame_function_bonusEntrance_mp3);
};