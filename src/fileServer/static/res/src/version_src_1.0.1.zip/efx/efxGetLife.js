/**
 * Created with AppCode.
 * User: WanThirty
 * Date: 15/7/9
 * Time: 下午1:31
 * To change this template use File | Settings | File Templates.
 */

var EfxGetLife = {
	show : function (pos) {
		var node = cc.BuilderReader.load(res.efx_GetLife_ccbi);
		node.setPosition(pos);
		node.getChildByTag(9).setPositionType(cc.ParticleSystem.TYPE_RELATIVE);
		node.runAction(cc.sequence(
			cc.delayTime(2),
			cc.callFunc(function () {
				this.removeFromParent();
			}.bind(node))
		));

		game.Data.oLyGame.lyMap.addChild(node, 11);
	}
};