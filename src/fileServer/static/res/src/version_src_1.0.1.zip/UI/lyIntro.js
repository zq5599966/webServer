/**
 * Created with AppCode.
 * User: Tezika
 * Date: 15-9-7
 * Time: 下午2:28
 * To change this template use File | Settings | File Templates.
 */


var LyIntro = vee.Class.extend({

	/** @type {number}动画播放次数 */
	_countOfAnimate: 0,
	/** @type {number}动画的总数 */
	_sumOfAnimates:0,
	/** @type {number} 运动速度 */
	_moveSpeed : 120,
	/** @type {boolean} */
	_isPlayerStop:false,
	/** @type {number} */
	_playerToMacCenter:3,
	/** @type {object} */
	_animateTimeLines:{
		logo_dis: "logo",
		mac_show: "show",
		mac_run: "run",
		logo_start: "2",
		breath: "huxi",
		run: "run"
	},

	onLoaded:function(){},
	/**
	 * 初始化方法
	 */
	ccbInit:function(){
		this._sumOfAnimates = 2;
		this.playAnimate(this._animateTimeLines.logo_dis,function(){
			if((++this._countOfAnimate) == 2){
//				this.mac.setLocalZOrder(1);
				this.mac.controller.playAnimate(this._animateTimeLines.mac_show);
				cc.log("animate callback");
				this.player.controller.playAnimate(this._animateTimeLines.run);
				this._updateFunc = this.updateFunc.bind(this);
				vee.Utils.scheduleCallbackForTarget(this.rootNode, this._updateFunc);
			}
			//物理按键响应
			this.handleKey(true);
		}.bind(this));
	},

	/**
	 * update
	 * @param dt
	 */
	updateFunc:function(dt){
		cc.log("update");
		if(!this._isPlayerStop){
			this.player.setPositionX(this.player.getPositionX()+this._moveSpeed*dt);
			this.judgeIsPlayerMoveToTheGoal();
		}

	},
	/**
	 * 判断猪脚是否到位置
	 */
	judgeIsPlayerMoveToTheGoal:function(){
		this._countOfAnimate = 0;
		if(this.player.getPositionX()>=this.mac.getPositionX()){
			//停止动画
			this.player.controller.playAnimate(this._animateTimeLines.breath);
			this._isPlayerStop  = true;
			//设置玩家的位置
			this.player.setPositionX(this.mac.getPositionX()-this._playerToMacCenter);
			//解除刷新
			vee.Utils.unscheduleCallbackForTarget(this.rootNode,this._updateFunc);
			var delay =  cc.delayTime(0.5);
			var callFunc = cc.callFunc(function(){this.mac.controller.playAnimate(this._animateTimeLines.mac_run,function(){
				this.logo.controller.playAnimate(this._animateTimeLines.logo_start,function(){
					if(++this._countOfAnimate == 4){
						this.onIntroOver();
					}
				}.bind(this));}.bind(this))
			}.bind(this));
			this.rootNode.runAction(cc.sequence(delay,callFunc));
		}
	},
	/**
	 * 结束回调
	 */
	onIntroOver : function () {
		vee.Transition.out(res.MapTransition_ccbi, function () {
			vee.PopMgr.closeAll();
			cc.director.purgeCachedData();
			vee.PopMgr.popCCB("res/veeGameLayer.ccbi");
			game.Data.oLyGame.onLoaded();
			game.Data.oLyGame.initStage('Tutorial');
		});
	}
})

cc.BuilderReader.registerController("LyIntro",LyIntro);

var MacCtrl = vee.Class.extend({});
cc.BuilderReader.registerController("MacCtrl",MacCtrl);

var LogoCtrl = vee.Class.extend({});
cc.BuilderReader.registerController("LogoCtrl",LogoCtrl);


var HeroCtrl = vee.Class.extend({});
cc.BuilderReader.registerController("HeroCtrl",HeroCtrl);

var PlayerCtrl = vee.Class.extend({});
cc.BuilderReader.registerController("PlayerCtrl",PlayerCtrl);

var RobotCtrl = vee.Class.extend({});
cc.BuilderReader.registerController("RobotCtrl",RobotCtrl);

LyIntro.show = function () {
	var node = vee.PopMgr.popCCB(res.intro_ccbi);
	node.controller.ccbInit();
};