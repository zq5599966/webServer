/**
 * Created with AppCode.
 * User: yop
 * Date: 15/8/27
 * Time: 下午3:34
 * To change this template use File | Settings | File Templates.
 */

EleText = vee.Class.extend({
	/** @type {cc.Label} */
	lbTitle : null,
	/** @type {cc.Label} */
	lbContent : null,

	id : -1,

	setText : function(title, content) {
		this.lbTitle.setString(title);
		this.lbContent.setString(vee.Utils.getLocalizedStringForKey(content));
	},

	_showOnce : false,
	setShowOnce : function(v) {
		this._showOnce = v;
	},

	show : function(pos, duration) {
		this.rootNode.setPosition(pos);
		this.rootNode.setVisible(true);
		this.playAnimate('Show');
		vee.Audio.playEffect(res.inGame_efx_showText_mp3);
		if (duration > 0) {
			vee.Utils.scheduleOnceForTarget(
				this.rootNode,
				function () {
					this.playAnimate('Hide',
						function () {
							this.rootNode.setVisible(false);
							EleText.ReuseText.push(this);
							EleText.Texts[this.id] = this._showOnce;
						});
				}.bind(this),
				duration);
		}
	}
});

EleText.Texts = [];
EleText.ReuseText = [];
EleText.GetText = function () {
	var temp = this.ReuseText.pop();
	if (!temp) {
		temp = cc.BuilderReader.load(res.eleText_ccbi).controller;
		game.Data.oLyGame.lyMap.addChild(temp.rootNode, -999);
	}
	temp.setShowOnce(false);
	return temp;
};

EleText.Clear = function() {
	EleText.Texts = [];
	EleText.ReuseText = [];
};

EleText.Show = function (id, pos, title, content, duration, isShowOnce) {
	var ctl = this.Texts[id];
	if (!ctl) {
		ctl = this.GetText();
		ctl.id = id;
		ctl.setText(title, content);
		if (duration.length > 0) duration = parseFloat(duration);
		else duration = -1;
		ctl.setShowOnce(isShowOnce);
		ctl.show(pos, duration);
		this.Texts[id] = ctl;
	}
}

Trigger.ShowText = Trigger.extend({

	func : function(grid, dir, isShowOnce) {
		var arrArg = this.name.split(";");
		if (arrArg[4]) {
			var offset = game.Data.getPointFromString1(arrArg[4]);
			grid = vee.Utils.pAdd(grid, offset);
		}
		var pos = game.Logic.getTilePosCenterByGrid(grid);
		if (arrArg[5] && vee.Controller.isConnected) return;
		EleText.Show(arrArg[0], pos, arrArg[1], arrArg[2], arrArg[3], isShowOnce);
	}
});

Trigger.ShowTextOnce = Trigger.ShowText.extend({
	func : function(grid, dir) {
		var arrArg = this.name.split(";");
		if (arrArg[4]) {
			var offset = game.Data.getPointFromString1(arrArg[4]);
			grid = vee.Utils.pAdd(grid, offset);
		}
		var pos = game.Logic.getTilePosCenterByGrid(grid);
		EleText.Show(arrArg[0], pos, arrArg[1], arrArg[2], arrArg[3], true);
	}
});