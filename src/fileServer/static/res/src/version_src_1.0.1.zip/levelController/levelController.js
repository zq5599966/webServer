/**
 * Created with AppCode.
 * User: yop
 * Date: 15/9/7
 * Time: 上午11:45
 * To change this template use File | Settings | File Templates.
 */

var LevelController = cc.Class.extend({
	_story : null,
	_handSkip : false,
	prepare : function(){
		this._story = [];
	},

	complete : function () {

	},

	onUpdateLife : function(count) {},

	showStory : function(id, grid, script) {
		if (this._story[id]) return;
		if (this._handSkip) {
			Story.showStory(script, grid, false, id, true);
		} else {
			this._story[id] = true;
			Story.showStory(script, grid, false, id, false);
		}
	},

	skipStory : function(storyIdx) {
		var storyFunc = this["eventStory"+storyIdx];
		this._handSkip = true;
		if (storyFunc) {
			storyFunc.bind(this)();
		}
		this._handSkip = false;
	},

	blockStory : function(storyIdx, force) {
		var storyHasPlayed = game.Data.getStoryHasPlayed(game.Data.performingTMXIdx, storyIdx);
		cc.log("story "+storyIdx+" played is "+storyHasPlayed);
		if (storyHasPlayed || force) {
			this._story[storyIdx] = true;
		}
	}
});

LevelController.getController = function (idx) {
	if (LevelController['Level' + idx]) {
		return new LevelController['Level' + idx]();
	} else return new LevelController();
}