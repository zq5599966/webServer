/**
 * Created by john on 2016/11/25.
 */
var appConfig_IOS = {
    AppID : 1041873285,

    AppName : app.configManager.AppName,

    AppAlias : app.configManager.AppAlias,

    AppURL : app.configManager.AppURL,

    RateURL : app.configManager.RateURL,

    PromoURL : app.configManager.PromoURL,
    PromoChannel : app.configManager.PromoChannel,
    PromoBannerEnable : app.configManager.PromoBannerEnable,
    PromoFullScreenEnable : app.configManager.PromoFullScreenEnable,

    //plugins
    GameCenterPluginName : app.configManager.GameCenterPluginName,
    AnalyticsPluginName : app.configManager.AnalyticsPluginName,
    AnalyticsPluginADTrackName : app.configManager.AnalyticsPluginADTrackName,
    IAPPluginName : app.configManager.IAPPluginName,

    //Deprecated
    AdVideoPluginName : app.configManager.AdVideoPluginName,
    AdBannerPluginName : app.configManager.AdBannerPluginName,
    AdInterstialPluginName : app.configManager.AdInterstialPluginName,

    AdInterstialPluginCoinfig : null,
    IsBannerEnabled : app.configManager.IsBannerEnabled,
    IsInterestialEnabled : app.configManager.IsInterestialEnabled,

    IAPs : [
        {ProductID: "com.veewo.unlock", NonConsumable:"false"},
        {ProductID: "com.veewo.allcat", NonConsumable:"true"},
        {ProductID: "com.veewo.power", NonConsumable:"false"}
    ],

    LeaderboardIDs : ["com.veewo.stars"],

    AnalyticsPluginADTrackConfig : {                            //不知道什么鬼 init plugin
        AdvertiserID : "164496",
        ConversionKey : "1b0e697a2fa9501dcafa6a08e2c1c017"
    },

    GameCenterPluginConfig : {"appid" : "1041873285"},

    AnalysticsPluginConfig : "584a53fb8f4a9d74180016f9",
    // AnalysticsPluginConfig : "9206B621D983CC3399084911F328C4C6",

    //Deprecated
    AdBannerPluginConfig : {
        AppGoogleBannerId: "ca-app-pub-4587184008612513/3196418381",            //未启用
        AppGoogleInterstialId: "ca-app-pub-1777019132527367/9535896334",        //多处修改
        AppFaceBookInterstialId : "150931201938556_234107046954304",            //多处修改
        AppGoogleRewardedVideoId : "ca-app-pub-1777019132527367/7773351931"     //多处修改
    },

    //vungle视频广告id
    AdVideoPluginConfig : {
        AdsVungle : "1041873285"
    },

    Achievements : [                        //成就
        "com.veewo.star1",   // star 1
        "com.veewo.star2",   // star 2
        "com.veewo.star3",   // star 3
        "com.veewo.star4",   // star 4
        "com.veewo.star5",   // star 5
        "com.veewo.flash",   // flash
        "com.veewo.jump",    // jump
        "com.veewo.heart",   // heart
        "com.veewo.coin"     // coin
    ],

    //Deprecated
    AdOdd : "ca-app-pub-1777019132527367/1974641134",
    AdEven : "ca-app-pub-1777019132527367/4442904336",
    AdPause : "ca-app-pub-1777019132527367/2966171130",
    AdGameOver : "ca-app-pub-1777019132527367/7396370731",
    AdStartUp : "ca-app-pub-1777019132527367/8873103936",
    AdExit : "ca-app-pub-1777019132527367/3451374331",

    AdPosEntityConfig : [
        "AdsAdapter",
        "AdsAdapter",
        "AdsAdapter"
    ],
}