/**
 * Created with AppCode.
 * User: WanThirty
 * Date: 15/11/5
 * Time: 上午11:42
 * To change this template use File | Settings | File Templates.
 */

var EfxLevel = vee.Class.extend({
	lbLevelTitle : null,
	lbLevelContent : null,
	nodeT : null,
//	nodeTL : null,
//	nodeBL : null,

	setLevel : function (stage, level) {
		if (stage > 99) {
			stage -= 100;
			stage = "M"+stage;
		}
		vee.PopMgr.setNodePos(this.nodeT, vee.PopMgr.PositionType.Top);
		this.lbLevelTitle.setString(stage+"-"+level);
		this.playAnimate("show", function () {
			this.playAnimate("end", function () {
				this.rootNode.removeFromParent();
				vee.PopMgr.closeLayerByCtl(this);
			}.bind(this))
		}.bind(this));
//		vee.PopMgr.setNodePos(this.nodeTL, vee.PopMgr.PositionType.TopLeft);
//		vee.PopMgr.setNodePos(this.nodeBL, vee.PopMgr.PositionType.BottomLeft);
	}
});

EfxLevel.show = function (stage, level) {
//	var node = cc.BuilderReader.load(res.guideLevel_ccbi);
	var node = vee.PopMgr.popCCB(res.guideLevel_ccbi);
//	game.Data.oLyGame.rootNode.addChild(node, 9999);
	node.controller.setLevel(stage, level);
//	node.setPosition(cc.p(568,364));
};