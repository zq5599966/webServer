/**
 * Created with AppCode.
 * User: yop
 * Date: 15/10/30
 * Time: 下午7:02
 * To change this template use File | Settings | File Templates.
 */


LevelController.LevelEvent102 = LevelController.extend({
	eventStory1 : function(grid, dir) {
		this.showStory(1, grid, ""+
			"SelectNpc,Flash;"+
			"FaceTo,right;"+
			"MoveCamera,34,32,2;"+
			"FaceTo,left;"+
			"MoveRole,34,33;"+
			"ShowDialog,"+ vee.Utils.getLocalizedStringForKey("Just in time, buddy!", "来的正好，伙计。") +";"+
			"ShowDialog,"+ vee.Utils.getLocalizedStringForKey("A branch of complex data has leaked out !", "有一组复杂的数据泄漏出来了。") +";"+
			"ShowDialog,"+ vee.Utils.getLocalizedStringForKey("Do you mind doing me a favor?", "如果你有时间的话，帮个忙呗？") +";"+
			"HideDialog;"+
			"SelectNpc;"+
			"MoveRole,35,33;"+
			"ShowDialog,"+ vee.Utils.getLocalizedStringForKey("That's my data -- mine! Okay, I admit that I might not be able to handle it...", "那是我的数据，我的！好吧我承认没法自己解决这事儿……") +";"+
			"ShowDialog,"+ vee.Utils.getLocalizedStringForKey("All I ask is for a copy of the data -- after you finish your work!", "你收集到之后只需要给我份拷贝就行！") +";"+
			"HideDialog;"+
			"UnlockRole;"+
			"TimeLine,huxi_2;"+
			"Delay,1;"+
			"Trigger,38,34;"+
			"MoveCamera,23,31,2;"+
			"MoveCamera,18,26,2;"+
			"MoveCamera,34,25,2;"+
			"MoveCamera,34,32,2;"+
			"ShowDialog,"+ vee.Utils.getLocalizedStringForKey("Fresh data! Come on!", "新鲜的数据！快！") +";"+
			"HideDialog"+
		"");
	}
});