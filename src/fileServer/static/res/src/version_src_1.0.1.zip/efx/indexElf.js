/**
 * Created with AppCode.
 * User: WanThirty
 * Date: 15/9/18
 * Time: 下午4:14
 * To change this template use File | Settings | File Templates.
 */

var IndexElf = vee.Class.extend({
	onCreate : function () {
		this.playAnimate("loop");
	}
});