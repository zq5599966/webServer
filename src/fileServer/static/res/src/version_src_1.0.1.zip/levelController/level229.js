/**
 * Created with AppCode.
 * User: yop
 * Date: 15/10/27
 * Time: 下午3:33
 * To change this template use File | Settings | File Templates.
 */

LevelController.Level229 = LevelController.extend({
	eventStory1 : function(grid, dir) {
		this.showStory(1, grid, ""+
		"SelectNpc,Flash;"+
		"FaceTo,left;"+
		"MoveCamera,20,10,2;"+
		"ShowDialog,"+ vee.Utils.getLocalizedStringForKey("Welcome to the Phantom World!", "欢迎来到幻影世界！") +";"+
		"ShowDialog,"+ vee.Utils.getLocalizedStringForKey("Let me show you some interesting things.", "我带你去看看有哪些好玩的东西吧~") +";"+
		"ShowDialog,"+ vee.Utils.getLocalizedStringForKey("Follow me!", "走，跟我来。") +";"+
		"HideDialog;"+
		"MoveCamera,25,10,1.5;"+
		"FaceTo,right;"+
		"MoveRole,25,10;"+
		"Jump,29,11;"+
		"MoveRole,30,11;"+
		"Jump,33,9;"+
		"MoveRole,34,9;"+
		"ResetRole,105,18"+
		"");
	},

	skip1 : function() {
		cc.log("skip 1 called!");
		this.skipStory(2);
	},

	eventStory2 : function(grid, dir) {
		this.showStory(2, grid, ""+
		"SelectNpc,Flash;"+
		"ResetRole,105,18;"+
		"FaceTo,left;"+
		"MoveCamera,102,18,1.5;"+
		"ShowDialog,"+ vee.Utils.getLocalizedStringForKey("Not bad!", "不赖嘛！") +";"+
		"ShowDialog,"+ vee.Utils.getLocalizedStringForKey("Come here!", "往这儿走。") +";"+
		"HideDialog;"+
		"FaceTo,right;"+
		"MoveRole,107,18;"+
		"Jump,110,19;"+
		"MoveRole,113,19;"+
		"RemoveRole"+
		"");
	},

	skip2 : function() {
		cc.log("skip 2 called!");
	}
});
