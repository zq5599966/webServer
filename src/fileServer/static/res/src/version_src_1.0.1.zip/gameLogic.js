/**
 * Created with AppCode.
 * User: WanThirty
 * Date: 4/16/15
 * Time: 6:29 PM
 * To change this template use File | Settings | File Templates.
 */

var game = game = game || {};

game.Logic = {
	_tmxMap : null,
	_tmxLayer : null,
	_tmxLayerEx : null,
	_tmxLayerHide : null,
	_tmxLayerExtra : null,
	_tmxLayerGrass : null,
	_tmxLayerTips : null,
	_tmxTileSize : null,
	_mapTips : [],
	/** @type {vee.Map} */
	objMap : null,      // to mark created item
	/** @type {vee.Map} */
	triggerMap : null,  // to mark trigger
	/** @type {vee.Map} */
	dynamicObjMap : null,// to mark dynamic object like enemy and dynamic item
	/** @type {vee.Map} */
	configMap : null,   // to mark configs
	/** @type {vee.Map} */
	map : null,         // to mark block tile info
	/** @type {vee.Map} */
	mapex : null,       // to mark enemy and item tile info

	_bgmName : null,

	_isParkour : null,

	_deadZoneRevivalCount : 1,

	init : function () {

	},

	// For init
	createTMXMap : function(tmxFileName) {
		var ret = cc.TMXTiledMap.create(tmxFileName);
		this.setPerformingTMX(ret, tmxFileName);
		return ret;
	},

	// temp
	savePointGrid : null,
	playerGrid : null,
	setPerformingTMX : function(tmx, tmxFileName) {
		this.funcPool = [];

		// set data...
		tmx.tmxFileName = tmxFileName;
		this._tmxMap = tmx;
		this._tmxMapSize = tmx.getMapSize();
		this._tmxTileSize = tmx.getTileSize();

		game.Data.mapRightEdge = this._tmxMapSize.width * TILE_WIDTH - TILE_WIDTH_HALF;
		game.Data.oLyGame.setCameraXRightEdge(game.Data.mapRightEdge);

		this._tmxLayer = this._tmxMap.getLayer("main");
		this.map = vee.Map.create(this._tmxMapSize, this._tmxTileSize);
		var zo = this._tmxLayer.getLocalZOrder();
		game.Data.oLyGame.lyMapBack.setLocalZOrder(zo-1);

		this._tmxLayerEx = this._tmxMap.getLayer("mainEx");
		if (this._tmxLayerEx) this._tmxLayerEx.setVisible(false);
		this.mapex = vee.Map.create(this._tmxMapSize, this._tmxTileSize);

		this._tmxLayerHide = this._tmxMap.getLayer("mask");
		if (this._tmxLayerHide) this._tmxLayerHide.setLocalZOrder(101);
		else this._tmxLayerHide = null;
		this._tmxLayerGrass = this._tmxMap.getLayer("grass");
		if (this._tmxLayerGrass) this._tmxLayerGrass = null;

		this._tmxLayerTips = this._tmxMap.getLayer("tips");
		if (this._tmxLayerTips) {
			this._tmxLayerTips.setVisible(false);
			var mapProperties = this._tmxMap.getProperties();
			this._mapTips = [];
			this._mapTips.push(mapProperties.tip1);
			this._mapTips.push(mapProperties.tip2);
			this._mapTips.push(mapProperties.tip3);
		} else {
			this._tmxLayerTips = null;
			this._mapTips = [];
		}

		this.configMap = vee.Map.create(this._tmxMapSize, this._tmxTileSize);

		// function in sequence...
		var func2 = function () {
			cc.log("func 1");
			// Preload enemy
			var mapProperties = this._tmxMap.getProperties();
			for (var name in mapProperties) {
				var count = parseInt(mapProperties[name]);
				var type = game.enemyStringMap[name];
				if (type) {
					for (var i = 0; i < count; ++i) {
						var node = Enemy.createWithInfo({type : type, dir : vee.Direction.Left}, true);
						if (node) {
							game.Data.enemyPool.push(node.controller);
						}
					}
				}
			}
			// Add bg
			var bgName = mapProperties["bg"];
			if (bgName) {
				game.Data.bgName = bgName;
				game.Data.oLyGame.lyBG.removeAllChildren();
				if (game.Data.isStaticBG()) {
					var bg = new cc.Sprite("res/"+bgName+".png");
					bg.setAnchorPoint(cc.p(0,0));
					game.Data.oLyGame.lyBG.addChild(bg, 1);
				} else {
					var bg = LyDynamicBG.create(bgName);
					game.Data.oLyGame.lyBG.addChild(bg, 1);
					game.Data.oLyGame.bgCtl = bg.controller;
				}
			} else {
				game.Data.bgName = null;
			}

			//parkour flag
			this._isParkour = mapProperties["isParkour"];
			if(this._isParkour){
				this.setForParkour(true);
			}
			else{
				this._isParkour = null;
			}

			// bgm
			this._bgmName = mapProperties["bgm"];
			if (this._bgmName) {
				this._bgmName = "res/"+this._bgmName+".mp3";
				vee.Audio.preload(this._bgmName);
			} else {
				this._bgmName = null;
			}

			//revival count
			var deadZoneRevivalCount = mapProperties["deadZoneRevivalCount"];
			if(deadZoneRevivalCount){
				this._deadZoneRevivalCount = parseInt(deadZoneRevivalCount);
			}
			else{
				this._deadZoneRevivalCount = 1;
			}


		}.bind(this);
		this.funcPool.push(func2);

		// Create map element by objMap...
		var func5 = function () {
			cc.log("func 2");
			this.playerGrid = this.deployConfig();
		}.bind(this);
		this.funcPool.push(func5);

		// deploy player...
		var func6 = function () {
			cc.log("func 3");
			// Check is create at save point...
			if (game.Data.getSavePointIdx() == game.Data.performingTMXIdx && this.savePointGrid) {
				this.playerGrid = this.savePointGrid;
				game.Data.savePointSaved = true;
			} else {
				game.Data.savePointSaved = false;
			}
			// deploy player...
			var tmxInfo = game.Data.getTMXInfoByName(tmxFileName);
			if (tmxInfo) {
				this.objMap = tmxInfo.info.objMap;
				if (game.Data.isDoorIn) {
					this.deployPlayer(this.playerGrid);
				} else {
					this.playerGrid = vee.Utils.pAdd(tmxInfo.info.playerGrid, game.Data.doorOutOffset);
					var pos = this.getTilePosByGrid(this.playerGrid);
					game.Data.oPlayerCtl.setElePosition(cc.p(pos.x + TILE_WIDTH_HALF, pos.y + TILE_WIDTH_HALF));
					game.Data.oPlayerCtl.resetPlayerState();
					game.Data.oLyGame.setCameraFollow(pos);
				}
			} else {
				this.objMap = vee.Map.create(this._tmxMapSize, this._tmxTileSize);
				this.triggerMap = vee.Map.create(this._tmxMapSize, this._tmxTileSize);
				this.dynamicObjMap = vee.Map.create(this._tmxMapSize, this._tmxTileSize);
				this.deployPlayer(this.playerGrid);
			}

			if(game.Data.isInParkour() && game.Data.oPlayerCtl){
				game.Data.oPlayerCtl.parkourMove();
			}


			// Reset camera position
			if (game.Data.oPlayerCtl) {
				game.Data.oLyGame.initCamera(game.Data.oPlayerCtl.getElePosition());
			}
		}.bind(this);
		this.funcPool.push(func6);

		// create elf...
		var func7 = function () {
			cc.log("func 4");
			if (game.Data.oPlayerCtl) {
				var elf = ElePowerSymbol.create(game.Data.oPlayerCtl);
				game.Data.oLyGame.lyMap.addChild(elf.nodeBox);
				game.Data.oPlayerCtl.elf = elf;
				game.Data.setPlayerType(game.PlayerType.Normal);
			}
		}.bind(this);
		this.funcPool.push(func7);

		// create tile data, its needs time!
		var func3 = function () {
			cc.log("func 5");
			cc.log(new Date());
			this.savePointGrid = null;
			for (var x = 0; x < this._tmxMapSize.width; ++x) {
				for (var y = 0; y < this._tmxMapSize.height; ++y) {
					var grid = cc.p(x, y);
					var tiledata = this.getTileData(grid, this._tmxLayer);
					if (tiledata) {
						if (tiledata.tileInfo.type == game.ObjectType.NPC) {
							this.createNPC(grid, tiledata);
						}
						if (tiledata && this.isExObjType(tiledata.tileInfo.type)) {
							this.mapex.setObject(tiledata, grid);
						} else {
							this.map.setObject(tiledata, grid);
						}
						if (tiledata.tileInfo.type == game.ObjectType.SavePoint) this.savePointGrid = cc.p(grid.x, grid.y);
						if (tiledata.gid == game.BlockType.Coin) {
							++game.Data.stageMaxCoin;
						}
					}
					if (this._tmxLayerEx) {
						var exTd = this.getTileData(grid, this._tmxLayerEx);
						if (exTd) {
							this.mapex.setObject(exTd, grid);
							if (exTd.gid == game.BlockType.Coin) {
								++game.Data.stageMaxCoin;
							}
						}
					}
					game.Data.addPerformingSkillBoxes(grid, this._tmxLayer);
				}
			}
			cc.log("coin in main : "+game.Data.stageMaxCoin);
			cc.log(new Date());
		}.bind(this);
		this.funcPool.push(func3);

		// preset extra layers...
		var func4 = function () {
			cc.log("func 6");
			var layers = this._tmxMap.allLayers();
			for (var i in layers) {
				var layer = layers[i];
				if (layer.getLayerName().substring(0, 5) == "extra") {
					var properties = layer.getProperties();
					layer.originX = parseInt(properties.x);
					layer.originY = parseInt(properties.y);
					layer.maxX = parseInt(properties.maxX);
					layer.maxY = parseInt(properties.maxY);
					layer.isExtra = true;
					if (properties.isShow) {
						cc.log("is show....");
						this.addExtraTileToMap(layer);
					} else {
						layer.runAction(cc.fadeTo(0, 0));
						layer.setVisible(false);
						var extraBgLayer = this._tmxMap.getLayer("bg_" + layer.getLayerName());
						if (extraBgLayer) {
							extraBgLayer.setVisible(false);
							extraBgLayer.runAction(cc.fadeTo(0, 0));
						}
					}
					var coin = parseInt(properties.coin);
					if (coin) game.Data.stageMaxCoin += coin;
				} else if (layer.getLayerName().substring(0,4) == "mask") {
					layer.setLocalZOrder(101);
				}
			}
			cc.log("coin in extra : "+game.Data.stageMaxCoin);

			var objGroups = this._tmxMap.getObjectGroups();
			for (var i in objGroups) {
				var objGroup = objGroups[i];
				if (objGroup.getGroupName().substring(0, 8) == "coinList") {
					game.Data.stageMaxCoin += objGroup.getObjects().length;
				}
			}
			cc.log("coin in object group : "+game.Data.stageMaxCoin);
		}.bind(this);
		this.funcPool.push(func4);

		// create triggers...
		var func9 = function () {
			cc.log("func 7");
			this.deployTriggerConfig();
		}.bind(this);
		this.funcPool.push(func9);

		// create map elements around player...
		var func8 = function () {
			cc.log("func 8");
			this.deployTileConfig(this.playerGrid);
		}.bind(this);
		this.funcPool.push(func8);

		// start...
		var func10 = function () {
			cc.log("func 9");
			if (game.Data.stageType != game.StageType.Event && vee.data["stad"]) {

			}
			game.Data.oLvCtl.prepare();
		}.bind(this);
		this.funcPool.push(func10);

		// preload efx...
		var func11 = function () {
			cc.log("func 10");
			EfxEnemyDie.show(cc.p(-5000,-5000));
			EfxBlockBreak.show(cc.p(-5000,-5000));
			EfxGetCoin.show(cc.p(-5000,-5000));

			if (game.Logic._bgmName) {
				vee.Audio.playMusic(game.Logic._bgmName);
			} else {
				vee.Audio.stopMusic();
			}

			if (!game.Data.isCinema && (game.Data.stageType == game.StageType.Normal || game.Data.stageType == game.StageType.Parkour) && game.LevelData.selectedCategory && game.LevelData.selectedLevel) {
				var category = game.LevelData.selectedCategory.idx + 1;
				var level = game.LevelData.selectedLevel.idx + 1;
				if (game.Data.performingTMXIdx != "Tutorial" && game.Data.performingTMXIdx != "Story1") {
					//if (game.Data.is61 && category == 7) {
					if (category == 7) {
						category = 0;
					}
					cc.log("ef level level=========%d", level);
					EfxLevel.show(category, level);
				}
			}

			game.Data.oLyGame.refreshCoin();

		}.bind(this);
		this.funcPool.push(func11);

		this.funcStepCallback = function (percent) {
			game.Data.oLvLoadingCtl.setPercent(percent);
		}.bind(this);
		this.funcSeqFinishCallback = function () {
			game.Data.oLvLoadingCtl.loaded();
			game.Data.oLyGame.startUpdate();
			game.Data.oLyGame.loadingFinish();

			if (game.Data.isFreeGame) {
				if (game.Data.retryCount > 1) {
					vee.Utils.scheduleOnce(function () {
						LyGetBlackCat.show();
					}, 1.5);
				}
			} else {
				if (game.Data.retryCount > 2 && vee.Utils.isLucky(0.3 + game.Data.retryCount/5)) {
					vee.Utils.scheduleOnce(function () {
						LyGetBlackCat.show();
					}, 1.5);
				}
			}
			cc.log("stage max coin count = "+game.Data.stageMaxCoin);

			if (Cinema.isCinema) {
				Cinema.init();
				if (game.Data.oLyGame.isFirstPlay()) {
					Cinema.setAnalyse(true);
				}
			}
		}.bind(this);
//		this.flushFunctionPool();
	},

	funcPool : null,
	funcPoolLen : null,
	flushFunctionPool : function () {
		this.funcPoolLen = this.funcPool.length;
		if (this.funcPoolLen > 0) {
			vee.Utils.scheduleOnce(this.funcInSeq.bind(this));
		}
	},

	funcStepCallback : null,
	funcSeqFinishCallback : null,
	funcInSeq : function () {
		var func = this.funcPool.shift();
		if (_.isFunction(func)) func();

		var len = this.funcPool.length;
		if (this.funcPool.length > 0) {
			if (this.funcStepCallback) this.funcStepCallback(parseInt((this.funcPoolLen-len)/this.funcPoolLen * 100));
			if (parseInt((this.funcPoolLen-len)/this.funcPoolLen * 100) == 70) cc.log("check point!");
			vee.Utils.scheduleOnce(this.funcInSeq.bind(this));
		} else {
			if (this.funcSeqFinishCallback) this.funcSeqFinishCallback();
		}
	},

	deployConfig : function() {
		var objConfig = this._tmxMap.getObjectGroup("objConfig").getObjects();
		var playerGrid = null;
		var arrLen = objConfig.length;
		var obj = null;
		var arrArg = null;
		for (var i = 0; i < arrLen; ++i) {
			obj = objConfig[i];
			var objGrid = this.getTileGridByPos(cc.p(obj.x + TILE_WIDTH_HALF, obj.y + TILE_WIDTH_HALF));
			if (obj.type == "player") {
				playerGrid = objGrid;
			} else if (obj.type == "enemy") {
				arrArg = obj.name.split(",");
				var len = arrArg.length;
				if (len >= 4) {
					var dir = len == 5 ? arrArg[4] : null;
					this.configMap.setObject({
						first : cc.p(parseInt(arrArg[0]), parseInt(arrArg[1])),
						last : cc.p(parseInt(arrArg[2]), parseInt(arrArg[3])),
						dir : dir,
						name : obj.name
					}, objGrid);
				} else if (len == 1) {
					this.configMap.setObject({
						dir : arrArg[0],
						name : obj.name
					}, objGrid);
				} else {
					this.configMap.setObject(obj, objGrid);
				}
			} else if (obj.type == "egg" ||
				obj.type == "transform" ||
				obj.type == "platform" ||
				obj.type == "trapStone" ||
				obj.type == "fire" ||
				obj.type == "npc") {
				this.configMap.setObject(obj, objGrid);
			}
			//add by zq for scaleBlock init 20160823
			else if(obj.type == "scaleBlock"){
				this.configMap.setObject(obj, objGrid);
			}
		}
		return playerGrid;
	},

	deployPlayer : function (playerGrid) {
		if (playerGrid) {
			var obj = this.getTilePosByGrid(playerGrid);
			if (game.Data.oPlayerCtl) {
				game.Data.oPlayerCtl.setElePosition(cc.p(obj.x + TILE_WIDTH_HALF, obj.y + TILE_WIDTH_HALF));
				game.Data.oPlayerCtl.resetPlayerState();
				game.Data.oLyGame.setCameraFollow(cc.p(obj.x, obj.y));
				game.Data.oPlayerCtl.startUpdate();
			} else {
				var avatarData = game.AvatarData.getCurrentAvatar();
				var ccbName = avatarData.role;
				if (avatarData.type == game.Roles.Vampire) {
					var spVmp = new cc.Sprite(res.bg_power_bat_png);
					spVmp.setScale(2);
					spVmp.setAnchorPoint(cc.p(0,0));
					game.Data.oLyGame.lyTouch.addChild(spVmp);
				}

				if (game.Data.checkIs61()) {
					ccbName = res.hero_smallfox_ccbi;
					game.Data.playerLife = 1;
					game.Data.oLyGame.refreshHeart();
				}
				else if(game.Data.checkIsMidAutumn()){
					ccbName = game.AvatarData.getAvatarData(12).role;
				}
				else if(game.Data.checkIsHolloween()){
					ccbName = game.AvatarData.getAvatarData(13).role;
				}
				else if(game.Data.checkIsThanksgiving()){
					ccbName = game.AvatarData.getAvatarData(14).role;
				}

				if ("Tutorial" == game.Data.performingTMXIdx) {
					ccbName = res.elePlayer_Zhai_ccbi;
				}
				var playerContent = ElePlayer.create(ccbName);
				playerContent.controller.stopUpdate();
				playerContent.controller.isCanOperatByParkour = false;
				playerContent.controller.playerInAninate();
				game.Data.oPlayerCtl = playerContent.controller;
				game.Data.oLyGame.lyMap.addChild(playerContent.container, 2);
				game.Data.oLyGame.lyContainer.setScale(game.Data.cameraScaleLimitMIN);
				var playerPos = cc.p(obj.x + TILE_WIDTH_HALF, obj.y + TILE_WIDTH_HALF);
				playerContent.controller.setElePosition(playerPos);
				playerContent.controller._offsetX = 0;
				playerContent.controller._offsetY = 0;

				if(this._isParkour){
					playerContent.controller.addMotionStreak();
				}
			}
			return this.getTileGridByPos(cc.p(obj.x + TILE_WIDTH_HALF, obj.y + TILE_WIDTH_HALF));
		}
	},

	deployTileConfig : function (playerGrid, clear, layer) {
		if (playerGrid) {
			var initX = playerGrid.x - this._checkDistanceHor;
			var initY = playerGrid.y - this._checkDistanceVer;
			var maxX = playerGrid.x + this._checkDistanceHor;
			var maxY = playerGrid.y + this._checkDistanceVer;
			if (initX < 0) initX = 0;
			if (initY >= this._tmxMapSize.height) initY = this._tmxMapSize.height - 1;
			if (maxX >= this._tmxMapSize.width) maxX = this._tmxMapSize.width - 1;
			if (maxY < 0) maxY = 0;

			if (clear) {
				for (var i = initX; i < maxX; ++i) {
					for (var j = initY; j < maxY; ++j) {
						var obj = this.objMap.getObject(cc.p(i,j));
						if (obj && obj._eleType != game.EleType.Trigger) {
							obj._container.removeFromParent();
							this.objMap.removeObject(cc.p(i,j));
						}
					}
				}
			} else {
				var grid = null;
				for (var i = initX; i <= maxX; ++i) {
					for (var j = initY; j <= maxY; ++j) {
						grid = cc.p(i,j);
						this.createItemByGrid(grid, false, layer);
						this.createEnemyByGrid(grid, layer);
						this._checkTd = game.Logic.map.getObject(grid);
						if (this._checkTd) {
							this._checkTd.viewIn();
						}
					}
				}
			}
		}
	},

	deployTriggerConfig : function() {


		Trigger.resetTriggerSign();
		var triggerGrop = this._tmxMap.getObjectGroup("triggerConfig");
		if (!triggerGrop) return;
		var triggerConfigs = triggerGrop.getObjects();
		var len = triggerConfigs.length;


		var category = game.LevelData.selectedCategory;

//		cc.log("zq debug select level index 111===%d", game.LevelData.selectedLevel.idx);
		/*
		var isCategoryAllUnlock = category && category.isAllLevelUnlock();//category.isAllStarArchive();
		*/
		var isMoonUnlock = false;
//		var firstCategoryPass = game.LevelData.getCategory(0).isAllLevelPass();
//		cc.log("zq debug select level index 222===%d", game.LevelData.selectedLevel.idx);

		if(category && category.checkHasUnlockMoon()){
//			cc.log("zq debug select level index 333===%d", game.LevelData.selectedLevel.idx);
			isMoonUnlock = true;
		}
		//end
//		cc.log("zq debug select level index 444===%d", game.LevelData.selectedLevel.idx);

		var level = game.LevelData.selectedLevel;
		var isKeyCollected = level && level.isLevelReverseKeyCollected();

		for (var i = 0; i < len; ++i) {
			var trigger = triggerConfigs[i];
			var grid = this.getTileGridByPos(cc.p(trigger.x + TILE_WIDTH_HALF, trigger.y + TILE_WIDTH_HALF));
			var isAdd = true;
			if (trigger.type == "ShowExtra") {
				var layer = this._tmxMap.getLayer(trigger.name);
				if (layer) {
					if (!layer.showTileGrid) {
						layer.showTileGrid = [];
					}
					layer.showTileGrid.push(grid);
				}
			} else if (trigger.type == "HideExtra") {
				var layer = this._tmxMap.getLayer(trigger.name);
				if (layer) {
					if (!layer.hideTileGrid) {
						layer.hideTileGrid = [];
					}
					layer.hideTileGrid.push(grid);
				}
			} else if (trigger.type == "ToggleExtra") {
				var layer = this._tmxMap.getLayer(trigger.name);
				if (layer) {
					if (!layer.toggleTileGrid) {
						layer.toggleTileGrid = [];
					}
					layer.toggleTileGrid.push(grid);
				}
			} else if (trigger.type == "AddItem") {
				if (trigger.name == "coin") {
					++game.Data.stageMaxCoin;
				}
			} else if (trigger.type == "ShowText" || trigger.type == "ShowTextOnce") {
				if (vee.data["moon"] && isMoonUnlock && !isKeyCollected) {
					var obj = this.triggerMap.getObject(grid);
					if (obj && !trigger.moon) {
						isAdd = false;
					}
				} else if (trigger.moon) {
					isAdd = false;
				}
			}
			if (isAdd) this.triggerMap.setObject(Trigger.create(trigger), grid);
		}


	},

	showSequenceCoin : function(coinLayerName) {
		var seqCoinLayer = this._tmxMap.getObjectGroup(coinLayerName);
		if (seqCoinLayer.hasShown) return;
		seqCoinLayer.hasShown = true;
		if (seqCoinLayer) {
			var objs = seqCoinLayer.getObjects();
			vee.Audio.playEffect(res.inGame_efx_coinGenerate_mp3);
			var schObj = {};
			schObj.objs = objs;
			schObj.coinIdx = 0;
			vee.Utils.scheduleCallbackForTarget(schObj, function(){
				var obj = this.objs.shift();
				if (!obj) {
					vee.Utils.unscheduleAllCallbacksForTarget(this);
					return;
				}
				var oLogic = game.Logic;
				var grid = oLogic.getTileGridByPos( cc.p(obj.x + TILE_WIDTH_HALF, obj.y + TILE_WIDTH_HALF) );
				var cointd = oLogic.getTileDataByGid(game.BlockType.Coin, grid);
				oLogic.mapex.setObject(cointd, grid);
				var item = oLogic.createItemByGrid(grid);
				item.controller.playAnimate("Create");
				item.controller.setGridInMap(grid);
				item.container.coinIdx = this.coinIdx;
				item.container.runAction(cc.sequence(
					cc.delayTime(0.25),
					cc.callFunc(function () {
						if (this.coinIdx < 10) {
							vee.Audio.playEffect(res.inGame_efx_coinListGenerate_mp3);
						}
					}.bind(item.container))
				));
				++this.coinIdx;
			}.bind(schObj), 0.1);
		} else {
			cc.log("Error: Load sequence coin layer failed. coinLayerName = "+coinLayerName);
		}
	},

	showSequenceSusliks : function (susliksLayerName) {
		var susliksLayer = this._tmxMap.getObjectGroup(susliksLayerName);
		if (susliksLayer) {
			var objs = susliksLayer.getObjects();
			var len = objs.length;
			var properties = susliksLayer.getProperties();
			var duration = parseFloat(properties.duration) || 3;
			var interval = parseFloat(properties.interval) || 1;
			EnemySusliks.arrSusliks = [];
			EnemySusliks.killCount = 0;
			EnemySusliks.disappearCount = 0;
			for (var i = 0; i < len; ++i) {
				var obj = objs[i];
				var dir = vee.Direction.string2Direction(obj.dir);
				if (!dir) dir = vee.Direction.Top;
				var susliks = EnemySusliks.create(this.getTilePosCenterByGrid(this.getTileGridByPos(cc.p(obj.x + TILE_WIDTH_HALF, obj.y + TILE_WIDTH_HALF))), dir);
				EnemySusliks.arrSusliks.push(susliks);
				susliks.susIdx = i;
				susliks._container.setVisible(false);
				susliks._container.runAction(cc.sequence(
					cc.delayTime((i+1) * interval),
					cc.callFunc(function() {
						// show susliks
						this.show();
						this._container.setVisible(true);
					}.bind(susliks)),
					cc.delayTime(duration),
					cc.callFunc(function() {
						// hide susliks
						this.disappear();
					}.bind(susliks))
				));
				game.Data.oLyGame.lyMapBack.addChild(susliks._container);
			}
		}
	},

	_checkW : 28,
	_checkH : 24,
	_checkWHalf : 14,
	_checkHHalf : 12,
	_checkDistanceHor : 12,
	_checkDistanceVer : 10,
	_checkGrid : null,
	_gridNext : null,
	_checkTd : null,
	checkNewGrids : function (pGridPrev, offset) {
		var gridPrev = cc.p(pGridPrev.x,pGridPrev.y);
		this._gridNext = vee.Utils.pAdd(gridPrev, offset);
		// 1. Remove enemies...
		// 2. Create enemy and items...
		if (Math.abs(offset.x) > 1) {
			cc.log("wtf 01!?!?");
		}
		if (Math.abs(offset.y) > 1) {
			cc.log("wtf 02!?!?");
		}
		if (offset.x != 0) {
			var increment;
			var nextX;
			if (offset.x > 0) {
				increment = 1;
				nextX = gridPrev.x + this._checkDistanceHor;
				gridPrev.x -= this._checkDistanceHor + 3;
			} else {
				increment = -1;
				nextX = gridPrev.x - this._checkDistanceHor;
				gridPrev.x += this._checkDistanceHor + 3;
			}
			for (var xoff = increment; Math.abs(xoff) <= Math.abs(offset.x); xoff = xoff + increment) {
				for (var i = -6; i < this._checkH + 6; ++i) {
					this._checkGrid = cc.p(gridPrev.x + (xoff - increment), this._gridNext.y-i+this._checkHHalf);
					this.removeItemByGrid(this._checkGrid);
					this._checkTd = game.Logic.map.getObject(this._checkGrid);
					if (this._checkTd) {
						this._checkTd.viewOut();
					}
					if (i >= 0 && i < this._checkH) {
						this._checkGrid = cc.p(nextX + xoff, this._gridNext.y-i+this._checkHHalf);
						this.createEnemyByGrid(this._checkGrid);
						this.createItemByGrid(this._checkGrid);
						this._checkTd = game.Logic.map.getObject(this._checkGrid);
						if (this._checkTd) {
							this._checkTd.viewIn();
						}
					}
				}
			}
		}
		if (offset.y != 0) {
			if (offset.y < 0) {
				this._gridNext.y -= this._checkDistanceVer;
				gridPrev.y += this._checkDistanceVer + 3;
			} else {
				this._gridNext.y += this._checkDistanceVer;
				gridPrev.y -= this._checkDistanceVer + 3;
			}
			for (var i = -6; i < this._checkW + 6; ++i) {
				this._checkGrid = cc.p(this._gridNext.x+i-this._checkWHalf, gridPrev.y);
				this.removeItemByGrid(this._checkGrid);
				this._checkTd = game.Logic.map.getObject(this._checkGrid);
				if (this._checkTd) {
					this._checkTd.viewOut();
				}
				if (i >=0 && i < this._checkW) {
					this._checkGrid = cc.p(this._gridNext.x+i-this._checkWHalf, this._gridNext.y);
					this.createEnemyByGrid(this._checkGrid);
					this.createItemByGrid(this._checkGrid);
					this._checkTd = game.Logic.map.getObject(this._checkGrid);
					if (this._checkTd) {
						this._checkTd.viewIn();
					}
				}
			}
		}
	},
	createEnemyByGrid : function(grid, layer) {
		if (this.checkTileGridValid(grid)) {
			if (this.dynamicObjMap.getObject(grid)) {
				return;
			}
			var tiledata = this.mapex.getObject(grid);
			if (tiledata) {
				if (layer && tiledata.layer != layer) return;
				if (!tiledata.refreshSign) tiledata.refreshSign = 0;
				switch (tiledata.tileInfo.type) {
					case game.ObjectType.Slime:{
						if (tiledata.refreshSign > 0) {
							tiledata.refreshSign = 0;
							return;
						}
					}
						break;
					default :
						break;
				}
				++tiledata.refreshSign;
				var enemy = Enemy.createWithInfo(tiledata.tileInfo);
				if (enemy) {
					if (Cinema.isCinema) {
						enemy.controller.AILogic = function () {};
						enemy.controller.AILogicPerFrame = function () {};
					}
					// Hide tile
					var tile = tiledata.layer.getTileAt(grid);
					if (tile) {
						tile.setVisible(false);
					}
					// show enemy
					var pos = this.getTilePosByGrid(grid);
					enemy.controller._grid = grid;
					enemy.controller.setGridInMap(grid);
					if (enemy.controller.objType == game.ObjectType.SusliksHawk) {
						enemy.controller.initPosition(cc.p(pos.x + TILE_WIDTH_HALF, pos.y + TILE_WIDTH_HALF));
					} else {
						enemy.controller.initPosition(cc.p(pos.x + TILE_WIDTH_HALF, pos.y + TILE_WIDTH_HALF+5));
					}
					enemy.controller.cutInAnimate();
					this.dynamicObjMap.setObject(enemy.controller, grid);
					game.Data.usingEnemyPool.push(enemy.controller);
					enemy.controller.afterCreate();
					if (Cinema.isCinema) {
						enemy.controller._hasCollide = false;
					}
				}
			}
		}
	},

	_layerType : game.LayerType.Main,
	createItemByGrid : function (grid, isCreateOther, layer) {
		if (this.checkTileGridValid(grid)) {
			if (this.objMap.getObject(grid)) {
				return;
			}
			var tiledata = this.mapex.getObject(grid);
			if (!tiledata) return;
			if (layer && tiledata.layer != layer) return;
			if (tiledata.tileInfo) {
				var item = Item.createWithInfo(tiledata.tileInfo, grid, layer);
				if (item == false) {
					// Hide tile
					var tile = tiledata.layer.getTileAt(grid);
					if (tile) {
						tile.setVisible(false);
					}
				} else if (item) {
					// Hide tile
					if (tiledata.layer) {
						var tile = tiledata.layer.getTileAt(grid);
						if (tile) {
							tile.setVisible(false);
						}
					}
					// show item
					var pos = this.getTilePosByGrid(grid);
					this.objMap.setObject(item.controller, grid);
					item.controller.setGridInMap(grid);
					item.controller._createByPlatform = isCreateOther;
					item.controller.initPosition(cc.p(pos.x + TILE_WIDTH_HALF, pos.y + TILE_WIDTH_HALF));
					item.controller._layerBelong = tiledata.layer;
					return item;
				}
			}
		}
	},

	createNPC : function (grid, td) {
		if (this.objMap.getObject(grid)) {
			return;
		}
		var config = this.configMap.getObject(grid);
		if (config) {
			var ccbName = game.RoleNameStrData[config.name];
			if (!ccbName) {
				var adata = game.AvatarData.getNextAvatar(0, true);
				if (adata) {
					ccbName = adata.role;
				} else {
					var arr = [0,1,2,3,4,5,6,7,8,9];
					var curIdx = game.AvatarData.getCurrentAvatar().idx;
					arr.splice(curIdx, 1);
					adata = game.AvatarData.getAvatarData(vee.Utils.randomChoice(arr));
					ccbName = adata.role;
				}
			}
			if (ccbName) {
				td.layer.removeTileAt(grid);
				var roleContent = ElePlayer.create(ccbName);
				game.Data.oLyGame.lyMap.addChild(roleContent.container, 2);
				var npcName = config.name;
				if (!npcName) npcName = "defaultNpc";
				game.Data.npcmap[npcName] = roleContent.controller;
				roleContent.controller.playAnimate("huxi_1");
				roleContent.controller.ccbName = ccbName;
				roleContent.controller.npcname = game.RoleNameStrDataRevert[ccbName];
				roleContent.container.setPosition(this.getTilePosCenterByGrid(grid));
				this.objMap.setObject(roleContent.controller, grid);
			}
		}
	},
	removeItemByGrid : function (grid) {
		var ctl = this.objMap.getObject(grid);
		if (ctl) {
			if (ctl._eleType != game.EleType.Item) return;
			if (ctl._type == game.ObjectType.Coin) {
				ctl._container.setVisible(false);
				this.objMap.setObject(null, grid);
				game.Data.itemCoinPool.push(ctl);
			} else if (ctl._type != game.ObjectType.MovingPlatform
				&& ctl._type != game.ObjectType.FallingBlock
				&& ctl._type != game.ObjectType.Egg
				&& ctl._type != game.ObjectType.Bullet) {
				this.objMap.setObject(null, grid);
				ctl.removeOnGridChange();
				ctl._container.removeFromParent();
			}
		}
	},

	checkItemCollide : function (grid) {
		var item = this.objMap.getObject(grid);
		if (item && item._eleType == game.EleType.Item) {
			item.collide();
		}
	},

	_checkBottom : false,
	_checkTop : false,
	_checkLeft : false,
	_checkRight : false,
	safePos : function (pos, nodeCtl) {
		nodeCtl._speedScaleRate = 1;
		var tGrid = this.getTileGridByPos(pos);
		var td = this.map.getObject(tGrid);
		var ret = this.checkTile(td, pos, nodeCtl, vee.Direction.Origin);
        
        if (nodeCtl._eleType == game.EleType.Player) {
            this.checkItemCollide(tGrid);
            var tilePos = this.getTilePosByGrid(tGrid);
            var offset = cc.p(pos.x - tilePos.x, pos.y - tilePos.y);
            if (offset.x < TILE_WIDTH_3_1) {
                this.checkItemCollide(cc.p(tGrid.x - 1, tGrid.y));
            } else if (offset.x > TILE_WIDTH_3_2) {
                this.checkItemCollide(cc.p(tGrid.x + 1, tGrid.y));
            }
        }

		this._checkBottom = false;
		this._checkTop = false;
		this._checkLeft = false;
		this._checkRight = false;
		var centerPos = this.getTilePosCenterByGrid(tGrid);
		if (!ret || (td && td.tileInfo && (td.tileInfo.type == game.ObjectType.BlockOneWay))) {// || td.tileInfo.type == game.ObjectType.BlockBounce
			if (!ret) ret = pos;
			var arrDir = [];
			if (nodeCtl._speedY > 0) {
				arrDir.push(vee.Direction.Top);
				if (pos.y < centerPos.y) arrDir.push(vee.Direction.Bottom);
			} else {
				arrDir.push(vee.Direction.Bottom);
				if (pos.y > centerPos.y) arrDir.push(vee.Direction.Top);
			}

			if (pos.x < centerPos.x) {
				arrDir.push(vee.Direction.Left);
				this._checkLeft = true;
			}
			if (pos.x > centerPos.x) {
				arrDir.push(vee.Direction.Right);
				this._checkRight = true;
			}
			for (var i = 0; i < arrDir.length; ++i) {
				var dir = arrDir[i];
				var tileData = this.getTileDataByDir(tGrid, dir);
				var safePos = this.checkTile(tileData, ret, nodeCtl, dir);
				if (safePos) {
					ret = safePos;
				} else if (dir == vee.Direction.Bottom) {// &&
					if (tileData && tileData.tileInfo && tileData.tileInfo.slope != 0) {
					} else {
						this._checkBottom = true;
					}
				} else if (dir == vee.Direction.Top) {
					this._checkTop = true;
				}
			}
		} else if (ret && (td && td.tileInfo && (td.tileInfo.slope == 0))) {
			var arrDir = [];

			if (pos.x < centerPos.x) {
				arrDir.push(vee.Direction.Left);
				this._checkLeft = true;
			}
			if (pos.x > centerPos.x) {
				arrDir.push(vee.Direction.Right);
				this._checkRight = true;
			}
			for (var i = 0; i < arrDir.length; ++i) {
				var dir = arrDir[i];
				var tileData = this.getTileDataByDir(tGrid, dir);
				var safePos = this.checkTile(tileData, ret, nodeCtl, dir);
				if (safePos) {
					ret = safePos;
				}
			}
		}

		var arrDirExt = [];
		if (this._checkBottom && nodeCtl._eleType == game.EleType.Player) {
			if (this._checkLeft) arrDirExt.push(vee.Direction.BottomLeft);
			if (this._checkRight) arrDirExt.push(vee.Direction.BottomRight);
		}

		if (this._checkTop && nodeCtl._eleType == game.EleType.Player) {
			if (this._checkLeft) arrDirExt.push(vee.Direction.TopLeft);
			if (this._checkRight) arrDirExt.push(vee.Direction.TopRight);
		}
		for (var i = 0; i < arrDirExt.length; ++i) {
			var dir = arrDirExt[i];
			var tileData = this.getTileDataByDir(tGrid, dir);
			var safePos = this.checkTile(tileData, ret, nodeCtl, dir);
			if (safePos) {
				ret = safePos;
			}
		}

		return ret;
	},

	checkTile : function(tiledata, pos, nodeCtl, dir) {
		var ret = null;
		if (tiledata && tiledata.check && tiledata.tileInfo) {
			switch(dir) {
				case vee.Direction.TopLeft :
					ret = tiledata.checkBottomRight(pos, nodeCtl);
					break;
				case vee.Direction.Top :
					ret = tiledata.checkBottom(pos, nodeCtl);
					break;
				case vee.Direction.TopRight :
					ret = tiledata.checkBottomLeft(pos, nodeCtl);
					break;
				case vee.Direction.Right :
					ret = tiledata.checkLeft(pos, nodeCtl);
					break;
				case vee.Direction.BottomRight :
					ret = tiledata.checkTopLeft(pos, nodeCtl);
					break;
				case vee.Direction.Bottom :
					ret = tiledata.checkTop(pos, nodeCtl);
					break;
				case vee.Direction.BottomLeft :
					ret = tiledata.checkTopRight(pos, nodeCtl);
					break;
				case vee.Direction.Left :
					ret = tiledata.checkRight(pos, nodeCtl);
					break;
				case vee.Direction.Origin :
					ret = tiledata.checkOrigin(pos, nodeCtl);
					break;
				default :
					break;
			}
		}

		return ret;
	},

	checkTileRough : function (tiledata, pos, nodeCtl, dir) {
		var ret = null;
		if (tiledata && tiledata.check && tiledata.tileInfo) {
			if (dir == vee.Direction.Origin) {
				ret = tiledata.checkOrigin(pos, nodeCtl);
			} else {
				ret = tiledata.checkTop(pos, nodeCtl);
			}
		}

		return ret;
	},

	calcSpeedScaleRate : function (nodeCtl, tileInfo) {
		if (nodeCtl._speedX*tileInfo.slope >= 0) {
			nodeCtl._speedScaleRate = tileInfo.speedScale;
		} else {
			nodeCtl._speedScaleRate = 1;
		}
	},

	checkTileTrigger : function (grid, dir, tiledata, nodeCtl, force) {
		if (nodeCtl && nodeCtl._eleType == game.EleType.Player && nodeCtl._isOver) return;
		if (!force) {
			if (!nodeCtl._triggerObj) return;
		}

		var triggered = false;
		if (force) {
			triggered = true;
		} else {
			switch (dir) {
				case vee.Direction.Origin: {
					var trigger = this.triggerMap.getObject(grid);
					if (trigger) {
						trigger.func(grid, dir);
					}
				}
					break;
				case vee.Direction.Top:
				case vee.Direction.TopLeft:
				case vee.Direction.TopRight:
					if (nodeCtl._speedY > game.Data.playerYTriggerSpeed) {
						dir = vee.Direction.Top;
						triggered = true;
					}
					break;
				case vee.Direction.Bottom:
				case vee.Direction.BottomLeft:
				case vee.Direction.BottomRight:
					if (nodeCtl._moveState == MoveState.Smash){
						dir = vee.Direction.Bottom;
						triggered = true;
					}
					break;
				case vee.Direction.Left:
					if (nodeCtl.isDashing()) {
						triggered = true;
					}
					break;
				case vee.Direction.Right:
					if (nodeCtl.isDashing()) {
						triggered = true;
					}
					break;
				default:
					break;
			}
		}

		if (triggered && tiledata) {
			var trigger = this.triggerMap.getObject(grid);
			var tile = null;
			if (tiledata.tile) {
				tile = tiledata.tile;
			} else if (tiledata.layer) {
				tile = tiledata.layer.getTileAt(grid);
			}

			var runAct = false;
			if (tile) {
				var gid = tiledata.gid;
				if (gid == game.BlockType.DynamicBlock) {
					// For move
					var off = vee.Direction.direction2Point(dir);
					var nextGrid = vee.Utils.pAdd(grid, cc.p(off.x, off.y));
					// 斜向被堵的时候，考虑上下移动
					if (tiledata.layer.getTileGIDAt(nextGrid) != 0 && (off.x * off.y != 0)) {
						nextGrid = vee.Utils.pAdd(grid, cc.p(0, off.y));
					}
					// 斜向，上下被堵的时候，考虑左右移动
					if (tiledata.layer.getTileGIDAt(nextGrid) != 0 && (off.x * off.y != 0)) {
						nextGrid = vee.Utils.pAdd(grid, cc.p(off.x, 0));
					}
					off = vee.Utils.pSub(nextGrid, grid);
					if (!this.map.getObject(nextGrid) && !this.mapex.getObject(nextGrid)) {// tiledata.layer.getTileGIDAt(nextGrid) == 0
						// 1. create new tile
						tiledata.layer.setTileGID(tiledata.gid, nextGrid);
						var newtile = tiledata.layer.getTileAt(nextGrid);
						newtile.setVisible(true);
						this.map.setObject(this.getTileData(nextGrid, tiledata.layer), nextGrid);
						var newTile = tiledata.layer.getTileAt(nextGrid);
						newTile.setPosition(this.getTilePosByGrid(grid));
						newTile.runAction(cc.EaseExponentialOut.create(cc.moveTo(0.2, vee.Utils.pAdd(newTile.getPosition(), cc.p(off.x*TILE_WIDTH, -off.y*TILE_WIDTH)))));
						// 2. remove old tile
						tiledata.layer.removeTileAt(grid);
						this.map.removeObject(grid);
						vee.Audio.playEffect(res.inGame_event_blockMove_mp3);
						EfxHitBlock.create(this.getTilePosCenterByGrid(nextGrid), vee.Direction.revert(dir));
						if (tiledata.layer.isExtra) {
							if (nextGrid.x < tiledata.layer.originX) tiledata.layer.originX = nextGrid.x;
							else if (nextGrid.x > tiledata.layer.maxX) tiledata.layer.maxX = nextGrid.x;
							if (nextGrid.y < tiledata.layer.originY) tiledata.layer.originY = nextGrid.y;
							else if (nextGrid.y > tiledata.layer.maxY) tiledata.layer.maxY = nextGrid.y;
						}
						runAct = true;
						var oPlayer = game.Data.oPlayerCtl;
						if (this.isGridSame(oPlayer._grid, nextGrid)) {
							var diroff = vee.Direction.direction2Point(dir);
							var playerNewGrid = null;
							if (diroff.x < 0) { // left
								playerNewGrid = cc.p(oPlayer._grid.x-1, oPlayer._grid.y);
							} else { // right
								playerNewGrid = cc.p(oPlayer._grid.x+1, oPlayer._grid.y);
							}
							oPlayer.setElePosition(this.getTilePosByGrid(playerNewGrid));
						}
					} else {
						vee.Audio.playEffect(res.inGame_efx_blockUnmove_mp3);
						triggered = false;
					}
				}
			}
			if (triggered && trigger && trigger != "removed") {
				if (trigger._eleType != game.EleType.Trigger) return;
				var moveOffset = vee.Direction.direction2Point(dir);
				trigger.func(grid, dir, tiledata);
			}
		}
	},

	// Other funcs...
	startGame : function (idx, isSavePoint, stageType) {
		vee.Transition.out(res.MapTransition_ccbi, function () {
			vee.PopMgr.closeAll();
			var node = vee.PopMgr.popCCB("res/veeGameLayer.ccbi");
			game.Data.oLyGame.onLoaded();
			game.Data.oLyGame.initStage(idx, isSavePoint, stageType);
		});
	},
	checkTileGridValid : function(grid) {
		return grid.x < this._tmxMapSize.width && grid.x >= 0 && grid.y < this._tmxMapSize.height && grid.y >= 0;
	},
	getTileGridByPos : function(pos) {
		var x = Math.floor(pos.x / this._tmxTileSize.width);
		var y = Math.floor(((this._tmxMapSize.height * this._tmxTileSize.height) - pos.y) / this._tmxTileSize.height);
		return cc.p(x,y);
	},
	getTilePosByGrid : function(grid) {
		if (!grid) return null;
		var x = grid.x * TILE_WIDTH;
		var y = (this._tmxMapSize.height - 1 - grid.y) * TILE_WIDTH;
		return cc.p(x,y);
	},
	getTilePosCenterByGrid : function (grid) {
		var x = grid.x * TILE_WIDTH + TILE_WIDTH_HALF;
		var y = (this._tmxMapSize.height - 1 - grid.y) * TILE_WIDTH + TILE_WIDTH_HALF;
		return cc.p(x,y);
	},
	getTileInfoByGID : function(gid) {
		return game.TileIDInfo["Tile"+gid];
	},
	getGridByDir : function(grid, dir) {
		var dirPoint = vee.Direction.direction2Point(dir);
		grid = vee.Utils.pAdd(grid, dirPoint);
		if (this.checkTileGridValid(grid)) return grid;
		else return null;
	},
	getTileData : function(grid, layer) {
		if (!layer) layer = this._tmxLayer;
		if (!layer || !grid || !this.checkTileGridValid(grid)) return null;

		var gid = layer.getTileGIDAt(grid);
		var tileData = this.getTileDataByGid(gid, grid, layer);

		return tileData;
	},
	getTileDataByGid : function (gid, grid, layer) {
		var tileData = TileData.createTileData(gid);
		if (tileData) {

			var tilePos = this.getTilePosByGrid(grid);
			tileData.setTileDataPos(tilePos);
			tileData.gid   = gid;
			tileData.grid  = cc.p(grid.x, grid.y);
			tileData.layer = layer;
			tileData.init();
			return tileData;
		} else {
			return null;
		}
	},

	getBlockTileData : function (grid, layer) {
		var tilePos = this.getTilePosByGrid(grid);
		var gid = layer.getTileGIDAt(grid);
		var tileData = TileData.createTileData(1);
		tileData.setTileDataPos(tilePos);
		tileData.gid   = 1;
		tileData.grid  = cc.p(grid.x, grid.y);
		if (layer) tileData.layer = layer;
		tileData.init();
		return tileData;
	},

	getTileInfoAt : function (grid, layer) {
		if (!layer) layer = this._tmxLayer;
		if (!layer || !grid || !this.checkTileGridValid(grid)) return null;
		var ti = this.getTileInfoByGID(layer.getTileGIDAt(grid));
		return ti;
	},

	getTileDataByDir : function(grid, dir) {
		return this.map.getObject(this.getGridByDir(grid, dir));
	},

	getCameraOffset : function (dir, isFreezeX, isFreezeY, dt) {
		if (!dt) dt = 0.02;
		if (!isFreezeX) {
			if (game.Data.cameraXrevived) {
				if (dir == vee.Direction.Right) {
					game.Data.cameraXPos -= (game.Data.cameraXMoveSpeed*dt);
					if (game.Data.cameraXPos < -game.Data.cameraXPosLimit) {
						game.Data.cameraXPos = -game.Data.cameraXPosLimit;
					}
				} else {
					game.Data.cameraXPos += (game.Data.cameraXMoveSpeed*dt);
					if (game.Data.cameraXPos > game.Data.cameraXPosLimit) {
						game.Data.cameraXPos = game.Data.cameraXPosLimit;
					}
				}
			} else {
				if (dir == vee.Direction.Right) {
					if (game.Data.cameraXPos < -game.Data.cameraXPosLimit) {
						game.Data.cameraXPos += (game.Data.cameraXMoveSpeed*dt)*4;
					} else {
						game.Data.cameraXPos -= (game.Data.cameraXMoveSpeed*dt)*4;
						if (game.Data.cameraXPos < -game.Data.cameraXPosLimit) {
							game.Data.cameraXPos = -game.Data.cameraXPosLimit;
							game.Data.cameraXrevived = true;
						}
					}
				} else {
					if (game.Data.cameraXPos > game.Data.cameraXPosLimit) {
						game.Data.cameraXPos -= (game.Data.cameraXMoveSpeed*dt)*4;
					} else {
						game.Data.cameraXPos += (game.Data.cameraXMoveSpeed*dt)*4;
						if (game.Data.cameraXPos > game.Data.cameraXPosLimit) {
							game.Data.cameraXPos = game.Data.cameraXPosLimit;
							game.Data.cameraXrevived = true;
						}
					}
				}
			}
		}

		var spdY = game.Data.oPlayerCtl._speedY;
		if (isFreezeY) {
			cc.log("")
			spdY = 0;
		}

		if (game.Data.cameraYrevived) {
			if (spdY == 0 || !game.Data.isEnableCameraYOff) {
				if (game.Data.cameraYPos > game.Data.cameraYPosOff) {
					game.Data.cameraYPos -= game.Data.cameraYRestoreSpeed*dt;
					if (game.Data.cameraYPos < game.Data.cameraYPosOff) {
						game.Data.cameraYPos = game.Data.cameraYPosOff;
					}
				} else if (game.Data.cameraYPos < game.Data.cameraYPosOff) {
					game.Data.cameraYPos += game.Data.cameraYRestoreSpeed*dt;
					if (game.Data.cameraYPos > game.Data.cameraYPosOff) {
						game.Data.cameraYPos = game.Data.cameraYPosOff;
					}
				}
			} else {
				game.Data.cameraYPos -= game.Data.oPlayerCtl._offsetY*game.Data.cameraYMoveRate;
//				cc.log("6666666666666  offsetY====%d", game.Data.oPlayerCtl._offsetY);
				if (game.Data.cameraYPos > game.Data.cameraYPosLimit) {
					// cc.log("77777777777777");
					game.Data.cameraYPos = game.Data.cameraYPosLimit;
				} else if (game.Data.cameraYPos < -game.Data.cameraYPosLimit) {
					// cc.log("8888888888888");
					game.Data.cameraYPos = -game.Data.cameraYPosLimit;
				}
			}
			if (game.Data.cameraRestoreY) {
//				cc.log("99999999999999");
				var offY = game.Data.cameraYPos - game.Data.cameraYPosOff;
				if (Math.abs(offY) > 2) {
					offY = offY > 0 ? 2 : -2;
					game.Data.cameraYPos -= offY;
				} else {
					game.Data.cameraRestoreY = false;
				}
			}
		} else {
			// cc.log("zzzzzzzzz 1111111111");
			if (game.Data.cameraYPos > game.Data.cameraYPosOff) {
				// cc.log("zzzzzzzzz 22222222222");
				game.Data.cameraYPos -= (game.Data.cameraXMoveSpeed*dt)*2;
				if (game.Data.cameraYPos < game.Data.cameraYPosOff) {
					// cc.log("zzzzzzzzz 3333333333");
					game.Data.cameraYPos = game.Data.cameraYPosOff;
					game.Data.cameraYrevived = true;
				}
			} else {
				game.Data.cameraYPos += (game.Data.cameraXMoveSpeed*dt)*2;
				// cc.log("zzzzzzzzz 444444444444");
				if (game.Data.cameraYPos > game.Data.cameraYPosOff) {
					// cc.log("zzzzzzzzz 55555555555");
					game.Data.cameraYPos = game.Data.cameraYPosOff;
					game.Data.cameraYrevived = true;
				}
			}
		}


		return cc.p(568 + game.Data.cameraXPos, 384 + game.Data.cameraYPos);
	},
	getCameraScaleRate : function(isScaleUp) {
		if (isScaleUp) {
			game.Data.cameraScaleRate -= game.Data.cameraScaleSpeed;
			if (game.Data.cameraScaleRate < game.Data.cameraScaleLimitMAX) {
				game.Data.cameraScaleRate = game.Data.cameraScaleLimitMAX;
			}
		} else {
			game.Data.cameraScaleRate += game.Data.cameraScaleSpeed;
			game.Data.cameraScaleRate += game.Data.cameraScaleSpeed;
			if (game.Data.cameraScaleRate > game.Data.cameraScaleLimitMIN) {
				game.Data.cameraScaleRate = game.Data.cameraScaleLimitMIN;
			}
		}
		return game.Data.cameraScaleRate;
	},
	getCameraPosByGrid : function (grid) {
		var targetPos  = game.Logic.getTilePosCenterByGrid(grid);
		return cc.p((568-targetPos.x), (384-targetPos.y));
	},
	getMoveDirectionBySpeedX : function(speedX) {
		var dir = null;
		if (speedX > 0) dir = vee.Direction.Right;
		else if (speedX < 0) dir = vee.Direction.Left;
		else dir = vee.Direction.Origin;
		return dir;
	},

	showTipsLayer : function () {
		if (this._tmxLayerTips) {
			this._tmxLayerTips.setVisible(true);
		}
	},

	addExtraTileToMap : function (extraLayer) {
		for (var x = extraLayer.originX; x <= extraLayer.maxX; ++x) {
			for (var y = extraLayer.originY; y <= extraLayer.maxY; ++y) {
				var td = game.Logic.getTileData(cc.p(x,y), extraLayer);
				if (td && this.isExObjType(td.tileInfo.type)) {
					this.mapex.setObject(td, cc.p(x,y));
				} else if (td) {
					this.map.setObject(td, cc.p(x,y));
					this.mapex.setObject(null, cc.p(x,y));
					var obj = this.objMap.getObject(cc.p(x,y));
					if (obj) {
						obj.disappear();
					}
				}
				game.Data.addPerformingSkillBoxes(cc.p(x,y), extraLayer);

			}
		}
	},

	triggerTileCallback : function (td, nodeCtl, dir) {
		if (td) {
			return td.collide(nodeCtl, dir);
		}
	},

	setBomb : function (targetGrid) {
		game.Logic._tmxLayer.setTileGID(game.BlockType.BombBlock, targetGrid);
		var bombTd = game.Logic.getTileData(targetGrid, game.Logic._tmxLayer);
		bombTd.isPlayerBomb = true;
		var tile = game.Logic._tmxLayer.getTileAt(targetGrid);
		tile.setVisible(false);
		game.Logic.map.setObject(bombTd, targetGrid);
	},

	isGridSame : function (g1, g2) {
		return g1.x == g2.x && g1.y == g2.y;
	},

	isBlock : function (td) {
		if (td && td.tileInfo && (
			td.tileInfo.type == game.ObjectType.Block
			|| td.tileInfo.type == game.ObjectType.Slope
			|| td.tileInfo.type == game.ObjectType.BlockStab
			|| td.tileInfo.type == game.ObjectType.BlockHurt
			|| td.tileInfo.type == game.ObjectType.BlockBreakable
			|| td.tileInfo.type == game.ObjectType.BlockBomb
			|| td.tileInfo.type == game.ObjectType.BlockScale))
		{
			return true;
		} else {
			return false;
		}
	},

	isHurtBlock : function (gid) {
		if (gid == 72 || gid == 73 || gid == 71)
		{
			return true;
		}
		else
		{
			return false;
		}
	},

	isBreakableBlock : function (gid) {
		if (gid == 62 || gid == 66 || gid == 69
			|| gid == 70
			|| gid == 137
			|| gid == 138
			|| gid == 139
			|| gid == 140) {
			return true;
		} else {
			return false;
		}
	},

	isExObjType : function (objtype) {
		return (objtype >= 0 && objtype <= 99) || (objtype >= 100 && objtype <= 200) || objtype == 2000;
	},

	// Global efx...
	showGetCoinEfx : function (pos) {
		EfxGetCoin.show(pos);
	},

	// Auxiliary funcs...
	drawRectByGrid : function(grid) {
		game.Data.oLyGame.drawNode.drawRect(
			cc.p(grid.x * TILE_WIDTH, (game.Logic._tmxMapSize.height - 1 - grid.y) * TILE_WIDTH),
			cc.p(grid.x * TILE_WIDTH + TILE_WIDTH, (game.Logic._tmxMapSize.height - 1 - grid.y) * TILE_WIDTH + TILE_WIDTH)
		);
	},

	drawRect : function (rect) {
		game.Data.oLyGame.drawNode.drawRect(
			cc.p(rect.x, rect.y),
			cc.p(rect.x + rect.width, rect.y + rect.height),
			cc.RED
		);
	},

	// will not remove blocks, only remove enemy and item tile info.
	removeMapExObjectByGrid : function (grid) {
		var tiledata = this.mapex.getObject(grid);
		if (tiledata) {
//			tiledata.layer.removeTileAt(grid);
//			this.map.removeObject(grid);
			this.mapex.removeObject(grid);
		}
	},
	
	setForParkour : function (isParkour) {

		if(isParkour){
			game.Data.stageType = game.StageType.Parkour;
			game.Data.oLyGame.hideControlButton(LyGame.ControlButtonType.ActionButton | LyGame.ControlButtonType.MoveButton | LyGame.ControlButtonType.JumpButton);
		}
		else{
			game.Data.stageType = game.StageType.Normal;
			if(!Story.isShowStory) {
				game.Data.oLyGame.showControlButton(LyGame.ControlButtonType.MoveButton);
			}
		}

		if(game.Data.oLyGame.bgCtl) {
			game.Data.oLyGame.bgCtl._moveRateX = isParkour ? 1.5 : 0.5;
		}
	}
};
