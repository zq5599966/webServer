var vee = vee = vee || {};



vee.GestureController = cc.Class.extend({
	_target : null,
	_touchSource : null,
	_isTouchBegin : false,
	_beginPoint : null,
	_lastPoint : null,
	_lastOffset : null,
	_timeBegin : null,
	_touchOffset : null,
	_eventListenser : null,
	_force : null,

	_antiFix : false,
	_normalWidth : 0,

	unregister : function(){
		this._target = null;
		if (this._eventListenser) {
			cc.eventManager.removeListener(this._eventListenser);
			this._eventListenser = null;
		}
		this._isTouchBegin = false;
	},

	setSwallowTouches : function(v){
		if (this._eventListenser) {
			this._eventListenser.setSwallowTouches(false);
		}
	},

	/**
	 *
	 * @param layer {cc.Layer}
	 * @param target {Object} target 需要回调方法才可以使用
     * @param swallowTouches {boolean} target 需要回调方法才可以使用
	 */
	register : function(layer, target, swallowTouches){
		this.unregister();
		this._target = target;
		layer.touchHandler = this;

        if (swallowTouches === undefined){
            swallowTouches = true;
        }
		this._swallow = swallowTouches;

		var listener = cc.EventListener.create({
			event: cc.EventListener.TOUCH_ONE_BY_ONE,
			swallowTouches: swallowTouches,
			onTouchBegan: this._handleTouchBegan,
			onTouchMoved: this._handleTouchMoved,
			onTouchEnded: this._handleTouchEnded,
			onTouchCancelled : this._handleTouchEnded
		});

		this._eventListenser = listener;
		cc.eventManager.addListener(listener, layer);

		var winSize = vee.PopMgr.winSize;
		this._antiFix = false;
		this._normalWidth = winSize.width-100;
		this._enabled = true;
	},

	/**
	 * 针对 iPhone 设备，iOS 对屏幕边缘做了点击修正，使用本方法取消苹果系统自带的修正
	 * @param pos
	 */
	setAntiFixEnabled : function(e) {
		if (e) {
			//only iPhone partail mode needs antiFix
			var winSize = vee.PopMgr.winSize;
			this._antiFix = (vee.Utils.getObjByPlatform(true, false, false) && (winSize.height > winSize.width) && (winSize.width/winSize.height <= 0.7));
		} else {
			this._antiFix = false;
		}
	},

	/**
	 * 针对 iPhone 设备，iOS 对屏幕边缘做了点击修正，使用本方法取消苹果系统自带的修正
	 * @param pos
	 */
	getAntiFixPosition : function(pos){
		if (this._antiFix && pos.x > this._normalWidth) {
			var offset = pos.x - this._normalWidth;
			var x = pos.x - offset*(1-offset/100)/4 - 10;
			return cc.p(x, pos.y);
		} else return pos;
	},

	getBeginPoint : function() {
		var p = (this._antiFix ? this.getAntiFixPosition(this._beginPoint) : this._beginPoint);
		var o = this._touchOffset;
		return cc.p(p.x-o.x, p.y- o.y);
	},

	getBeginPointInWorld : function() {
		return (this._antiFix ? this.getAntiFixPosition(this._beginPoint) : this._beginPoint);
	},

	getLastPoint : function() {
		var p = (this._antiFix ? this.getAntiFixPosition(this._lastPoint) : this._lastPoint);
		var o = this._touchOffset;
		return cc.p(p.x-o.x, p.y- o.y);
	},

	getLastOffset : function() {
		return this._lastOffset;
	},

	getLastPointInWorld : function() {
		return (this._antiFix ? this.getAntiFixPosition(this._lastPoint) : this._lastPoint);
	},

	getDuration : function() {
		var time = new Date();
		return time - this._timeBegin;
	},

	getForce : function () {
		return this._force;
	},

	_handleTouchBegan : function(touch, event) {

		if(!vee.GestureController.checkHasCanTouch(touch)) return false;

		var layer = event.getCurrentTarget();
		var g = layer.touchHandler;
		g._touchOffset = layer.convertToWorldSpace(cc.p(0,0));
		g._isTouchBegin = true;
		g._beginPoint = touch.getLocation();
		g._lastPoint = g._beginPoint;
		g._lastOffset = cc.p(0,0);
		g._timeBegin = new Date();
		if (touch.getTouchForce) {
			g._force = touch.getTouchForce();
		}
		return g._onGestureBegin();
	},

	_handleTouchMoved : function(touch, event) {

		if(!vee.GestureController.checkHasCanTouch(touch)) return;

		var g = event.getCurrentTarget().touchHandler;
		var p = touch.getLocation();
		g._lastOffset = cc.p(p.x-g._lastPoint.x, p.y-g._lastPoint.y);
		if (touch.getTouchForce) {
			g._force = touch.getTouchForce();
		}
		g._onGestureMove(p);
		g._onGestureDrag(p);
		g._lastPoint = p;
		return true;
	},

	_handleTouchEnded : function(touch, event) {

		if(vee.GestureController.checkHasCanTouch(touch)){
			vee.GestureController.singleTouchCacheId = null;
		}

		var g = event.getCurrentTarget().touchHandler;
		var p = touch.getLocation();
		if (touch.getTouchForce) {
			g._force = touch.getTouchForce();
		}
		g._onGestureMove(p);
		g._onGestureDrag(p);
		var distance = vee.Utils.distanceBetweenPoints(g._beginPoint, p);
		if (distance < 50) g._onGestureTap(distance);
		else if (distance >= 50 && (distance / g.getDuration() > 0.5)) {
			g._onGestureSwipe(p, distance);
		}
		g._onGestureLeave();
		g._isTouchBegin = false;
		return true;
	},

	_enabled : true,
	setEnabled : function (v) {
		this._enabled = v;
	},

	_onGestureBegin : function(){
		if (!this._enabled) return false;
		if (this._target && this._target.onGestureBegin) {
			return (this._target.onGestureBegin(this) ? true : false);
		}
		return true;
	},

	_onGestureTap : function(distance){
		if (this._target && this._target.onGestureTap) {
			this._target.onGestureTap(this, distance);
		}
	},

	_onGestureMove : function(p){
		if (this._target && this._target.onGestureMove) {
			this._target.onGestureMove(this, this._lastOffset);
		}
	},

	_onGestureDrag : function(p){
		if (this._target && this._target.onGestureDrag) {
			var fp = this._beginPoint;
			this._target.onGestureDrag(this, cc.p(p.x-fp.x, p.y-fp.y));
		}
	},

	_onGestureSwipe : function(p, distance){
		if (this._target && this._target.onGestureSwipe) {
			var angle = vee.Utils.angleOfLine(this._beginPoint, p);
			this._target.onGestureSwipe(this, angle, distance);
		}
	},
	
	_onGestureLeave : function(){
		if (this._target && this._target.onGestureLeave) {
			this._target.onGestureLeave(this);
		}
	}
});

/**
 * 注册接收 Gesture 事件
 * delegate 只需要实现下列方法即可在 Gesture 出现的时候被回调:
 //onGestureTap (gestureController, distance) {}
 //onGestureMove (gestureController, offset) {}
 //onGestureDrag (gestureController, offset) {}
 //onGestureSwipe (gestureController, angle, distance) {}
 * @param {cc.Layer} touchSource
 * @param {vee.GestureControllerDelegate} delegate 可以单独实现上面的回调方法, 也可以直接 extend vee.GestureControllerDelegate
 * @param {boolean} swallow whether stop event pass to lower layer.
 * @return {vee.GestureController}
 */
vee.GestureController.registerController = function(touchSource, delegate, swallow) {
	var ctl = new vee.GestureController();
	ctl.register(touchSource, delegate, swallow);
	delegate.gestureController = ctl;
	return ctl;
};

//只允许屏幕上一个触摸点有效
vee.GestureController.isSingleTouchMode = false;
vee.GestureController.singleTouchCacheId = null;
vee.GestureController.checkHasCanTouch = function (touch) {
	if(vee.GestureController.isSingleTouchMode){
		var touchId = touch.getID();
		if(vee.GestureController.singleTouchCacheId == null || vee.GestureController.singleTouchCacheId == touchId){
			vee.GestureController.singleTouchCacheId = touchId;
			return true;
		}
		return false;
	}
	return true;
};

vee.GestureControllerDelegate = vee.Class.extend({
	/**
	 * @param {vee.GestureController} gestureController
	 * @param {Number} distance, 整个 Tap 的过程造成的 touch 移动距离
	 */
	onGestureTap : function(gestureController, distance) {},
	/**
	 * @param {vee.GestureController} gestureController
	 * @param {cc.Point} offset, 与上一次 move 之间的距离
	 */
	onGestureMove : function(gestureController, offset) {},

	/**
	 * @param {vee.GestureController} gestureController
	 * @param {cc.Point} offset, 与第一次 touch 之间的距离
	 */
	onGestureDrag : function(gestureController, offset) {},

	/**
	 *
	 * @param {vee.GestureController} gestureController
	 * @param {Number} angle 划动的角度 12点方向为 0度
	 * @param {Number} distance 划动的距离
	 */
	onGestureSwipe : function(gestureController, angle, distance) {},

	onGestureBegin : function(gestureController) {
		return true;
	},

	onGestureLeave : function(gestureController) {}
});
