/**
 * Created with AppCode.
 * User: yop
 * Date: 15/9/18
 * Time: 下午3:28
 * To change this template use File | Settings | File Templates.
 */


var TileTransition = EfxTileMap.extend({
	_callback : null,

	_in : function(callback){
		this._callback = callback;
		this.forEachTile(function (tile) {
			tile.setColor(cc.color.BLACK);
		});
		var center = cc.p(parseInt(this._map.mapSize.width/2), parseInt(this._map.mapSize.height/2));
		this.playEffect(center, cc.color.BLACK, this.delayPointRandom, this.transFadeOut, this.onInCompleted.bind(this));
	},

	_out : function(callback){
		this._callback = callback;
		this.forEachTile(function (tile) {
			tile.setColor(cc.color.BLACK);
			tile.rootNode.setOpacity(0);
		});
		var center = cc.p(parseInt(this._map.mapSize.width/2), parseInt(this._map.mapSize.height/2));
		this.playEffect(center, cc.color.BLACK, this.delayPointRandom, this.transFadeIn, this.onOutCompleted.bind(this));
	},

	onInCompleted : function() {
		this.rootNode.removeFromParent();
		this.onOutCompleted();
	},

	onOutCompleted : function() {
		if (this._callback) {
			vee.Utils.scheduleOnce(this._callback, 0.03);
		}
	},


	delayPointRandom : function(tile, input){
		var offset = vee.Utils.pSub(tile.getGrid(), input);
		var delay = (offset.x * offset.x + offset.y * offset.y + vee.Utils.randomInt(-20, 20))*0.001;
		return Math.min(Math.max(delay, 0), 0.3);
	},

	transFadeIn : function(data, input) {
		return cc.fadeTo(0, 255);
	},

	transFadeOut : function(data, input) {
		return cc.fadeTo(0, 0);
	}
});