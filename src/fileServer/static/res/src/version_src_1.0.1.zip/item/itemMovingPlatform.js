/**
 * Created with AppCode.
 * User: WanThirty
 * Date: 15/7/2
 * Time: 下午1:51
 * To change this template use File | Settings | File Templates.
 */

var ItemMovingPlatform = Item.extend({
	_type : game.ObjectType.MovingPlatform,
	_checkPosWidth      : 0,
	_checkPosHeight     : 0,
	nodePlatform        : null,
	_createByPlatform   : false,
	_createMapPointAndPlatform : true,
	_backToOrigin       : false,
	_w : null,
	_h : null,
	_startPos : null,

	bornWithPos : function(pos) {
		this._lastPos = pos;
		this._container.stopAllActions();
		game.Data.registerUpdateObj(this);
		var mapConfig = game.Logic.configMap.getObject(this._gridInMap);
		if (!mapConfig) {
			this.errorInInit();
			return;
		}
		var arrPosStr = mapConfig.name.split(";");

		for (var i = 0; i < 2; ++i) {
			var strBack = arrPosStr[arrPosStr.length-1];
			var arrBack = strBack.split(",");
			if (arrBack.length == 1) {
				if (arrBack == "X") {
					this._createMapPointAndPlatform = false;
					arrPosStr.pop();
				} else if (arrBack == "R") {
					this._backToOrigin = true;
					arrPosStr.pop();
				}
			}
		}

		var w = mapConfig.width || 3;
		var h = mapConfig.height || 1;
		this.nodeBox.setContentSize(cc.size((w)*game.Data.tileSizeWidth ,(h+1)*game.Data.tileSizeWidth));

		if (!(w == this._w && h == this._h)) {
			this.nodePlatform.removeAllChildren();
			this._w = w;
			this._w = h;
			var left   = -TILE_WIDTH*w/2 + TILE_WIDTH_HALF;
			var bottom = -TILE_WIDTH*h/2 + TILE_WIDTH_HALF;

			var fileName;
			if (game.LevelData.selectedCategory) {
				var idx = game.LevelData.selectedCategory.idx + 1;
				if (idx > 100) idx -= 100;
				fileName = "res/block_move_"+idx+".png";
				if(null == res["block_move_" + idx + "_png"]){
					fileName = "res/block_move_1.png";
				}
			} else {
				fileName = "res/block_move_1.png";
			}

			for (var i = 0; i < w; ++i) {
				for (var j = 0; j < h; ++j) {
					var spr = new cc.Sprite(fileName);
					spr.setPosition(cc.p(left + i*TILE_WIDTH, bottom + j*TILE_WIDTH));
					this.nodePlatform.addChild(spr);
				}
			}
		}

		var texSize = cc.size((w)*game.Data.tileSizeWidth ,(h)*game.Data.tileSizeWidth);
		this.resetBoxInfo();
		this._checkPosWidth = this.boxSize.width/2;
		this._checkPosHeight = this.boxSize.height/2;

		var posOff = cc.p(texSize.width/2-game.Data.tileSizeWidth/2, texSize.height/2-game.Data.tileSizeWidth/2);
		var elePos = vee.Utils.pAdd(pos, posOff);
		this.setElePosition(elePos);
		this._startPos = elePos;

		// Run repeat action
		var arrAct = [];
		var arrPos = [];
		var posPrev = elePos;
		var posNext = null;
		var lastPos = cc.p(this._gridInMap.x, this._gridInMap.y);
		for (var i = 0, l = arrPosStr.length; i < l; ++i) {
			var str = arrPosStr[i];
			var gridNext = game.Data.getPointFromString1(str);
			gridNext = vee.Utils.pAdd(lastPos, gridNext);
			var created = false;
			var tdForCheck = game.Logic.mapex.getObject(gridNext);
			if (!this._createByPlatform && tdForCheck && !game.Logic.isGridSame(gridNext, this._gridInMap)) {
				// Create linked platform
				if (tdForCheck.gid == game.BlockType.MovingPlatform) {
					cc.log('platform : creating linked platform at: ' + gridNext.x + ', ' + gridNext.y);
					game.Logic.createItemByGrid(gridNext, true);
					created = true;
				}
			}
			if ((this._createMapPointAndPlatform || !created) && this.shouldCreateMapPoint(gridNext)) {
				cc.log('platform : creating path at: ' + gridNext.x + ', ' + gridNext.y);
				posNext = vee.Utils.pAdd(game.Logic.getTilePosCenterByGrid(gridNext), posOff);
				arrAct.push(cc.moveTo(vee.Utils.distanceBetweenPoints(posPrev, posNext)/100, posNext));
				arrPos.push(cc.p(posNext.x, posNext.y));
				posPrev = posNext;
			}
			lastPos = gridNext;
		}
		if (this._backToOrigin) {
			arrAct.push( cc.callFunc(function () {
				this.setElePosition(this._startPos);
				if (this._isGetPlayer) {
					this._isGetPlayer = false;
					game.Data.oPlayerCtl.jumpSign = false;
				}
				game.Data.removeGrabbedPlatform(this);
			}.bind(this)) );
		} else if (!game.Logic.isGridSame(gridNext, this._gridInMap)) {
			arrPos = arrPos.reverse();
			arrPos.push(cc.p(elePos.x, elePos.y));
			arrPos.shift();
			for (var i = 0, l = arrPos.length; i < l; ++i) {
				posNext = arrPos[i];
				arrAct.push( cc.moveTo(vee.Utils.distanceBetweenPoints(posPrev, posNext)/100, posNext));
				posPrev = posNext;
			}
		}

		this._container.runAction(cc.repeat(cc.sequence(arrAct), 9999));
	},

	errorInInit : function () {
		cc.log("error in init item moving platform!");
		this._container.removeFromParent();
	},

	shouldCreateMapPoint : function (grid) {
		if (game.Logic.isGridSame(grid, this._gridInMap)) return true;
		var mapConfig = game.Logic.configMap.getObject(grid);
		if (!mapConfig) return true;
		if (!this._createMapPointAndPlatform) return false;
		var arrPosStr = mapConfig.name.split(";");
		var strBack = arrPosStr[arrPosStr.length-1];
		var arrBack = strBack.split(",");
		if (arrBack.length == 1) {
			return false;
		} else {
			return true;
		}
	},

	_lastPos : null,
	_dt : null,
	_isGetPlayer : false,
	updatePos : function(dt) {
		this._dt = dt;
		var oPlayer = game.Data.oPlayerCtl;
		var posPlayer = oPlayer._pos;
		var posPlatform = this.getElePosition();

		if (posPlayer.x < posPlatform.x - this._checkPosWidth || posPlayer.x > posPlatform.x + this._checkPosWidth || oPlayer._speedY > 0) {
			// check X red zone
			if (this._isGetPlayer) oPlayer.jumpSign = false;
			this._isGetPlayer = false;
			game.Data.removeGrabbedPlatform(this);
		} else if (this._isGetPlayer) {
			// let player move on platform
			this.pushTo(vee.Direction.Top, posPlayer, this.getEleRect(), oPlayer);
		} else {
			// check Y red zone
			// cast player position at next frame
			var castSpeedY = oPlayer._speedY;
			var castDt = 0.02;
			castSpeedY += (oPlayer._accY + (oPlayer._jumpSpeedProtect ? 0 : game.Data.G))*castDt;
			if (oPlayer.isLimitY) castSpeedY =  (castSpeedY < game.Data.playerYSpeedLimit ? game.Data.playerYSpeedLimit : castSpeedY);
			// calc safe postion...
			var posNextY = posPlayer.y + castSpeedY*castDt;
			var checkHeight = this.getCheckLine(posPlatform.y);
			var checkHeightPrev = this.getCheckLine(this._lastPos.y);
			if ( oPlayer._speedY <= 0
				&&
				((posNextY <= checkHeight && posPlayer.y >= checkHeight)
				|| (posNextY <= checkHeightPrev && posPlayer.y >= checkHeightPrev)) ) {
				this._isGetPlayer = true;
				game.Data.addGrabbedPlatform(this);
				oPlayer.downToBarrier();
				oPlayer.setJumping(false);
				oPlayer._speedY = 0;
				oPlayer.jumpSign = true;
				this.pushTo(vee.Direction.Top, posPlayer, this.getEleRect(), oPlayer);
			} else {
				this._isGetPlayer = false;
				oPlayer.jumpSign = false;
				game.Data.removeGrabbedPlatform(this);
			}
		}

		this._lastPos = posPlatform;
		this.afterUpdate(dt);
	},

	pushTo : function (dir, posPlayer, rectPlatform, nodeCtl) {
		if (nodeCtl._isSmashing) {
			nodeCtl._speedY = 0;
		}
		nodeCtl.isUpdateY = false;
		nodeCtl.needUpdateState = false;
		nodeCtl.updateState();
		var posOff = this.getPosOff();
		nodeCtl.setElePosition(cc.p(posPlayer.x + posOff.x, rectPlatform.y + rectPlatform.height));
		this.playerOnTop();
	},

	getPosOff : function() {
		return vee.Utils.pSub(this._container.getPosition(), this._lastPos);
	},

	getCheckLine : function (y) {
		return y+this._checkPosHeight;
	},

	playerOnTop : function () {},

	afterUpdate : function () {},

	getInhaleController : function () {
		return null;
	},

	die : function () {
		game.Data.removeUpdateObj(this);
	}
});